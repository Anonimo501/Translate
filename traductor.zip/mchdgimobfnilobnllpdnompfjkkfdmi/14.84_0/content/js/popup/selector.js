var LIMIT=5000;
var SLG_DARK="invert(95%)";
var LIMITsplit=150;
var SLG_SETINTERVAL_ST = 0;
var TTSDetLang="";
var DetLang="";
var TempDetLang4History="";
var DetLangName="";
var BackDetLang="en";
var SLG_no_detect="";
var CATCHED_TEXT=0;
var CLOSER=0;
var ListProviders="";
var SLG_DETECT="";
var SLG_TEMPKEYSTRING="";
var SLG_KEYCOUNT={ length: 0 };
var SLG_KEYSTRING = "";
var SLG_WRONGLANGUAGEDETECTED = 0;
var SLG_TRANS_TEXT = "";
var ALLvoices = FExtension.bg.ImTranslatorBG.ALLvoices;
var GTTS_length=200;
var BACK_VIEW=FExtension.store.get("SLG_BACK_VIEW");
var TTSbackupLangs="zh,zt,en,de,hi,id,it,nl,pl,es,ru,ja,ko,fr,pt";
var globaltheQ="";
var synth = window.speechSynthesis;
var TheVolume=10;
var TheNewText = "";
var TheNewLang = "";
var TheNewBox = "";
var FirstLoop = 0;
var SLG_EVENT="";
var YSID = "";
var YSIDold = "";
var YSIDstatus = false;

var BOXCONTENT = "";
var GLOBAL_WIDTH = 465;
var GLOBAL_HEIGHT = 670;
var WINDOW_TYPE = 0;
var EXC = 488; // VK exception 

GLOB_BACK_HEIGHT=118;
GLOB_BOX = 1;

'use strict';




var SLG_BaseLanguages = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLanguages');
var SLG_Languages = CUSTOM_LANGS(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLanguages'));
var SLG_LanguagesExt = CUSTOM_LANGS(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLanguagesNew'));
var SLG_FAV_LANGS_IMT = FExtension.store.get("SLG_FAV_LANGS_IMT");
var SLG_FAV_MAX = FExtension.store.get("SLG_FAV_MAX");
var SLG_FAV_START = FExtension.store.get("SLG_FAV_START");


window.addEventListener('resize', function(e){ 
	GLOBAL_WIDTH = window.innerWidth; SLG_GLOBAL_RESIZER(); 
	REMOTE_Voice_Close(e);
}, false);

var SLWINDOW = setInterval(function(){
	localStorage["WINDOW_TOP"]=window.screenTop;
	localStorage["WINDOW_LEFT"]=window.screenLeft;
},1500);


if(localStorage["SLG_other_gt"]=="1"){   
	LISTofPR = FExtension.store.get("SLG_ALL_PROVIDERS_GT").split(",");
} else LISTofPR[0]="Google";

for (var SLG_I = 0; SLG_I < LISTofPR.length; SLG_I++){
    switch(LISTofPR[SLG_I]){
	case "Google": LISTofPRpairs[SLG_I]=LISTofLANGsets[0];break;
	case "Microsoft": LISTofPRpairs[SLG_I]=LISTofLANGsets[1];break;
	case "Translator": LISTofPRpairs[SLG_I]=LISTofLANGsets[2];break;
	case "Yandex": LISTofPRpairs[SLG_I]=LISTofLANGsets[3];break;
    }	
}


var BASELANGS =    new Array ();
var SLG_BaseLnum = SLG_BaseLanguages.split(",");
for(var i = 0; i < SLG_BaseLnum.length; i++) BASELANGS.push(SLG_BaseLnum[i]);


var LANGS =    new Array ();
var SLG_Lnum = SLG_Languages.split(",");
for(var i = 0; i < SLG_Lnum.length; i++) LANGS.push(SLG_Lnum[i]);

var LANGSext = new Array ();
var SLG_LnumExt = SLG_LanguagesExt.split(",");
for(var i = 0; i < SLG_LnumExt.length; i++) LANGSext.push(SLG_LnumExt[i]);

(function(){document.addEventListener("mousedown",function(){
 try{
   var id = event.target.id;
   if(GEBI("SLG_myRange")){
	if(SLG_getTEMP("TTSvolume")==null || SLG_getTEMP("TTSvolume")=="undefined" || SLG_getTEMP("TTSvolume")=="") SLG_setTEMP("TTSvolume","5");
	else SLG_setTEMP("TTSvolume",GEBI("SLG_myRange").value);
	if(GEBI("SLG_myRange").value==0) GEBI("SLG_volume").className="SLG_novolume";
	else GEBI("SLG_volume").className="SLG_volume";
	TheVolume = GEBI("SLG_myRange").value;
   }	
   if(id == "SLG_controls"){
	//var FirstLoop = 0;
	PlayPause("SLG_controls", event);
   }	
   if(id == "SLG_volume"){
	synth.cancel();
        if(GEBI(id).className=="SLG_novolume") {
		GEBI("SLG_myRange").value = 5;
		GEBI("SLG_volume").className="SLG_volume";
	} else { 
		GEBI("SLG_myRange").value = 0;
		GEBI("SLG_volume").className="SLG_novolume";
	}
	SLG_setTEMP("TTSvolume",GEBI("SLG_myRange").value);
	Start_GOOGLE_TTS_backup();

   }	
   if(id == "SLG_myRange"){
	synth.cancel();
	if(GEBI("SLG_myRange").value>0)	GEBI("SLG_volume").className="SLG_volume";
	else 	GEBI("SLG_volume").className="SLG_novolume";
    	setTimeout(function(){
		SLG_setTEMP("TTSvolume",GEBI("SLG_myRange").value);
		Start_GOOGLE_TTS_backup();
        },500);

   }
 }catch(ext){}
},!1);} )();

document.onmousedown=function(event){
	SLG_EVENT=event;
};


(function(){
	var y=GEBI("SLG_backbox");
	y.addEventListener("click",function(){
                REMOTE_Voice_Close();
		//Switch();
		//SET_PROV(1);
		if(GEBI("SLG_backbox").checked==true){
			LOADBackTranslate("");			
		}
		if(BACK_VIEW==1) SetBackWindow(); 
		else SetBackWindow2(); 
	},!1);
})();

SLG_Tabs_Maker();

for(I=0; I<LISTofPR.length; I++){
   (function(){GEBI("SLG_P"+I).addEventListener("click",function(){SLG_Tabs_Settler();},!1);} )();
}



function SLG_Tabs_Maker(){
  for(var I=0; I<LISTofPR.length; I++){
	  var OB = document.createElement('div');
	  var id = document.createAttribute("id");
	  id.value = "SLG_P"+I;
          OB.setAttributeNode(id);
	  var cl = document.createAttribute("class");
	  cl.value = "SLG_LABLE";
       	  OB.setAttributeNode(cl);
	  var tl = document.createAttribute("title");
	  tl.value = LISTofPR[I];
       	  OB.setAttributeNode(tl);
	  var st = document.createAttribute("style");
	  if(I == LISTofPR.length-1) st.value = "border-right: 1px solid #BDBDBD; margin-left:"+(75*I+12)+"px;"; 
	  else st.value = "margin-left:"+(75*I+12)+"px;";
       	  OB.setAttributeNode(st);
	  OB.appendChild(document.createTextNode(LISTofPR[I]));
          GEBI("SLG_PROVIDERS").appendChild(OB);
  }
  GEBI('SLG_PROVIDERS').style.marginTop='35px';
  if(localStorage["SLG_other_gt"]!="1"){   
   PROV=LISTofPR[0];
   SLG_setTEMP("PROV",PROV);
   if(GEBI('ClosedTab')) GEBI('ClosedTab').style.display='block';
  } 
}


function SLG_Tabs_Settler(){
 var id = SLG_EVENT.target.id;
 var ind = id.replace("SLG_P","");
 if(GEBI(id).className!="SLG_LABLE_DEACT"){
	 SLG_setTEMP("PROV",LISTofPR[ind]);
	 var t=LETSTRANS();
	 if(t==true)Loader(1);
	 REMOTE_Voice_Close();
	 SET_PROV(ind);
 }
}



document.onkeydown=function(event){
 if(event.keyCode != 33 && event.keyCode != 34){
  if(localStorage["SLG_HK_btnbox"]=="true"){
        var keyCode = ('which' in event) ? event.which : event.keyCode;
    	setTimeout(function(){
	    	if(!SLG_KEYCOUNT[keyCode] && SLG_KEYCOUNT.length<3)   {
        		SLG_KEYCOUNT[keyCode] = true;
		        SLG_KEYCOUNT.length++;
			SLG_KEYSTRING=SLG_KEYSTRING+keyCode+":|";
                	if(SLG_KEYSTRING!="")SLG_TEMPKEYSTRING=SLG_KEYSTRING;
		}
        },35);
  }
 }else	event.preventDefault();
};

document.onkeyup=function(){
  if(localStorage["SLG_HK_btnbox"]=="true"){
	var SLG_HKL = SLG_HK_TRANSLATE().toLowerCase();
	var SLG_DBL = localStorage["SLG_HK_btn"]+":|";
        SLG_DBL=SLG_DBL.replace(/ \+ /g,":|").toLowerCase();
	if(SLG_HKL == SLG_DBL) {
		SAVEtheSTATE();
		Loader(1);
		REMOTE_Voice_Close();
	}
  }	
};

(function(){var w=GEBI("SLG_switch");w.addEventListener("click",function(){langSWITCHER();},!1);} )();
(function(){var q=GEBI("SLG_switch");q.addEventListener("mouseover",function(){SwitchButton(0);},!1);q.addEventListener("mouseout",function(){SwitchButton(1);},!1);} )();
(function(){var s1=GEBI("SLG_src_delete");s1.addEventListener("click",function(){ClearSource();},!1);} )();
(function(){var t1=GEBI("SLG_dst_delete");t1.addEventListener("click",function(){GEBI("SLG_target").value="";},!1);} )();
(function(){var s2=GEBI("SLG_src_copy");s2.addEventListener("click",function(){CopyToClipBoard(0);},!1);} )();
(function(){var t2=GEBI("SLG_dst_copy");t2.addEventListener("click",function(){CopyToClipBoard(1);},!1);} )();
(function(){var q1=GEBI("SLG_src_font");q1.addEventListener("click",function(){FontSizeState();FontSize();},!1);} )();
(function(){var v1=GEBI("SLG_src_tts");v1.addEventListener("click",function(){startTTS("SLG_source");},!1);} )();
(function(){var v2=GEBI("SLG_dst_tts");v2.addEventListener("click",function(){startTTS("SLG_target");},!1);} )();
(function(){var c2=GEBI("SLG_logo-link");c2.addEventListener("click",function(){startCopyright();},!1);} )();
(function(){var tr=GEBI("SLG_trans_button");tr.addEventListener("click",function(){var t=LETSTRANS();if(t==true){Loader(1);REMOTE_Voice_Close();}},!1);} )();
(function(){var loc=GEBI("SLlocpl");loc.addEventListener("click",function(){LOCcontrol(0); var t=LETSTRANS();if(t==true){Loader(1);REMOTE_Voice_Close();}},!1);} )();
(function(){var loc=GEBI("SLG_tab2");loc.addEventListener("click",function(){GoToDictionary();},!1);} )();

(function(){if(GEBI("SLG_BT"))GEBI("SLG_BT").addEventListener("click",function(){BT_2STEPS_TRANSLATION(GEBI("SLG_source").value);},!1);} )();
(function(){if(GEBI("SLG_TR"))GEBI("SLG_TR").addEventListener("click",function(){DETECT(GEBI("SLG_source").value);},!1);} )();



(function(){
	var pp=GEBI("SLG_PP");
	pp.addEventListener("click",function(){
		FExtension.browserPopup.openNewTab("https://imtranslator.net"+_CGI+"&a=0");
	},!1);
} )();



(function(){var Sback0=GEBI("SLG_back");Sback0.addEventListener("mousedown",function(){REMOTE_Voice_Close();},!1);} )();

(function(){var Starget1=GEBI("SLG_target");Starget1.addEventListener("keydown",function(){REMOTE_Voice_Close();},!1);} )();
(function(){var Starget2=GEBI("SLG_target");Starget2.addEventListener("paste",function(){REMOTE_Voice_Close();},!1);} )();
(function(){var Starget3=GEBI("SLG_target");Starget3.addEventListener("drop",function(){REMOTE_Voice_Close();},!1);} )();
(function(){var Starget4=GEBI("SLG_target");Starget4.addEventListener("mousedown",function(){REMOTE_Voice_Close();},!1);} )();
(function(){var Ssource1=GEBI("SLG_source");Ssource1.addEventListener("keydown",function(){REMOTE_Voice_Close();},!1);} )();
(function(){var Ssource2=GEBI("SLG_source");Ssource2.addEventListener("paste",function(){REMOTE_Voice_Close();},!1);} )();
(function(){var Ssource3=GEBI("SLG_source");Ssource3.addEventListener("drop",function(){REMOTE_Voice_Close();},!1);} )();
(function(){var Ssource4=GEBI("SLG_source");Ssource4.addEventListener("mousedown",function(){REMOTE_Voice_Close();},!1);} )();


(function(){var Ssource5=GEBI("SLG_source");Ssource5.addEventListener("change",function(){SAVEtheSTATE();},!1);} )();


(function(){GEBI("SLG_posterSRC").addEventListener("click",function(){SLShowHideAlert100('none','SRC');SLG_GotIt('SRC');CLOSER=0;},!1);} )();
(function(){GEBI("SLG_posterDST").addEventListener("click",function(){SLShowHideAlert100('none','DST');SLG_GotIt('DST');CLOSER=0;},!1);} )();

(function(){GEBI("SLG_GotItSRC").addEventListener("click",function(){SLG_GotItStorage('SRC');CLOSER=0;},!1);} )();
(function(){GEBI("SLG_GotItDST").addEventListener("click",function(){SLG_GotItStorage('DST');CLOSER=0;},!1);} )();

(function(){GEBI("SLG_CloseMeSRC").addEventListener("click",function(){SLShowHideAlert100('none','SRC');CLOSER=1;},!1);} )();
(function(){GEBI("SLG_CloseMeDST").addEventListener("click",function(){SLShowHideAlert100('none','DST');CLOSER=1;},!1);} )();

(function(){GEBI("SLG_CloseAlert").addEventListener("click",function(){SLShowHideAlert();},!1);} )();
(function(){GEBI("SLG_CloseAlertBTN").addEventListener("click",function(){SLShowHideAlert();},!1);} )();


(function(){
	var l1=GEBI("SLG_langSrc");
	l1.addEventListener("change",function(){
		Switch();
	},!1);
} )();
(function(){
	var l2=GEBI("SLG_langDst");
	l2.addEventListener("change",function(){
		FExtension.store.set("SLG_langDst2", l2.value);
               	var t=LETSTRANS();if(t==true){Loader(1);REMOTE_Voice_Close();}
	},!1);
} )();


//(function(){ window.addEventListener('blur',function(){self.close();},!1);} )();



(function(){
    window.addEventListener('blur',function(){
        FExtension.browserPopup.addOnMessageListener(
            function(request, sender, sendResponse) {
                if (request.greeting == "hello"){
                    self.close();
                }
                if (request.greeting == "hello2"){
                    self.close();
                }
            }
        );
    },!1);
})();


function GEBI(id){
	return document.getElementById(id);
}

function CONSTRUCTOR(){

	GEBI('SLG_h3').innerText="v."+FExtension.bg.ImTranslatorBG.Version();  
        if(SLG_getTEMP("PROV")=="" || SLG_getTEMP("PROV")=="undefined") PROV=LISTofPR[0];
        else PROV=SLG_getTEMP("PROV");


       	GEBI('SLG_translate_container_app').style.opacity="1";
	GEBI('SLG_h2').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extTITLE')));
                                                                    

	GEBI('SLoptions_ttl').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extOptions');
	GEBI('SLhistory_ttl').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extHistory');
	GEBI('SLhelp_ttl').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extHelp');
	GEBI('SLG_PP').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extContribution_ttl');

	GEBI('SLG_tts_limit').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extTTS_Limit')));
	GEBI('SLG_tts_limit2').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extTTS_Limit')));

	GEBI('SLG_CloseMeSRC').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extClose');
	GEBI('SLG_GotItSRC').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extIGetIt')));
	GEBI('SLG_ClosePosterSRC').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extOk')));

	GEBI('SLG_CloseMeDST').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extClose');
	GEBI('SLG_GotItDST').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extIGetIt')));
	GEBI('SLG_ClosePosterDST').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extOk')));

	var CMPR = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extCompare')
	var theview = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDownload') + ": " + CMPR;
	GEBI('SLcompare_ttl').title=theview;
	GEBI('SLG_view_menu').title=theview;
	GEBI('SLG_dst_view').title=CMPR;


	GEBI('SLG_src_delete').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extClearText');
	GEBI('SLG_src_copy').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extCopyText');
	GEBI('SLG_src_font').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extFont_Size_ttl');
	GEBI('SLG_src_tts').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extListen');


	GEBI('SLG_dst_delete').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extClearText');
	GEBI('SLG_dst_copy').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extCopyText');
	GEBI('SLG_dst_tts').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extListen');



	GEBI('SLG_detect').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetected')));
	GEBI('SLG_switch').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSwitch_languages_ttl');
	GEBI('SLG_trans_button').value=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extTrButton');
	GEBI('SLG_tab1').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'exttabTrans')));
	GEBI('SLG_tab1').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'exttabTrans');
	GEBI('SLG_tab2').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'exttabDict')));
	GEBI('SLG_tab2').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'exttabDict');
	GEBI('SLG_BT').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extBackTrans')));

	if(GEBI('SLG_TR'))GEBI('SLG_TR').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extResTrans')));

	//GEBI('SLG_powered').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extPowered')));

	GEBI('SLlocpl').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLock_in_language');

	SET_PROV(0);

	switch(PLATFORM){
	 case "Opera" : GEBI('SLhelp_a').href="https://about.imtranslator.net/tutorials/presentations/google-translate-for-opera/opera-translator/"; break;
	 case "Chrome": GEBI('SLhelp_a').href="https://about.imtranslator.net/tutorials/presentations/imtranslator-for-chrome/imtranslator-tool/"; break;
	 default      : GEBI('SLhelp_a').href="https://about.imtranslator.net/tutorials/presentations/";break;
	}


  	if(localStorage["SLG_Flag"]=="FALSE") {
	        if(localStorage["SLG_no_detect"]=="false") GEBI('SLlocpl').checked=true;
       		else GEBI('SLlocpl').checked=false;
		SLG_setTEMP("LOC",String(GEBI('SLlocpl').checked));
	}else{
	        if(SLG_getTEMP("LOC")==""){
		        if(localStorage["SLG_no_detect"]=="false") GEBI('SLlocpl').checked=true;
	       		else GEBI('SLlocpl').checked=false;
		}else{
			if(SLG_getTEMP("LOC")=="true")	GEBI('SLlocpl').checked = true;
			else                            GEBI('SLlocpl').checked = false;
		}
        }

        LOCcontrol(1);
	

	var OB = GEBI('SLG_langSrc');
	if(FExtension.store.get("SLG_LNG_LIST").indexOf("auto")!=-1 || FExtension.store.get("SLG_LNG_LIST")=="all"){
		var OB1 = document.createElement('option');
		var v = document.createAttribute("value");
		v.value = "auto";
		OB1.setAttributeNode(v);
		OB1.appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetect_language_from_box')));
		OB.appendChild(OB1); 
	}
	var SLG_TMP = SLG_Languages.split(",");
	for(var J=0; J < SLG_TMP.length; J++){
	    var SLG_TMP2=SLG_TMP[J].split(":");
	    var OB2 = document.createElement('option');
	    var v = document.createAttribute("value");
	    v.value = SLG_TMP2[0];
	    OB2.setAttributeNode(v);
	    OB2.appendChild(document.createTextNode(SLG_TMP2[1]));
	    OB.appendChild(OB2);
	}
	var SEL = 0;
	var OB3 = GEBI('SLG_langDst');
	var MENU = SLG_Languages.split(",");
        if(MENU.length>=SLG_FAV_START){
	        var SLG_FAV_LANGS_IMT_LONG = SLG_ADD_LONG_NAMES(SLG_FAV_LANGS_IMT);
		if(SLG_FAV_LANGS_IMT_LONG!=""){
			var favArr=SLG_FAV_LANGS_IMT_LONG.split(","); 
			for(var J=0; J < favArr.length; J++){
			    var CURlang3 = favArr[J].split(":");
			    var OB_FAV = document.createElement('option');
			    var v = document.createAttribute("value");
			    v.value = CURlang3[0];
			    OB_FAV.setAttributeNode(v);
			    if(J == 0){
				    var sel = document.createAttribute("selected");
				    sel.value = "selected";
				    OB_FAV.setAttributeNode(sel);
				    SEL = 1;
				    //localStorage["SLG_langDst"]=CURlang3[0];
				    //localStorage["SLG_langDst2"]=CURlang3[0];
			    }
			    OB_FAV.appendChild(document.createTextNode(CURlang3[1]));
			    OB3.appendChild(OB_FAV);
			}
			OB_FAV = document.createElement('option');
			var d = document.createAttribute("disabled");
			d.value = true;
			OB_FAV.setAttributeNode(d);
			var all = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extwptDAll');
	    		OB_FAV.appendChild(document.createTextNode("-------- [ "+ all +" ] --------"));
	            	OB3.appendChild(OB_FAV);
		}
	}

	for(var J=0; J < SLG_TMP.length; J++){
	    var SLG_TMP2=SLG_TMP[J].split(":");
	    var OB2 = document.createElement('option');
	    v = document.createAttribute("value");
	    v.value = SLG_TMP2[0];
	    OB2.setAttributeNode(v);
	    if(SEL == 0){	
		    if(J == 0){
			    var sel = document.createAttribute("selected");
			    sel.value = "selected";
			    OB2.setAttributeNode(sel);
			    //localStorage["SLG_langDst"]=SLG_TMP2[0];
			    //localStorage["SLG_langDst2"]=SLG_TMP2[0];
		    }
	    }
	    OB2.appendChild(document.createTextNode(SLG_TMP2[1]));
	    OB3.appendChild(OB2);
	}



	if(localStorage["SLG_Flag"]=="FALSE") {var mySLG_langSrc = localStorage["SLG_langSrc"]; localStorage["SLG_langSrc2"]=localStorage["SLG_langSrc"];}
	else	var mySLG_langSrc = localStorage["SLG_langSrc2"];
	GEBI('SLG_langSrc').value = mySLG_langSrc;

	if(localStorage["SLG_Flag"]=="FALSE") {var mySLG_langDst = localStorage["SLG_langDst"]; localStorage["SLG_langDst2"]=localStorage["SLG_langDst"]; localStorage["SLG_Flag"]="TRUE";}
	else	var mySLG_langDst = localStorage["SLG_langDst2"];
	GEBI('SLG_langDst').value = mySLG_langDst;

   	SET_PROV(1);

	if(GEBI('SLG_donate')) GEBI('SLG_donate').addEventListener("mouseover",function(){SLG_DONATE_manu(1);},!1);
	if(GEBI('SLG_donate')) GEBI('SLG_donate').addEventListener("mouseout",function(){SLG_DONATE_manu(0);},!1);
	if(GEBI('SLG_donate_menu')) GEBI('SLG_donate_menu').addEventListener("mouseover",function(){SLG_DONATE_manu(1);},!1);
	if(GEBI('SLG_donate_menu')) GEBI('SLG_donate_menu').addEventListener("mouseout",function(){SLG_DONATE_manu(0);},!1);

	if(GEBI('M_D1')) GEBI('M_D1').addEventListener("click",function(){SLG_DONATE_links(1);},!1);
	if(GEBI('M_D2')) GEBI('M_D2').addEventListener("click",function(){SLG_DONATE_links(2);},!1);
	if(GEBI('M_D3')) GEBI('M_D3').addEventListener("click",function(){SLG_DONATE_links(3);},!1);
	if(GEBI('M_D4')) GEBI('M_D4').addEventListener("click",function(){SLG_DONATE_links(4);},!1);

	if(GEBI('SLcompare_ttl')) GEBI('SLcompare_ttl').addEventListener("click",function(){SLG_VIEW_link(0);},!1);
	if(GEBI('SLcompare_ttl')) GEBI('SLcompare_ttl').addEventListener("mouseover",function(){SLG_VIEW_manu(1);},!1);
	if(GEBI('SLcompare_ttl')) GEBI('SLcompare_ttl').addEventListener("mouseout",function(){SLG_VIEW_manu(0);},!1);
	if(GEBI('SLG_view_menu')) GEBI('SLG_view_menu').addEventListener("mouseover",function(){SLG_VIEW_manu(1);},!1);
	if(GEBI('SLG_view_menu')) GEBI('SLG_view_menu').addEventListener("mouseout",function(){SLG_VIEW_manu(0);},!1);

	if(GEBI('M_V1')) GEBI('M_V1').addEventListener("click",function(){SLG_VIEW_link(1);},!1);
	if(GEBI('M_V2')) GEBI('M_V2').addEventListener("click",function(){SLG_VIEW_link(2);},!1);
	if(GEBI('M_V3')) GEBI('M_V3').addEventListener("click",function(){SLG_VIEW_link(3);},!1);


//	if(GEBI('SLG_dst_view')) GEBI('SLG_dst_view').addEventListener("mouseover",function(){SLG_VIEW_manu2(1);},!1);
//	if(GEBI('SLG_dst_view')) GEBI('SLG_dst_view').addEventListener("mouseout",function(){SLG_VIEW_manu2(0);},!1);
//	if(GEBI('SLG_view_menu2')) GEBI('SLG_view_menu2').addEventListener("mouseover",function(){SLG_VIEW_manu2(1);},!1);
//	if(GEBI('SLG_view_menu2')) GEBI('SLG_view_menu2').addEventListener("mouseout",function(){SLG_VIEW_manu2(0);},!1);

	if(GEBI('SLG_dst_view')) GEBI('SLG_dst_view').addEventListener("click",function(){startCompare("SLG_source");},!1);


	if(GEBI('M_2V1')) GEBI('M_2V1').addEventListener("click",function(){SLG_VIEW_link(1);},!1);
	if(GEBI('M_2V2')) GEBI('M_2V2').addEventListener("click",function(){SLG_VIEW_link(2);},!1);
	if(GEBI('M_2V3')) GEBI('M_2V3').addEventListener("click",function(){SLG_VIEW_link(3);},!1);


	ACTIVATE_THEME(FExtension.store.get("THEMEmode"));
    	setTimeout(function(){
	        SLG_GLOBAL_RESIZER();
	},2);



}

function SET_FIRST_AVAILABLE_PROV(){
 if(localStorage["SLG_other_gt"]=="1"){   
  if(SLG_getTEMP("PLT_TR_FIRSTRUN")!="done"){
   if(ListProviders.indexOf(SLG_getTEMP("PROV"))==-1){
    var theList = FExtension.store.get("SLG_ALL_PROVIDERS_GT").split(",");
    var theList2 = ListProviders.split(",");
    for(I=0; I<(theList.length-1); I++){
      PROV=theList2[0];
      SLG_setTEMP("PROV",PROV);
      if(theList[I] == PROV) GEBI("SLG_P"+I).className="SLG_LABLE";
      SLG_setTEMP("PLT_TR_FIRSTRUN","done");
    }
   }
  }else{
   if(ListProviders.indexOf(SLG_getTEMP("PROV"))==-1){
    var theList = ListProviders.split(",");
    var theList2 = FExtension.store.get("SLG_ALL_PROVIDERS_GT").split(",");
    for(var I=0; I<(theList.length-1); I++){
      PROV=theList[I];
      SLG_setTEMP("PROV",PROV);
      break;
    }
    
    for(I=0; I<(theList2.length-1); I++){
      if(theList2[I] == SLG_getTEMP("PROV")) GEBI("SLG_P"+I).className="SLG_LABLE";
    }

   }
  }
 }else 	GEBI("SLG_P0").className="SLG_LABLE";

 if(PROV==undefined){
	PROV="Google";
	SLG_setTEMP("PROV",PROV);
 }

}



function SET_PROV(st){
  ListProviders="";
  var GT_PROVS = FExtension.store.get("SLG_ALL_PROVIDERS_GT").split(",");
  var P = "Google";
  if(GT_PROVS.length>0) P = GT_PROVS[0];
  if(SLG_getTEMP("PROV") == "" || SLG_getTEMP("PROV") =="undefined"){ SLG_setTEMP("PROV",P); }
  for(I=0; I<LISTofPR.length; I++){

    //if(PROV == LISTofPR[I]) GEBI("SLG_P"+I).className="SLG_LABLE";
    //else                    GEBI("SLG_P"+I).className="SLG_LABLE_OFF";
   
    var from=GEBI("SLG_langSrc").value;
    var to = GEBI("SLG_langDst").value;

    if(SLG_DETECT=="" && from=="auto") DetLang = "en"

    if(from=="auto" || GEBI("SLlocpl").checked==false) from=SLG_DETECT;

    if(SLG_getTEMP("PROV") == LISTofPR[I]) GEBI("SLG_P"+I).className="SLG_LABLE";
    else                    GEBI("SLG_P"+I).className="SLG_LABLE_OFF";   

	    if(from!="") {
    		if(LISTofPR[I]!="Translator"){
		     if(FIND_PROVIDER(LISTofPRpairs[I],from) ==-1 || FIND_PROVIDER(LISTofPRpairs[I],to)==-1){
			 GEBI("SLG_P"+I).className="SLG_LABLE_DEACT";
			 ListProviders=ListProviders.replace(LISTofPR[I]+",","");
		     } else ListProviders=ListProviders+LISTofPR[I]+",";
    		} else {
		      if(LISTofPRpairs[I].indexOf(from + "/" + to)==-1){
			 GEBI("SLG_P"+I).className="SLG_LABLE_DEACT";
			 ListProviders=ListProviders.replace(LISTofPR[I]+",","");
		      } else ListProviders=ListProviders+LISTofPR[I]+",";
    		}
	    }
    }

    ListProviders=ListProviders.replace("Translator,Translator","Translator");
    if(ListProviders!=""){
	  if(st==1) SET_FIRST_AVAILABLE_PROV();
    }	

}

function FIND_PROVIDER(list,ln){
  var arr = list.split(",");
  var cnt=-1
  for(var i=0; i<arr.length; i++){
	if(arr[i]==ln) cnt++;
  }
  return cnt;
}


function LETSTRANS(){
 GEBI("SLG_source").value=FExtension.store.get("SLG_SavedText_gt").replace(/\^/ig,"%");
 if(GEBI("SLG_source").value==""){
//	SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Text'));
	return false;
 }else return true;
}

function SESSION(){        
        CONSTRUCTOR();
        var resp = 1;
	if(FExtension.store.get("SLG_session") != resp){
        	FExtension.store.set("SLG_session", resp);
	       	FExtension.store.set("SLG_Flag", "FALSE");
	   	FExtension.bg.ImTranslatorBG.DIC_TRIGGER = 0;
		FExtension.store.set("SLG_GWPTHist", "");
        	SLG_setTEMP("LOC","");
        }
	if(localStorage["SLG_TS"]!=SLG_getTEMP("OLD_TS_TR")){
		localStorage["SLG_Flag"]="FALSE";
		SLG_setTEMP("OLD_TS_TR",localStorage["SLG_TS"]);
                SLG_setTEMP("PROV","");
		SLG_setTEMP("TR_FIRSTRUN","");
                SET_PROV(1);
	}

    	START();
	if(BACK_VIEW==1) SetBackWindow(); 
	else 	TR_WINDOW();
}

(function(){
	SESSION();
	var b=null,d=b,e=b,k=function(a){
		a.target="_blank";
		if(GEBI("SLG_langSrc").value=="")GEBI("SLG_langSrc").value=localStorage["SLG_langSrc"];
		if(GEBI("SLG_langDst").value=="")GEBI("SLG_langDst").value=localStorage["SLG_langDst"];
	    	setTimeout(function(){
			Loader(0);
			window.focus();
			if(FExtension.store.get("SLG_Flag")=="TRUE") LTR_RTL("SLG_source");
		},200);
	},n=function(){
		var a,c,l;
	},d=GEBI("SLG_trans_button"),e=GEBI("SLG_source");
	e.focus();

	FExtension.browserPopup.executeForSelectedTab(b,function(a){
		FExtension.browserPopup.tabSendRequest(a.id,{type:"get_selection"},function(a){
			GEBI("SLG_target").focus(); 
			GEBI("SLG_source").focus();
			if(a && a.selection!=""){
				CATCHED_TEXT=1;
	        	}	        
			if(a) a.selection&&(e.value=a.selection.substring(0,LIMIT),n())
		})
	});
	k(e);
	d.addEventListener("click",function(){
		//DETECT(e.value);
	},!1); 
})();




function PDFhandler(text){
//	if(FExtension.store.get("THE_URL") && FExtension.store.get("THE_URL").indexOf(".pdf")!=-1){
//		text = text.replace(/[\n\r]+/g, ' ');
//	}
        return text;
}




function SLG_Links(ob,todo){
	GEBI(ob).style.display=todo;
}



function ClearSource(){
	GEBI("SLG_source").value="";
	SLG_TRANS_TEXT = "";
	FExtension.store.set("SLG_SavedText_gt","");
	BOXCONTENT="";
	SLG_DETECT="";
	GEBI("SLG_detect").style.visibility="hidden";
}

function Switch(){

	BOXCONTENT="";
	FExtension.store.set("SLG_langSrc2", GEBI('SLG_langSrc').value);
	FExtension.store.set("SLG_langDst2", GEBI('SLG_langDst').value);
	FExtension.store.set("SLG_show_back2", GEBI('SLG_backbox').checked);
	FExtension.store.set("SLG_Fontsize2", GEBI('SLG_source').style.fontSize);
	FExtension.store.set("SLG_Flag", "TRUE");
	FExtension.store.set("SLG_langDst_name", GEBI("SLG_langDst").options[GEBI("SLG_langDst").selectedIndex].text);
	if(FExtension.bg.ImTranslatorBG){
		FExtension.bg.ImTranslatorBG.SLG_Planshet_Reset();//SLG_callbackRequest2();
	}
        LTR_RTL("SLG_source");
	SET_PROV(1);
	ACTIVATE_THEME(FExtension.store.get("THEMEmode"));
	var t=LETSTRANS();if(t==true){Loader(1);REMOTE_Voice_Close();}

}


function START(){   

	if(FExtension.store.get("SLG_Flag")=="FALSE")  	var mySLG_langSrc = FExtension.store.get("SLG_langSrc");
	else					      	var mySLG_langSrc = FExtension.store.get("SLG_langSrc2");

	var mySLG_langSrcSelect = GEBI("SLG_langSrc");
	for (var i = 0; i < mySLG_langSrcSelect.options.length; i++) {
		var mySLG_langSrcOption = mySLG_langSrcSelect.options[i];
		if (mySLG_langSrcOption.value == mySLG_langSrc) {
			mySLG_langSrcOption.selected = "true";
			break;
		}
	}

	if(FExtension.store.get("SLG_Flag")=="FALSE")  
		var mySLG_langDst = FExtension.store.get("SLG_langDst");
	else					
		var mySLG_langDst = FExtension.store.get("SLG_langDst2");
	var mySLG_langDstSelect = GEBI("SLG_langDst");
	for (var i = 0; i < mySLG_langDstSelect.options.length; i++) {
		var mySLG_langDstOption = mySLG_langDstSelect.options[i];
		if (mySLG_langDstOption.value == mySLG_langDst) {
			mySLG_langDstOption.selected = "true";
			break;
		}
	}
	if(FExtension.store.get("SLG_Flag")=="FALSE") var mySLG_backbox = FExtension.store.get("SLG_show_back");
	else var mySLG_backbox = FExtension.store.get("SLG_show_back2"); 


        if(BACK_VIEW==1){
		if(mySLG_backbox=="true") GEBI("SLG_backbox").checked = true;
		else GEBI("SLG_backbox").checked = false;
	} else GEBI("SLG_backbox").checked = false;

	if(FExtension.store.get("SLG_Flag")=="FALSE")  var mySLG_FS = FExtension.store.get("SLG_Fontsize");
	else var mySLG_FS = FExtension.store.get("SLG_Fontsize2");
  

	if(mySLG_FS=="undefined") {
		GEBI('SLG_source').style.fontSize="17px";
		GEBI('SLG_target').style.fontSize="17px";
		if(GEBI('SLG_back'))
			GEBI('SLG_back').style.fontSize="17px";
	}else{
		GEBI('SLG_source').style.fontSize = mySLG_FS;
		GEBI('SLG_target').style.fontSize = mySLG_FS;
		if(GEBI('SLG_back'))
			GEBI('SLG_back').style.fontSize=mySLG_FS;
	}

	//Update the CONTEXT menu---------
    setTimeout(function(){
    	if(FExtension.store.get("SLG_langDst")!=GEBI("SLG_langDst").value){
    		var SLSelect = GEBI("SLG_langDst");
    		var SLText = SLSelect.options[SLSelect.selectedIndex].text;
    	} else 
    		SLText = FExtension.store.get("SLG_langDst_name");
    		FExtension.store.set("SLG_langDst_name", SLText);
    	try{
    		FExtension.bg.ImTranslatorBG.SLG_Planshet_Reset();//SLG_callbackRequest2();
    	}catch(e){}
    }, 30);
//Update the CONTEXT menu----------
}


function Loader(st){  

 var STOP_TRANSLATE=0;
 var CGI = String(window.location.href);
 if(CGI.indexOf("&t=1")!=-1 && FExtension.store.get("SLG_SaveText_box_gt")==1) GEBI("SLG_source").value=FExtension.store.get("SLG_SavedText_gt").replace(/\^/ig,"%");

 if(GEBI("SLG_source").value=="" && CGI.indexOf("?text=")==-1) STOP_TRANSLATE=1;
 else{
	CGI = CGI.replace("&t=1","");
	var WER = CGI.split("?text=");
	if(GEBI("SLG_source").value=="" && WER.length == 2 && WER[1]==""){
		STOP_TRANSLATE=1;		
	}else{
		if(GEBI("SLG_source").value=="" && WER[1]!=""){
			GEBI("SLG_source").value=decodeURIComponent(WER[1]);
		}
	}
 }

 if(GEBI("SLG_source").value=="" && st==0 && FExtension.store.get("SLG_SaveText_box_gt")==1) GEBI("SLG_source").value=FExtension.store.get("SLG_SavedText_gt").replace(/\^/ig,"%");
 GEBI("SLG_source").value=PDFhandler(GEBI("SLG_source").value);

 if(GEBI("SLG_source").value==""){
   window.focus();
   GEBI("SLG_source").focus();
   if(FExtension.store.get("SLG_Dtext")=="" || FExtension.store.get("SLG_Dtext")=="undefined"){
	var ARR = CGI.split("?text=");
	var TXT = ARR[1];
   }else TXT = FExtension.store.get("SLG_Dtext");

   if(TXT){
     var theTEXT = TXT.replace("%20%20","\n\n");
     FExtension.store.set("SLG_SavedText_gt",decodeURIComponent(theTEXT));
     CATCHED_TEXT=0;
     if(theTEXT!=""){
	   SET_PROV(1);
	   GEBI("SLG_source").value=decodeURIComponent(theTEXT);
	   DETECT(GEBI("SLG_source").value);
           CATCHED_TEXT=1;
     } //  else SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Text'));
//   }else{
//    if(st==1) SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Text'));
   }
 }else{
  if(STOP_TRANSLATE==0){
   var TMPkey=0;
   if(FExtension.store.get("SLG_Dtext")!="" && FExtension.store.get("SLG_Dtext")!="undefined"){
	   GEBI("SLG_source").value=decodeURIComponent(FExtension.store.get("SLG_Dtext"));
	   TMPkey=1;
   }
   var s=GEBI("SLG_source").value.replace(/(^[\s]+|[\s]+$)/g, '');
   s=s.replace(/%/ig,"^");

   if(s!=""){
	   FExtension.store.set("SLG_SavedText_gt",decodeURIComponent(s));
	   var theQ=s.split(" ").length;
	   globaltheQ=theQ;
	   
	   if(s.match(/[-/‧·﹕﹗！：，。﹖？:-?!.,:{-~!"^_`\[\]]/g)!=null) theQ=100;

	   if(localStorage["SLG_dict"]=="false") theQ=100;

	   if(s.match(/[\u3400-\u9FBF]/) && s.length>1) theQ=100;
    	   //if(FExtension.bg.ImTranslatorBG.DIC_TRIGGER != 0) theQ = 100;

    	   if(TMPkey==1)theQ = 100;
    	   if(theQ==1) theQ=s.split("\n").length;
	   if(theQ==1){
		window.location.href="../../html/popup/dictionary.html?text="+encodeURIComponent(s);
	   }else{
		DETECT(GEBI("SLG_source").value);
	   }
   } // else SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Text'));
  }
 }

 FExtension.store.set("SLG_Dtext", "");

}




function startCopyright(){ 
	FExtension.browserPopup.openNewTab("https://about.imtranslator.net/about/company/");
}


function Google_TTS(text,id,TTSlang,SLG_TTS_box,Resp){
  if(localStorage["SLG_GVoices"]=="1"){
	if(text.length>GTTS_length){
       	   var SLbox="SRC";
	   if(id=="SLG_target") SLbox="DST";
	   if(localStorage["SLG_GotIt"]!="1") SLShowHideAlert100('block',SLbox);
	   else SLG_GotIt(SLG_TTS_box);	
	}else REMOTE_Voice(TTSlang,text,SLG_TTS_box);
  } else AutoForm(text, Resp, "https://text-to-speech.imtranslator.net/");
}

function Start_GOOGLE_TTS_backup(){
 try{
    if(GEBI("SLG_controls").className=="SLG_play"){
	GEBI("SLG_controls").className="SLG_pause";
	GOOGLE_TTS_backup();
    } else {
	GEBI("SLG_controls").className="SLG_play";
	synth.pause();	
    }
 }catch(ext){}
}

function GOOGLE_TTS_backup(TTSlang,SLbox){
 try{
	FirstLoop=1;
	synth.cancel();

	if(TheNewBox=="") TheNewBox=SLbox;

	var speechText = GEBI('SLG_target').value; 
	if(TheNewBox==1) speechText = GEBI('SLG_source').value; 



			var voices = synth.getVoices();
			const utterance = new SpeechSynthesisUtterance();
			var LNG="";
			if(TheNewLang=="") TheNewLang=TTSlang;
			switch(TheNewLang){
			 	case "zt":LNG = "zh-HK"; break;
			 	case "zh":LNG = "zh-TW"; break;
//			 	case "en":LNG = "en-GB|Male"; break;
			 	case "en":LNG = "en-US"; break;
			 	case "de":LNG = "de-DE"; break;
			 	case "hi":LNG = "hi-IN"; break;
			 	case "id":LNG = "id-ID"; break;
			 	case "it":LNG = "it-IT"; break;
			 	case "nl":LNG = "nl-NL"; break;
			 	case "pl":LNG = "pl-PL"; break;
			 	case "es":LNG = "es-US"; break;

			 	case "ru":LNG = "ru-RU"; break;
			 	case "ja":LNG = "ja-JP"; break;
			 	case "ko":LNG = "ko-KR"; break;
			 	case "fr":LNG = "fr-FR"; break;
			 	case "pt":LNG = "pt-BR"; break;

			}

			for (var a=0; a<voices.length; a++){
			    if(LNG.indexOf("|")!=-1){
				var ARR=LNG.split("|");
				if(ARR[0]==voices[a].lang && voices[a].name.indexOf(ARR[1])!=-1){
					utterance.voice = voices[a];
				}
			    }else{
				if(LNG==voices[a].lang){
					utterance.voice = voices[a];
				}
			    }
			}
			var SP = 1.0;


			if(SLG_getTEMP("TTSvolume")!=null && SLG_getTEMP("TTSvolume")!="undefined" && SLG_getTEMP("TTSvolume")!="") TheVolume = SLG_getTEMP("TTSvolume");


			var PLANSHET = GEBI("SLG_TTS_player2");
			if(TheNewBox==1) PLANSHET = GEBI("SLG_TTS_player1");
		 	PLANSHET.style.display='block';
		 	var PLAYER = "<div id='PL_lbplayer'><table width='350' colspan='3' style='padding:6px;' bgcolor='#fff'><tr><td width=20><div id='SLG_controls' class='SLG_pause'></div></td><td width=5></td><td align='left' width=20><div id='SLG_volume' class='SLG_volume'></div></td><td><input type='range' min='0' max='10' value='"+TheVolume+"' class='SLG_slider' id='SLG_myRange'></td></tr></table></div>";
			PLANSHET.innerHTML=PLAYER;


                        //SLG_setTEMP("TTSvolume",TheVolume);


                        if(TheNewText=="") TheNewText = speechText;

			utterance.text = TheNewText;
			utterance.rate = SP;
			utterance.volume = SLG_getTEMP("TTSvolume")*1/10;


			utterance.addEventListener('end', handleSpeechEvent);
			utterance.addEventListener('pause', handleSpeechPause);
			utterance.addEventListener('resume', handleSpeechResume);

			synth.speak(utterance);
			if(GEBI("PL_lbplayer").style.display!="block"){
			}

	if(SLG_getTEMP("TTSvolume")==null || SLG_getTEMP("TTSvolume")=="undefined" || SLG_getTEMP("TTSvolume")=="") SLG_setTEMP("TTSvolume","5");
	else SLG_setTEMP("TTSvolume",GEBI("SLG_myRange").value);
	if(SLG_getTEMP("TTSvolume")>0)	GEBI("SLG_volume").className="SLG_volume";
	else 	GEBI("SLG_volume").className="SLG_novolume";

	GEBI("SLG_myRange").value = SLG_getTEMP("TTSvolume");
 }catch(ext){}
}

function handleSpeechPause(){
	GEBI("SLG_controls").className="SLG_pause";
}

function handleSpeechResume(){
	GEBI("SLG_controls").className="SLG_play";
}

function handleSpeechEvent(){
	GEBI("SLG_controls").className="SLG_play";
	FirstLoop=0;	
}

function PlayPause(ob, event){   
 try{
    if(GEBI(ob).className=="SLG_play"){
	GEBI(ob).className="SLG_pause";
	if(FirstLoop==0){
		Reload(ob);
		FirstLoop=1;
	} else {
		synth.resume();	
		event.preventDefault();
	}
    } else {
	FirstLoop=1;
	event.preventDefault();
	GEBI(ob).className="SLG_play";
	synth.pause();	
    }
 }catch(ext){}
}

function Reload(ob){
 try{
    synth.cancel();    
    FirstLoop=0;	
    GOOGLE_TTS_backup();
    GEBI(ob).className="SLG_pause";
 }catch(ext){}
}


function startTTS(id){
	try{
	  DetLang = "";
	  //SLG_DETECT="";
	  TheNewBox="";
	  synth.cancel();    
	  var SLG_TTS_box=2;
	  if(id=="SLG_source") SLG_TTS_box=1;
	  var text = GEBI(id).value;
	  if(text!=""){
		//GEBI("SLG_detect").style.visibility="hidden";
		var tm = 1500;
   		if((id=="SLG_source" && GEBI('SLlocpl').checked==false) || (id=="SLG_source" && GEBI("SLG_langSrc").value=="auto")){
      			var resp = i18n_LanguageDetect(GEBI(id).value);
		      	if(BOXCONTENT == GEBI(id).value) resp=SLG_DETECT;
			if(resp == ""){
			  	if(DET==0) TTSDODetection(GEBI(id).value,0);
			  	else       SLDetectPATCH(GEBI(id).value);
			} else {
				SLG_DETECT=resp;
		             	var thetemp=GEBI("SLG_langSrc").value;

				if(SLG_no_detect=="true" || thetemp=="auto" || resp!=thetemp){
				  	// DetLang = resp;
				   	var shift=0;
	        		   	for (var i=0;i<BASELANGS.length;i++){
		        	        	templang=BASELANGS[i].split(":");
						if(resp == templang[0]){shift=1; resp = templang[1]; DetLang = templang[0]; DetLangName = resp; break;}
			                }
                			//SLG_WRONGLANGUAGEDETECTED=0;
				        if(shift==0){
						GEBI("SLG_detect").innerHTML="";
						st=1;
	                			if(GEBI("SLG_langSrc").value!="auto") DetLang=GEBI("SLG_langSrc").value;	
						else DetLang="en";
						SLG_Google_Only()
						SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Voice')); 		

				        } 	
				        if(thetemp=="auto") GEBI("SLG_langSrc").value="auto";
				}
				tm = 0;
      			} 
		} else tm = 0;	

		if(GEBI('SLlocpl').checked==true && GEBI('SLG_langSrc').value!="auto") tm=0;
		setTimeout(function(){

		   if(SLG_WRONGLANGUAGEDETECTED==1) {
			//SLG_setTEMP("PROV","Google"); 
			for(var i=0; i<LISTofPR.length; i++){
			 	if(GEBI("SLG_P"+i).title.toLowerCase() == "google"){GEBI("SLG_P"+i).className="SLG_LABLE";}
			}
			SLG_BLOCK_OBJECTS();  
			if(id=="SLG_source"){
				SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Voice')); 
				return false;
			}
		   } else { 
			SET_PROV(1);
			GEBI("SLG_detect").innerHTML = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetected')+" "+DetLangName;
		   }
		   var Resp="es";
		   var SLG_to=GEBI("SLG_langSrc").value;
		   if(id=="SLG_source" || id=="SLG_back"){
		      if(DetLang!="") Resp = DetLang;
		      else Resp = GEBI("SLG_langSrc").value;
		   }else Resp = GEBI("SLG_langDst").value;
		   Resp = Resp.replace("-TW","");
		   Resp = Resp.replace("-CN","");
		   var TTSlang = Resp;
		   switch(localStorage["SLG_SLVoices"]){
			case "0": 	if(ALLvoices.indexOf(Resp)!=-1){
                              			if(SLG_TTS.indexOf(Resp)!=-1){
							if(text.length>GTTS_length) AutoForm(text, Resp, "https://text-to-speech.imtranslator.net/");
							else Google_TTS(text,id,TTSlang,SLG_TTS_box,Resp);
			      			} else Google_TTS(text,id,TTSlang,SLG_TTS_box,Resp);
			  		} else SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Voice'));
			  		break;
			case "1": 	if(ALLvoices.indexOf(Resp)!=-1){
						if(G_TTS.indexOf(Resp)!=-1) Google_TTS(text,id,TTSlang,SLG_TTS_box,Resp);
					else SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Voice'));
		  			} else SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Voice'));
		  			break;
			case "2": 	if(ALLvoices.indexOf(Resp)!=-1){
		                              	if(SLG_TTS.indexOf(Resp)!=-1) AutoForm(text, Resp, "https://text-to-speech.imtranslator.net/");
		      				else Google_TTS(text,id,TTSlang,SLG_TTS_box,Resp);
		  			} else SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Voice'));
					break;
		   }
		}, tm);
	  } // else SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Text'));
 }catch(ext){}
}

function SetTTStextLimit(text,limit){
 text=text.replace(/(\r\n|\n|\r)/gm,"");
 var ttstexttmp=text.split(" ");
 var OutPut="";
 var OutPut_="";
 for(var i=0; i<ttstexttmp.length; i++){
     OutPut=OutPut+ttstexttmp[i]+" ";
     if(OutPut.length>limit) break;
     else OutPut_=OutPut_+ttstexttmp[i]+" ";
 }
 return(OutPut_);
}


function REMOTE_Voice (dir, text, box){
  if(dir==""){
   dir="es";
   if(box==2) dir = GEBI("SLG_langDst").value;
   else {
    //if(GEBI("SLG_langSrc").value!="auto") dir = GEBI("SLG_langSrc").value;
    //else dir = DetLang;
    dir = DetLang;
   }
  }
  GLOB_BOX = box;
  if(text==""){
   if(box==1) text=document.getElementById("SLG_source").value;
   else text=document.getElementById("SLG_target").value;
   text=text.substring(0,GTTS_length);
  }

  var BackUpDir = dir;

  dir = dir.replace("-TW","");
  dir = dir.replace("-CN","");
  if(dir=="en") dir = dir.replace("en","en-BR");
  dir = dir.replace("es","es-419");
  if(dir=="fr-CA") dir="fr";
  if(dir=="lzh") dir="zh";
  if(dir=="yue") dir="zh";
  if(dir=="pt") dir="pt-BR";


  if(GEBI("SLG_TTS_player1")) GEBI("SLG_TTS_player1").style.display='none';
  if(GEBI("SLG_TTS_player2")) GEBI("SLG_TTS_player2").style.display='none';

  var a=Math.floor((new Date).getTime()/36E5)^123456;
  var TK = a+"|"+Math.floor((Math.sqrt(5)-1)/2*(a^654321)%1*1048576);
  var length = text.length;
  var num = Math.floor((Math.random() * SLG_GEO.length)); 
  var theRegion = SLG_GEO[num];
  if(FExtension.store.get("SLG_DOM")!="auto") theRegion=FExtension.store.get("SLG_DOM");
  var baseUrl = "https://translate.google."+theRegion;
  baseUrl = baseUrl+'/translate_tts';


  var client = "tw-ob";
//  if(BackUpDir=="es") client="t";

  var SLG_Params='tk='+TK+'&ie=UTF-8&tl='+dir+'&total=1&idx=0&textlen='+length+'&client='+client+'&q='+encodeURIComponent(text);

  baseUrl = baseUrl +"?"+ SLG_Params;

   if(BACK_VIEW == 2 && box==2) GEBI("SLG_backbox").style.display="none";
   GEBI("SLG_TTS_player"+box).innerHTML="";
   var frame = document.getElementById('PL_lbframe');
   if(frame)	frame.parentNode.removeChild(frame);
   if(!document.getElementById("PL_lbframe")){
    var die=document.createElement("iframe");
    die.src="";
    die.name="PL_lbframe";
    die.id="PL_lbframe";
    die.width="447px";
    die.height="35px";
    die.scrolling="no";
    die.frameBorder="0";
    document.getElementById('SLG_TTS_player'+box).appendChild(die);
            const http = new XMLHttpRequest
            http.onload = e => {
                const reader = new FileReader();
                reader.onloadend = function() {
		     var audioElement = document.createElement('audio');
		     audioElement.setAttribute('src', reader.result);
		     audioElement.setAttribute('preload', 'auto');
		     audioElement.setAttribute('controls', '');
		     audioElement.setAttribute('autoplay', '');
		     audioElement.setAttribute('id', 'SLmedia');
		     audioElement.setAttribute('name', 'SLmedia');

		     audioElement.setAttribute('style', 'width:470px;margin-top:-18px;margin-left:-20px;');
		     window.frames["PL_lbframe"].document.body.appendChild (audioElement);

			setTimeout(function(){
			  try {
			     var TTSstatus = String((window.frames["PL_lbframe"].document.getElementById("SLmedia").duration));
		        	 if(TTSstatus=="NaN") {
                                        TheNewLang="";
					if(PLATFORM=="Chrome" && TTSbackupLangs.indexOf(BackUpDir)!=-1) GOOGLE_TTS_backup(BackUpDir,box);
					else {
						GEBI("SLG_TTS_player"+box).innerHTML="<div align=center><font color='#BD3A33'>"+FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extADVstu')+"</font><br><a href='../options/options.html?feed' target='_blank' class='SLG_links'>"+FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extFeedback')+"</a></div>";
				     		document.getElementById('SLG_TTS_player'+box).style.height="20px";
					}
				 }
			   } catch (ex) {if(PLATFORM=="Chrome" && TranslatorIM.TTSbackupLangs.indexOf(BackUpDir)!=-1)TranslatorIM.GOOGLE_TTS_backup(BackUpText,BackUpDir);}	  
			}, 3000);  

		     document.getElementById('SLG_TTS_player'+box).style.display="block";
		     document.getElementById('SLG_TTS_player'+box).style.height="35px";
		     document.getElementById('SLG_TTS_player'+box).style.width="425px";
		     document.getElementById('SLG_TTS_player'+box).style.marginTop="3px";

                }
                reader.readAsDataURL(e.target.response)
            }

            SLG_BLOCK_OBJECTS();
	//    SLG_WRONGLANGUAGEDETECTED=0;
            http.onerror = e => {
                console.error(e)
                reject(e)
            }
            http.open("GET", baseUrl)
            http.responseType = "blob"
            http.send()
   }

   if(GEBI("PL_lbframe").style.display!="block"){
	if(BACK_VIEW==1){
		GEBI('SLG_back').style.height = (GLOB_BACK_HEIGHT-38)+"px";
	} else {
		RESIZE_AND_SHOW_PLAYER(box);
	}	
   }



}

function REMOTE_Voice_Close (){
	try{
	 resetCursor();
	 if(GEBI("SLG_TTS_player1")) GEBI("SLG_TTS_player1").style.display='none';
	 if(GEBI("SLG_TTS_player2")) GEBI("SLG_TTS_player2").style.display='none';
	 synth.cancel();
	 var frame = document.getElementById('PL_lbframe');
	 if(frame) {
		frame.parentNode.removeChild(frame);

		 if(BACK_VIEW==1) GEBI('SLG_back').style.height = (GLOB_BACK_HEIGHT)+"px"; 
		 else {
			if(GLOB_BOX==1){
				GEBI("SLG_fieldset").style.height=(GLOB_BACK_HEIGHT-55)+"px";
				GEBI('SLG_source').style.height = (GLOB_BACK_HEIGHT-55)+"px";
			}else{
				GEBI("SLG_fieldset_trg").style.height=(GLOB_BACK_HEIGHT-17)+"px";
				GEBI('SLG_target').style.height = (GLOB_BACK_HEIGHT-22)+"px";
			}
		 }

	}
      }catch(ext){}
}


function startCompare(id){
	// var text = encodeURIComponent(GEBI(id).value);
	var text = GEBI(id).value;
	if(text!=""){
	        var tm = 300;
		var comparelangs="ar,bs,bg,ca,zh,zt,hr,cs,da,nl,en,et,fi,fr,de,el,ht,ha,iw,hi,hu,id,it,ja,ko,lv,lt,ms,mt,no,fa,pl,pt,ro,ru,sr,sk,sl,es,sv,th,tr,uk,ur,vi,cy";
		if(id=="SLG_source"){
	        	var resp = i18n_LanguageDetect(GEBI(id).value);
			if(BOXCONTENT == GEBI(id).value) resp=SLG_DETECT;
		        if(resp == ""){
			  if(DET==0) DODetection(GEBI(id).value);
			  else       SLDetectPATCH(GEBI(id).value);
		        } else {
		             	SLG_DETECT=resp;
		             	var thetemp=GEBI("SLG_langSrc").value;
				if(SLG_no_detect=="true" || thetemp=="auto" || resp!=thetemp){
				   //DetLang = resp;
				   var shift=0;
			           for (var i=0;i<BASELANGS.length;i++){
        			        templang=BASELANGS[i].split(":");
					if(resp == templang[0]){shift=1; resp = templang[1]; DetLang = templang[0]; DetLangName = resp; break;}
                		   }
//		                   SLG_WRONGLANGUAGEDETECTED=0;

	        		   if(shift==0){
					GEBI("SLG_detect").innerHTML="";
					st=1;
//		                	if(GEBI("SLG_langSrc").value!="auto") DetLang=GEBI("SLG_langSrc").value;	
//					else DetLang="en";
		                        //SLG_setTEMP("PROV","Google");
					SET_PROV(1);
		                        SLG_WRONGLANGUAGEDETECTED=1;
	        		   }

		                   GEBI("SLG_detect").style.visibility="visible";
				   GEBI("SLG_detect").innerHTML = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetected')+" "+resp;
			           if(thetemp=="auto") GEBI("SLG_langSrc").value="auto";
				}  
				tm = 0;
			}
		} else tm = 0;
		setTimeout(function(){

		   	if(SLG_WRONGLANGUAGEDETECTED==1) {
				//SLG_setTEMP("PROV","Google"); 
				for(var i=0; i<LISTofPR.length; i++){
		 			if(GEBI("SLG_P"+i).title.toLowerCase() == "google"){GEBI("SLG_P"+i).className="SLG_LABLE";}
				}
				SLG_BLOCK_OBJECTS();  
				//SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Voice')); 
				return false;
		   	} else { 
				SET_PROV(1);
				GEBI("SLG_detect").innerHTML = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetected')+" "+DetLangName;
		   	}

			if(GEBI("SLG_langSrc").value=="auto") var RespS = DetLang;
			else    var RespS = GEBI("SLG_langSrc").value;
//			RespS = RespS.replace("zh-TW","zt");
//			RespS = RespS.replace("zh-CN","zh");
			var RespT = GEBI("SLG_langDst").value;
//			RespT = RespT.replace("zh-TW","zt");
//			RespT = RespT.replace("zh-CN","zh");

			if(RespS!=RespT){
				if(comparelangs.indexOf(RespS)>-1 && comparelangs.indexOf(RespT)>-1){
					AutoForm(text, RespS+"/"+RespT, "https://imtranslator.net/compare/");
				}else{
					for (var i=0;i<BASELANGS.length;i++){
						var templangS=BASELANGS[i].split(":");
						if(RespS == templangS[0]) 
							RespS = templangS[1];
					}
					for (var j=0;j<BASELANGS.length;j++){
						var templangT=BASELANGS[j].split(":");

						if(RespT == templangT[0]) 
							RespT = templangT[1];
					}
					if(RespS!="auto"){
						if(SLG_WRONGLANGUAGEDETECTED==0){
						        var msg=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_TextCompare').replace("XXX",RespS);
						        msg=msg.replace("YYY",RespT);
							SLG_alert(msg);
						} else {
							GEBI("SLG_detect").innerHTML="";
							SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Voice')); 
						}
					} else {	  
						setTimeout(function(){
							startCompare("SLG_source");
						}, 500);  
					}
				}
			} else  SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extS_T_L_diff'));
                                                       
		}, tm);
	} // else  SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Text'));

}





function AutoForm(text,dir,url){
    if(dir=="")dir="en/es";
    var tmpdir=dir.split("/");
    text = truncStrByWord(text,1200);
    if(dir == "en-gb") dir = "g_en-UK_f";

    if(tmpdir[0]=="es" || tmpdir[0]=="fr" || tmpdir[0]=="it" || tmpdir[0]=="pt") text=unescape(encodeURIComponent(text));
    var submitForm = getNewSubmitForm();

    createNewFormElement(submitForm, "text", text);
    createNewFormElement(submitForm, "url", "CHROME");
    createNewFormElement(submitForm, "dir", dir);
    submitForm.action= url;
//    submitForm.target= "_blank";
    submitForm.setAttribute('target', '_blank');
    submitForm.submit();
}


function FontSize(){
	if(GEBI('SLG_source').style.fontSize=="17px" || GEBI('SLG_source').style.fontSize==""){
		GEBI('SLG_source').style.fontSize="19px";
		GEBI('SLG_target').style.fontSize="19px";
		if(GEBI('SLG_back'))GEBI('SLG_back').style.fontSize="19px";
	}else{
		GEBI('SLG_source').style.fontSize="17px";
		GEBI('SLG_target').style.fontSize="17px";
		if(GEBI('SLG_back')) GEBI('SLG_back').style.fontSize="17px";
	}
}

function FontSizeState(){
	if(GEBI('SLG_source').style.fontSize=="17px" || GEBI('SLG_source').style.fontSize==""){
		FExtension.store.set("SLG_Fontsize2", "19px");
	}else{
		FExtension.store.set("SLG_Fontsize2", "17px");
	}
	FExtension.store.set("SLG_Flag", "TRUE");
}

function CopyToClipBoard(ctrl){
	if(ctrl==0){
		GEBI('SLG_source').focus();
		var tempNode = GEBI('SLG_source');
		tempNode.select();
		document.execCommand("copy");
	}else{
		GEBI('SLG_target').focus();
		var tempNode = GEBI('SLG_target');
		tempNode.select();
		document.execCommand("copy");
	}	
}

function SwitchButton(st){
	if(st==0) GEBI('SLG_switch').src='../../img/util/switch2.png';
	else 	  GEBI('SLG_switch').src='../../img/util/switch.png';
}

function langSWITCHER(){
	if(GEBI("SLG_langSrc").value!="auto"){
		var temp = GEBI("SLG_langDst").value;
		GEBI("SLG_langDst").value=GEBI("SLG_langSrc").value;
		GEBI("SLG_langSrc").value=temp;
		Switch();
	}else   SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDisabled'));

}

function SetBackWindow(){
 if(GEBI("SLG_TTS_player1")) GEBI("SLG_TTS_player1").style.display='none';
 if(GEBI("SLG_TTS_player2")) GEBI("SLG_TTS_player2").style.display='none';

	if(GEBI("SLG_backbox").checked==false){
		GEBI("SLG_back_zone").style.display="none";
		GEBI("SLG_back").style.display="none";
		if(GEBI("SLG_b_arrow"))GEBI("SLG_b_arrow").src="../../img/util/box.png";
	}else {
		GEBI("SLG_back_zone").style.display="block";
		GEBI("SLG_back").style.display="block";
		if(GEBI("SLG_b_arrow"))GEBI("SLG_b_arrow").src="../../img/util/box-on.png";
	}
	if(BACK_VIEW==1) GEBI('SLG_back').style.height='118px';
	FExtension.store.set("SLG_show_back2",GEBI("SLG_backbox").checked);
}

function SetBackWindow2(){
 if(GEBI("SLG_TTS_player1")) GEBI("SLG_TTS_player1").style.display='none';
 if(GEBI("SLG_TTS_player2")) GEBI("SLG_TTS_player2").style.display='none';
	if(GEBI("SLG_backbox").checked==false){
		GEBI("SLG_back_zone2").style.display="none";
		GEBI("SLG_back").style.display="none";
	}else {
		GEBI("SLG_back_zone2").style.display="block";
		GEBI("SLG_back").style.display="block";
	}
	BT_WINDOW();
	FExtension.store.set("SLG_show_back2",GEBI("SLG_backbox").checked);
}


function DETECT(myTransText){
	GEBI("SLG_source").focus();
 	if(GEBI("SLG_langSrc").value!="auto") GEBI("SLG_detect").style.visibility="hidden";
 	SLG_no_detect=FExtension.store.get("SLG_no_detect");
 	var SOURCELNG=localStorage["SLG_langSrc"];
 	if(FExtension.store.get("SLG_langSrc2")!=null && FExtension.store.get("SLG_langSrc2")!="") SOURCELNG=FExtension.store.get("SLG_langSrc2");
 	if(myTransText=="") myTransText = GEBI("SLG_target").value;
	myTransText=myTransText.substring(0,LIMIT); 
	var MAYAK=0;

 
	if(BOXCONTENT == myTransText){ 
		MAYAK=1;
		if(GEBI('SLlocpl').checked != true){
		        GEBI("SLG_detect").style.visibility="visible";
//			if(GEBI("SLG_langDst").value==SLG_DETECT) 
			SLG_Flip_Langs(SLG_DETECT);
//			if(SLG_WRONGLANGUAGEDETECTED==0)	GEBI("SLG_detect").innerHTML = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetected')+" "+DetLangName;
		}
	} else {
		SLG_Flip_Langs(SLG_DETECT);
//		if(SLG_WRONGLANGUAGEDETECTED==0)	GEBI("SLG_detect").innerHTML = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetected')+" "+DetLangName;
	}	

	if((GEBI('SLlocpl').checked==false || SOURCELNG=="auto") && MAYAK==0){
	   var resp = i18n_LanguageDetect(myTransText);
	   if(resp != ""){

		DetLang = resp;
		SET_PROV(1);
        	TempDetLang4History=DetLang;
		TranslateLOC(myTransText);
		GEBI("SLG_detect").style.visibility="visible";
		FExtension.store.set("SLG_langDst_name", GEBI("SLG_langDst").options[GEBI("SLG_langDst").selectedIndex].text);         
		FExtension.bg.ImTranslatorBG.SLG_Planshet_Reset();//SLG_callbackRequest2();
//		if(GEBI("SLG_langSrc").value!="auto")                        SLG_Flip_Langs(DetLang);
        	BackDetLang=DetLang;
	        SLG_DETECT=DetLang;
        	var st=0;
	        DetLang=DetLang.replace("zh-CN","zh");
		DetLang=DetLang.replace("zh-TW","zt");

	        SLG_DETECT=DetLang;
        	var thetemp=GEBI("SLG_langSrc").value;
	        if(SLG_no_detect=="true" || thetemp=="auto" || resp!=thetemp){
		   //DetLang = resp;
			var shift=0;
		        for (var i=0;i<BASELANGS.length;i++){
        			templang=BASELANGS[i].split(":");
				if(resp == templang[0]){shift=1; resp = templang[1]; DetLang = templang[0]; DetLangName = resp; break;}
	                }

	        	if(shift==0){
				GEBI("SLG_detect").innerHTML="";
				st=1;
        	        	if(GEBI("SLG_langSrc").value!="auto") DetLang=GEBI("SLG_langSrc").value;	
				else DetLang="en";
                        	//SLG_setTEMP("PROV","Google");
				SET_PROV(1);
        	                SLG_WRONGLANGUAGEDETECTED=1;
				//SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extnotsupported'));
	      	   	} else SLG_WRONGLANGUAGEDETECTED=0;
			if(st==0){
//                	        if(GEBI("SLG_langSrc").value!="auto") SLG_Flip_Langs(DetLang);
				GEBI("SLG_detect").style.visibility="visible";
				GEBI("SLG_detect").innerHTML = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetected')+" "+resp;
			}
	        	if(thetemp=="auto") GEBI("SLG_langSrc").value="auto";
		}
	    } else {
		var big5 = DetectBig5(myTransText);
		if(big5 == 0){
			setTimeout(function(){
				if(DET==0) DODetection(myTransText,0);
				else       SLDetectPATCH(myTransText);		
			}, 50);
		}else{
			SLDetectPATCH(myTransText);		
		}

		setTimeout(function(){
		     	if(GEBI('SLlocpl').checked==false || GEBI("SLG_langSrc").value=="auto"){
          			var OLD_FROM = GEBI("SLG_langSrc").value;
		          	if(OLD_FROM!="auto"){
            				if(DetLang==GEBI("SLG_langDst").value){
						GEBI("SLG_langDst").value=OLD_FROM;
						GEBI("SLG_langSrc").value=DetLang;
	    				}
			   	}
				var SLIDL = setInterval(function(){
					//By VK - only in this version
					//if(DetLang!="" && DetLang!="zh-CN") {
					if(DetLang!="") {
						SET_PROV(1);
		                        	TempDetLang4History=DetLang;
						TranslateLOC(myTransText);
			        	        clearInterval(SLIDL);
						GEBI("SLG_detect").style.visibility="visible";
						FExtension.store.set("SLG_langDst_name", GEBI("SLG_langDst").options[GEBI("SLG_langDst").selectedIndex].text);         
						FExtension.bg.ImTranslatorBG.SLG_Planshet_Reset();//SLG_callbackRequest2();
//						if(GEBI("SLG_langSrc").value!="auto")                        SLG_Flip_Langs(DetLang);
	                		        BackDetLang=DetLang;
			                        SLG_DETECT=DetLang;
						DetLang="";
						SLG_BLOCK_OBJECTS();
					} 
				},50);
				
			}else{
			 	TranslateLOC(myTransText);
		       	}
		       	
		}, 1250);
		
	    }
   } else { 
        if(SLG_WRONGLANGUAGEDETECTED==1){
		//SLG_setTEMP("PROV","Google"); 
		SET_PROV(1);
		for(var i=0; i<LISTofPR.length; i++){
	 		if(GEBI("SLG_P"+i).title.toLowerCase() == "google"){GEBI("SLG_P"+i).className="SLG_LABLE";}
		}
	}
	TranslateLOC(myTransText);
   }
// setTimeout(function(){LTR_RTL("SLG_source")},250); 
  
}



function LOADBackTranslate(myTransText){
     if(SLG_WRONGLANGUAGEDETECTED==0){
	if(myTransText=="") myTransText = GEBI("SLG_target").value;
	myTransText=myTransText.substring(0,LIMIT); 
	setTimeout(function(){
		BackTranslateLOC(myTransText);		
	}, 500);                  
     }	
}

function truncStrByWord(str, length){
	if(str!="undefined"){
		if(str.length>25){
			length=length-25;
			var thestr=str;
			if (str.length > length) {
				str = str.substring (0, length);
				str = str.replace(new RegExp("/(.{1,"+length+"})\b.*/"), "$1")    // VK - cuts str to max length without splitting words.
				var str2 = thestr.substring(length, (length+25));
				var tempstr=str2.split(" ");
				var tmp="";
				for (var i=0; i<tempstr.length-1; i++){
					tmp = tmp+tempstr[i]+" ";
				} 
				str=str+tmp;
			}
		} else 
			str = str+" ";
	}
	return str;
}


function DODetection(myTransText,st) {
  if(st==0){
   GEBI("SLG_detect").style.visibility="hidden";
   GEBI("SLG_detect").innerHTML = "";
  }
  if(myTransText=="") myTransText = GEBI("SLG_source").value;

  if(myTransText!=""){

    newTEXT = truncStrByWord(myTransText,100);

    var num = Math.floor((Math.random() * SLG_GEO.length)); 
    var theRegion = SLG_GEO[num];

    if(FExtension.store.get("SLG_DOM")!="auto") theRegion=FExtension.store.get("SLG_DOM");
    var baseUrl = 'https://translate.google.'+theRegion+'/translate_a/single';
    var SLG_Params="client=gtx&dt=t&dt=bd&dj=1&source=input&q=" + encodeURIComponent(newTEXT) + "&sl=auto&tl=en&hl=en";

	var ajaxRequest;  
	try{
		ajaxRequest = new XMLHttpRequest();
	} catch (e){
		try{
			ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			try{
				ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (e){
				SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extError1'));
				return false;
			}
		}
	}
	 ajaxRequest.onreadystatechange = function(){
	        var captcha = 0;
		if(ajaxRequest.readyState == 4){
                        var resp = ajaxRequest.responseText;

			if(resp.indexOf('CaptchaRedirect')!=-1) captcha = 1;
		        if(resp.indexOf('ld_result":{"srclangs":["')!=-1) {

                                var GDImTranslator_lang=resp.split('ld_result":{"srclangs":["');
				var GDImTranslator_lang1=GDImTranslator_lang[1].split('"');
 				resp=GDImTranslator_lang1[0];
				DetLang = resp;
				DetLang=DetLang.replace("zh-CN","zh");
				DetLang=DetLang.replace("zh-TW","zt");

	                        SLG_DETECT=DetLang;


				// NOT TRUSTED LANGUAGES
	                        if(DO_NOT_TRUST_WORD.indexOf(SLG_DETECT)!=-1 && globaltheQ==1){
					SLDetector(myTransText);
					return false;
				}	

	                        if(SLG_DETECT==DO_NOT_TRUST_TEXT){
					SLDetector(myTransText);
					return false;
				}
				//----------------------



        	                var thetemp=GEBI("SLG_langSrc").value;

		                CNTR('2311',DetLang+"/"+DetLang, newTEXT.length);

 				 if(SLG_no_detect=="true" || thetemp=="auto" || resp!=thetemp){
				   //DetLang = resp;


				   resp = resp.replace("or-IN","or");
				   resp = resp.replace("ku-Latn","ku");
				   resp = resp.replace("ku-Arab","ckb");
				   resp = resp.replace("sr-Latn-RS","sr-Latn");  

				   if(GEBI("SLG_langDst").value == "tlsl") resp = resp.replace("tl","tlsl");
				   if(GEBI("SLG_langDst").value == "srsl") resp = resp.replace("sr","srsl");
				   DetLang = resp;

				   var shift=0;
	                           for (var i=0;i<BASELANGS.length;i++){
        	                        templang=BASELANGS[i].split(":");
					if(resp == templang[0]){shift=1; resp = templang[1]; DetLang = templang[0]; DetLangName = resp; break;}
                        	   }


	                       	   if(shift==0){
					GEBI("SLG_detect").innerHTML="";
					st=1;
					SLG_Google_Only(); 
                                        SLG_WRONGLANGUAGEDETECTED=1;
	                	   } else SLG_WRONGLANGUAGEDETECTED=0;
	                           SLG_DETECT=DetLang;
				   if(st==0){
//                                    if(GEBI("SLG_langSrc").value!="auto") SLG_Flip_Langs(DetLang);
				    GEBI("SLG_detect").style.visibility="visible";
				    GEBI("SLG_detect").innerHTML = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetected')+" "+resp;
				   }
	                           if(thetemp=="auto") GEBI("SLG_langSrc").value="auto";
				 }  

			} else 	SLDetectPATCH(myTransText);
		}
	}
	baseUrl = baseUrl +"?"+ SLG_Params;
	ajaxRequest.open("GET", baseUrl, true);
        ajaxRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	ajaxRequest.send(SLG_Params);               	
  }
}                                 





function SLG_Flip_Langs(lng){
	if(GEBI("SLG_langSrc").value != "auto" && GEBI('SLlocpl').checked==false){
	  lng = lng.replace("or-IN","or")
	  lng = lng.replace("ku-Latn","ku")
	  lng = lng.replace("ku-Arab","ckb")
	  lng = lng.replace("sr-Latn-RS","sr-Latn")  
	  if(GEBI("SLG_langDst").value == "tlsl" && lng == "tl") lng = "tlsl";
	  if(GEBI("SLG_langDst").value == "srsl" && lng == "sr") lng = "srsl";
	  if(GEBI("SLG_langDst").value == "tl" && lng == "tlsl") lng = "tl";
	  if(GEBI("SLG_langDst").value == "sr" && lng == "srsl") lng = "sr";

	  if(GEBI("SLG_langDst").value == lng){
	      	var tmp = GEBI("SLG_langDst").value;
	      	GEBI("SLG_langDst").value = GEBI("SLG_langSrc").value;
      	      	GEBI("SLG_langSrc").value = tmp;
      	      	FExtension.store.set("SLG_langDst2", GEBI("SLG_langDst").value);
	  }
	}
	for (var i=0;i<BASELANGS.length;i++){
       		templang=BASELANGS[i].split(":");
		if(lng == templang[0]){DetLangName = templang[1]; break;}
	}

	GEBI("SLG_detect").innerHTML = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetected')+" "+DetLangName;
	SET_PROV(0);   
}

function SLDetectPATCH(theText){
        SLDetector(theText);
	GEBI("SLG_detect").innerHTML="";
}

function SLDetector (text){
  	var theLIMIT = 100;
  	var newTEXT = truncStrByWord(text,theLIMIT);
        var fr = GEBI('SLG_langSrc').value;
	if(fr=="auto") fr="*a";
        CNTRP('2311',fr+"/"+GEBI('SLG_langDst').value, newTEXT.length);
	var SLDImTranslator_url = ImTranslator_theurl+"ld.asp?tr=pl&text="+encodeURIComponent(newTEXT);
	if(text=="") text = GEBI("SLG_source").value;
		var ajaxRequest;  
		try{
			ajaxRequest = new XMLHttpRequest();
		} catch (e){
			try{
				ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
				try{
					ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (e){
					SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extError1'));
					return false;
				}
			}
		}
		ajaxRequest.onreadystatechange = function(){
			if(ajaxRequest.readyState == 4){
                        	var tmp = ajaxRequest.responseText;
                        	tmp = tmp.replace("zh","zh-CN");
                        	tmp = tmp.replace("zt","zh-TW");
				if(tmp.indexOf("#|#")!=-1){
				    var tmp2 = tmp.replace("#|#","");
		                    DetLang="en";
        		            if(tmp2.length>0 && tmp2.length<7) DetLang=tmp2;

					   DetLang = DetLang.replace("or-IN","or");
					   DetLang = DetLang.replace("ku-Latn","ku");
					   DetLang = DetLang.replace("ku-Arab","ckb");
					   DetLang = DetLang.replace("sr-Latn-RS","sr-Latn");  
					   if(GEBI("SLG_langDst").value == "tlsl") DetLang = DetLang.replace("tl","tlsl");
					   if(GEBI("SLG_langDst").value == "srsl") DetLang = DetLang.replace("sr","srsl");
					   if(GEBI("SLG_langSrc").value == "tlsl") DetLang = DetLang.replace("tl","tlsl");
					   if(GEBI("SLG_langSrc").value == "srsl") DetLang = DetLang.replace("sr","srsl");


                    				var shift=0;
		                	        for (var i=0;i<BASELANGS.length;i++){
        		                	        var templang=BASELANGS[i].split(":");
							if(DetLang == templang[0]){ shift=1; DetLang = templang[0]; DetLangName = templang[1]; break;}
		                	       	}
	                                        
			                       	if(shift==0){
							GEBI("SLG_detect").innerText="";
							SLG_Google_Only();
		                                        SLG_WRONGLANGUAGEDETECTED=1;
	                			} else {
							SLG_WRONGLANGUAGEDETECTED=0;
							GEBI("SLG_detect").style.visibility="visible";
							GEBI("SLG_detect").innerHTML = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetected')+" "+DetLangName;
						}


			    	} else DetLang="en";
                        	//DetLang = DetLang.replace("zh-TW","zt");
                        	//DetLang = DetLang.replace("zh-CN","zh");
	                        SLG_DETECT=DetLang;
               			SLG_BLOCK_OBJECTS();
				SET_PROV(1);
			}
		}
		ajaxRequest.open("POST", SLDImTranslator_url, true);
		ajaxRequest.send(null);                          
}





function TranslateLOC(myTransText) {

	SLG_Google_Only();
        TR_WINDOW();
        if(SLG_getTEMP("PROV")=="" || SLG_getTEMP("PROV")=="undefined") PROV="Google";
        else PROV=SLG_getTEMP("PROV");

        SET_PROV(1);

	if(ListProviders=="" && localStorage["SLG_other_gt"]=="1") NoProvidersAlert();
	else {
           var STATUS = DETERMIN_IF_LANGUAGE_IS_AVAILABLE();
	   if(STATUS == 0 && localStorage["SLG_other_gt"]=="0") NoProvidersAlert();
	   else {



	GEBI("SLG_target").value="";
	if(GEBI("SLG_backbox").checked==true)	GEBI("SLG_back").value="";


	if(GEBI("SLG_langSrc").value=="")GEBI("SLG_langSrc").value=localStorage["SLG_langSrc"];
	if(GEBI("SLG_langDst").value=="")GEBI("SLG_langDst").value=localStorage["SLG_langDst"];



	var mySourceLang = GEBI("SLG_langSrc").value;
	var myTargetLang = GEBI("SLG_langDst").value;

	if(myTransText=="") myTransText = GEBI("SLG_source").value;

	if(myTransText!=""){
	        myTransText=myTransText.trim();
		GEBI("SLG_source").value = myTransText;
	}
        BOXCONTENT = myTransText;
        myTransText = myTransText.replace(/\t/g,"");

	if(myTransText!=""){

             SLG_SAVE_FAVORITE_LANGUAGES(myTargetLang)
	     myTransText = myTransText.replace(/\"/ig,"'");
	     myTransText = myTransText.replace(/\''/ig,"'");
	     GEBI('SLG_indicator1').style.display='block';
             var num = Math.floor((Math.random() * SLG_GEO.length)); 
	     var theRegion = SLG_GEO[num];
	     if(FExtension.store.get("SLG_DOM")!="auto") theRegion=FExtension.store.get("SLG_DOM");
	     var baseUrl ="https://translate.google."+theRegion+"/translate_a/single";

             var SrcLng = mySourceLang;

	     if(GEBI('SLlocpl').checked==false || mySourceLang=="auto") SrcLng = SLG_DETECT;

             if(SrcLng == "") SrcLng = mySourceLang;

//		        if((SrcLng=="" || SrcLng=="en") && PROV.toLowerCase()=="google") SrcLng="auto";

		        //Flip
		          if(GEBI('SLlocpl').checked==false && mySourceLang!="auto"){
		            if(DetLang==myTargetLang){
				SrcLng=myTargetLang;
                                GEBI("SLG_langSrc").value=SrcLng;
				myTargetLang=mySourceLang;
                                GEBI("SLG_langDst").value=myTargetLang;
			    }
			   }

			//Flip


	  		localStorage["SLG_langSrc2"]=GEBI('SLG_langSrc').value;
			localStorage["SLG_langDst2"]=GEBI('SLG_langDst').value;
		   	FExtension.store.set("SLG_Flag","TRUE");

	                if(PROV.toLowerCase()=="google"){
				SrcLng = SrcLng.replace("tlsl","tl");
				SrcLng = SrcLng.replace("srsl","sr");

				myTargetLang = myTargetLang.replace("tlsl","tl");
				myTargetLang = myTargetLang.replace("srsl","sr");

        	                if(SLG_WRONGLANGUAGEDETECTED==1) {SrcLng = "auto"; TempDetLang4History="auto";}
				var SLG_Params="client=gtx&dt=t&dt=bd&dj=1&source=input&q="+encodeURIComponent(myTransText)+"&sl="+SrcLng+"&tl="+myTargetLang+"&hl=en";

				SLG_SETINTERVAL_ST=0;

	                        if(myTransText.length<=LIMIT){
				  var ajaxRequest;	
				  try{
					ajaxRequest = new XMLHttpRequest();
				  } catch (e){
					try{
						ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
					} catch (e) {
						try{
							ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
						} catch (e){
							SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extError1'));
							return false;
						}
					}
				  }
        	                  SLG_TRANS_TEXT="";
				  ajaxRequest.onreadystatechange = function(){
		
					if(ajaxRequest.readyState == 4 && ajaxRequest.status == 200){
	                		  var resp = ajaxRequest.responseText;

		  			  if(resp.indexOf('{"trans":')>-1){
        	                                  var ReadyToUseGoogleText="";
                	                          var Gr1=resp.split('"trans":"');
                        	                  for(var h=1; h<Gr1.length; h++){
                                	              var Gr2 = Gr1[h].split('","orig"');
                                        	      var Gr3 = Gr2[0].replace(/\\n/ig,"\n");
	                                              Gr3 = Gr3.replace(/\\"/ig,"'");
        	       	                              Gr3 = Gr3.replace(/\\u0026/ig,"&");
               		                              Gr3 = Gr3.replace(/\\u003c/ig,"<");
               	        	                      Gr3 = Gr3.replace(/\\u003e/ig,">");
               	                	              Gr3 = Gr3.replace(/\\u0027/ig,"'");
		                        	      Gr3 = Gr3.replace(/\\u003d/ig,"=");
			                              Gr3 = Gr3.replace(/\\/g,"");

						      //Gr3 = Gr3.charAt(0).toUpperCase() + Gr3.slice(1);
                	                              ReadyToUseGoogleText=ReadyToUseGoogleText+Gr3;
                        	                  }
				                  CNTR('2321',SrcLng+"/"+myTargetLang, myTransText.length);
					          GEBI("SLG_target").value = ReadyToUseGoogleText;
                                        	  SLG_TRANS_TEXT=ReadyToUseGoogleText;
					          GEBI('SLG_indicator1').style.display='none';
				                  SLG_SETINTERVAL_ST++;

				        	  if(GEBI("SLG_backbox").checked==true) 	LOADBackTranslate("");

					          if (FExtension.store.get("SLG_TH_1")==1){

				        		var SLnow = new Date();
					        	SLnow=SLnow.toString();
					        	var TMPtime=SLnow.split(" ");
				        		var CurDT=TMPtime[1]+" "+TMPtime[2]+" "+TMPtime[3]+", "+TMPtime[4];

				        		if(mySourceLang=="auto" || TempDetLang4History!="") mySourceLang=TempDetLang4History;

                                                        myTransText=myTransText.replace(/~/ig," ");
                                                        ReadyToUseGoogleText=ReadyToUseGoogleText.replace(/~/ig," ");
							myTransText = myTransText.replace(/(<([^>]+)>)/ig, '');
							ReadyToUseGoogleText = ReadyToUseGoogleText.replace(/(<([^>]+)>)/ig, '');
							if(myTransText!=""){
						        	if(CATCHED_TEXT==0) FExtension.store.set("THE_URL", "{empty}");
					        		FExtension.store.set("SLG_History", myTransText + "~~" + ReadyToUseGoogleText + "~~" + mySourceLang + "|" + myTargetLang + "~~"+ FExtension.store.get("THE_URL") +"~~"+CurDT+"~~1~~"+PROV[0]+"^^" + FExtension.store.get("SLG_History"));
                	                                	TempDetLang4History="";
							}
						  }
					  } else SLG_OTHER_PROVIDERS(myTransText,SrcLng,myTargetLang,1);
				       } else { if(ajaxRequest.readyState == 4 && ajaxRequest.status != 200) SLG_OTHER_PROVIDERS(myTransText,SrcLng,myTargetLang,1); }
				  }

	//			baseUrl = baseUrl + "?" + SLG_Params;
				ajaxRequest.open("POST", baseUrl, true);
				ajaxRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
				ajaxRequest.send(SLG_Params);

			  } else {SLG_TRANS_TEXT="";SLG_OTHER_PROVIDERS(myTransText,SrcLng,myTargetLang,1);}

			} else {
				if(PROV.toLowerCase()=="microsoft") MS(SrcLng,myTargetLang,myTransText,1);
				else SLG_OTHER_PROVIDERS(myTransText,SrcLng,myTargetLang,1);	
			}
			LTR_RTL("SLG_target");
		}
	} // else SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Text'));
	
        SLG_BLOCK_OBJECTS();
   }
}





function SLG_OTHER_PROVIDERS(text,f,t,ind){

 if(SLG_TRANS_TEXT=="" || PROV!="Google"){
 	var ctrl = "SLG_target";
	if(ind != 1) ctrl = "SLG_back";
        BOXCONTENT = text;

        if(PROV.toLowerCase()=="yandex") { 
		if(f == "zh-CN") f = "zh";
		if(f == "jw") f = "jv";
		if(f == "iw") f = "he";
		if(f == "srsl") f = "sr";
		if(f == "tlsl") f = "tl";

		if(t == "zh-CN") t = "zh";
		if(t == "jw") t = "jv";
		if(t == "iw") t = "he";
		if(t == "srsl") t = "sr";
		if(t == "tlsl") t = "tl";

		SLG_YANDEX(f+"-"+t,text, ctrl, ind); 
		return false;
	}

	 var mySourceLang = GEBI("SLG_langSrc").value;
	 var myTargetLang = GEBI("SLG_langDst").value;

	 if(PROV.toLowerCase()=="" || PROV.toLowerCase() == "undefined" || PROV.toLowerCase() =="null") PROV = "microsoft";
	 if(f=="auto") f=SLG_DETECT;
	 if(f=="") f=mySourceLang;



				                  
	        if(PROV.toLowerCase()=="google"){ 
			if(ind==1) CNTRP('2321',f+"/"+t, text.length);
			else  CNTRP('2321_',f+"/"+t, text.length);
		}

	        if(PROV.toLowerCase()=="microsoft"){
				if(f == "zh") f = "zh-CHS";
				if(f == "zt") f = "zh-CHT";
				if(f == "iw") f = "he";
				if(f == "sr") f = "sr-Cyrl";
			        if(f == "srsl") f = "sr-Cyrl";
				if(f == "tl") f = "fil";
				if(f == "tlsl") f = "fil";
				if(f == "hmn") f = "mww";
				if(f == "ku") f = "kmr";
				if(f == "ckb") f = "ku";

				if(t == "zh") t = "zh-CHS";
				if(t == "zt") t = "zh-CHT";
				if(t == "iw") t = "he";
				if(t == "sr") t = "sr-Cyrl";
			        if(t == "srsl") t = "sr-Cyrl";
				if(t == "tl") t = "fil";
				if(t == "tlsl") t = "fil";
				if(t == "hmn") t = "mww";
				if(t == "ku") t = "kmr";
				if(t == "ckb") t = "ku";

			text=text.replace(/</g,"< ");
			text=truncStrByWord(text,3000);
		}
		var baseUrl = ImTranslator_theurl+"dotrans.asp";
		var cgi = "dir="+f+"/"+t+"&provider="+PROV.toLowerCase()+"&text="+encodeURIComponent(text);

		var ajaxRequest;  
		try{
			ajaxRequest = new XMLHttpRequest();
		} catch (e){
			try{
				ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
				try{
					ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (e){
					SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extError1'));
					return false;
				}
			}
		}
		ajaxRequest.onreadystatechange = function(){

			if(ajaxRequest.readyState == 4){
		             var resp = ajaxRequest.responseText;

			     if(ajaxRequest.status!=200) resp=PROV + ": "+ FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),"extnotrsrv");
			     if(ajaxRequest.status==414) resp=PROV + ": "+ FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extADVstu').replace("XXX","4000");;
		             if(resp.indexOf('<#<')!=-1 || resp.indexOf('&lt;#')!=-1) resp=PROV + ": "+ FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),"extnotrsrv");
			     if(resp.indexOf("ID=V2_Json_Translate")!=-1) resp=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),"extnotrsrv");

			     //--------------------------------
                             resp=resp.replace(/\\n/g,"\r");
                             resp=resp.replace(/\\/g,"");

			     if(PROV.toLowerCase()=="google") {
		                resp=resp.replace(/\\n/g,"<br>");
			     }

			     if(PROV.toLowerCase()=="microsoft") {
				resp=resp.replace(/< /g,"<");
				resp=resp.replace(/ >/g,">");
				resp=resp.replace(/\\"/g,"'");
			     }
			     if(PROV.toLowerCase()=="translator") {
				resp=resp.replace(/&lt;/g,"<");
				resp=resp.replace(/&gt;/g,">");
			     }
                             resp=resp.replace(/\\n/ig,"\n");
			     //--------------------------------

                             GEBI(ctrl).value=resp;
			     GEBI('SLG_indicator'+ind).style.display='none';

			     if(GEBI("SLG_backbox").checked==true && ind==1) 	LOADBackTranslate(resp);

			     if(ind!=2){
			        if (FExtension.store.get("SLG_TH_1")==1){
			        	var SLnow = new Date();
			        	SLnow=SLnow.toString();
			        	var TMPtime=SLnow.split(" ");
		        		var CurDT=TMPtime[1]+" "+TMPtime[2]+" "+TMPtime[3]+", "+TMPtime[4];
		        		if(mySourceLang=="auto") mySourceLang=TempDetLang4History;

					
			        	if(CATCHED_TEXT==0) FExtension.store.set("THE_URL", "{empty}");
					setTimeout(function(){
                                                text=text.replace(/~/ig," ");
                                                resp=resp.replace(/~/ig," ");
						text = text.replace(/(<([^>]+)>)/ig, '');
						resp = resp.replace(/(<([^>]+)>)/ig, '');
						if(text!=""){
					        	FExtension.store.set("SLG_History", text + "~~" + resp + "~~" + mySourceLang + "|" + myTargetLang + "~~"+ FExtension.store.get("THE_URL") +"~~"+CurDT+"~~1~~"+PROV[0]+"^^" + FExtension.store.get("SLG_History"));
						}
					},1500);


			        }
			     }

			}
		}
		ajaxRequest.open("POST", baseUrl, true);
		ajaxRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		ajaxRequest.send(cgi); 
  }

}

function SLG_SETLOC(ob){
 return FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),ob);
}



function BackTranslateLOC(myTransText) {
 GEBI("SLG_back").value="";
 var myTargetLang = GEBI("SLG_langSrc").value;

 if(GEBI("SLG_TTS_player1")) GEBI("SLG_TTS_player1").style.display='none';
 if(GEBI("SLG_TTS_player2")) GEBI("SLG_TTS_player2").style.display='none';


 if((SLG_no_detect=="true" || GEBI("SLG_langDst").value=="auto") && BackDetLang!="")myTargetLang = BackDetLang;
 var mySourceLang = GEBI("SLG_langDst").value;
 if(myTransText=="") myTransText = GEBI("SLG_target").value;
/*
 if(GEBI("SLG_TTS_player1").style.display=='block' || GEBI("SLG_TTS_player2").style.display=='block'){
   mySourceLang=GEBI("SLG_langDst").value;
   myTargetLang=SLG_GetLangCode();
 }
*/


 if(myTransText!=""){
    GEBI('SLG_indicator2').style.display='block';
        var a=Math.floor((new Date).getTime()/36E5)^123456;
        var tk = a+"|"+Math.floor((Math.sqrt(5)-1)/2*(a^654321)%1*1048576);

	var num = Math.floor((Math.random() * SLG_GEO.length)); 
	var theRegion = SLG_GEO[num];
	if(FExtension.store.get("SLG_DOM")!="auto") theRegion=FExtension.store.get("SLG_DOM");
	var baseUrl ="https://translate.google."+theRegion+"/translate_a/single";

        myTargetLang=myTargetLang.replace("zt","zh-TW")
        mySourceLang=mySourceLang.replace("zt","zh-TW")

  if(DetLang!="") myTargetLang = DetLang;
  if((myTargetLang=="" || myTargetLang=="auto") && SLG_DETECT!="") myTargetLang = SLG_DETECT;
  if(myTargetLang == "") myTargetLang = GEBI("SLG_langDst").value;

  if(mySourceLang!=myTargetLang){

   if(PROV.toLowerCase()=="yandex"){
	if(mySourceLang == "zh-CN") mySourceLang = "zh";
	if(mySourceLang == "jw") mySourceLang = "jv";
	if(mySourceLang == "iw") mySourceLang = "he";
	if(mySourceLang == "srsl") mySourceLang = "sr";
	if(mySourceLang == "tlsl") mySourceLang = "tl";

	if(myTargetLang == "zh-CN") myTargetLang = "zh";
	if(myTargetLang == "jw") myTargetLang = "jv";
	if(myTargetLang == "iw") myTargetLang = "he";
	if(myTargetLang == "srsl") myTargetLang = "sr";
	if(myTargetLang == "tlsl") myTargetLang = "tl";

        SLG_YANDEX_BACK(mySourceLang+"-"+myTargetLang, myTransText);
	return false;
   }

   if(PROV.toLowerCase()=="google"){


//     var SLG_Params = "hl=en&langpair="+mySourceLang+"|"+myTargetLang+"&q="+encodeURIComponent(myTransText)+"&tbb=1&ie=UTF-8&oe=UTF-8&tk=" + tk;
     var SLG_Params="client=gtx&dt=t&dt=bd&dj=1&source=input&q="+encodeURIComponent(myTransText)+"&sl="+mySourceLang+"&tl="+myTargetLang+"&hl=en";


     if(myTransText.length<=LIMIT){
	var ajaxRequest;	
	try{
		ajaxRequest = new XMLHttpRequest();
	} catch (e){
		try{
			ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			try{
				ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (e){
				SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extError1'));
				return false;
			}
		}
	}

	ajaxRequest.onreadystatechange = function(){
		if(ajaxRequest.readyState == 4){
                   var resp = ajaxRequest.responseText;
	  			  if(resp.indexOf('{"trans":')>-1){
                                          var ReadyToUseGoogleText="";
                                          var Gr1=resp.split('"trans":"');
                                          for(var h=1; h<Gr1.length; h++){
                                              var Gr2 = Gr1[h].split('","orig"');
                                              var Gr3 = Gr2[0].replace(/\\n/ig,"\n");

                                              Gr3 = Gr3.replace(/\\"/ig,"'");
               	                              Gr3 = Gr3.replace(/\\u0026/ig,"&");
               	                              Gr3 = Gr3.replace(/\\u003c/ig,"<");
               	                              Gr3 = Gr3.replace(/\\u003e/ig,">");
               	                              Gr3 = Gr3.replace(/\\u0027/ig,"'");
		                              Gr3 = Gr3.replace(/\\u003d/ig,"=");
		                              Gr3 = Gr3.replace(/\\t/ig," ");


                                              ReadyToUseGoogleText=ReadyToUseGoogleText+Gr3;
                                          }

					  CNTR('2321_',mySourceLang+"/"+myTargetLang, myTransText.length);

			GEBI("SLG_back").value = ReadyToUseGoogleText;
			GEBI('SLG_indicator2').style.display='none';
		    } else {SLG_TRANS_TEXT="";SLG_OTHER_PROVIDERS(myTransText,mySourceLang,myTargetLang,2);}

		}
	}
	//baseUrl = baseUrl + "?" + SLG_Params;

	ajaxRequest.open("POST", baseUrl, true);
	ajaxRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	ajaxRequest.send(SLG_Params);

     } else {	   
	   SLG_TRANS_TEXT="";SLG_OTHER_PROVIDERS(myTransText,mySourceLang,myTargetLang,2);
     }
   } else {
	if(PROV.toLowerCase()=="microsoft") MS(mySourceLang,myTargetLang,myTransText,2);
	else { SLG_TRANS_TEXT="";SLG_OTHER_PROVIDERS(myTransText,mySourceLang,myTargetLang,2);}
        //LTR_RTL("SLG_back");
   }
  }else{
	 GEBI("SLG_back").value=myTransText;
         GEBI("SLG_indicator2").style.display='none';
  }
 }
}



function LTR_RTL(ctrl){

	if(ctrl=="SLG_source") 
		var myLang = GEBI("SLG_langSrc").value;
	if(ctrl=="SLG_target")
		var myLang = GEBI("SLG_langDst").value;
	if(ctrl=="SLG_back")   
		var myLang = GEBI("SLG_langSrc").value;
	if(SLG_no_detect=="true" || GEBI("SLG_langSrc").value=="auto") MORE_LTR_RTL();

	GEBI(ctrl).dir="ltr";
	if(myLang=="ar" || myLang=="iw" || myLang=="fa" || myLang=="yi" || myLang=="ur" || myLang=="ps" || myLang=="sd" || myLang=="ckb" || myLang=="ug" || myLang=="dv" || myLang=="prs") GEBI(ctrl).dir="rtl";
}

function MORE_LTR_RTL(){
 	var myLang = DetLang; 	
	GEBI("SLG_source").dir="ltr";
	if(myLang=="ar" || myLang=="iw" || myLang=="fa" || myLang=="yi" || myLang=="ur" || myLang=="ps" || myLang=="sd" || myLang=="ckb" || myLang=="ug" || myLang=="dv" || myLang=="prs") GEBI("SLG_source").dir="rtl";

	myLang = GEBI("SLG_langDst").value;
	GEBI("SLG_target").dir="ltr";
	if(myLang=="ar" || myLang=="iw" || myLang=="fa" || myLang=="yi" || myLang=="ur" || myLang=="ps" || myLang=="sd" || myLang=="ckb" || myLang=="ug" || myLang=="dv" || myLang=="prs") GEBI("SLG_target").dir="rtl";

	myLang = DetLang;
	GEBI("SLG_back").dir="ltr";
	if(myLang=="ar" || myLang=="iw" || myLang=="fa" || myLang=="yi" || myLang=="ur" || myLang=="ps" || myLang=="sd" || myLang=="ckb" || myLang=="ug" || myLang=="dv" || myLang=="prs") GEBI("SLG_back").dir="rtl";
}


function SLG_MEDIA_HOST(dir, text){
    if(dir=="")dir="en/es";
    var tmpdir=dir.split("/");
    if(tmpdir[0]=="es" || tmpdir[0]=="fr" || tmpdir[0]=="it" || tmpdir[0]=="pt") text=unescape(encodeURIComponent(text));
    var submitForm = getNewSubmitForm();

    createNewFormElement(submitForm, "text", text);
    createNewFormElement(submitForm, "url", "FF");
    createNewFormElement(submitForm, "dir", dir);
    submitForm.action= "https://text-to-speech.imtranslator.net";
    submitForm.setAttribute('target', '_blank');
    submitForm.submit();
}



function getNewSubmitForm(){
	var submitForm = document.createElement("FORM");
	document.body.appendChild(submitForm);
	submitForm.method = "POST";
	return submitForm;
}

function createNewFormElement(inputForm, elementName, elementValue){
	try{
		var newElement = document.createElement("<input name='"+elementName+"' type='hidden'>");
	}catch(err){   
		var newElement = document.createElement('input');
		newElement.setAttribute('type','hidden');
		newElement.setAttribute('name',elementName);
	} 
	inputForm.appendChild(newElement);
	newElement.value = elementValue;
	return newElement;
}

function SLShowHideAlert100(act,box){
	GEBI('SLG_posterSRC').style.display='none';
	GEBI('SLG_posterDST').style.display='none';
	var id = "SLG_poster"+box;
	GEBI(id).style.display=act; 
	if(GEBI(id).style.display=="block"){
		var obw = GEBI(id).clientWidth;
		GEBI(id).style.marginLeft=(GLOBAL_WIDTH/2-obw/2)+"px";
		var obh = GEBI(id).clientHeight;
		GEBI(id).style.marginTop=(GLOBAL_HEIGHT/2-obh/2-50)+"px";
	}
}

function SLG_GotIt(box) {

if(box==1 || box=="SRC")box="SRC";
else      box="DST";
if(CLOSER==0 || localStorage["SLG_GotIt"]!="1"){
 var SLG_to="es";
 var SLG_TTS_box="SLG_target";
 var SLG_TTS_boxNumber=2;
 SLG_to = DetLang;
 if(box=="SRC"){ SLG_TTS_box="SLG_source"; SLG_TTS_boxNumber=1; SLG_to=GEBI('SLG_langSrc').value;}
 var text = GEBI(SLG_TTS_box).value;
 if(box=="SRC") {
  	if(DET==0) TTSDODetection(text,0);
  	else       SLDetectPATCH(text);
 }
  setTimeout(function(){
   SLG_to = TTSDetLang;
   var ALL_TTS = G_TTS + SLG_TTS;
   if(ALL_TTS.indexOf(SLG_to)==-1){
	 SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Voice')); return false;
   }else{
	 text=SetTTStextLimit(text,GTTS_length);REMOTE_Voice(SLG_to,text,SLG_TTS_boxNumber);
   }
  }, 1000);
}
}

function SLG_GotItStorage(box) { 
//VK: Speaks twice
// SLG_GotIt(box);

 SLShowHideAlert100("none",box);
 localStorage["SLG_GotIt"]=1;
}


function SLG_setTEMP(cname, cvalue) {
    localStorage["PLT_"+cname] = cvalue;
}



function SLG_getTEMP(cname) {
    var cvalue = localStorage["PLT_"+cname];
    if(cvalue != "") return cvalue;
    else return "";
}


function SLG_alert(txt){
 GEBI('SLG_alert').style.display="block";
 GEBI("SLalertcont").innerText=txt;
	if(GEBI('SLG_alert').style.display=="block"){
		var obw = GEBI('SLG_alert').clientWidth;
		GEBI('SLG_alert').style.marginLeft=(GLOBAL_WIDTH/2-obw/2)+"px";
		var obh = GEBI('SLG_alert').clientHeight;
		GEBI('SLG_alert').style.marginTop=(GLOBAL_HEIGHT/2-obh/2-50)+"px";
	}
}

function SLShowHideAlert(){
 GEBI('SLG_alert').style.display='none'; 
}

function SLG_HK_TRANSLATE(){
                SLG_TEMPKEYSTRING=SLG_TEMPKEYSTRING.replace("18:|","Alt:|");
                SLG_TEMPKEYSTRING=SLG_TEMPKEYSTRING.replace("17:|","Ctrl:|");
                SLG_TEMPKEYSTRING=SLG_TEMPKEYSTRING.replace("16:|","Shift:|");
		var TMP1= SLG_TEMPKEYSTRING.split(":|");
		var NUM = TMP1.length-1;
		var HOTKEY = Array();
		var HOTKEYSline="";
		var cnt=0;
		for(var x=0; x<NUM; x++){
		    if(TMP1[x]!="Alt" && TMP1[x]!="Ctrl" && TMP1[x]!="Shift") HOTKEY[x]=String.fromCharCode(TMP1[x]);
		    else HOTKEY[x]=TMP1[x];
                    HOTKEYSline=HOTKEYSline+HOTKEY[x]+":|";
                    if(TMP1[x]=="Alt")cnt++;
                    if(TMP1[x]=="Ctrl")cnt++;
		}
		if(cnt==2){
                  HOTKEYSline=HOTKEYSline.replace("Alt:|","");
                  HOTKEYSline=HOTKEYSline.replace("Ctrl:|","");
                  HOTKEYSline="Ctrl:|Alt:|"+HOTKEYSline;
		}
		SLG_KEYCOUNT = { length: 0 }; SLG_KEYSTRING="";SLG_TEMPKEYSTRING="";
		return HOTKEYSline.toLowerCase();
}

function LOCcontrol(st){
    GEBI("SLlocbox").src="../../img/util/box.png";
    if(GEBI('SLlocpl').checked == true){SLG_DETECT=""; GEBI("SLlocbox").src="../../img/util/box-on.png";}
    if(st==0) SLG_setTEMP("LOC",String(GEBI('SLlocpl').checked));
    BOXCONTENT = "";
}



function GoToDictionary(){

	   var s=GEBI("SLG_source").value.replace(/(^[\s]+|[\s]+$)/g, '');
	   s=encodeURIComponent(s).replace(/%0A/ig, " ");
	   s=decodeURIComponent(s);
	   var theQ=s.split(" ").length;
	   if(s.match(/[-/‧·﹕﹗！：，。﹖？:-?!.,:{-~!"^_`\[\]]/g)!=null) theQ=100;

	   if(localStorage["SLG_dict"]=="false") theQ=100;
	   if(s.match(/[\u3400-\u9FBF]/) && s.length>1) theQ=100;
    	   if(FExtension.bg.ImTranslatorBG.DIC_TRIGGER != 0) theQ = 100;
	   FExtension.store.set("SLG_SavedText_gt",s);
	   FExtension.store.set("SLG_Flag","TRUE");

	   if(theQ==1){
	     var TEXT = s;
	   }else{
	     var TEXT = SetTextLimit(s,50);
	   }
	   window.location.href="../../html/popup/dictionary.html?text="+encodeURIComponent(TEXT);
}


function SetTextLimit(text,limit){
 text=text.replace(/(\r\n|\n|\r)/gm,"");
 if(text.indexOf(" ")>-1 && text.length>limit){
   var texttmp=text.split(" ");
   var OutPut="";
   var OutPut_="";
   for(var i=0; i<texttmp.length; i++){
     OutPut=OutPut+texttmp[i]+" ";
     if(OutPut.length>limit) break;
     else OutPut_=OutPut_+texttmp[i]+" ";
   }
 }else OutPut_ = text.substring(0,limit);
 return(OutPut_);
}


function MS(f,t,text,ind){
 SLG_OTHER_PROVIDERS(text,f,t,ind);
}


function SLG_VIEW_manu(st){
        if(st==0) GEBI('SLG_view_menu').style.display='none';
	else GEBI('SLG_view_menu').style.display='block';
}

function SLG_VIEW_manu2(st){
        if(st==0) GEBI('SLG_view_menu2').style.display='none';
	else GEBI('SLG_view_menu2').style.display='block';
}


function SLG_DONATE_manu(st){
        if(st==0) GEBI('SLG_donate_menu').style.display='none';
	else GEBI('SLG_donate_menu').style.display='block';
}

function SLG_DONATE_links(st){
	var link = 'https://imtranslator.net'+_CGI+'&a=0'; 
 	switch(st){
		case 1: link = 'https://imtranslator.net'+_CGI+'&a=5'; break;
		case 2: link = 'https://imtranslator.net'+_CGI+'&a=10'; break;
		case 3: link = 'https://imtranslator.net'+_CGI+'&a=20'; break;
		case 4: link = 'https://imtranslator.net'+_CGI+'&a=0'; break;
	}
	SLG_OPEN_WINDOW(link);
}


function SLG_VIEW_link(st){
  	SLG_OPEN_WINDOW("https://chrome.google.com/webstore/detail/translation-comparison/kicpmhgmcajloefloefojbfdmenhmhjf?utm_source=chrome-ntp-icon");
}

function SLG_OPEN_WINDOW(url){
        window.open(url, '_blank', 'toolbar=yes, location=yes, status=yes, menubar=yes, scrollbars=yes');
}

function BT_WINDOW(){
	REMOTE_Voice_Close ();
 	GEBI('SLG_TR').className="SLG_TABback SLG_TAB_OFFback";
 	GEBI('SLG_BT').className="SLG_TABback SLG_TAB_back";
 	GEBI('SLG_BT').style.borderLeft="0px";
 	GEBI('SLG_BT').style.borderRight="1px solid #BDBDBD";
	GEBI('SLG_back_zone2').style.display="block";
	GEBI('SLG_back_zone2').style.display="absolute";
	GEBI('SLG_back').style.display="block";
//	GEBI('SLG_back').style.marginTop="-156px";
	GEBI('SLG_back').style.marginLeft="-16px";
//	GEBI('SLG_back').style.height="115px";
	GEBI('SLG_back').style.border="0px";
	//GEBI('SLG_backbox').checked="true";
	GEBI('SLG_footer').style.marginTop="34px";
	GEBI('SLG_icons_target').style.visibility='hidden';
        LOADBackTranslate("");
//	FExtension.store.set("SLG_show_back2",GEBI("SLG_backbox").checked);

}
function TR_WINDOW(){
	if(GEBI('SLG_TR')){
	 	GEBI('SLG_TR').className="SLG_TABback SLG_TAB_back";
	 	GEBI('SLG_BT').className="SLG_TABback SLG_TAB_OFFback";
 		GEBI('SLG_TR').style.borderRight="1px solid #BDBDBD";
		GEBI('SLG_back_zone2').style.display="none";
		//GEBI('SLG_backbox').checked="false";
		GEBI('SLG_footer').style.marginTop="5px";
		GEBI('SLG_icons_target').style.visibility='visible';
	//	FExtension.store.set("SLG_show_back2",GEBI("SLG_backbox").checked);
	}
}

function SAVEtheSTATE(){
SLG_WRONGLANGUAGEDETECTED=0;
// var txt = GEBI("SLG_source").value.replace(/'/ig,'"');
 var txt = GEBI("SLG_source").value;
 var userText = txt.replace(/^\s+/, '').replace(/\s+$/, '');
 if (userText === '') txt = "";
 if(txt != ""){
	 txt=txt.trim();
	 FExtension.store.set("SLG_SavedText_gt",txt);
 } else ClearSource();
}


function SLG_YANDEX(dir, text, ctrl, ind){
 	 var ctrl = "SLG_target";
	 if(ind != 1) ctrl = "SLG_back";
         if(text.length<=LIMIT) text = truncStrByWord(text,LIMIT);

	getYSID(0);
	setTimeout(function(){
	    YSLIDL = setInterval(function(){
		if(YSIDstatus === true) {
			clearInterval(YSLIDL);
			YSLIDL="";
			getY_TRANSLATION(dir,text, ctrl, ind);
		} 
	    },5);  
       	},5);  		
}

function getYSID(st){
 	var YK = FExtension.store.get("SLG_YKEY");
	YSIDold = YK;
	if(st==1) YK=0;
	if(YK==0) {
	       	var baseUrl="https://translate.yandex.net/website-widget/v1/widget.js?widgetId=ytWidget&pageLang=en&widgetTheme=light&autoMode=false";
		var ajaxRequest;	
		try{
			ajaxRequest = new XMLHttpRequest();
		} catch (e){
			try{
				ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
				try{
					ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (e){
					return false;
				}
			}
		}
		ajaxRequest.onreadystatechange = function(){
		        var resp = "";
			if(ajaxRequest.readyState == 4 && ajaxRequest.status == 200){
		            var resp = ajaxRequest.responseText.match(/sid\:\s\'[0-9a-f\.]+/);
	                    if (resp && resp[0] && resp[0].length > 7) {
               		        YSID = resp[0].substring(6);

				var H = FExtension.store.get("SLG_YHIST");
				if(H == "") H="First key";
				else H = H +"; Rekey";
				var K = "***"+YSID.substring(45);
				FExtension.store.set("SLG_YHIST",H+" -> "+K);
				FExtension.store.set("SLG_YKEY", YSID);
	                        YSIDstatus = true;
               		    } else {
				var H = FExtension.store.get("SLG_YHIST");
				FExtension.store.set("SLG_YHIST",H+"; KEY not found");
	                        YSIDstatus = false;
				FExtension.store.set("SLG_YKEY", "0");
               		    }
			}else { 
				if(ajaxRequest.readyState == 4){
				    var msg = "Yandex: "+FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extnotrsrv');
				    GEBI("SLG_target").value=msg;
	     			    GEBI('SLG_indicator1').style.display='none';
				}
			}
		}
		ajaxRequest.open("GET", baseUrl, true);
		ajaxRequest.setRequestHeader("Access-Control-Allow-Headers", "*");
		ajaxRequest.setRequestHeader("Access-Control-Allow-Origin", "null");
		ajaxRequest.send();
	  } else {
		YSID = FExtension.store.get("SLG_YKEY");
                YSIDstatus = true;
	  }
}


function getY_TRANSLATION(dir, text, ctrl, ind){
	dir = dir.replace("iw","he");
        var tmp=dir.split("_");
	var mySourceLang=tmp[0];
	var myTargetLang=tmp[1];

  	var baseUrl="https://translate.yandex.net/api/v1/tr.json/translate?srv=tr-url-widget&id=" + YSID + "-0-0&format=html&lang=" + dir + "&text="+ encodeURIComponent(text);

	var ajaxRequest;	
	try{
		ajaxRequest = new XMLHttpRequest();
	} catch (e){
		try{
			ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			try{
				ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (e){
				return false;
			}
		}
	}
	ajaxRequest.onreadystatechange = function(){
	        var resp = "";
		if(ajaxRequest.readyState == 4 && ajaxRequest.status == 200){
	            var resp = ajaxRequest.responseText;

		    resp = unescape(resp);
        	    resp=resp.replace(/\\"/ig,"'");
        	    if(resp.indexOf('text":["')!=-1){
	    		var R1 = resp.split('text":["');
		    	var R2 = R1[1].split('"');
	    		var R3 = R2[0];
       		        R3 = R3.replace(/\\n/ig,"\n");
                        GEBI(ctrl).value=R3;
                        text = text.trim();
			var theQ = text.split(" ").length;
			if (theQ==1) CNTR('2332',mySourceLang.replace("-","/"), text.length);
			else CNTR('2322',mySourceLang.replace("-","/"), text.length);

	     	        GEBI('SLG_indicator'+ind).style.display='none';
	                if(GEBI("SLG_backbox").checked==true && ind==1) 	LOADBackTranslate(R3);

			

			     if(ind!=2){
			        if (FExtension.store.get("SLG_TH_1")==1){
			        	var SLnow = new Date();
			        	SLnow=SLnow.toString();
			        	var TMPtime=SLnow.split(" ");
		        		var CurDT=TMPtime[1]+" "+TMPtime[2]+" "+TMPtime[3]+", "+TMPtime[4];
		        		if(mySourceLang=="auto") mySourceLang=TempDetLang4History;

					
			        	if(CATCHED_TEXT==0) FExtension.store.set("THE_URL", "{empty}");
					setTimeout(function(){
                                                text=text.replace(/~/ig," ");
                                                R3=R3.replace(/~/ig," ");
						text = text.replace(/(<([^>]+)>)/ig, '');
						R3 = R3.replace(/(<([^>]+)>)/ig, '');
                                                var t = mySourceLang.split("-");
						mySourceLang=t[0];
						myTargetLang=t[1];
				        	FExtension.store.set("SLG_History", text + "~~" + R3 + "~~" + mySourceLang + "|" + myTargetLang + "~~"+ FExtension.store.get("THE_URL") +"~~"+CurDT+"~~1~~"+PROV[0]+"^^" + FExtension.store.get("SLG_History"));
					},1500);


			        }
			     }


		   } else {
                        YSIDstatus = false;
			FExtension.store.set("SLG_YKEY", YSID);
			var H = FExtension.store.get("SLG_YHIST");
			FExtension.store.set("SLG_YHIST",H+"; Keys are equal -> yandex response: " +resp);
		    	var msg = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extnotrsrv');
			SLG_alert("Yandex: " + msg);
			GEBI("SLG_alert").style.height="185px";
			GEBI('SLG_indicator'+ind).style.display='none';
		   }
		   TRIGGER=0;
		} else {
		    if(ajaxRequest.status == 403){
			FExtension.store.set("SLG_YKEY", 0);
			YSID=0;
			if(YSID!=YSIDold){
				SLG_YANDEX(dir, text);
				var H = FExtension.store.get("SLG_YHIST");
				FExtension.store.set("SLG_YHIST",H+"; Yandex answers: #405 -> requesting a new key");
			}else{
	                        YSIDstatus = false;
				FExtension.store.set("SLG_YKEY", 0);
				YSIDold = 0;
			}
		     }else { 
			if(ajaxRequest.readyState == 4){
			    var msg = "Yandex: "+FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extnotrsrv');
			    GEBI("SLG_target").value=msg;
	     		    GEBI('SLG_indicator1').style.display='none';
			}
		    }
		}
	}
	ajaxRequest.open("GET", baseUrl, true);
	ajaxRequest.setRequestHeader("Access-Control-Allow-Headers", "*");
	ajaxRequest.setRequestHeader("Access-Control-Allow-Origin", "null");
	ajaxRequest.send();
} 

function SLG_YANDEX_BACK(dir, text){
	getYSID(0);
	setTimeout(function(){
	    var YSLIDLback = setInterval(function(){
		if(YSIDstatus === true) {
			clearInterval(YSLIDLback);
			YSLIDL="";
			getY_TRANSLATIONback(dir,text);
		} 
	    },5);  
       	},5);  		
}

function getY_TRANSLATIONback(dir, text){
	var ind=1;
       	dir = dir.replace("zh-CN","zh");
       	dir = dir.replace("jw","jv");
        dir = dir.replace("iw","he");
        var tmp=dir.split("_");
	var mySourceLang=tmp[0];
	var myTargetLang=tmp[1];
  	var baseUrl="https://translate.yandex.net/api/v1/tr.json/translate?srv=tr-url-widget&id=" + YSID + "-0-0&format=html&lang=" + dir + "&text="+ encodeURIComponent(text);
	var ajaxRequest;	
	try{
		ajaxRequest = new XMLHttpRequest();
	} catch (e){
		try{
			ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			try{
				ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (e){
				return false;
			}
		}
	}
	ajaxRequest.onreadystatechange = function(){
	        var resp = "";
		if(ajaxRequest.readyState == 4 && ajaxRequest.status == 200){
	            var resp = ajaxRequest.responseText;
		    resp = decodeURIComponent(resp);
        	    resp=resp.replace(/\\"/ig,"'");
        	    if(resp.indexOf('text":["')!=-1){

	    		var R1 = resp.split('text":["');
		    	var R2 = R1[1].split('"');
	    		var R3 = R2[0];
       		        R3 = R3.replace(/\\t/ig,"\t");
       		        R3 = R3.replace(/\\n/ig,"\n");

                        GEBI("SLG_back").value=R3;
			CNTR('2322_',mySourceLang.replace("-","/"), text.length);
			GEBI("SLG_indicator2").style.display="none";

		   } else {
                        YSIDstatus = false;
			FExtension.store.set("SLG_YKEY", YSID);
			var H = FExtension.store.get("SLG_YHIST");
			FExtension.store.set("SLG_YHIST",H+"; Keys are equal -> yandex response: " +resp);
		    	var msg = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extnotrsrv');
			SLG_alert("Yandex: " + msg);
			GEBI("SLG_alert").style.height="185px";
			GEBI('SLG_indicator2').style.display='none';
		   }
		   TRIGGER=0;
		} else {
		    if(ajaxRequest.status == 403){
			FExtension.store.set("SLG_YKEY", 0);
			YSID=0;
			if(YSID!=YSIDold){
				SLG_YANDEX(dir, text);
				var H = FExtension.store.get("SLG_YHIST");
				FExtension.store.set("SLG_YHIST",H+"; Yandex answers: #405 -> requesting a new key");
			}else{
	                        YSIDstatus = false;
				FExtension.store.set("SLG_YKEY", 0);
				YSIDold = 0;
			}
		    }
		}
	}
	ajaxRequest.open("GET", baseUrl, true);
	ajaxRequest.setRequestHeader("Access-Control-Allow-Headers", "*");
	ajaxRequest.setRequestHeader("Access-Control-Allow-Origin", "null");
	ajaxRequest.send();
} 


function TTSDODetection(myTransText,st) {
  if(st==0){
   GEBI("SLG_detect").style.visibility="hidden";
   GEBI("SLG_detect").innerHTML = "";
  }
  if(myTransText=="") myTransText = GEBI("SLG_source").value;

  if(myTransText!=""){
    BOXCONTENT = myTransText;
    newTEXT=myTransText;

    var num = Math.floor((Math.random() * SLG_GEO.length)); 
    var theRegion = SLG_GEO[num];

    if(FExtension.store.get("SLG_DOM")!="auto") theRegion=FExtension.store.get("SLG_DOM");
    var baseUrl = 'https://translate.google.'+theRegion+'/translate_a/single';
    var SLG_Params="client=gtx&dt=t&dt=bd&dj=1&source=input&q=" + encodeURIComponent(truncStrByWord(newTEXT,100)) + "&sl=auto&tl=en&hl=en";

	var ajaxRequest;  
	try{
		ajaxRequest = new XMLHttpRequest();
	} catch (e){
		try{
			ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			try{
				ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (e){
				SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extError1'));
				return false;
			}
		}
	}
	ajaxRequest.onreadystatechange = function(){
	        var captcha = 0;
		if(ajaxRequest.readyState == 4){
                        var resp = ajaxRequest.responseText;

			if(resp.indexOf('CaptchaRedirect')!=-1) captcha = 1;
		        if(resp.indexOf('ld_result":{"srclangs":["')!=-1) {

                                var GDImTranslator_lang=resp.split('ld_result":{"srclangs":["');
				var GDImTranslator_lang1=GDImTranslator_lang[1].split('"');
 				resp=GDImTranslator_lang1[0];
				DetLang = resp;
				DetLang=DetLang.replace("zh-CN","zh");
				DetLang=DetLang.replace("zh-TW","zt");

	                        SLG_DETECT=DetLang;
        	                var thetemp=GEBI("SLG_langSrc").value;

        	                if(SLG_no_detect=="") SLG_no_detect="true";
 				if(SLG_no_detect=="true" || thetemp=="auto" || resp!=thetemp){

				   // NOT TRUSTED LANGUAGES
				   globaltheQ=myTransText.trim().split(" ").length;
	                           if(DO_NOT_TRUST_WORD.indexOf(SLG_DETECT)!=-1 && globaltheQ==1){
					SLDetector(myTransText);
					return false;
				   }	
	                           if(SLG_DETECT==DO_NOT_TRUST_TEXT){
					SLDetector(myTransText);
					return false;
				   }
				   //----------------------


				   DetLang = resp;

				   var shift=0;
	                           for (var i=0;i<BASELANGS.length;i++){
        	                        templang=BASELANGS[i].split(":");
					if(resp == templang[0]){shift=1; resp = templang[1]; DetLang = templang[0]; DetLangName = resp; break;}
                        	   }

	                       	   if(shift==0){
					GEBI("SLG_detect").innerHTML="";
					st=1;
					if(GEBI("SLG_langSrc").value!="auto") DetLang=GEBI("SLG_langSrc").value;	
					else DetLang="en";
                                        SLG_setTEMP("PROV","Google");
					SET_PROV(1);
                                        SLG_WRONGLANGUAGEDETECTED=1;

					//SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extnotsupported'));
	                	   } else SLG_WRONGLANGUAGEDETECTED=0;

				   if(st==0){
				    GEBI("SLG_detect").style.visibility="visible";
				    GEBI("SLG_detect").innerHTML = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetected')+" "+resp;
				   }
	                           if(thetemp=="auto") GEBI("SLG_langSrc").value="auto";
				 }

			} else 	SLDetectPATCH(myTransText);
		}
	}
	baseUrl = baseUrl +"?"+ SLG_Params;
	ajaxRequest.open("GET", baseUrl, true);
        ajaxRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	ajaxRequest.send(SLG_Params);         
 }                                
}                                 

function ACTIVATE_THEME(st){
 	if(st==1){
		var bg="#191919";
		var clr="#BF7D44";
		var clr_deact="#BDBDBD";
		GEBI("SLG_body").style.filter=SLG_DARK;
		GEBI("SLG_body").style.background=bg;
		if(GEBI("SLG_P0").className!="SLG_LABLE_DEACT") GEBI("SLG_P0").style.color=clr;
		else GEBI("SLG_P0").style.color=clr_deact;
		if(localStorage["SLG_other_gt"]=="1"){   
			if(GEBI("SLG_P1").className!="SLG_LABLE_DEACT") GEBI("SLG_P1").style.color=clr;		
			else GEBI("SLG_P1").style.color=clr_deact;
			if(GEBI("SLG_P2").className!="SLG_LABLE_DEACT") GEBI("SLG_P2").style.color=clr;
			else GEBI("SLG_P2").style.color=clr_deact;
			if(GEBI("SLG_P3").className!="SLG_LABLE_DEACT") GEBI("SLG_P3").style.color=clr;
			else GEBI("SLG_P3").style.color=clr_deact;

		}
		GEBI("SLG_trans_button").style.filter=SLG_DARK;
                if(GEBI("SLG_TR")) GEBI("SLG_TR").style.color=clr;
                if(GEBI("SLG_BT")) GEBI("SLG_BT").style.color=clr;
                GEBI("SLG_detect").style.color=clr;
		GEBI("SLG_h1").style.color=clr;
		GEBI("SLG_h3").style.color=clr;
		GEBI("SLG_tab1").style.color=clr;
		GEBI("SLG_tab2").style.color=clr;
		var OPT = document.getElementsByTagName("option");
		for(var i=0; i<OPT.length; i++){
			OPT[i].setAttribute("style", "background:"+bg+";color:#fff;");
		}   
                if(GEBI("SLG_CloseAlertBTN")) GEBI("SLG_CloseAlertBTN").style.filter=SLG_DARK;
                if(GEBI("SLG_GotItSRC")) GEBI("SLG_GotItSRC").style.filter=SLG_DARK;
                if(GEBI("SLG_GotItDST")) GEBI("SLG_GotItDST").style.filter=SLG_DARK;
                if(GEBI("SLG_ClosePosterSRC")) GEBI("SLG_ClosePosterSRC").style.filter=SLG_DARK;
                if(GEBI("SLG_ClosePosterDST")) GEBI("SLG_ClosePosterDST").style.filter=SLG_DARK;
	}
}

function i18n_LanguageDetect(text){
    	return ("");
}


function CNTR(id,dir,nmb){
	    chrome.runtime.sendMessage({greeting: "CNTR:>"+id+","+dir+","+nmb}, function(response) {}); 
}

function CNTRP(id,dir,nmb){
	    chrome.runtime.sendMessage({greeting: "CNTRP:>"+id+","+dir+","+nmb}, function(response) {}); 
}

function SLG_ADD_LONG_NAMES(codes){
	var OUT = "";
	var MENU = SLG_Languages.split(",");
	if(MENU.length>=SLG_FAV_START){
		var FAV = codes.split(",");
		for (var i=0; i<FAV.length; i++){
			var MARKER = 0;
			for (var j=0; j<MENU.length; j++){
				var M = MENU[j].split(":");
				if(FAV[i] == M[0]){
					OUT = OUT + M[0] + ":" + M[1];
					MARKER=1;
				}
			}
			if(MARKER==1){
				if(i <= FAV.length) OUT = OUT + ","
			}
		}
	}
	if(OUT.slice(-1)==",") 	OUT = OUT.slice(0, OUT.length - 1);
	return OUT;	
}

function SLG_SAVE_FAVORITE_LANGUAGES(ln){
	var OUT = "";
	var OUT2 = "";
	SLG_FAV_LANGS_IMT = FExtension.store.get("SLG_FAV_LANGS_IMT");

	if(SLG_FAV_LANGS_IMT.indexOf(ln)!=-1){
		SLG_FAV_LANGS_IMT = SLG_FAV_LANGS_IMT.replace(ln+",",""); 
		if(SLG_FAV_LANGS_IMT.indexOf(",")==-1) SLG_FAV_LANGS_IMT = SLG_FAV_LANGS_IMT.replace(ln,""); 
	}

	OUT = ln + ",";	
	var ARR = SLG_FAV_LANGS_IMT.split(",");
	for (var i = 0; i < ARR.length; i++){
	 	OUT = OUT + ARR[i]+",";
	}
	if(OUT.slice(-1)==",") 	OUT = OUT.slice(0, OUT.length - 1);
	var TMP = OUT.split(",");
	if(TMP.length > SLG_FAV_MAX) {
		for (var j = 0; j < TMP.length-1; j++){
		 	OUT2 = OUT2 + TMP[j]+",";
		}		
		OUT = OUT2 
	}
	if(OUT.slice(-1)==",") 	OUT = OUT.slice(0, OUT.length - 1);
       	FExtension.store.set("SLG_FAV_LANGS_IMT", OUT);
	var MENU = SLG_Languages.split(",");
	if(MENU.length>=SLG_FAV_START){
		SLG_REBUILD_TARGET_LANGUAGE_MENU(OUT,"SLG_langDst");
	}
}


function SLG_REBUILD_TARGET_LANGUAGE_MENU (FAV, ob){
		var doc = document;
		var MENU = SLG_Languages.split(",");
		if(MENU.length>=SLG_FAV_START){
        	        doc.getElementById(ob).innerText="";
			var SEL = 0;
			if(FAV!=""){
                        	FAV = SLG_ADD_LONG_NAMES(FAV);
				var favArr=FAV.split(","); 
				for(var J=0; J < favArr.length; J++){
				    var CURlang = favArr[J].split(":");
				    var OB_FAV = doc.createElement('option');

				    var v = doc.createAttribute("value");				    		
				    v.value = CURlang[0];
				    OB_FAV.setAttributeNode(v);

				    if(J == 0){
					    var sel = doc.createAttribute("selected");
					    sel.value = "selected";
					    OB_FAV.setAttributeNode(sel);
					    SLG_langDst = CURlang[0];
					    SEL = 1;	
				    }

				    OB_FAV.appendChild(doc.createTextNode(CURlang[1]));
				    doc.getElementById(ob).appendChild(OB_FAV);
				}
				OB_FAV = doc.createElement('option');
				var d = doc.createAttribute("disabled");
				d.value = true;
				OB_FAV.setAttributeNode(d);
				var all = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extwptDAll');
			    	OB_FAV.appendChild(doc.createTextNode("-------- [ "+ all +" ] --------"));
			    	doc.getElementById(ob).appendChild(OB_FAV);
			}
			var tmp =favArr[0].split(":");
		        var thelang = tmp[0];
			for(J=0; J < MENU.length; J++){
			    CURlang = MENU[J].split(":");
			    var option = doc.createElement('option');
			    if(SEL == 0){
				    if(CURlang[0] == thelang){
					    var sel = doc.createAttribute("selected");
					    sel.value = "selected";
					    option.setAttributeNode(sel);
				    }
			    }
			    v = doc.createAttribute("value");
			    v.value = CURlang[0];
			    option.setAttributeNode(v);
			    option.appendChild(doc.createTextNode(CURlang[1]));
			    doc.getElementById(ob).appendChild(option);
			}
		} else {
			doc.getElementById(ob).innerText="";
		        var thelang = localStorage["SLG_langDst2"];
			for(J=0; J < MENU.length; J++){
			    CURlang = MENU[J].split(":");
			    var option = doc.createElement('option');
			    if(CURlang[0] == thelang){
				    var sel = doc.createAttribute("selected");
				    sel.value = "selected";
				    option.setAttributeNode(sel);
			    }
			    v = doc.createAttribute("value");
			    v.value = CURlang[0];
			    option.setAttributeNode(v);
			    option.appendChild(doc.createTextNode(CURlang[1]));
			    doc.getElementById(ob).appendChild(option);
			}

		}
}


function BT_2STEPS_TRANSLATION(txt) {
   if(SLG_WRONGLANGUAGEDETECTED==0){
	   GEBI("SLG_back").value="";
	   if(GEBI("SLG_source").value!=""){
		if(BOXCONTENT == txt && GEBI("SLG_target").value!="") {
			BT_WINDOW();
		}else{
			GEBI("SLG_target").value="";
			DETECT(txt);
			setTimeout(function(){
			    var BTIDL = setInterval(function(){
				if(GEBI("SLG_target").value != "") {
					clearInterval(BTIDL);
					BTIDL="";
					if(SLG_WRONGLANGUAGEDETECTED==0){
						BT_WINDOW();
					}
				} 
			    },10);  
	       		},250);
		}
	   } else {	
		GEBI("SLG_target").value="";
		GEBI("SLG_back").value="";
	   }
   }
}

function SLG_BLOCK_OBJECTS(){
   if(SLG_WRONGLANGUAGEDETECTED == 1){
	if(BACK_VIEW==2) {
		var ob = GEBI("SLG_BT");
		ob.style.cursor="not-allowed";
		ob.style.color="#bababa";
	} else {	 	
		var ob = GEBI("SLG_back_view1");
		ob.className="SLG_BACK_GREYOUT2";
	}

	GEBI("SLG_dst_view").style.cursor="not-allowed";
   } else {
	if(BACK_VIEW==2) {
		var ob = GEBI("SLG_BT");
		ob.style.cursor="pointer";
		ob.style.color="#1284B8";
	} else {
		var ob = GEBI("SLG_back_view1");
		ob.className="";
	}
	GEBI("SLG_dst_view").style.cursor="pointer";
  }	
}

function resetCursor(){
	GEBI("SLG_dst_view").style.cursor="pointer";
}

function SLG_Google_Only(){
   if(SLG_WRONGLANGUAGEDETECTED == 1){
	setTimeout(function(){
        	SLG_setTEMP("PROV","Google");
		for(var i=0; i<LISTofPR.length; i++){
			GEBI("SLG_P"+i).className="SLG_LABLE_DEACT";
	 		if(GEBI("SLG_P"+i).title.toLowerCase() == "google"){GEBI("SLG_P"+i).className="SLG_LABLE";}
		}
	},300);
   }	
   SLG_BLOCK_OBJECTS();  
}


function SLG_GLOBAL_RESIZER(){

   GEBI('SLG_body').style.marginLeft="10px";
       	GLOBAL_HEIGHT = Math.ceil(window.innerHeight);
	GLOBAL_WIDTH = Math.ceil(window.innerWidth);
	var W = Math.ceil((GLOBAL_WIDTH-15)*1);
	var H = Math.ceil((GLOBAL_HEIGHT-100)*1);

	var MIN_W = 465;
	if(GLOBAL_WIDTH >= MIN_W){
		if(GEBI('SLG_alert').style.display=="block"){
			var obw = GEBI('SLG_alert').clientWidth;
			GEBI('SLG_alert').style.marginLeft=(GLOBAL_WIDTH/2-obw/2)+"px";
			var obh = GEBI('SLG_alert').clientHeight;
			GEBI('SLG_alert').style.marginTop=(GLOBAL_HEIGHT/2-obh/2-50)+"px";
		}
		if(GEBI('SLG_posterSRC').style.display=="block"){
			var obw = GEBI('SLG_posterSRC').clientWidth;
			GEBI('SLG_posterSRC').style.marginLeft=(GLOBAL_WIDTH/2-obw/2)+"px";
			var obh = GEBI('SLG_posterSRC').clientHeight;
			GEBI('SLG_posterSRC').style.marginTop=(GLOBAL_HEIGHT/2-obh/2-50)+"px";
		}

		if(GEBI('SLG_posterDST').style.display=="block"){
			var obw = GEBI('SLG_posterDST').clientWidth;
			GEBI('SLG_posterDST').style.marginLeft=(GLOBAL_WIDTH/2-obw/2)+"px";
			var obh = GEBI('SLG_posterDST').clientHeight;
			GEBI('SLG_posterDST').style.marginTop=(GLOBAL_HEIGHT/2-obh/2-50)+"px";
		}

		GEBI("SLG_LR").style.marginLeft="5px";	
		GEBI("SLG_translate_container_app").style.width=(W)+"px";
		var RIGHTMARGIN = 8;
		GEBI("SLG_services").style.width=(W-RIGHTMARGIN)+"px";
		GEBI("SLG_links").style.marginLeft=(W-350)+"px";
		var r = (GEBI("SLG_services").clientWidth);
		if(GEBI("SLG_TAB_BLANK")) GEBI("SLG_TAB_BLANK").style.width=(r-25)+"px";
		GEBI("SLG_fieldset").style.width=(r-20)+"px";
		GEBI("SLG_source").style.width=(r-47)+"px";
		GEBI("SLG_icons").style.marginLeft=(r-35)+"px";
		GEBI("SLG_fieldset_trg").style.width=(r-20)+"px";
		GEBI("SLG_topic").style.width=(r-35)+"px";
		GEBI("SLG_target").style.width=(r-47)+"px";
		GEBI("SLG_icons_target").style.marginLeft=(r-35)+"px";
		GEBI("SLG_back").style.width=(r-47)+"px";
		if(GEBI("SLG_back_zone2")) GEBI("SLG_back_zone2").style.width=(r-45)+"px";
		GEBI("SLG_LR").style.marginLeft="-0px";
		if(GLOBAL_WIDTH >= MIN_W){
			localStorage["WINDOW_WIDTH"]=GLOBAL_WIDTH;
		}
       	}
		if(BACK_VIEW==2){
			var MIN_H = 465;
			if(GLOBAL_HEIGHT >= MIN_H){
				GEBI("SLG_fieldset").style.height=Math.ceil(H/2-75)+"px";
				GEBI("SLG_source").style.height=Math.ceil(H/2-75)+"px";
        			GEBI("SLG_fieldset_trg").style.height=Math.ceil(H/2-37)+"px";
				GEBI("SLG_target").style.height=Math.ceil(H/2-66)+"px";
        			if(GEBI("SLG_back_zone2")) GEBI("SLG_back_zone2").style.height=Math.ceil(H/2-30)+"px";
				GEBI("SLG_back").style.height=Math.ceil(H/2-67)+"px";
				GEBI("SLG_back").style.marginTop=((H/2-26)*-1)+"px";
				GLOB_BACK_HEIGHT = Math.ceil(H/2-20);
			}
		} else {
			var MIN_H = 620;
			if(GLOBAL_HEIGHT >= MIN_H){
				GEBI("SLG_fieldset").style.height=Math.ceil(H/3-72)+"px";
				GEBI("SLG_source").style.height=Math.ceil(H/3-72)+"px";
        			GEBI("SLG_fieldset_trg").style.height=Math.ceil(H/3-30)+"px";
				GEBI("SLG_target").style.height=Math.ceil(H/3-60)+"px";
	        		if(GEBI("SLG_back_zone")){
					GEBI("SLG_back_zone").style.height=(H/3-20)+"px";
					GEBI("SLG_back").style.height=(H/3-20)+"px";
					GLOB_BACK_HEIGHT = (H/3-20);				
				} 
			}
		}

		var MIN_H = 640;
		GEBI("SLG_LR").style.marginLeft="-0px";
        	if(GLOBAL_HEIGHT >= MIN_H){
			localStorage["WINDOW_HEIGHT"]=GLOBAL_HEIGHT;
		}

}

function RESIZE_AND_SHOW_PLAYER(box){
	if(box==1){
		GEBI("SLG_fieldset").style.height=(GLOB_BACK_HEIGHT-93)+"px";
		GEBI('SLG_source').style.height = (GLOB_BACK_HEIGHT-93)+"px";
	} else {
		GEBI("SLG_fieldset_trg").style.height=(GLOB_BACK_HEIGHT-45)+"px";
		GEBI('SLG_target').style.height = (GLOB_BACK_HEIGHT-50)+"px";
	}
}


function NoProvidersAlert(){
	var msg = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLPNotSupported');
	var selectDst = GEBI('SLG_langDst');
	var selectedDstIndex = selectDst.selectedIndex;
	var selectedDstText = selectDst.options[selectedDstIndex].text; 
	var selectSrc = GEBI('SLG_langSrc');
	var selectedSrcIndex = selectSrc.selectedIndex;
	var selectedSrcText = selectSrc.options[selectedSrcIndex].text; 
	if(selectSrc.value=="auto" || GEBI("SLlocpl").checked==false) selectedSrcText=DetLangName;
	msg = msg.replace("XXX",selectedSrcText);
	msg = msg.replace("YYY",selectedDstText);
	msg = msg + "\n\n" + "Please activate all providers in the Options";
	SLG_alert(msg); 
	GEBI("SLG_target").value="";
}

function DETERMIN_IF_LANGUAGE_IS_AVAILABLE(){
	try{
		var T = GEBI('SLG_langDst').value;
		var F = GEBI('SLG_langSrc').value;
		if(SLG_DETECT!="") F = SLG_DETECT;
		var lngarr = LISTofLANGsets[0].split(",");
		var cnt = 0;
		var cnt1 = 0;
		var cnt2 = 0;
		if(lngarr.length>1 && T!=""){
			for(var i=1; i<lngarr.length; i++){
				if(lngarr[i]==T) cnt1++;
				if(lngarr[i]==F) cnt2++;
			}
		}
		if(cnt1>0 && cnt2>0) cnt=1;
		if(cnt==0) {
			GEBI("SLG_target").value="";
			if(GEBI("SLG_P0").innerText=="Google") GEBI("SLG_P0").className="SLG_LABLE_DEACT";
		}
		return(cnt);
	} catch(ex){}
}

function DetectBig5(myTransText){
    var all = myTransText.length;
    var count = 0;
    for (var i = 0, len = myTransText.length; i < len; i++) {
	var rr = myTransText[i].match(/[\u3400-\u9FBF]/);
	if(rr) count ++;
    }
    var other = all-count;
    var OUT = 0	
    if(other<=count) OUT=1
    return(OUT);
}