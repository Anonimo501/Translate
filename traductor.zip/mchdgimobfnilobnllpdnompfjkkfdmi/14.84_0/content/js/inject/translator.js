//'use strict';
try{

TranslatorIM = {
        SLG_WPT_ERROR: 0,
	AVOID_SHADOW_ROOT_TEXT: "",
        SLG_UNTRUST_WORD: "",
        SLG_UNTRUST_TEXT: "",
	globaltheQ: "",
	ONCE_DETECT: "",
	ONLYONCE: 0,
	CONTROL_SUM: "",
        MoveBBLX: 0,
	MoveBBLY: 0,
	TTS_btn_location: 0,
	TTS_status:"on",
	FlippedByAuto: 0,
        AVOIDAUTODETECT: 0,
        TIMEOUT: "",
	THEMEmode: 0,
	SLG_DARK: "invert(95%)",
	SLG_LIGHT: "invert(0%)",
	TTSvolume: 1,
	BL_D_PROV: "Google",
	BL_T_PROV: "Google",
	AutoFlipState: 1,
	BBL_RESULT: "",
	BBL_DETECT: "",
        FORSEbubble: 0,
        GlobalCorrectionX: 0,
        GlobalCorrectionY: 0,
        GlobalBoxX: 0,
        GlobalBoxY: 0,
	SLG_FRAME: 0,
        SLG_DICT_PRESENT: "",
	SLG_MODE: "",
	synth: window.speechSynthesis,
	TheVolume: 10,
	TheNewText: "",
	TheNewLang: "",
	TTSbackupLangs: "zh,zt,en,de,hi,id,it,nl,pl,es,ru,ja,ko,fr,pt",
        SLG_CNT: 0,
        LISTofPR: {},
	LISTofPRpairs: {},
    	invalidElements:  {
      		'APPLET': 1,
      		'AREA': 1,
      		'BASE': 1,
      		'BR': 1,
      		'COL': 1,
      		'B': 1,
      		'HR': 1,
      		'IMG': 1,
      		'INPUT': 1,
      		'IFRAME': 1,
      		'ISINDEX': 1,
      		'LINK': 1,
      		'NOFRAMES': 1,
      		'NOSCRIPT': 1,
      		'META': 1,
      		'OBJECT': 1,
      		'PARAM': 1,
      		'SCRIPT': 1,
      		'STYLE': 1,
      		'SELECT': 1
    	},
	SLG_IS_SUBDOMAIN: false,
	SLG_GWPT_Show_Hide: 0,
	SLG_GWPT_Show_Hide_tmp: 0,
	SLG_GWHOST: "",
	SLG_DETLANG: "",
	SLG_D_List: "",
	SLG_L_List: "",

	SLG_wptDHist: "",
	SLG_wptLHist: "",
	SLG_wptGlobAuto: "0",
	SLG_wptGlobTb: "0",
	SLG_wptGlobTip: "0",
	SLG_wptGlobLang: "",

	SLG_wptGlobAutoTmp: "0",
	SLG_wptGlobTbTmp: "1",
	SLG_wptGlobTipTmp: "1",
	SLG_wptGlobLangTmp: "",

	//WPT D temp params
	SLG_wptDp1: "",
	SLG_wptDp2: "0",
	SLG_wptDp3: "",
	SLG_wptDp4: "0",
	SLG_wptDp5: "0",
	SLG_wptDp6: "0",

	//WPT L temp params
	SLG_wptLp1: "",
	SLG_wptLp2: "0",
	SLG_wptLp3: "0",
	SLG_wptLp4: "0",

	SLG_WPT_SKIP: 0,
	SLG_WPT_IGRORE: 0,
	SLG_WPT_TB_DEFAULT: 0,
    	SLG_WPT_TEMP_LANG: "",
    	SLG_WPT_LANG: "",
        SLG_DOM: "auto",
        SLG_LNG_LIST: "",
	SLG_LNG_CUSTOM_LIST: "",
	ImTranslator_theurl: ImTranslator_theurl,
        SLG_WRONGLANGUAGEDETECTED: 0,
	GTTS_length: 200,
	SLIDL:"",
	SLG_DBL_FLAG: 0,
        myWindow:null,
        DELAY:0,
        PROV: "",
	SLG_TRIGGER:"TRUE",
        SLG_storedSelections: [],
        ListProviders: "",
        SLG_SHOW_PROVIDERS: "1",
	SLG_FLAG: 0,        
        SLG_ONETIMERUN: 0,
	SLG_SETINTERVAL_ST: 0,
        SLG_SETINTERVAL_PROXY: 0,
	SLG_BALLON_W: 450,
	SLG_BALLON_H: 85,
	SLG_MoveX: "-1000px",
	SLG_MoveY: "-1000px",
	SLG_Xdelta: 0,
	SLG_Ydelta: 0,
	SLG_FROMlng: "en",
	SLG_TEMP_TEXT: "",
	SLG_temp_result: "",
	SLG_temp_result2: "",
	SLG_Balloon_translation_limit: 5000,
	SLG_PLANSHET_LIMIT: 5000,
	SLG_GLOBAL_X1: 0,
	SLG_GLOBAL_X2: 0,
	SLG_GLOBAL_Y1: 0,
	SLG_GLOBAL_Y2: 0,
	SLG_L: 0,
	SLG_T: 0,
	SLG_R: 0,
	SLG_B: 0,
	SLG_NEST: "TOP",
	SLG_DETECT: "",
	SLG_DETECTED: "",
	SLG_IS_DICTIONARY: 0,
        SLG_EVENT: window.event,
	SLG_KEYCOUNT: { length: 0 },
	SLG_KEYSTRING: "",
	SLG_TEMPKEYSTRING: "",
	SLG_MSG: "",
	SLG_TEMPREARTEXT: "",
	//-------------------Globals for TRANSFER from BBL to PLANSHET
	SLG_TRANSFER_SRC: "en",
	SLG_TRANSFER_DST: "es",
	SLG_TRANSFER_DET: "true",
	//-------------------Globals for TRANSFER from BBL to PLANSHET
        SLG_dict_bbl: "true",
	//-------------------STORAGE
	SLG_ENABLE: false,
	SLG_OnOff_BTN: "true",
	SLG_OnOff_BTN2: "true",
	SLG_OnOff_PIN: "",
	SLG_OnOff_HK: "",
	SLG_langSrc: "",
	SLG_langDst: "",
	SLG_FontSize_bbl: "",
	SLG_TH_2: "",
	SLG_TH_4: "",
	SLG_HK: "",
	SLG_HK2: "",
	SLG_actualkey: "",
	LNGforHISTORY: "",
        Timing: 3,
	Delay: 0,
	//-------------------STORAGE

	//-------------------SESSION
	SLG_SID_PIN: "",
	SLG_SID_TO: "",
	SLG_SID_FROM: "",
	SLG_FONT: "",
	SLG_FONT2: "",
	SLG_FONT_SID: "",
	SLG_SID_TEMP_TARGET: "",
	SLG_SID_TEMP_SOURCE: "",
	SLG_TMPbox: "false",
	SLG_bbl_loc_langs: "false",
	SLG_pin_bbl2: "false",
	//-------------------SESSION

	//-------------------INLINER
	SLG_FK_box1: true,
	SLG_inlinerFK1: "Alt",
	SLG_inliner: "T",
	SLG_FK_box2: true,
	SLG_inlinerFK2: "Ctrl",
	SLG_clean: "X",
	INLINEflip: 0,
	//-------------------INLINER

	//------------------ NEW HOT KEYS
	SLG_BBL_CLOSER: true,
	SLG_HK_gt1: "Ctrl + Alt + Z",
	SLG_HK_gt2: "Alt + Z",
	SLG_HK_it1: "Alt + C",
	SLG_HK_it2: "Alt + X",
	SLG_HK_bb1: "Alt",
	SLG_HK_bb2: "Escape",
	SLG_WPT1: "Alt + P",
	SLG_WPT2: "Alt + M",
	SLG_OPT: "Ctrl + Alt + O",
	SLG_WPTbox1: true,
	SLG_WPTbox2: true,
	SLG_OPTbox: true,
	SOWPTbox: true,
	SOWPT: "Alt + W",
	CTWPTbox: true,
	CTWPT: "Alt + Q",


	//------------------ NEW HOT KEYS

        SLG_WPTsrclang: "auto",
        SLG_WPTdstlang: "es",
	SLG_WPTHosts: "",

	//------------------ DBL bbl
	SLG_DBL: false,
	//------------------ DBL bbl

        TempActiveObjId: "",
        DBLClick_tempText: "",

	// CHECKBOX FOR BLANK GT
        SLG_GT_INV: true,

        SLG_LOC: "en",

	// ADVANCES
	SLG_GVoices: "1",
	SLG_SLVoices: "0",
	SLG_ALLvoices: "",
	// ADVANCES
	
        SLG_SAVETEXT: 0,

        GOOGLE_TTS_backup_loader: 0,
        SLG_ALL_PROVIDERS_BBL: "Google,Microsoft,Translator,Yandex",
        SLG_ALL_PROVIDERS_IT: "",

	SLG_WPT_TRG_LNG: "",
	SLG_WPT_DET_LNG: "",
	SLG_WPT_FLAG: 0,

	// BBL session params
	SLG_langSrc_bbl2: "auto",
	SLG_langDst_bbl2:  "",
	SLG_BBL_COORD_TRIGER: 0,
	SLG_Fontsize_bbl2: "",

	// IT change lang
	SLG_change_lang_it: 0,
	SLG_change_lang_HKbox_it: 1,
	SLG_change_lang_HK_it: "Alt + S",
        SLG_langDst_it: "en",

	//FAVORITE LANGUAGES
	SLG_FAV_START: 10,
	SLG_FAV_MAX: 3,
	SLG_FAV_LANGS_BBL: "",
	SLG_FAV_LANGS_IT: "",
	SLG_FAV_LANGS_WPT: "",

	WPTflip: 0,

	MOver_PROVIDERS:function(e){
	    try{
	        var id = e.target.id.replace("SLG_PN","");
		if(e.target.id.indexOf("SLG_PN")!=-1){
			var doc = FExtension.browserInject.getDocument();
		}
	    } catch(ex){}
	},

	MOut_PROVIDERS:function(e){
	    try{
	        var id = e.target.id.replace("SLG_PN","");
		if(e.target.id.indexOf("SLG_PN")!=-1){
			var doc = FExtension.browserInject.getDocument();
			TranslatorIM.SLG_bring_DOWN();
		}
	    } catch(ex){}
	},

	Click_PROVIDERS:function(e){
	    try{
	        var id = e.target.id.replace("SLG_PN","");
	        if(e.target.parentNode.className!="SLG_BL_LABLE_DEACT"){
			if(id=="BBL_OPT") TranslatorIM.OPEN_BG_OPTIONS('bbl');
			if(id=="HIST_OPT") TranslatorIM.OPEN_BG_OPTIONS('hist');
			if(id=="FEED_OPT") TranslatorIM.OPEN_BG_OPTIONS('feed');
			if(id=="DONATE_OPT") TranslatorIM.OPEN_BG_OPTIONS('donate');
			if(e.target.id.indexOf("SLG_PN")!=-1){
				var doc = FExtension.browserInject.getDocument();
				if(TranslatorIM.SLG_MODE==1) TranslatorIM.SLG_setTMPdata("BL_D_PROV",TranslatorIM.LISTofPR[id]);
				else TranslatorIM.SLG_setTMPdata("BL_T_PROV",TranslatorIM.LISTofPR[id]);
				ImTranslatorDataEvent.mousedown();
				TranslatorIM.SET_FIRST_AVAILABLE_PROV();
				TranslatorIM.SLG_bring_UP();
	                        TranslatorIM.SLG_JUMP(doc);
			}
		}
	    } catch(ex){}
	},

// TOUCT SCREEN
	touchstart:function(e){
	      TranslatorIM.SLG_HideButton();
	      TranslatorIM.SLG_EVENT=e;
	      TranslatorIM.SLG_bring_DOWN();
	},


	touchend:function(e){
     	  var doc = FExtension.browserInject.getDocument();
          TranslatorIM.SLG_BBL_OBJ_OFF(0);
	  if(TranslatorIM.SLG_ENABLE == "true"){
	    if(FExtension.browserInject.getSelectionText()!=""){
		TranslatorIM.SLG_OBJ_BUILDER();
                var COORD = TranslatorIM.TSgetSelectionCoords();
		TranslatorIM.SLG_ShowButton();
		var ratioX = document.body.clientWidth / window.innerWidth;
		var ratioY = document.body.clientHeight / window.innerHeight;

	        var theX = (COORD.x/ratioX) + window.pageXOffset;
	        var theY = (COORD.y/ratioY) + window.pageYOffset;

		TranslatorIM.SLG_MoveX=Math.ceil(theX) + "px";
		TranslatorIM.SLG_MoveY=Math.ceil(theY) + "px";
		var SLdivField = doc.getElementById("SLG_button");
		SLdivField.style.left = TranslatorIM.SLG_MoveX;
		SLdivField.style.top = TranslatorIM.SLG_MoveY;
            } else { 
		if(doc && doc.getElementById("SLG_button"))doc.getElementById("SLG_button").style.display="none"; 
	    }	
	  }

	},


// TOUCT SCREEN


	dblclick:function(e){
	   try{	
	    var doc = FExtension.browserInject.getDocument();
            if(doc.getElementById("SLG_shadow_translator").style.display!="block"){
              var txt=FExtension.browserInject.getSelectionText();

              if(txt!="")TranslatorIM.DBLClick_tempText=txt;

	      var target = e.target || e.srcElement;
              TranslatorIM.SLG_DBL_FLAG=1;

	      if(target.className.toString().indexOf("CodeMirror-")==-1){


		if(TranslatorIM.SLG_OnOff_HK=="true" && TranslatorIM.SLG_ENABLE=="true"){
	                TranslatorIM.getSelectionCoords(e);
			var DBHOTKEYSline1=TranslatorIM.SLG_HK_bb1.replace(" + ",":|").toLowerCase()+":|";
			DBHOTKEYSline1=DBHOTKEYSline1.replace(" + ",":|");
			var HOTKEYSline = TranslatorIM.HOTKEYS_line();
			if(TranslatorIM.SLG_SYNC_FILTER(DBHOTKEYSline1,HOTKEYSline)==true) TranslatorIM.SLG_ShowBalloon();
                        
			if(doc.getElementById("SLG_balloon_obj")){
				TranslatorIM.SLG_LNG_LIST = TranslatorIM.CUSTOM_LANGS(FExtension.element(TranslatorIM.SLG_LOC,'extLanguages'));
				TranslatorIM.SLG_BBL_OBJ_OFF(0);
				TranslatorIM.SLG_OBJ_BUILDER();
			}
		        var ext = FExtension.browserInject;
		  	doc.getElementById('SLG_button').style.background='url('+ext.getURL('content/img/util/imtranslator-s.png')+')';
			doc.getElementById('SLG_button').style.opacity=100;

		}

		if(TranslatorIM.SLG_DBL=="true"){
		    	if(TranslatorIM.ONLYONCE==0){
				TranslatorIM.ONLYONCE = 1;
				setTimeout(function() {TranslatorIM.ONLYONCE = 0;}, 500);
				setTimeout(function() {TranslatorIM.SLG_ShowBalloon();}, 50); 	                      	
			}
		}else TranslatorIM.SLG_ShowButton();
	      }	
	    }
	  } catch(ex){}
	},

	SLG_BTN_mousemove: function(e){
		var id = e.target.id;
	  	if(id=="SLG_button") TranslatorIM.unfade();
	},
	SLG_BTN_mouseout: function(e){
		TranslatorIM.dofade();
	},

	mousedown: function(e){
		try{
			var target = e.target || e.srcElement;
			var doc = FExtension.browserInject.getDocument();
                        TranslatorIM.FlippedByAuto = 0;
			//EXCEPTIONS
			var ROUT = 0;
			if(e.target.className.indexOf("ytp-fullscreen-button")!=-1) ROUT = 1;
			if(e.target.tagName.toLowerCase()=="button") ROUT = 1;
			if(e.target.tagName.toLowerCase()=="video") ROUT = 1;
			if(e.target.hasAttribute("onclick")==true) ROUT = 1;
			if(e.which == 3) {
				//if(doc.getElementById("SLG_shadow_translator").style.display!="block") 
				FExtension.browserInject.runtimeSendMessage({greeting: "RCM:>"}, function(response) {});
			}
			if(e.which != 3 && target.type=="file") ROUT = 1;
			if(e.which == 2) ROUT = 1;

			//EXCEPTIONS

			//IT change target menu

		    	var txt = FExtension.browserInject.getSelectionText();
	    		if(txt == "" && TranslatorIM.AVOID_SHADOW_ROOT_TEXT!="") txt=TranslatorIM.AVOID_SHADOW_ROOT_TEXT;
	    		if(txt!=""){		

			        if(e.which != 3){
					if(e.target.id.indexOf("_MENU")==-1) TranslatorIM.CloseIT_target_lang();
					else{
						if(e.target.id!="SLG_IT_MENU") e.preventDefault();
						TranslatorIM.SLG_addEvent(doc.getElementById("SLG_IT_MENU"), 'change', TranslatorIM.SLG_IT_retranslate);
						TranslatorIM.SLG_addEvent(doc.getElementById("SLG_MENU_CLOSE"), 'click', TranslatorIM.SLG_IT_retranslate_and_close);
					}
				} else e.preventDefault();

				if(TranslatorIM.SLG_SAVETEXT == 1 && TranslatorIM.BL_T_PROV==""){
				    if(TranslatorIM.ListProviders!=""){
					TranslatorIM.SLG_BBL_OBJ_OFF(1);
					TranslatorIM.SLG_OBJ_BUILDER();
				    }	
				}
			}

			if(e.target.id!="SLG_BBL_VOICE" && e.target.id!="SLG_TTS_voice")	TranslatorIM.REMOTE_Voice_Close();

			if(TranslatorIM.SLG_ENABLE == "true"){
	        	     	FExtension.browserInject.extensionSendMessage({greeting: 1}, function(response) {
       					if(response && response.farewell){
       	        				var theresponse = response.farewell.split("~");
				                var theresponse2 = theresponse[2].split("|");
       				        	TranslatorIM.SLG_OnOff_BTN=theresponse2[3];
						TranslatorIM.SLG_OnOff_BTN2=theresponse[62];

						TranslatorIM.SLG_langSrc_bbl2=theresponse[60];
						TranslatorIM.SLG_langDst_bbl2=theresponse[61];
				                TranslatorIM.SLG_langSrc=theresponse2[0];
				                TranslatorIM.SLG_langDst=theresponse2[1];
						TranslatorIM.SLG_bbl_loc_langs=theresponse[65];
						if(TranslatorIM.SLG_bbl_loc_langs=="true") TranslatorIM.SLG_TMPbox="true";
						else TranslatorIM.SLG_TMPbox="false";

						TranslatorIM.SLG_Fontsize_bbl2=theresponse[63];
                                                TranslatorIM.SLG_FONT_SID=TranslatorIM.SLG_Fontsize_bbl2;

						TranslatorIM.SLG_ALL_PROVIDERS_BBL=theresponse[42];
						TranslatorIM.SLG_LOC=theresponse[22];
						TranslatorIM.SLG_LNG_CUSTOM_LIST=theresponse[29];
						TranslatorIM.SLG_pin_bbl2=theresponse[69];
                                                TranslatorIM.SLG_OnOff_PIN=TranslatorIM.SLG_pin_bbl2;
						TranslatorIM.SLG_FAV_MAX=theresponse[79];
						TranslatorIM.SLG_FAV_LANGS_BBL=theresponse[80];
						TranslatorIM.SLG_FAV_LANGS_IT=theresponse[81];
						TranslatorIM.SLG_FAV_LANGS_WPT=theresponse[82];
						TranslatorIM.WPTflip=theresponse[83];
	             			}
					TranslatorIM.SLG_LNG_LIST = TranslatorIM.CUSTOM_LANGS(FExtension.element(TranslatorIM.SLG_LOC,'extLanguages'));
					TranslatorIM.LISTofPR = TranslatorIM.SLG_ALL_PROVIDERS_BBL.split(",");


       				});
			}

			if(ROUT == 0){


				//by VK - SENDING A REQUEST TO BG to reset bubble result data exchange buffer ------
			        FExtension.browserInject.runtimeSendMessage({greeting: "TR_STOP:>"}, function(response) {});
	        		//by VK ----------------------------------------------------------------------------
		                TranslatorIM.SLG_ONETIMERUN=0;

				if(TranslatorIM.SLG_ENABLE == "true"){

					var id = target.id;

					if(target.className.toString().indexOf("CodeMirror-")==-1){
						TranslatorIM.SLG_LNG_LIST = TranslatorIM.CUSTOM_LANGS(FExtension.element(TranslatorIM.SLG_LOC,'extLanguages'));	       
					        if(e.which != 3){
							//WPT------

//							if(id.indexOf("SLG_")==-1 && id=="SLG_WPT_SHOW" || id =="") TranslatorIM.SLG_WPT_OPTIONS_CLOSE(1);
							if(id.indexOf("SLG_")==-1 || id =="") TranslatorIM.SLG_WPT_OPTIONS_CLOSE(1);

							//WPT------


							if(id == "SLG_button"){                                        
								e.preventDefault();
								TranslatorIM.SLG_ShowBalloon();
							} else {
								var id2 = TranslatorIM.BBL_IfMouseIsInside(e);

								if(id2==0){
									TranslatorIM.SLG_BBL_OBJ_OFF(0);
                                                                        if(doc.location.href.indexOf("rsa.com/") != -1){
										if (window.getSelection().empty) {  // Chrome
											window.getSelection().empty();
										} else if (window.getSelection().removeAllRanges) {  // Firefox
											window.getSelection().removeAllRanges();
										}
									}
								}
							}

							FExtension.browserInject.setEvent(e);
							TranslatorIM.TempActiveObjId = id;                

							if(id == "SLHKclose" || id == "SLG_alert_cont" || id == "SLG_alert_bbl" || id == "SLG_shadow_translation_result" || id == "SLG_shadow_translation_result2" || id=="") TranslatorIM.SLShowHideAlert();
							if(id == "SLG_BBL_VOICE") TranslatorIM.SLG_BBL_VOICE();
							if(id != "SLG_button" || id !="SLG_TTS_voice") {

								TranslatorIM.SLG_GLOBALPosition(e, 0);
								TranslatorIM.SLG_HideButton();
					                	TranslatorIM.SLG_EVENT=e;
								if(id.indexOf("SL")==-1 || id=="") TranslatorIM.SLG_CloseBalloon();	

							}
							if(id != "SLG_button") {
								TranslatorIM.SLG_HideButton();
						                TranslatorIM.SLG_EVENT=e;
								TranslatorIM.SLG_bring_DOWN();
							}

						}else {
							FExtension.browserInject.runtimeSendMessage({greeting: "RCL:>"}, function(response) {}); 
							if(doc.getElementById("SLG_button")) doc.getElementById("SLG_button").style.display="none"; 
						}

				       } 


				}else TranslatorIM.SLG_BBL_OBJ_OFF(0);
			} //else inlinerInjectClean();
		  } catch(ex){}
	          TranslatorIM.CleanUpAll(e);
	},


	
	mouseup:function(e){
		if(e.which != 3){
			//EXCEPTIONS
			var ROUT = 0;
			if(e.target){
				if(e.target.tagName.toLowerCase()=="video") ROUT=1;
				if(e.target.tagName.toLowerCase()=="img") ROUT=1;
		                try{
					if(e.target.className.indexOf("ytp-")!=-1) ROUT = 1;
				} catch (e){chrome.runtime.lastError}			
			}
			//EXCEPTIONS
			var doc = FExtension.browserInject.getDocument();
			if(e.target.id == "SLG_WPT_MENU_CLOSE") {TranslatorIM.closeWPT_ERROR_MSG();}
			if(doc.getElementById("SLG_MENU_WPT")){
				if(e.target.id.indexOf("SLG_")==-1 && doc.getElementById("SLG_MENU_WPT").style.display!='none') {TranslatorIM.closeWPT_ERROR_MSG();}
			}
			if(ROUT==1) TranslatorIM.SLG_HideButton();
			else{
                                TranslatorIM.AVOID_SHADOW_ROOT_TEXT="";
				if(TranslatorIM.SLG_ENABLE == "true"){
				        TranslatorIM.AVOID_SHADOW_ROOT_TEXT = FExtension.browserInject.getSelectionText();
					if(FExtension.browserInject.getSelectionText()!=""){		
						try{    							
						        var id = e.target.id;
							if(id.indexOf("SLG_")==-1) TranslatorIM.SLG_OBJ_BUILDER();

							if(TranslatorIM.SLG_SID_TO != "") TranslatorIM.SLG_langDst=TranslatorIM.SLG_SID_TO;
							else TranslatorIM.SLG_langDst=TranslatorIM.SLG_langDst_bbl2;
							FExtension.browserInject.runtimeSendMessage({greeting: "CM_BBL:>" + TranslatorIM.SLG_langDst}, function(response) {}); 
						} catch (e){chrome.runtime.lastError}	

						if(window.top==window.self)TranslatorIM.SLG_FRAME=0;
						else TranslatorIM.SLG_FRAME=1;
						var SLdivField = doc.getElementById("SLG_shadow_translator");
						if(TranslatorIM.SLG_FRAME==1){
							TranslatorIM.SLG_EVENT=e;
							TranslatorIM.WINDOW_and_BUBBLE_alignment(doc,SLdivField)
						}
				                TranslatorIM.getSelectionCoords(e);
				                TranslatorIM.unfade();
						var wl = doc.location.href;
						if(wl.indexOf("http")!=-1){
							if(TranslatorIM.SLG_SAVETEXT == 1){
							        TranslatorIM.SLG_GLOBALPosition(e, 1);
	        						TranslatorIM.SLG_EVENT=e;
							        FExtension.browserInject.setEvent(e);
								TranslatorIM.QuickInitTranslators(e);
						                TranslatorIM.SLG_GOOGLE_WPT();				
							} else {

								if(SLdivField && SLdivField.style.display!="block"){
							        	TranslatorIM.SLG_GLOBALPosition(e, 1);
						        		TranslatorIM.SLG_EVENT=e;
								        FExtension.browserInject.setEvent(e);
									TranslatorIM.QuickInitTranslators(e);
						        	        TranslatorIM.SLG_GOOGLE_WPT();				
								}
							}
						}


				  	       if(TranslatorIM.SLG_OnOff_BTN2=="true") {
						   try{
						        var ext = FExtension.browserInject;
						  	doc.getElementById('SLG_button').style.background='url('+ext.getURL('content/img/util/imtranslator-s.png')+')';
							doc.getElementById('SLG_button').style.opacity=100;
						   }catch(e){}
						}

				    } else{
					if(TranslatorIM.SLG_SAVETEXT == 1 && doc.getElementById("SLG_shadow_translator").style.display!="block"){
						TranslatorIM.SLG_BBL_OBJ_OFF(1);

					}
			                TranslatorIM.CleanUpAll(e);
				    }
		           } else { 
				if(doc.getElementById("SLG_button"))doc.getElementById("SLG_button").style.display="none"; 
			   }
		  	}
	         }
	},


	keydown:function(e){                
		setTimeout(function() {
		        //ALT-Tab handler
			window.onfocus = function() {
			    TranslatorIM.SLG_KEYSTRING="";
			    TranslatorIM.SLG_TEMPKEYSTRING="";
			}
			//---------------
/*
			if(e.key==TranslatorIM.SLG_HK_bb2){
				TranslatorIM.REMOTE_Voice_Close();
		 	        var doc = FExtension.browserInject.getDocument();       
				if(TranslatorIM.SLG_BBL_CLOSER=="true"){
					TranslatorIM.SLG_CloseBalloonWithLink();
				} else {
					TranslatorIM.SLG_BBL_OBJ_OFF(0);
				}


			//IT change target menu
				if(doc.getElementById("SLG_MENU")) TranslatorIM.SLG_IT_retranslate_and_close();


			}else{
*/
			    	if(!TranslatorIM.SLG_KEYCOUNT[e.keyCode] && TranslatorIM.SLG_KEYCOUNT.length<3)   {
        				TranslatorIM.SLG_KEYCOUNT[e.keyCode] = true;
				        TranslatorIM.SLG_KEYCOUNT.length++;
					TranslatorIM.SLG_KEYSTRING=TranslatorIM.SLG_KEYSTRING+e.keyCode+":|";
                			if(TranslatorIM.SLG_KEYSTRING!="") {TranslatorIM.SLG_TEMPKEYSTRING=TranslatorIM.SLG_KEYSTRING;TranslatorIM.SLG_CNT=0;}
				}
//			}
		}, 100);		
        },



	keyup:function(e){ 
//		if(e.key=="Escape") {
//			TranslatorIM.CloseAnyOpenTranslator();			
//		}

		TranslatorIM.QuickInitTranslators(e);
		var HOTKEYSline = TranslatorIM.HOTKEYS_line();
		if(TranslatorIM.SLG_MSG.indexOf("~")!=-1){
			var theresponse = TranslatorIM.SLG_MSG.split("~");

			var theresponse2 = theresponse[1].split("|");
			var thekey4 = theresponse2[1];
			var theresponse4 = theresponse[4].split("|");
			var INLINER_CLEAN_ONOFF = theresponse4[0];
			var BUBBLE_CLEAN_ONOFF = theresponse[45];
		
			var INL_CL_HK1 = theresponse4[1];
			var INL_CL_HK2 = theresponse4[2];

			//WPT
			if(TranslatorIM.SLG_WPT1=="") TranslatorIM.SLG_WPTbox1="false";
			var DBHOTKEYSlineWPT1=TranslatorIM.SLG_WPT1.replace(/ \+ /g,":|").toLowerCase()+":|";
       			DBHOTKEYSlineWPT1=DBHOTKEYSlineWPT1.replace(/ \+ /g,":|");
			if(TranslatorIM.SLG_WPTbox1 == "true"){
	                        if(TranslatorIM.SLG_SYNC_FILTER(DBHOTKEYSlineWPT1,HOTKEYSline)==true){
					if(TranslatorIM.SLG_CNT==0){
						TranslatorIM.SLG_WEB_PAGE_TRANSLATION_FROM_CM_AND_HK(TranslatorIM.SLG_wptGlobAuto, "reset");
						TranslatorIM.SLG_CNT++;
					}
				}
	                }

			//WPT MO
			if(TranslatorIM.SLG_WPT2=="") TranslatorIM.SLG_WPTbox2="false";
			var DBHOTKEYSlineWPT2=TranslatorIM.SLG_WPT2.replace(/ \+ /g,":|").toLowerCase()+":|";
       			DBHOTKEYSlineWPT2=DBHOTKEYSlineWPT2.replace(/ \+ /g,":|");
			if(TranslatorIM.SLG_WPTbox2 == "true"){
	                        if(TranslatorIM.SLG_SYNC_FILTER(DBHOTKEYSlineWPT2,HOTKEYSline)==true) TranslatorIM.SLG_WPT(1);
	                }

			//OPT
			if(TranslatorIM.SLG_OPT=="") TranslatorIM.SLG_OPTbox="false";
			var DBHOTKEYSlineOPT=TranslatorIM.SLG_OPT.replace(/ \+ /g,":|").toLowerCase()+":|";
       			DBHOTKEYSlineOPT=DBHOTKEYSlineOPT.replace(/ \+ /g,":|");
			if(TranslatorIM.SLG_OPTbox == "true"){                                       
	                        if(TranslatorIM.SLG_SYNC_FILTER(DBHOTKEYSlineOPT,HOTKEYSline)==true) TranslatorIM.OPEN_BG_OPTIONS("");
	                }

			//ImTranslator Blank
			if(TranslatorIM.SLG_HK_gt2=="") TranslatorIM.SLG_GT_INV="false";
			var DBHOTKEYSline1=TranslatorIM.SLG_HK_gt2.replace(/ \+ /g,":|").toLowerCase()+":|";
      			DBHOTKEYSline1=DBHOTKEYSline1.replace(/ \+ /g,":|");
			if(TranslatorIM.SLG_GT_INV == "true"){
				if(TranslatorIM.SLG_SYNC_FILTER(DBHOTKEYSline1,HOTKEYSline)==true) setTimeout(function() {TranslatorIM.HotKeysWindow(e,0);}, 100);
			}

			//Inline clean
			if(TranslatorIM.SLG_HK_it2=="") INLINER_CLEAN_ONOFF="false";
			var DBHOTKEYSline2=TranslatorIM.SLG_HK_it2.replace(/ \+ /g,":|").toLowerCase()+":|";
	       		DBHOTKEYSline2=DBHOTKEYSline2.replace(/ \+ /g,":|");
			if(INLINER_CLEAN_ONOFF=="true"){
				if(TranslatorIM.SLG_SYNC_FILTER(DBHOTKEYSline2,HOTKEYSline)==true) inlinerInjectClean();
			}

			//BUBBLE close
			if(TranslatorIM.SLG_HK_bb2==""){ BUBBLE_CLEAN_ONOFF="false"}
			var DBHOTKEYSline2=TranslatorIM.SLG_HK_bb2.replace(/ \+ /g,":|").toLowerCase()+":|";
		       	DBHOTKEYSline2=DBHOTKEYSline2.replace(/ \+ /g,":|");
			if(BUBBLE_CLEAN_ONOFF=="true"){
				if(TranslatorIM.SLG_SYNC_FILTER(DBHOTKEYSline2,HOTKEYSline)==true){
					TranslatorIM.REMOTE_Voice_Close();
			        	var doc = FExtension.browserInject.getDocument();       
					if(TranslatorIM.SLG_BBL_CLOSER=="true"){
						TranslatorIM.SLG_CloseBalloonWithLink();
					} else {
						TranslatorIM.SLG_BBL_OBJ_OFF(0);
					}
				}
			}

			//WPT SHOW ORIGINAL
			if(TranslatorIM.SOWPT=="") TranslatorIM.SOWPTbox="false";
			var DBHOTKEYSlineSOWPT=TranslatorIM.SOWPT.replace(/ \+ /g,":|").toLowerCase()+":|";
       			DBHOTKEYSlineSOWPT=DBHOTKEYSlineSOWPT.replace(/ \+ /g,":|");

			if(TranslatorIM.SOWPTbox == "true"){
	                        if(TranslatorIM.SLG_SYNC_FILTER(DBHOTKEYSlineSOWPT,HOTKEYSline)==true) TranslatorIM.SLG_SHOW_ORIGINAL();
	                }

			//WPT CLOSE TRANSLATION
			if(TranslatorIM.CTWPT=="") TranslatorIM.CTWPTbox="false";
			var DBHOTKEYSlineCTWPT=TranslatorIM.CTWPT.replace(/ \+ /g,":|").toLowerCase()+":|";
       			DBHOTKEYSlineCTWPT=DBHOTKEYSlineCTWPT.replace(/ \+ /g,":|");
			if(TranslatorIM.CTWPTbox == "true"){
	       			HOTKEYSline=HOTKEYSline.replace(/escape:/g,"esc:");
                                DBHOTKEYSlineCTWPT=DBHOTKEYSlineCTWPT.replace(/escape:/g,"esc:");
	                        if(TranslatorIM.SLG_SYNC_FILTER(DBHOTKEYSlineCTWPT,HOTKEYSline)==true) TranslatorIM.CloseAnyOpenTranslator();
	                }


		}
		TranslatorIM.SLG_closer(e);
        },

	QuickInitTranslators: function(e){
 	        var doc = FExtension.browserInject.getDocument();       
                var HOTKEYSline = TranslatorIM.HOTKEYS_line();
		setTimeout(function() {
		  try{
		    if(TranslatorIM.SLG_MSG!="" || TranslatorIM.SLG_MSG!="undefuned"){
			var theSLtext = window.getSelection().toString();
			theSLtext = theSLtext.replace(/(^\s+|\s+$)/g, '');

			var theresponse = TranslatorIM.SLG_MSG.split("~");
			var theresponse1 = theresponse[0].split("|");
			var thekey2 = theresponse1[1];

                        if(theresponse[3].indexOf("|")!=-1){
				var theresponse3 = theresponse[3].split("|");
				var INLINER_ONOFF = theresponse3[0];
				var INL_HK1 = theresponse3[1];
				var INL_HK2 = theresponse3[2];
				var theresponse4 = theresponse[4].split("|");
			}

			//Balloon
			if(TranslatorIM.SLG_HK_bb1=="") TranslatorIM.SLG_OnOff_HK = "false";
                        var SLdivField = doc.getElementById("SLG_shadow_translator");

			if(TranslatorIM.SLG_SAVETEXT==0){
				if(SLdivField && SLdivField.style.display!="block"){
					var DBHOTKEYSline1=TranslatorIM.SLG_HK_bb1.replace(/ \+ /g,":|").toLowerCase()+":|";
					DBHOTKEYSline1=DBHOTKEYSline1.replace(/ \+ /g,":|");
				} else DBHOTKEYSline1="";
			} else {
				var DBHOTKEYSline1=TranslatorIM.SLG_HK_bb1.replace(/ \+ /g,":|").toLowerCase()+":|";
				DBHOTKEYSline1=DBHOTKEYSline1.replace(/ \+ /g,":|");
			}

			//ImTranslator Blank
			if(TranslatorIM.SLG_HK_gt1=="") theresponse1[2] = "false";
			if(theSLtext!=""){
				var DBHOTKEYSline2=TranslatorIM.SLG_HK_gt1.replace(/ \+ /g,":|").toLowerCase()+":|";
				DBHOTKEYSline2=DBHOTKEYSline2.replace(/ \+ /g,":|");
			}

			//Inline Translation
			if(TranslatorIM.SLG_HK_it1=="") INLINER_ONOFF = "false";
			var DBHOTKEYSline3=TranslatorIM.SLG_HK_it1.replace(/ \+ /g,":|").toLowerCase()+":|";
			DBHOTKEYSline3=DBHOTKEYSline3.replace(/ \+ /g,":|");

			//Inline Translation with target lang selection
			var DBHOTKEYSline4=TranslatorIM.SLG_change_lang_HK_it.replace(/ \+ /g,":|").toLowerCase()+":|";
			DBHOTKEYSline4=DBHOTKEYSline4.replace(/ \+ /g,":|");


			if(theSLtext!=""){

			   	if(TranslatorIM.SLG_OnOff_BTN2=="true" && theSLtext.indexOf("Google - Map Data")==-1 && theSLtext!="." && theSLtext!="," && theSLtext!="?" && theSLtext!="!" && theSLtext!=":" && theSLtext!=";" && theSLtext!="-"){
				 	if(TranslatorIM.SLG_ENABLE=="true"){
						if(TranslatorIM.TempActiveObjId!="SLG_button")	TranslatorIM.SLG_ShowButton();
					}
				}



				if((TranslatorIM.SLG_OnOff_HK=="true" && TranslatorIM.SLG_ENABLE=="true") && TranslatorIM.FORSEbubble!=1){
					if(TranslatorIM.SLG_SYNC_FILTER(DBHOTKEYSline1,HOTKEYSline)==true){
						if(doc.getElementById("SLG_balloon_obj")){
							TranslatorIM.SLG_LNG_LIST = TranslatorIM.CUSTOM_LANGS(FExtension.element(TranslatorIM.SLG_LOC,'extLanguages'));
							TranslatorIM.SLG_BBL_OBJ_OFF(0);
							TranslatorIM.SLG_OBJ_BUILDER();
						} 
						TranslatorIM.SLG_ShowBalloon();
					}
				}
				if(TranslatorIM.FORSEbubble==1){
					if(doc.getElementById("SLG_balloon_obj")){
						TranslatorIM.SLG_LNG_LIST = TranslatorIM.CUSTOM_LANGS(FExtension.element(TranslatorIM.SLG_LOC,'extLanguages'));
						TranslatorIM.SLG_BBL_OBJ_OFF(0);
						TranslatorIM.SLG_OBJ_BUILDER();
					}
					TranslatorIM.SLG_ShowBalloon();
				}
			}	
			if(theresponse1[2]=="true"){
				if(TranslatorIM.SLG_SYNC_FILTER(DBHOTKEYSline2,HOTKEYSline)==true) TranslatorIM.HotKeysWindow(e, 1);
			}

			if(INLINER_ONOFF=="true"){
				if(TranslatorIM.SLG_SYNC_FILTER(DBHOTKEYSline3,HOTKEYSline)==true){
					if(TranslatorIM.SLG_ONETIMERUN==0) {runinliner();TranslatorIM.SLG_ONETIMERUN=1;}
			        }
			}
			if(theresponse[66]=="true" && theresponse[67]!=""){
        				if(TranslatorIM.SLG_SYNC_FILTER(DBHOTKEYSline4,HOTKEYSline)==true) {
					if(TranslatorIM.SLG_ONETIMERUN==0) {TranslatorIM.InitiateIT_target_lang();/*runinliner();*/TranslatorIM.SLG_ONETIMERUN=1;}
				}
			}


			
		    }	
		  }catch(e){
			//alter(e);
		  }
		}, 20); //VK: was 200 
		setTimeout(function() {
			TranslatorIM.SLG_closer(e);
			HOTKEYSline="";
		}, 500);
	},

	SLG_SYNC_FILTER: function (l1,l2){
		if(l1=="auto translate:|") return true;
	        if(l1!=":|"){
		        var LINE1 = l1.split(":|");
		        var LINE2 = l2.split(":|");
	        	var CNT1 = LINE1.length-1;
		        var CNT2 = LINE2.length-1; 
		        var cnt=0;
                	var CNTlimit=3;
		        if(CNT1 == CNT2){
				CNTlimit = CNT1;
	        		for(var i=0; i<CNT1; i++){
		        		for(var j=0; j<CNT2; j++){
						if(LINE1[i]==LINE2[j]){
							cnt++; 	
						}
					}
				}
			}
			if(cnt>=CNTlimit) return true;
			else return false;
		} else {
		 if(l2=="") return true;
		 else return false;
		}
	},

	SLG_closer:function(e){
		setTimeout(function() {TranslatorIM.SLG_KEYCOUNT = { length: 0 }; TranslatorIM.SLG_KEYSTRING="";TranslatorIM.SLG_TEMPKEYSTRING="";}, 300);
        },


	HOTKEYS_line: function(){
                TranslatorIM.SLG_TEMPKEYSTRING=TranslatorIM.SLG_TEMPKEYSTRING.replace("18:|","Alt:|");
                TranslatorIM.SLG_TEMPKEYSTRING=TranslatorIM.SLG_TEMPKEYSTRING.replace("17:|","Ctrl:|");
                TranslatorIM.SLG_TEMPKEYSTRING=TranslatorIM.SLG_TEMPKEYSTRING.replace("16:|","Shift:|");
                TranslatorIM.SLG_TEMPKEYSTRING=TranslatorIM.SLG_TEMPKEYSTRING.replace("27:|","Escape:|");
		var TMP1= TranslatorIM.SLG_TEMPKEYSTRING.split(":|");
		var NUM = TMP1.length-1;
		var HOTKEY = Array();
		var HOTKEYSline="";
		var cnt=0;
		for(var x=0; x<NUM; x++){
		    if(TMP1[x]!="Alt" && TMP1[x]!="Ctrl" && TMP1[x]!="Shift" && TMP1[x]!="Escape") HOTKEY[x]=String.fromCharCode(TMP1[x]);
		    else HOTKEY[x]=TMP1[x];
                    HOTKEYSline=HOTKEYSline+HOTKEY[x]+":|";
                    if(TMP1[x]=="Alt")cnt++;
                    if(TMP1[x]=="Ctrl")cnt++;
                    if(TMP1[x]=="Escape")cnt++;
		}
		if(cnt==2){
                  HOTKEYSline=HOTKEYSline.replace("Alt:|","");
                  HOTKEYSline=HOTKEYSline.replace("Ctrl:|","");
                  HOTKEYSline="Ctrl:|Alt:|"+HOTKEYSline;
		}
		return HOTKEYSline.toLowerCase();
	},


	SLG_setTMPdata: function(name, value) {
       		FExtension.browserInject.runtimeSendMessage({greeting: "SAVE_DATA:>"+name+":"+value}, function(response) {});
		switch(name){
		 	case "BL_T_PROV": TranslatorIM.BL_T_PROV=value; break;
		 	case "BL_D_PROV": TranslatorIM.BL_D_PROV=value; break;
		 	case "TTSvolume": TranslatorIM.TTSvolume=value; break;
		}
	},

	init: function(){
   	   var doc = FExtension.browserInject.getDocument();	   
//	   TranslatorIM.SLG_setTMPdata("BL_D_PROV","");
//	   TranslatorIM.SLG_setTMPdata("BL_T_PROV","");
//=========================================================
	   if(self==top){
		 TranslatorIM.SLG_IS_SUBDOMAIN=TranslatorIM.SLG_DETECTsubDomain();
		 setTimeout(function() {
		   TranslatorIM.SLG_getSHOW_HIDE_TB_TMP("SLG_GWPT_Show_Hide_tmp");
		   TranslatorIM.SLG_get_AUTO_TMP("SLG_AUTO_TMP");
		   var r = doc.getElementsByClassName("goog-te-banner-frame");
		   if(r[0]) r[0].style = "display:none !important";
	           if(TranslatorIM.SLG_GWPT_Show_Hide_tmp!="2" && TranslatorIM.SLG_GWPT_Show_Hide_tmp!="none"){
			TranslatorIM.SLG_WPT_DETECT(1);
			TranslatorIM.SLG_GWHOST = TranslatorIM.SLG_GetHost();
			TranslatorIM.SLG_getLNG_TMP("SLG_G_WPT_TO");

			setTimeout(function() {
			  var SLG_WPTid = setInterval(function(){
				var FirstRun = 0;
				if(TranslatorIM.SLG_GWPT_Show_Hide_tmp!=2) FirstRun=1;

				if(TranslatorIM.SLG_WPT_LANG!="") {
					clearInterval(SLG_WPTid);
					TranslatorIM.SLG_getDATA();
					setTimeout(function() {
						var DOMAINS = TranslatorIM.SLG_D_List;
						var LANGUAGES = TranslatorIM.SLG_L_List;
						TranslatorIM.SLG_IS_SUBDOMAIN=TranslatorIM.SLG_DETECTsubDomain();
		                		var MH = TranslatorIM.SLG_GetMAINHost(TranslatorIM.SLG_GWHOST);

						var isLangPresented = LANGUAGES.indexOf("All");
						if(isLangPresented == -1) isLangPresented = LANGUAGES.indexOf(TranslatorIM.SLG_WPT_LANG);

						if(TranslatorIM.SLG_wptGlobAutoTmp==0) isLangPresented=-1;
                                                
						if(TranslatorIM.SLG_wptGlobAutoTmp==1){
							if(TranslatorIM.SLG_IS_DOMAIN_IN_THE_LIST(DOMAINS,TranslatorIM.SLG_GWHOST)==1){
								TranslatorIM.SLG_WEB_PAGE_TRANSLATION(TranslatorIM.SLG_wptGlobAuto,"continue");
							} else {
						               if(TranslatorIM.SLG_WPT_TEMP_LANG!="" || isLangPresented!=-1) TranslatorIM.SLG_WEB_PAGE_TRANSLATION(TranslatorIM.SLG_wptGlobAuto,"continue");
						               else TranslatorIM.SLG_WEB_PAGE_TRANSLATION(TranslatorIM.SLG_wptGlobAutoTmp,"continue");
							}
						} else {
							if(FirstRun!=1){
						                if(TranslatorIM.SLG_WPT_TEMP_LANG!="" || isLangPresented!=-1) TranslatorIM.SLG_WEB_PAGE_TRANSLATION(TranslatorIM.SLG_wptGlobAuto,"continue"); 
							}
						}

					}, 100);    
				}
			    },100);//was 10
			}, 300);  //was 100
		   } 
  		  }, 100);    
	     }
//=========================================================



                
                TranslatorIM.SLG_GOOGLE_WPT();

      	
        	doc.addEventListener('mousedown', TranslatorIM.mousedown,!1);
        	doc.addEventListener('dblclick', TranslatorIM.dblclick,!1);

	        doc.addEventListener('mouseup', TranslatorIM.mouseup,!1);

        	doc.addEventListener('keydown', TranslatorIM.keydown,!1);
        	doc.addEventListener('keyup', TranslatorIM.keyup,!1);


        	doc.addEventListener('touchstart', TranslatorIM.touchstart,!1);
        	doc.addEventListener('touchend', TranslatorIM.touchend,!1);


        	doc.addEventListener('mouseover', TranslatorIM.MOver_PROVIDERS,!1);
        	doc.addEventListener('mouseout', TranslatorIM.MOut_PROVIDERS,!1);
        	doc.addEventListener('click', TranslatorIM.Click_PROVIDERS,!1);




/*
		try{
	            doc.addEventListener("load", function(){
				setTimeout('TranslatorIM.SLG_Hider()',500); 

			}, false);
		}catch(e){
			//alter(e);
		}
	
*/	
		(function(){                 

			var SLG_d=!0,SLG_e=null,SLG_g=!1,SLG_j,
			SLG_k=function(SLG_a){
				return SLG_a.replace(/^\s+|\s+$/g,"")
			},
			SLG_o=function(SLG_a,SLG_b){
				return function(){
					return SLG_b.apply(SLG_a,arguments)
					}
			 },
			 SLG_p=function(SLG_a){
			  if(SLG_a&&SLG_a.tagName){
				  var SLG_b=SLG_a.tagName.toLowerCase();
				  if("input"==SLG_b||"textarea"==SLG_b)
					  return SLG_d;
			  }
			  for(;SLG_a;SLG_a=SLG_a.parentNode)
				  if(SLG_a.isContentEditable)
					  return SLG_d;
			  	   return SLG_g;
			  },
			  SLG_r=/[0-9A-Za-z]/,
			  SLG_A=function(){
				  FExtension.browserInject.extensionSendRequest({type:"initialize"},SLG_o(this,
				  function(SLG_a){
					  this.SLG_B=SLG_a.instanceId;
					  FExtension.browserInject.addOnRequestListener(SLG_z);

				  })
			  )}
			  var SLG_x=function(SLG_a,SLG_b,SLG_c){
				  FExtension.browserInject.getDocument().addEventListener?SLG_c.addEventListener(SLG_a,SLG_b,SLG_g):SLG_c.attachEvent("on"+SLG_a,SLG_b)
			  },
			  SLG_w=function(){};
			  var SLG_z=function(SLG_a,SLG_b,SLG_c){
		                      "get_selection"==SLG_a.type&&(SLG_a=SLG_k(FExtension.browserInject.getSelectionText()))&&SLG_c({selection:SLG_a})
			  };
			  window.SLInstance=new SLG_A;  

/*
			  try{
				if(document.location.href.indexOf('acid3.acidtests.org')!=-1){
					setTimeout('TranslatorIM.SLG_OBJ_BUILDER()',1000); 
				} else TranslatorIM.SLG_OBJ_BUILDER();
			  }catch(e){
				//alter(e);
			  }

*/

			  FExtension.browserInject.extensionSendMessage({greeting: 1}, function(response) {
				  FExtension.browserInject.setStyle();
		      });

		})();


	},


    addEvent: function (element, eventName, callback) {
        if (element.addEventListener) {
            element.addEventListener(eventName, callback, false);
        } else if (element.attachEvent) {
            element.attachEvent("on" + eventName, callback);
        }
    },

    openFeedback: function(){
        FExtension.browserInject.openNewTab(FExtension.browserInject.getURL('feedback.html', false));
    },
	
	SLG_Links: function(ob,todo){
		FExtension.browserInject.getDocument().getElementById(ob).style.display=todo;
	},
/*
	SLG_Hider: function(){
		if(FExtension.browserInject.getDocument().getElementById("SLG_shadow_translator")){
			FExtension.browserInject.getDocument().getElementById("SLG_shadow_translator").style.display='none';
		}
	},
*/
	StartImTranslatorWindow: function(){
		 var tmpSLstr = FExtension.browserInject.getSelectionText();
		 if(tmpSLstr=="")  tmpSLstr=" ";

		 FExtension.browserInject.extensionSendMessage({greeting: tmpSLstr}, function(response) {
			 //chrome.extension.sendMessage({greeting: tmpSLstr}, function(response) {
             if(response){
			    //console.log(response.farewell);
             }
		 });
	},

	//---------------BUTTON

	SLG_ShowButton: function(){
         clearTimeout(TranslatorIM.TIMEOUT);
	 TranslatorIM.TIMEOUT = setTimeout(function() {
	   if(TranslatorIM.SLG_OnOff_BTN2 == "true"){
	        var doc = FExtension.browserInject.getDocument();
		 if(TranslatorIM.SLG_SAVETEXT == 0){
			if(doc.getElementById('SLG_shadow_translator') && doc.getElementById('SLG_shadow_translator').style.display!="block"){
				TranslatorIM.SLG_ShowButtonEXEC(doc);
			}
		 } else TranslatorIM.SLG_ShowButtonEXEC(doc);	 	
	   }
	 }, TranslatorIM.Delay*1000);
	},


	SLG_ShowButtonEXEC: function(doc){
	  	TranslatorIM.dofade();
		   if(doc.getElementById("SLG_shadow_translator")){
			if(doc.getElementById("SLG_shadow_translator").style.backgroundColor==''){
				var theSLtext=FExtension.browserInject.getSelectionText();
				if(theSLtext!=""){
					doc.getElementById("SLG_shadow_translator").style.backgroundColor="";					
					doc.getElementById('SLG_button').style.display="block";
					doc.getElementById('SLG_button').style.opacity=1;
				    	TranslatorIM.SLG_addEvent(doc.getElementById('SLG_button'), 'mousemove', TranslatorIM.SLG_BTN_mousemove);
				    	TranslatorIM.SLG_addEvent(doc.getElementById('SLG_button'), 'mouseover', TranslatorIM.SLG_BTN_mousemove);
				    	TranslatorIM.SLG_addEvent(doc.getElementById('SLG_button'), 'mouseout', TranslatorIM.SLG_BTN_mouseout);
		        	        if(TranslatorIM.SLG_DBL_FLAG==1){
					   var TN = TranslatorIM.SLG_EVENT.target.tagName.toLowerCase();
					   if(TN == "input" || TN == "textarea"){
					     var corrector=-3;
					     TranslatorIM.SLG_GLOBAL_Y1=TranslatorIM.SLG_GLOBAL_Y1+corrector;
					     TranslatorIM.SLG_GLOBAL_Y2=TranslatorIM.SLG_GLOBAL_Y2+corrector;
					   }
					   TranslatorIM.SLG_DBL_FLAG=0;
					}
					TranslatorIM.SLG_GetButtonCurPosition(TranslatorIM.SLG_GLOBAL_X1, TranslatorIM.SLG_GLOBAL_Y1, TranslatorIM.SLG_GLOBAL_X2, TranslatorIM.SLG_GLOBAL_Y2);
				} else doc.getElementById('SLG_button').style.display="none";
			}
		   }
	},

	SLG_HideButton: function(){
	         var doc = FExtension.browserInject.getDocument();
		 var SLdivField=doc.getElementById("SLG_button");
		 if(SLdivField){
			 TranslatorIM.SLG_addEvent(SLdivField, 'mouseover', TranslatorIM.SLG_addButtonColor);
			 TranslatorIM.SLG_addEvent(SLdivField, 'mouseout', TranslatorIM.SLG_removeButtonColor);
			 SLdivField.style.display="none"; 		   
		 }
	},



	SLG_addButtonColor: function() {
		TranslatorIM.unfade();
	},
	SLG_removeButtonColor: function() {
		TranslatorIM.fade();
	},



	SLG_GetButtonCurPosition: function (X1,Y1,X2,Y2) {
	        var doc = FExtension.browserInject.getDocument();
	        var SLdivField = doc.getElementById("SLG_button");

                var delta1=-25;
                if(X1<X2) delta1=10;
                var delta2=-5;

              //  if(Y1<Y2) delta2=10;
                var pos = "top";
                if(Y1<Y2) pos="bottom";

                //VK BUTTON MOVER

                var correctionX = Math.ceil(TranslatorIM.GlobalCorrectionX/2);
                var correctionY = Math.ceil(TranslatorIM.GlobalCorrectionY/2);

		if(PLATFORM=="Opera"){
			if(correctionY==0) correctionY = correctionY-10;
			//VK - for GT only
			correctionX=correctionX+15;
		}else{
			if(correctionX==0) correctionX = correctionX-15;
		}

                if(pos=="top"){
	                //correctionX = correctionX * -1;
        	        correctionY =  correctionY * -1;
		}
                var AL = TranslatorIM.SLG_AlignCoordL(doc,delta1,correctionX);
                var AT = TranslatorIM.SLG_AlignCoordT(doc,delta2,correctionY);

		var bodyScrollLeft = doc.documentElement.scrollLeft || doc.body.scrollLeft;
		var NEWleft = ((X2-delta2+AL)+correctionX);

		if(delta2<0){
			if((bodyScrollLeft+window.innerWidth-40)<=NEWleft) NEWleft=((bodyScrollLeft+window.innerWidth)-40);
		}

		if(NEWleft<5) NEWleft=(bodyScrollLeft+5);
	        SLdivField.style.left = NEWleft+"px";

		var bodyScrollTop = doc.documentElement.scrollTop || doc.body.scrollTop;

		//NEW BUTTON CORRECTION
		correctionY = correctionY-7; 
		//-----------------------

		
	       	if(pos=="top"){
	        	SLdivField.style.top = ((Y2+delta1+AT)+correctionY)+"px";
        		if(((Y2+delta1+AT)+correctionY)<=bodyScrollTop)	SLdivField.style.top = (bodyScrollTop+2)+"px";
        		if(((Y2+delta1+AT)+correctionY)>=(bodyScrollTop+window.innerHeight-25))	SLdivField.style.top = (bodyScrollTop+window.innerHeight-25)+"px";
		} else {
			if(correctionY<0){
				SLdivField.style.top = ((Y2-delta1-AT)-correctionY)+"px";
	        		if(SLdivField.style.top.replace("px","")>=(bodyScrollTop+window.innerHeight-25)){
					SLdivField.style.top = (bodyScrollTop+window.innerHeight-45)+"px";
				}
			}else{
				SLdivField.style.top = ((Y2-AT)-correctionY)+"px";
				if((Y1-delta1-AL-TranslatorIM.GlobalCorrectionY)<=(bodyScrollTop)) SLdivField.style.top = (bodyScrollTop+2)+"px";
			}
		}



	},

        SLG_AlignCoordT: function(doc,delta,correction){
		var T=0;
		var bodyScrollTop = doc.documentElement.scrollTop || doc.body.scrollTop;
		if(correction>0){
			if(bodyScrollTop>(TranslatorIM.SLG_T+bodyScrollTop+delta) && delta < 0){
				if(correction>25) T=correction;
				else              T=25;
			}
			var screen = window.innerHeight;
			var r = (TranslatorIM.SLG_B+bodyScrollTop+correction-(bodyScrollTop+screen));
			if(r<0)	if((bodyScrollTop+screen)<(TranslatorIM.SLG_B+bodyScrollTop+correction) ) T=correction+delta-r;
			if(T==0) T = T + correction;
			else{
				if(T==10) T = -5;
			}
		}else{
			var r = correction+TranslatorIM.SLG_T+bodyScrollTop-bodyScrollTop;
			if(bodyScrollTop>(TranslatorIM.SLG_T+bodyScrollTop+correction)) T=correction-r-delta*2;
			else T=correction; 
		}
		return(T);
	},

        SLG_AlignCoordL: function(doc,delta,correction){
		var L=delta;
		var bodyScrollLeft = doc.documentElement.scrollLeft || doc.body.scrollLeft;
		if(correction>=0){
			if(bodyScrollLeft<(TranslatorIM.SLG_R+bodyScrollLeft)) L=correction;
			var screen = window.innerWidth;
			r = TranslatorIM.SLG_R+bodyScrollLeft+correction-(bodyScrollLeft+screen);
			if(r>delta) r=delta*2;			
			if((bodyScrollLeft+screen)<(TranslatorIM.SLG_R+bodyScrollLeft+correction-delta)){
				L=correction+r;
			}
		}else{
			L=correction; 
			if(bodyScrollLeft>(TranslatorIM.SLG_R+bodyScrollLeft+correction)) L=5;
			if(TranslatorIM.SLG_L<Math.abs(correction)) L=5;
		}
		return(L);
	},

	SLG_GLOBALPosition: function(e, state) {

		if(!e) e = TranslatorIM.SLG_EVENT;
	        var doc = FExtension.browserInject.getDocument();
		var posx = 0;
		var posy = 0;
		if (!e) var e = window.event;

		if(e){
			if (e.pageX || e.pageY){
				posx = e.pageX;
				posy = e.pageY;
			}
			else if (e.clientX || e.clientY){
				posx = e.clientX + doc.body.scrollLeft + doc.documentElement.scrollLeft;
				posy = e.clientY + doc.body.scrollTop + doc.documentElement.scrollTop;
			}
		}


		if(state==0){
			TranslatorIM.SLG_GLOBAL_X1 = posx;
			TranslatorIM.SLG_GLOBAL_Y1 = posy;
		}else{
			TranslatorIM.SLG_GLOBAL_X2 = posx;
			TranslatorIM.SLG_GLOBAL_Y2 = posy;
		}
	},
	//---------------BUTTON
	//---------------BALLOON
        SLG_quikCloseBalloon: function(){
		TranslatorIM.SLG_removeBalloonColor();
		TranslatorIM.SLG_CloseBalloon();
	},

	SLG_ShowBalloon: function(){

		TranslatorIM.SLG_BBL_locer_settler();
	        TranslatorIM.SLG_HideButton();

	        var doc = FExtension.browserInject.getDocument();
		try{
			doc.onmousemove = null;			
		}catch(e){}

		//HANDLER: http://www.legislation.gov.uk/ukpga/2008/22/contents
		var theurl = String(doc.location);
		if(doc.body.innerHTML.indexOf("/1999/xhtml")!=-1 && theurl.indexOf("legislation.gov.uk")!=-1) {	
			//runinliner();
			var theSLtext = FExtension.browserInject.getSelectionText();
			if(theSLtext=="" && TranslatorIM.DBLClick_tempText!="") theSLtext = TranslatorIM.DBLClick_tempText;
		        FExtension.browserInject.runtimeSendMessage({greeting: "PUSH:>"+theSLtext}, function(response) {});
			return false;
		}
   		//-------------------------------------------------------------

		var SLG_tb = doc.getElementById("SLG_TB");
		var SLdivField = doc.getElementById("SLG_shadow_translator");
		var SLdivField2 = doc.getElementById("SLG_button");
		SLdivField2.style.display = "none";


                if(TranslatorIM.SLG_TRIGGER=="FALSE"){
			doc.getElementById("SLG_lng_to").value=TranslatorIM.SLG_langDst;
			doc.getElementById("SLG_lng_from").value=TranslatorIM.SLG_langSrc;
			chrome.runtime.sendMessage({method: "getStatus"}, function(response) {
			 // console.log(response.status);
			});
		}


		doc.getElementById('SLG_planshet').style.background = "#efefef";
		doc.getElementById('SLG_Balloon_options').style.background = "#efefef";


		var SLselect = doc.getElementById("SLG_lng_to");
		var SLselectFROM = doc.getElementById("SLG_lng_from");
		var SLG_locer = doc.getElementById("SLG_locer");
		var SLswitch = doc.getElementById('SLG_switch_b');

		var SLG_P0 = doc.getElementById("SLG_PN0");
		var SLG_P1 = doc.getElementById("SLG_PN1");
		var SLG_P2 = doc.getElementById("SLG_PN2");
		var SLG_P3 = doc.getElementById("SLG_PN3");

		if(SLdivField.style.backgroundColor==""){

	                TranslatorIM.SLShowHideAlert();
		        TranslatorIM.SLG_DETECT = "";
			TranslatorIM.SLG_GetTransCurPosition();
			var theSLtext = FExtension.browserInject.getSelectionText();

			if(theSLtext=="" && TranslatorIM.DBLClick_tempText!="") theSLtext = TranslatorIM.DBLClick_tempText;
			TranslatorIM.DBLClick_tempText="";
			if(theSLtext == "" && TranslatorIM.AVOID_SHADOW_ROOT_TEXT != "") theSLtext = TranslatorIM.AVOID_SHADOW_ROOT_TEXT;
			if(theSLtext != ""){

				theSLtext = theSLtext.substring(0, TranslatorIM.SLG_Balloon_translation_limit);
				var OBJ = doc.getElementById('SLG_pin');

				if(theSLtext.length > TranslatorIM.SLG_Balloon_translation_limit) {
					TranslatorIM.SLG_FLOATER();
				}else{
					var evt = window.event;
					SLdivField.style.backgroundColor = "#FEFEFE";
					if(TranslatorIM.SLG_SID_TEMP_TARGET != "") SLselect.value = TranslatorIM.SLG_SID_TEMP_TARGET;

				}
				var bodyScrollTop = doc.documentElement.scrollTop || doc.body.scrollTop;
				var bodyScrollLeft = doc.documentElement.scrollLeft || doc.body.scrollLeft;

				var OBJ = doc.getElementById('SLG_pin');

				if(TranslatorIM.SLG_FRAME==0){
					if(TranslatorIM.SLG_SAVETEXT == 1){
						TranslatorIM.SLG_NEST="FLOAT";
						TranslatorIM.SLG_SID_PIN="true";
					}
				}

                                theSLtext = theSLtext.trim();
				//theSLtext = theSLtext.replace(/\n/ig," @ "); 

				theSLtext = theSLtext.replace(/(^\s+|\s+$)/g, '');

				TranslatorIM.SLG_TEMP_TEXT = theSLtext;
				var win = null;
				
				TranslatorIM.SLG_BALLOON_TRANSLATION(theSLtext,evt,0, win);
				
				        if(TranslatorIM.GlobalBoxX!=0 && TranslatorIM.GlobalBoxY != 0) TranslatorIM.SLG_NEST = "FLOAT";

					// TO HANDLE INVOKING FROM CM
				        if(TranslatorIM.SLG_NEST=="") TranslatorIM.SLG_NEST="TOP";
				        //---------------------------

	                                switch(TranslatorIM.SLG_NEST){
						case "TOP":  	SLdivField.style.top=TranslatorIM.SLG_T+bodyScrollTop-164+"px"; 
								TranslatorIM.SLG_arrows('up'); 
								OBJ.style.background="url("+FExtension.browserInject.getURL('content/img/util/pin-off.png')+")";
								OBJ.title=FExtension.element(TranslatorIM.SLG_LOC,"extPin_ttl");
								break;
						case "BOTTOM": 	SLdivField.style.top=TranslatorIM.SLG_B+bodyScrollTop+9+"px"; 
								TranslatorIM.SLG_arrows('down'); 
								OBJ.style.background="url("+FExtension.browserInject.getURL('content/img/util/pin-off.png')+")";
								OBJ.title=FExtension.element(TranslatorIM.SLG_LOC,"extPin_ttl");
								break;
						case "FLOAT": 	TranslatorIM.SLG_arrows('all');
								OBJ.style.background="url("+FExtension.browserInject.getURL('content/img/util/pin-on.png')+")";
								OBJ.title=FExtension.element(TranslatorIM.SLG_LOC,"extUnPin_ttl");
								TranslatorIM.SLG_FLOATER();
								break;
					}				


					var situation = 0;
					var setleft=(TranslatorIM.SLG_L+TranslatorIM.SLG_R)/2-448/2;
					if(setleft+473>window.innerWidth){
						setleft=window.innerWidth-467-18;
						var situation = 1;
					}
					if(setleft<25){
						setleft=25;
						var situation = 2;
					}
					var ArrowLeft='3px';

					if(TranslatorIM.SLG_NEST!="FLOAT") SLdivField.style.left=(bodyScrollLeft*1)+setleft +"px";

        	                        var textCenter=Math.ceil((TranslatorIM.SLG_R-TranslatorIM.SLG_L)/2);
					switch(situation){
					  case 0:ArrowLeft='214px'; break;
					  case 1:var obj = (SLdivField.style.left.replace("px","")*1)
						 var coord = TranslatorIM.SLG_L-obj+bodyScrollLeft+textCenter-10;
						 var delta=0;
						 if(bodyScrollLeft!=0) delta=5;
						 if(coord>obj) ArrowLeft = coord-delta+"px";
						 else ArrowLeft=coord+'px'; 
						 break;
					  case 2:if(TranslatorIM.SLG_L<25){
							if(textCenter<25) ArrowLeft='3px';
                	                                else ArrowLeft=textCenter-25 + 'px';
						 }else ArrowLeft=TranslatorIM.SLG_L+textCenter-35+'px'; 
						 break;
					}

					doc.getElementById("SLG_arrow_down").style.left=ArrowLeft;
					doc.getElementById("SLG_arrow_up").style.left=ArrowLeft;

                                TranslatorIM.SLG_Bubble_Reposition();

                               
				TranslatorIM.SLG_NotAllowed();

				TranslatorIM.SLG_addEvent(SLdivField, 'mouseup', TranslatorIM.SLG_ShowBalloon);
			    	TranslatorIM.SLG_addEvent(SLdivField, 'mousedown', TranslatorIM.SLG_CloseBalloon);
			    	TranslatorIM.SLG_addEvent(SLdivField, 'mouseover', TranslatorIM.SLG_addBalloonColor);
			    	TranslatorIM.SLG_addEvent(SLdivField, 'mouseout', TranslatorIM.SLG_removeBalloonColor);

			    	TranslatorIM.SLG_addEvent(SLselect, 'change', TranslatorIM.SLG_retranslate);
			    	TranslatorIM.SLG_addEvent(SLselectFROM, 'change', TranslatorIM.SLG_retranslate);
			    	TranslatorIM.SLG_addEvent(SLG_switch_b, 'click', TranslatorIM.SLG_flip);
			    	TranslatorIM.SLG_addEvent(SLG_locer, 'click', TranslatorIM.SLG_locker);  

			    	TranslatorIM.SLG_addEvent(SLG_P0, 'click', TranslatorIM.SLG_retranslate);  
			    	TranslatorIM.SLG_addEvent(SLG_P1, 'click', TranslatorIM.SLG_retranslate);  
			    	TranslatorIM.SLG_addEvent(SLG_P2, 'click', TranslatorIM.SLG_retranslate);  
			    	TranslatorIM.SLG_addEvent(SLG_P3, 'click', TranslatorIM.SLG_retranslate);  

			    	TranslatorIM.SLG_addEvent(SLG_BBL_locer, 'click', TranslatorIM.SLG_BBL_locer);  

			    	if(theSLtext.indexOf(' ')!=-1){
				    TranslatorIM.SLG_addEvent(doc.getElementById("SLG_shadow_translation_result"), 'mousedown', TranslatorIM.ClickInside);				    
				    TranslatorIM.SLG_addEvent(doc.getElementById("SLG_shadow_translation_result"), 'mousedown', TranslatorIM.SLG_bring_UP);
				    TranslatorIM.SLG_addEvent(doc.getElementById("SLG_shadow_translation_result2"), 'mouseout', TranslatorIM.SLG_addBalloonColor);
			    	}else{
				    TranslatorIM.SLG_addEvent(doc.getElementById("SLG_shadow_translation_result"), 'mousedown', TranslatorIM.ClickInside);
				    TranslatorIM.SLG_addEvent(doc.getElementById("SLG_shadow_translation_result"), 'mousedown', TranslatorIM.SLG_bring_UP);
				    TranslatorIM.SLG_addEvent(doc.getElementById("SLG_shadow_translation_result2"), 'mouseout', TranslatorIM.SLG_bring_DOWN);
			    	}

				



//			    	TranslatorIM.SLG_addEvent(doc.getElementById("SLG_alert100"), 'mousedown', TranslatorIM.SLG_ALERTPROTECT);
			    	TranslatorIM.SLG_addEvent(doc.getElementById("SLG_lng_to"), 'mousedown', TranslatorIM.SLG_SCROLL);
			    	TranslatorIM.SLG_addEvent(doc.getElementById("SLG_lng_to"), 'mouseout', TranslatorIM.SLG_bring_DOWN);
			    	TranslatorIM.SLG_addEvent(doc.getElementById("SLG_TTS_voice"), 'click', TranslatorIM.SLG_Voice);
			    	TranslatorIM.SLG_addEvent(doc.getElementById("SLG_copy"), 'click', TranslatorIM.SLG_CopyToClipBoard);
			    	TranslatorIM.SLG_addEvent(doc.getElementById("SLG_bbl_font"), 'click', TranslatorIM.SLG_Font);
			    	TranslatorIM.SLG_addEvent(doc.getElementById("SLG_pin"), 'click', TranslatorIM.SLG_pinme);
			    	TranslatorIM.SLG_addEvent(doc.getElementById("SLG_bbl_help"), 'click', TranslatorIM.SLG_bbl_help);
			    	TranslatorIM.SLG_addEvent(doc.getElementById("SLG_Balloon_Close"), 'click', TranslatorIM.SLG_CloseBalloonWithLink);
			    	TranslatorIM.SLG_addEvent(doc.getElementById("SLG_Balloon_Close"), 'mouseover', TranslatorIM.SLG_bring_DOWN);



			    	TranslatorIM.SLG_addBalloonColor();
			    	TranslatorIM.SLG_removeBalloonColor();
			    	setTimeout(function() { 
				    	doc.getElementById("SLG_button").style.display = "none";
				}, 10);    
			}
			
		}		 
		var OBJ = doc.getElementById('SLG_shadow_translation_result');
		var OBJ2 = doc.getElementById('SLG_shadow_translation_result2');
		// FONT SIZE icon
		var OBJ3 = doc.getElementById('SLG_bbl_font');




		if(TranslatorIM.SLG_FONT_SID==""){
		 	TranslatorIM.SLG_FontSize_bbl = TranslatorIM.SLG_FONT;
			TranslatorIM.SLG_FONT2 = TranslatorIM.SLG_FONT;
		}else TranslatorIM.SLG_FontSize_bbl = TranslatorIM.SLG_FONT_SID;

		if(TranslatorIM.SLG_FontSize_bbl != OBJ.style.fontSize){
			if(TranslatorIM.SLG_FontSize_bbl == "16px"){
				OBJ.style.fontSize = "16px";
				OBJ.style.lineHeight = "22px";
				OBJ2.style.fontSize = "16px";
				OBJ2.style.lineHeight = "22px";
			}else{
				OBJ.style.fontSize = "14px";
			   	OBJ.style.lineHeight = "20px";
			   	OBJ2.style.fontSize = "14px";
			   	OBJ2.style.lineHeight = "20px";
			}
			TranslatorIM.SLG_FontSize_bbl = OBJ.style.fontSize;
		}

		if(TranslatorIM.SLG_FontSize_bbl == "14px")   OBJ3.className="SLG_font_on";
		if(TranslatorIM.SLG_FontSize_bbl == "16px")   OBJ3.className="SLG_font_off";

		// COPY icon
		doc.getElementById('SLG_copy').className="SLG_copy_hand";
		// TRANSLATION HISTORY icon
		//doc.getElementById('SLG_TH').className="SLG_TH";


		setTimeout(function() { 
                        var SLdivField2=FExtension.browserInject.getDocument().getElementById("SLG_button");
			if(SLdivField2) SLdivField2.style.display = "none";
		}, 1300); 
		if(TranslatorIM.SLG_SHOW_PROVIDERS!="1"){
			doc.getElementById("SLG_Bproviders").style.visibility = "hidden";
		} else 	doc.getElementById("SLG_Bproviders").style.visibility = "visible";

              

		setTimeout(function() { 
	            try {
			if(doc.getElementById('SLG_lng_from')){
			 	if(doc.getElementById('SLG_lng_from').value=="auto"){
					doc.getElementById('SLG_switch_b').title=FExtension.element(TranslatorIM.SLG_LOC,"extDisabled");
					doc.getElementById('SLG_switch_b').style.cursor="not-allowed";
				} else {
					doc.getElementById('SLG_switch_b').title=FExtension.element(TranslatorIM.SLG_LOC,"extSwitch_languages_ttl");
					doc.getElementById('SLG_switch_b').style.cursor="pointer";
				}
			}
		     } catch (ex){}
	 	}, 1300); 

		setTimeout(function() { 
	        	 var obj_1="Tn"+"IT"+"Tt"+"w-t"+"oo"+"lt"+"ip"+"-wr"+"ap";
		         var zi=Math.floor((Math.random() * 100) + 1);
			 if(doc.getElementById(obj_1)) doc.getElementById(obj_1).style.zIndex=zi;
		}, 10); 



        	if(doc.doctype){
	             doc.getElementById("SLG_shadow_translator").style.width="467px";
		}
		TranslatorIM.ACTIVATE_THEMEbbl(TranslatorIM.THEMEmode);
	},

	SLG_BBL_VOICE: function(){	
	   TranslatorIM.TTS_btn_location=0;	
           var doc = FExtension.browserInject.getDocument();	
//	   doc.getElementById('SLG_alert100').style.display="none";	
	   var SLG_to= doc.getElementById("SLG_lng_to").value;	
	   SLG_to= SLG_to.replace("-TW","");	
	   SLG_to= SLG_to.replace("-CN","");	

	   var TTStext=TranslatorIM.SLG_temp_result.replace(/<br>/g, " ");	
	   var text = TTStext;	
	   text = TranslatorIM.truncStrByWord(text,1200);	
	   switch(TranslatorIM.SLG_SLVoices){	
		case "0": if(TranslatorIM.SLG_ALLvoices.indexOf(SLG_to)!=-1){	
                              if(SLG_TTS.indexOf(SLG_to)!=-1){	
				if(text.length>TranslatorIM.GTTS_length) {
					if(SLG_to == "en-gb") SLG_to = "g_en-UK_f";
					window.open("https://text-to-speech.imtranslator.net/?dir="+SLG_to+"&text="+encodeURIComponent(text)); 	
				} else TranslatorIM.Google_TTS(text,SLG_to);	
			      } else TranslatorIM.Google_TTS(text,SLG_to);	
			  } else TranslatorIM.SLG_alert(FExtension.element(TranslatorIM.SLG_LOC,"extNo_Voice"));	
			  break;	
		case "1": if(TranslatorIM.SLG_ALLvoices.indexOf(SLG_to)!=-1){	
				if(G_TTS.indexOf(SLG_to)!=-1) TranslatorIM.Google_TTS(text,SLG_to);	
				else TranslatorIM.SLG_alert(FExtension.element(TranslatorIM.SLG_LOC,"extNo_Voice"));	
			  } else TranslatorIM.SLG_alert(FExtension.element(TranslatorIM.SLG_LOC,"extNo_Voice"));	
			  break;	
		case "2": if(TranslatorIM.SLG_ALLvoices.indexOf(SLG_to)!=-1){	
                              if(SLG_TTS.indexOf(SLG_to)!=-1) {
					if(SLG_to == "en-gb") SLG_to = "g_en-UK_f";
					window.open("https://text-to-speech.imtranslator.net/?dir="+SLG_to+"&text="+encodeURIComponent(text));	
			      }else TranslatorIM.Google_TTS(text,SLG_to);	
			  } else TranslatorIM.SLG_alert(FExtension.element(TranslatorIM.SLG_LOC,"extNo_Voice"));	
			  break;	
	   }	
	},	

	SLG_BBL_locer_settler: function(){
          var doc = FExtension.browserInject.getDocument();
	 if(TranslatorIM.SLG_OnOff_BTN2=="true") doc.getElementById('SLG_BBL_locer').checked=true;
	 else doc.getElementById('SLG_BBL_locer').checked=false;
	},

	SLG_BBL_locer: function(){
		if(TranslatorIM.SLG_EVENT){ 
			var ev = TranslatorIM.SLG_EVENT;
		        var doc = FExtension.browserInject.getDocument();

				if(doc.getElementById('SLG_BBL_locer')) {
					if(ev.target.id == "SLG_BBL_locer") TranslatorIM.SLG_OnOff_BTN2 = doc.getElementById('SLG_BBL_locer').checked.toString();
				}
			TranslatorIM.SAVE_SES_PARAMS();
		}
	},

	SLG_bbl_help: function(){
		switch(PLATFORM){
			 case "Opera" : var slurl="https://about.imtranslator.net/tutorials/presentations/google-translate-for-opera/opera-popup-bubble/"; break;
			 case "Chrome": var slurl="https://about.imtranslator.net/tutorials/presentations/imtranslator-for-chrome/chrome-bubble-translator/"; break;
			 default      : var slurl="https://about.imtranslator.net/tutorials/presentations/";break;
		}
		window.open(slurl,"ImTranslator:Bubble");
	},


	SLG_locker: function(){	
	        var doc = FExtension.browserInject.getDocument();
		var ev = TranslatorIM.SLG_EVENT;
		if(doc.getElementById('SLG_locer')) {
			if(ev.target.id == "SLG_locer"){
				if(doc.getElementById('SLG_locer').checked==false){
					TranslatorIM.SLG_TMPbox="false";
				} else {
					TranslatorIM.SLG_TMPbox="true";
				}
				TranslatorIM.SLG_MAKE_FROM();
			}
		}

	},

	SLG_locker_settler: function(){
	        var doc = FExtension.browserInject.getDocument();
		if(TranslatorIM.SLG_TMPbox=="true") {
			doc.getElementById('SLG_locer').checked=true;
			TranslatorIM.SLG_TMPbox="true";
		}else{ 
			doc.getElementById('SLG_locer').checked=false;
			TranslatorIM.SLG_TMPbox="false";
		}		
	},


        SLG_ALERTPROTECT: function(){
                TranslatorIM.SLG_quikCloseBalloon();
	},

	SLG_flip: function(){
	        var doc = FExtension.browserInject.getDocument();
		try{ doc.onmousemove = null; }catch(e) { console.log(e); }
		var SLselTO=doc.getElementById("SLG_lng_to");
		var SLselFROM=doc.getElementById("SLG_lng_from");
		if(SLselFROM.value!="auto"){
 		 if(TranslatorIM.SLG_DETECT != SLselFROM.value || doc.getElementById('SLG_locer').checked==true){
		   var TMP = SLselTO.value;
		   SLselTO.value=SLselFROM.value;
		   SLselFROM.value=TMP;  		   
		 }
		 TranslatorIM.SLG_retranslate();
		}
	},

        SLG_hist: function(){
		window.open(FExtension.browserInject.getURL('options.html?hist', true),"ImTranslator:Translation_History");
	},

	SLG_SYN: function(ob){
		TranslatorIM.SLG_retranslate();
	},

	SLG_bring_UP: function(){
	    try{
		var doc = FExtension.browserInject.getDocument();

       	   	doc.getElementById('SLG_alert100').style.display="none";

		if(window.event && window.event.which==1){
			var theMainOBJ = doc.getElementById('SLG_shadow_translator');
			var theOBJ = doc.getElementById('SLG_shadow_translation_result');
			var theOBJ2 = doc.getElementById('SLG_shadow_translation_result2');
			var ToLng = doc.getElementById('SLG_lng_to').value;
			theOBJ2.style.display = 'block';
			theOBJ2.style.marginTop = theMainOBJ.offsetTop + 30 + "px";
			theOBJ2.style.marginLeft = theMainOBJ.offsetLeft + 1 + "px";
			theOBJ.style.visibility = "hidden";


                        theOBJ2.style.direction="ltr";
                        theOBJ2.style.textAlign="left";

			if(ToLng=="ar" || ToLng=="iw" || ToLng=="fa" || ToLng=="yi" || ToLng=="ur" || ToLng=="ps" || ToLng=="sd" || ToLng=="ckb" || ToLng=="ug" || ToLng=="dv" || ToLng=="prs"){
                          theOBJ2.style.direction="rtl";
                          theOBJ2.style.textAlign="right";
			}
		}
	     }catch(ex){}
	},

	SLG_bring_DOWN: function(){
		var theOBJ = FExtension.browserInject.getDocument().getElementById('SLG_shadow_translation_result');
		var theOBJ2 = FExtension.browserInject.getDocument().getElementById('SLG_shadow_translation_result2');
	        if(theOBJ2){
			theOBJ2.style.display = 'none';
			theOBJ.style.visibility = "visible";
		}
	},

	SLG_MAKE_FROM:function(){     
	        var doc = FExtension.browserInject.getDocument();
		var SLselFROM = doc.getElementById("SLG_lng_from");
		var SLselTO = doc.getElementById("SLG_lng_to");
		if(doc.getElementById('SLG_locer').checked!=true){
		     if(TranslatorIM.SLG_Finde_Lang()==1){
 			if(TranslatorIM.LNGforHISTORY == SLselTO.value){
			   var TMP = SLselTO.value;
			   SLselTO.value=SLselFROM.value;
			   SLselFROM.value=TMP;  		   
			}else{
				SLselFROM.value = TranslatorIM.LNGforHISTORY;
			}
		     }  else {
 			if(TranslatorIM.LNGforHISTORY == SLselTO.value){
			   var TMP = SLselTO.value;
			   SLselTO.value=SLselFROM.value;
			   SLselFROM.value=TMP;  		   
			}

		     }
		}
		TranslatorIM.SLG_retranslate();
	},

	SLG_Finde_Lang(){
		var out = 0;
		var ln = TranslatorIM.LNGforHISTORY;
		var MENU = TranslatorIM.SLG_LNG_LIST.split(",");
		for(var i = 0; i<MENU.length; i ++){
			if(MENU[i]==ln) out = 1;
		}
		return out;
	},

	SLG_retranslate:function(){     
	   if(TranslatorIM.SLG_EVENT.target.parentNode.className!="SLG_BL_LABLE_DEACT"){
		TranslatorIM.AutoFlipState=0;
		TranslatorIM.FlippedByAuto=0;
	        var doc = FExtension.browserInject.getDocument();
	   	doc.getElementById('SLG_alert100').style.display="none";
		TranslatorIM.SLG_bring_DOWN();
		TranslatorIM.SLG_bring_UP();
		
		var theSLtext = FExtension.browserInject.getSelectionText();
                //theSLtext = theSLtext.replace("\n","");
		if(theSLtext == "") theSLtext = TranslatorIM.SLG_TEMP_TEXT;
		//theSLtext=theSLtext.replace(/\n/ig," @ "); 

		TranslatorIM.SLG_BALLOON_TRANSLATION(theSLtext,window.event, 1);	
		if(doc.getElementById('SLG_lng_from').value=="auto"){
			doc.getElementById('SLG_switch_b').title=FExtension.element(TranslatorIM.SLG_LOC,"extDisabled");
			doc.getElementById('SLG_switch_b').style.cursor="not-allowed";
		} else { 
			doc.getElementById('SLG_switch_b').title=FExtension.element(TranslatorIM.SLG_LOC,"extSwitch_languages_ttl");
			doc.getElementById('SLG_switch_b').style.cursor="pointer";
		}
		
                switch(TranslatorIM.SLG_NEST){
			case "TOP": TranslatorIM.SLG_arrows('up'); break;
			case "BOTTOM": TranslatorIM.SLG_arrows('down'); break;
			case "FLOAT": TranslatorIM.SLG_arrows('all'); break;
		}
                TranslatorIM.SLG_HideShowTTSicon();
//                TranslatorIM.SLG_DETECT="";
		TranslatorIM.SLG_NotAllowed();
		TranslatorIM.SET_FIRST_AVAILABLE_PROV();
		TranslatorIM.SAVE_SES_PARAMS();
	   }	
	},

        SLG_HideShowTTSicon: function(){
	         var doc = FExtension.browserInject.getDocument();
		 var SLG_from = doc.getElementById('SLG_lng_from').value;
		 if(doc.getElementById('SLG_locer').checked==false || doc.getElementById('SLG_lng_from').value=="auto") SLG_from = TranslatorIM.SLG_DETECT;
		 if(TranslatorIM.SLG_ALLvoices.indexOf(SLG_from)!=-1) doc.getElementById('SLG_TTS_voice').style.visibility="visible";
		 else doc.getElementById('SLG_TTS_voice').style.visibility="hidden";
	},

	SLG_CloseBalloonWithLink: function(){
	    	try{
		 	var doc = FExtension.browserInject.getDocument();
		  	doc.getElementById('SLG_shadow_translator').style.display='none';		
                        TranslatorIM.SLG_BBL_OBJ_OFF(1);
		}catch (ex){}
	},

	SLG_CloseBalloon: function() {
	 try{
           var doc = FExtension.browserInject.getDocument();
	   var bodyScrollLeft = doc.documentElement.scrollLeft || doc.body.scrollLeft;
	   if((window.innerWidth+bodyScrollLeft-window.event.pageX)>20){

		var SLdivField = doc.getElementById("SLG_shadow_translator");
		if(doc.getElementById('SLG_shadow_translation_result2').style.display == "none"){
			TranslatorIM.SLG_Xdelta = window.event.pageX - SLdivField.offsetLeft;
			TranslatorIM.SLG_Ydelta = window.event.pageY - SLdivField.offsetTop;

			TranslatorIM.SLG_addEvent(SLdivField, 'mouseover', TranslatorIM.SLG_addBalloonColor);
			TranslatorIM.SLG_addEvent(SLdivField, 'mouseout', TranslatorIM.SLG_removeBalloonColor);

			if(SLdivField.style.backgroundColor == ""){
				if(TranslatorIM.SLG_SAVETEXT == 0){
					doc.getElementById("SLG_shadow_translation_result").innerText="";
					doc.getElementById("SLG_shadow_translation_result2").innerText="";
	                              	SLdivField.style.left="-10000px";
	                                SLdivField.style.top="-10000px";
					SLdivField.style.display = 'none';
				}
                                doc.getElementById('SLG_balloon_obj').alt="0";
			}else{
				var evt = window.event;
				TranslatorIM.SLG_MoveX = evt.pageX + "px";
				TranslatorIM.SLG_MoveY = evt.pageY + "px";
				try{
				    if(evt.target.id!="SLG_pin")	doc.onmousemove = TranslatorIM.SLG_GetTransCurPosition;
				}catch(e){}
			}
		}
	    }
	 } catch(ex){}
	},

	SLG_addBalloonColor: function() {
	        var doc = FExtension.browserInject.getDocument();
		var SLdivField = doc.getElementById("SLG_shadow_translator");
		if(SLdivField){
			SLdivField.style.backgroundColor = "#FEFEFE";
			SLdivField.style.boxShadow = "0px 0px 0px #000";
		}
	},
	SLG_removeBalloonColor: function() {
        	var doc = FExtension.browserInject.getDocument();
		var SLdivField = doc.getElementById("SLG_shadow_translator");
		if(SLdivField){
			SLdivField.style.backgroundColor = "";
			SLdivField.style.boxShadow = "0px 0px 0px #BAB9B5";
		}
	},


	SLG_addEvent: function( obj, type, fn ) {
		if (obj) {
			if ( obj.attachEvent ) {
				obj['e'+type+fn] = fn;
				obj[type+fn] = function(){ obj['e'+type+fn]( window.event ); }
				obj.attachEvent( 'on'+type, obj[type+fn] );
			} else 	obj.addEventListener(type, fn, false);
		}
	},



	SLG_Bubble_Reposition: function() {
		setTimeout(function(){
			var doc = FExtension.browserInject.getDocument();
			var SLdivField = doc.getElementById("SLG_shadow_translator");
			var bodyScrollTop = doc.documentElement.scrollTop || doc.body.scrollTop;
			var bodyScrollLeft = doc.documentElement.scrollLeft || doc.body.scrollLeft;
			var position = SLdivField.getBoundingClientRect();
			var x = position.left;
			var y = position.top;
			var DELTAy = 1;
			if (doc.body.offsetHeight < window.innerHeight)	var DELTAy = 17;

			var DELTAx = 1;
			if (doc.body.offsetWidth < window.innerWidth)	var DELTAx = 17;

			if((x+SLdivField.offsetWidth)>(bodyScrollLeft+window.innerWidth-DELTAx)){
				TranslatorIM.SLG_MoveX = (bodyScrollLeft+window.innerWidth-SLdivField.offsetWidth-DELTAx) +"px";
                                SLdivField.style.left = TranslatorIM.SLG_MoveX;
			}
		}, 50);  
	},

	SLG_GetTransCurPosition: function(e) {
	 try{
	  if(e){
		var doc = FExtension.browserInject.getDocument();
		var posx = 0;
		var posy = 0;
		if (!e) var e = window.event;
		var id = e.target.id;
		var cl = e.target.className;
		var SLdivField = doc.getElementById("SLG_shadow_translator");
		if(cl!="SLG_options" && (id.indexOf("SLG_")==-1 || id=="SLG_button")){
			if (e.pageX || e.pageY)	{
				posx = e.pageX;
				posy = e.pageY;
			}
			else if (e.clientX || e.clientY) {
				posx = e.clientX + doc.body.scrollLeft + doc.documentElement.scrollLeft;
				posy = e.clientY + doc.body.scrollTop + doc.getDocument().documentElement.scrollTop;
			}


			var bodyScrollTop = doc.documentElement.scrollTop || doc.body.scrollTop;
			var bodyScrollLeft = doc.documentElement.scrollLeft || doc.body.scrollLeft;

			var DELTAy = 1;
			if (doc.body.offsetHeight < window.innerHeight)	var DELTAy = 17;

			var DELTAx = 1;
			if (doc.body.offsetWidth < window.innerWidth)	var DELTAx = 17;

			TranslatorIM.SLG_MoveX = posx - TranslatorIM.SLG_Xdelta + "px";
			if((posx - TranslatorIM.SLG_Xdelta) < bodyScrollLeft) {
				TranslatorIM.SLG_MoveX = (bodyScrollLeft+DELTAx) +"px";
			}
			if((posx - TranslatorIM.SLG_Xdelta) > (bodyScrollLeft+window.innerWidth - SLdivField.offsetWidth-DELTAx) ) {
				TranslatorIM.SLG_MoveX = (bodyScrollLeft+window.innerWidth - SLdivField.offsetWidth-DELTAx) +"px";
			}
		
			TranslatorIM.SLG_MoveY = posy - TranslatorIM.SLG_Ydelta + "px";
			if((posy - TranslatorIM.SLG_Ydelta) < bodyScrollTop) {
				TranslatorIM.SLG_MoveY = bodyScrollTop +"px";
			}
			if((posy - TranslatorIM.SLG_Ydelta) > (bodyScrollTop+window.innerHeight - SLdivField.offsetHeight-DELTAy) ) {
				TranslatorIM.SLG_MoveY = (bodyScrollTop+window.innerHeight - SLdivField.offsetHeight-DELTAy) +"px";
			}



			if(TranslatorIM.SLG_FRAME==0){
				TranslatorIM.GlobalBoxY=TranslatorIM.SLG_MoveY.replace("px","")-bodyScrollTop;
				TranslatorIM.GlobalBoxX=TranslatorIM.SLG_MoveX.replace("px","")-bodyScrollLeft;
	               		FExtension.browserInject.runtimeSendMessage({greeting: "SAVE_COORD:>"+TranslatorIM.GlobalBoxX+","+TranslatorIM.GlobalBoxY}, function(response) {});
			}
			SLdivField.style.left = TranslatorIM.SLG_MoveX;
			SLdivField.style.top = TranslatorIM.SLG_MoveY;


			var OBJ = doc.getElementById('SLG_pin');

			if(TranslatorIM.SLG_FRAME==0){
				if(cl!="SLG_options"){
					OBJ.style.background="url("+FExtension.browserInject.getURL('content/img/util/pin-on.png')+")";
					OBJ.title=FExtension.element(TranslatorIM.SLG_LOC,"extUnPin_ttl");
					TranslatorIM.SLG_NEST="FLOAT";
					TranslatorIM.SLG_arrows('all');
					TranslatorIM.SLG_SID_PIN="true";
					TranslatorIM.SLG_FLOATER();
				} 
			}

			if(id!="" || cl!=""){
				//STOPS MOUSE EVENT WHEN A CURSOR IS PRESSED ON THE ARROWS
				if(id=="SLG_arrow_down" || id=="SLG_arrow_up" || id=="SLG_Balloon_Close" || cl=="SLG_options"){ 
					var sel = window.getSelection ? window.getSelection() : document.selection;
					SLdivField.style.backgroundColor = "#FEFEFE";
					TranslatorIM.SLG_ShowBalloon();
					sel.removeAllRanges();
				}

				//STOPS MOUSE EVENT WHEN A CURSOR IS OUT OF VIEWPORT

				var OUTofVIEWport=5; // was: 50;
				if(e.clientX<=OUTofVIEWport || e.clientY<10 || (e.clientX+OUTofVIEWport) >= (window.innerWidth-DELTAx) || (e.clientY+OUTofVIEWport) >= (window.innerHeight-DELTAy)){
					var sel = window.getSelection ? window.getSelection() : document.selection;
					SLdivField.style.backgroundColor = "#FEFEFE";
					TranslatorIM.SLG_ShowBalloon();
					sel.removeAllRanges();
					if (e.stopPropagation) {
					      e.stopPropagation();
					}
				}
			}
		}
	   }
	 }catch(ex){}
	},

	SLG_IMG_LOADER: function(){
		TranslatorIM.LISTofPR = TranslatorIM.SLG_ALL_PROVIDERS_BBL.split(",");
		for (var SLG_I = 0; SLG_I < TranslatorIM.LISTofPR.length; SLG_I++){
		    switch(TranslatorIM.LISTofPR[SLG_I]){
			case "Google": TranslatorIM.LISTofPRpairs[SLG_I]=LISTofLANGsets[0];break;
			case "Microsoft": TranslatorIM.LISTofPRpairs[SLG_I]=LISTofLANGsets[1];break;
			case "Translator": TranslatorIM.LISTofPRpairs[SLG_I]=LISTofLANGsets[2];break;
			case "Yandex": TranslatorIM.LISTofPRpairs[SLG_I]=LISTofLANGsets[3];break;
		    }	
		}
	        var ext = FExtension.browserInject;
		var doc = ext.getDocument()
            	doc.getElementById('SLG_pin').style.background='url('+ext.getURL('content/img/util/pin-on.png')+')';

       		doc.getElementById('SLG_TTS_voice').style.background='url('+ext.getURL('content/img/util/ttsvoice.png')+')';
            	doc.getElementById('SLG_switch_b').style.background='url('+ext.getURL('content/img/util/switchb.png')+')';
       	    	doc.getElementById('SLG_copy').style.background='url('+ext.getURL('content/img/util/copy.png')+')';
               	doc.getElementById('SLG_bbl_font').style.background='url('+ext.getURL('content/img/util/font.png')+')';
            	doc.getElementById('SLG_bbl_help').style.background='url('+ext.getURL('content/img/util/bhelp.png')+')';
	    	doc.getElementById('SLG_Balloon_options').style.background="#FFF url('"+ext.getURL('content/img/util/bg3.png')+"')";
    		doc.getElementById('SLG_loading').style.background="url('"+ext.getURL('content/img/util/loading.gif')+"')";
	    	doc.getElementById('SLHKclose').style.background="url('"+ext.getURL('content/img/util/delete.png')+"')";
	    	doc.getElementById('SLG_arrow_down').style.background="url('"+ext.getURL('content/img/util/down.png')+"')";
    		doc.getElementById('SLG_arrow_up').style.background="url('"+ext.getURL('content/img/util/up.png')+"')";
	    	doc.getElementById('SLG_BBL_IMG').style.background="url('"+ext.getURL('content/img/util/bbl-logo.png')+"')";
	},

	//---------------BALLOON

        CONTROL_SUM_SYN: function (text){
           if(TranslatorIM.SLG_DETECT == "") TranslatorIM.CONTROL_SUM="";
	},

	DODetection: function(myTransText) {
 	   myTransText = myTransText.replace(/@/ig,"")
	   myTransText = myTransText.trim();
	   var doc = FExtension.browserInject.getDocument();
	   TranslatorIM.SLG_SETINTERVAL_ST=0;
	   var AUTO = doc.getElementById('SLG_locer').checked;
	   var isAuto=0;

	   //DETECTION ONLY ONCE-------------------
           TranslatorIM.CONTROL_SUM_SYN(myTransText);
	   if(TranslatorIM.CONTROL_SUM == myTransText){
		AUTO = true;
		isAuto = 0;
	   } else TranslatorIM.CONTROL_SUM = myTransText;
	   //DETECTION ONLY ONCE-------------------
	   if(doc.getElementById('SLG_lng_from').value=="auto"){AUTO = false; isAuto=1;}

	   if(AUTO==false || isAuto==1){
		  if(myTransText!=""){

			    myTransText = myTransText.replace(/|/g,"");
			    myTransText = myTransText.replace(/&/g,"");
			    myTransText = myTransText.replace(/$/g,"");
			    myTransText = myTransText.replace(/^/g,"");
			    myTransText = myTransText.replace(/~/g,"");
			    myTransText = myTransText.replace(/`/g,"");
			    myTransText = myTransText.replace(/@/g,"");
			    myTransText = myTransText.replace(/%/g," ");
			    var a=Math.floor((new Date).getTime()/36E5)^123456;
			    var tk = a+"|"+Math.floor((Math.sqrt(5)-1)/2*(a^654321)%1*1048576);
			    var num = Math.floor((Math.random() * SLG_GEO.length)); 
			    var theRegion = SLG_GEO[num];
			    var cntr = myTransText.split(" ");
                	    var newTEXT = truncStrByWord(myTransText,100);
			    if(TranslatorIM.SLG_DOM!="auto") theRegion=TranslatorIM.SLG_DOM;


			    var baseUrl ="https://translate.google."+theRegion+"/translate_a/single";
			    var SLG_Params = "client=gtx&dt=t&dt=bd&dj=1&source=input&q="+encodeURIComponent(newTEXT)+"&sl=auto&tl=en&hl=en";



			   FExtension.browserInject.runtimeSendMessage({from:"content_detect", url: baseUrl, cgi:SLG_Params,});
			   chrome.runtime.onMessage.addListener(function(msg) {
			   if (msg.from == "background") {
				TranslatorIM.BBL_DETECT = msg.detected;

						chrome.runtime.onMessage.removeListener(arguments.callee);
						if(TranslatorIM.BBL_DETECT!="" && TranslatorIM.BBL_DETECT!="<#>") {
							var resp = TranslatorIM.BBL_DETECT;
							TranslatorIM.BBL_DETECT="";

							if(doc.getElementById("SLG_shadow_translator").style.display=='block'){	
							       	var myTransText = FExtension.browserInject.getSelectionText();
								if(myTransText == "") myTransText = TranslatorIM.SLG_TEMP_TEXT;
								var AUTO = doc.getElementById('SLG_locer').checked;
								DetLang = resp;
								var Det=DetLang;


						                TranslatorIM.CNTR('2211',Det+"/"+Det, newTEXT.length);

								// NOT TRUSTED LANGUAGES
								myTransText = myTransText.trim();
								TranslatorIM.globaltheQ = myTransText.split(" ").length;

					                        if(TranslatorIM.SLG_UNTRUST_WORD.indexOf(Det)!=-1 && TranslatorIM.globaltheQ==1){
									TranslatorIM.SLDetector(myTransText);
									return false;
								}	

					                        if(Det==TranslatorIM.SLG_UNTRUST_TEXT){
									TranslatorIM.CONTROL_SUM="";TranslatorIM.SLDetector(myTransText);
									return false;
								}
								//----------------------


					                        TranslatorIM.SLG_DETECT = DetLang;
					                        TranslatorIM.SLG_DETECTED = DetLang;
				        	                TranslatorIM.SLG_FLAG=0;
				                	        var cnt=0;

								var LANGSALL = FExtension.element(TranslatorIM.SLG_LOC,'extLanguages').split(",");
								var LANGS = TranslatorIM.SLG_LNG_LIST.split(",");

								for (var i = 0; i < LANGSALL.length; i++){
									var templang = LANGSALL[i].split(":");
									if(DetLang == templang[0]){ 
									        var tmp = doc.getElementById('SLG_lng_from').value;
										if(tmp == "" || tmp == "auto") tmp = TranslatorIM.SLG_langSrc;
										//DetLang=tmp;
										TranslatorIM.SLG_FLAG=1;
										cnt=1;
									}
								}

			                        	        TranslatorIM.SLG_WRONGLANGUAGEDETECTED=0;
								if(cnt==0){
			        	                                TranslatorIM.SLG_DETECT = DetLang;
						                        TranslatorIM.SLG_DETECTED = DetLang;
									TranslatorIM.SLG_setTMPdata("BL_D_PROV","Google");
									TranslatorIM.SLG_setTMPdata("BL_T_PROV","Google");
									TranslatorIM.SLG_WRONGLANGUAGEDETECTED=1;
								}

				                                TranslatorIM.SLG_HideShowTTSicon(); 
			        	                	TranslatorIM.LNGforHISTORY = DetLang;

				        	                TranslatorIM.SLG_SID_FROM = doc.getElementById('SLG_lng_from').value;
								TranslatorIM.SLG_SID_TO   = doc.getElementById('SLG_lng_to').value;

							        if(TranslatorIM.SLG_SID_TO!=""){
									doc.getElementById('SLG_lng_from').value=TranslatorIM.SLG_SID_FROM;
									doc.getElementById('SLG_lng_to').value=TranslatorIM.SLG_SID_TO;
								}

						                if(doc.getElementById('SLG_lng_to').value==resp && doc.getElementById('SLG_lng_from').value!="auto"){
						                        var TMP=doc.getElementById('SLG_lng_to').value;
						                        doc.getElementById('SLG_lng_to').value = doc.getElementById('SLG_lng_from').value;
					        	                doc.getElementById('SLG_lng_from').value = TMP;
									TranslatorIM.SLG_SID_FROM=doc.getElementById('SLG_lng_from').value;
									TranslatorIM.SLG_SID_TO=doc.getElementById('SLG_lng_to').value;
                                                                        TranslatorIM.AutoFlipState=1;
									TranslatorIM.FlippedByAuto=1;
					       	        	}else{
									// AVOIDING AUTO DETETECT TAG 
									var autopattern = TranslatorIM.AUTOhandler(doc,AUTO,DetLang);
			                       	        		if(doc.getElementById('SLG_lng_from').value!=autopattern){
				                       	                cnt=0;
									for (var i = 0; i < LANGS.length; i++){
										var templang = LANGS[i].split(":");
										if(DetLang == templang[0]) cnt=1;
									}
									if(cnt==1){TranslatorIM.FlippedByAuto=1; doc.getElementById('SLG_lng_from').value=DetLang;}
								}
							}

						        TranslatorIM.SLG_SETINTERVAL_ST=1;

						   }
			        	    	}  else {
							TranslatorIM.SLDetector(TranslatorIM.SLG_TEMP_TEXT);
						}

			  }
			});


	          }
	 }else{



	     	TranslatorIM.SLG_SID_FROM = doc.getElementById('SLG_lng_from').value;
		TranslatorIM.SLG_SID_TO  = doc.getElementById('SLG_lng_to').value;
       		if(TranslatorIM.SLG_SID_TO!=""){
			doc.getElementById('SLG_lng_from').value=TranslatorIM.SLG_SID_FROM;
			doc.getElementById('SLG_lng_to').value=TranslatorIM.SLG_SID_TO;
		}
		if(TranslatorIM.SLG_SID_FROM=="auto" && TranslatorIM.SLG_DETECT!="" && doc.getElementById('SLG_locer').checked==false) doc.getElementById('SLG_lng_from').value=TranslatorIM.SLG_DETECT;

		TranslatorIM.SLG_SETINTERVAL_ST=1;


	 }

         TranslatorIM.FlipNonStandartDir(doc);
	},


	FlipNonStandartDir: function(doc){

		if(doc.getElementById('SLG_lng_from').value != "auto" && doc.getElementById('SLG_locer').checked==false){
		        if(TranslatorIM.SLG_DETECT == "zh") TranslatorIM.SLG_DETECT="zh-CN";
			if(TranslatorIM.SLG_DETECT == "zt") TranslatorIM.SLG_DETECT="zh-TW";
			if(TranslatorIM.SLG_DETECT == "or-IN") TranslatorIM.SLG_DETECT="or";
			if(TranslatorIM.SLG_DETECT == "ku-Latn") TranslatorIM.SLG_DETECT="ku";
			if(TranslatorIM.SLG_DETECT == "ku-Arab") TranslatorIM.SLG_DETECT="ckb";
			if(TranslatorIM.SLG_DETECT == "sr-Latn-RS") TranslatorIM.SLG_DETECT="sr-Latn";


		  	if(doc.getElementById("SLG_lng_to").value == "tlsl" && TranslatorIM.SLG_DETECT == "tl") TranslatorIM.SLG_DETECT = "tlsl";
			if(doc.getElementById("SLG_lng_to").value == "srsl" && TranslatorIM.SLG_DETECT == "sr") TranslatorIM.SLG_DETECT = "srsl";
		  	if(doc.getElementById("SLG_lng_to").value == "tl" && TranslatorIM.SLG_DETECT == "tlsl") TranslatorIM.SLG_DETECT = "tl";
		  	if(doc.getElementById("SLG_lng_to").value == "sr" && TranslatorIM.SLG_DETECT == "srsl") TranslatorIM.SLG_DETECT = "sr";

		  if(doc.getElementById("SLG_lng_to").value == TranslatorIM.SLG_DETECT){
			var TMP=doc.getElementById('SLG_lng_to').value;
			doc.getElementById('SLG_lng_to').value = doc.getElementById('SLG_lng_from').value;
			doc.getElementById('SLG_lng_from').value = TMP;
			doc.getElementById('SLG_lng_from').title=FExtension.element(TranslatorIM.SLG_LOC,'extDetected') + " " + TranslatorIM.SLG_GetLongName(TranslatorIM.SLG_DETECT);
		  }
		}

	},



	SLDetector: function(myTransText) {
		myTransText = myTransText.replace(/@/ig,"");
		setTimeout(function() {

		var doc = FExtension.browserInject.getDocument();
		TranslatorIM.SLG_SETINTERVAL_ST=0;
		var AUTO = doc.getElementById('SLG_locer').checked;
		if(AUTO==false || doc.getElementById('SLG_lng_from').value=="auto"){
		  if(myTransText!=""){

		    myTransText = myTransText.replace(/|/g,"");
		    myTransText = myTransText.replace(/&/g,"");
		    myTransText = myTransText.replace(/$/g,"");
		    myTransText = myTransText.replace(/^/g,"");
		    myTransText = myTransText.replace(/~/g,"");
		    myTransText = myTransText.replace(/`/g,"");
		    myTransText = myTransText.replace(/@/g,"");
		    myTransText = myTransText.replace(/%/g," ");

		    var theLIMIT = 100;
		    //myTransText = TranslatorIM.DELAY+"XX"+myTransText;
		    var fr = doc.getElementById('SLG_lng_from').value;
		    if(doc.getElementById('SLG_lng_from').value=="auto") fr="*a";
                    TranslatorIM.CNTRP('2211',fr+"/"+doc.getElementById('SLG_lng_to').value, truncStrByWord(myTransText,100).length);


		    var SLDImTranslator_url = TranslatorIM.ImTranslator_theurl+"ld.asp?tr=bl&text="+encodeURIComponent(truncStrByWord(myTransText,theLIMIT));

			var ajaxRequest;  
			try{
				ajaxRequest = new XMLHttpRequest();
			} catch (e){
				try{
					ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
				} catch (e) {
					try{
						ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
					} catch (e){
						TranslatorIM.SLG_alert(FExtension.element(TranslatorIM.SLG_LOC,"extError1"));
						return false;
					}
				}
			}
			ajaxRequest.onreadystatechange = function(){
				if(ajaxRequest.readyState == 4){

		                   var resp = ajaxRequest.responseText;

		                   if(resp!=""){     
					if(resp.indexOf('#|#')!=-1){
				 	  	var tmp=decodeURIComponent(resp);
						var tmp2 = tmp.split("#|#");
					  	resp=tmp2[0];               

						var DetLang = resp;

						DetLang=DetLang.replace("zh","zh-CN");
						DetLang=DetLang.replace("zt","zh-TW");

                                                TranslatorIM.SLG_FLAG=0;
						var LANGSALL = FExtension.element(TranslatorIM.SLG_LOC,'extLanguages').split(",");
						var LANGS = TranslatorIM.SLG_LNG_LIST.split(",");
						var cnt=0;



						for (var i = 0; i < LANGSALL.length; i++){
							var templang = LANGSALL[i].split(":");
							if(DetLang == templang[0] ){ 
							        var tmp = doc.getElementById('SLG_lng_from').value;
								if(tmp == "" || tmp == "auto") tmp = TranslatorIM.SLG_langSrc;
								//DetLang=tmp;
								cnt=1;
								TranslatorIM.SLG_FLAG=1;
							}
						}


                                                TranslatorIM.SLG_WRONGLANGUAGEDETECTED=0;
						if(cnt==0){
							if(doc.getElementById('SLG_lng_from').value!="auto") DetLang=doc.getElementById('SLG_lng_from').value;
						        else DetLang="en";
							TranslatorIM.SLG_WRONGLANGUAGEDETECTED=1;						        
							TranslatorIM.SLG_setTMPdata("BL_D_PROV","Google");
							TranslatorIM.SLG_setTMPdata("BL_T_PROV","Google");
						}

                                                TranslatorIM.SLG_DETECT =  DetLang;
			                        TranslatorIM.SLG_DETECTED = DetLang;
		                        	TranslatorIM.LNGforHISTORY = DetLang;
                                                TranslatorIM.SLG_HideShowTTSicon();


			                        TranslatorIM.SLG_SID_FROM = doc.getElementById('SLG_lng_from').value;
						TranslatorIM.SLG_SID_TO   = doc.getElementById('SLG_lng_to').value;
						        if(TranslatorIM.SLG_SID_TO!=""){
								doc.getElementById('SLG_lng_from').value=TranslatorIM.SLG_SID_FROM;
								doc.getElementById('SLG_lng_to').value=TranslatorIM.SLG_SID_TO;
							}




			                        if(doc.getElementById('SLG_lng_to').value==DetLang && doc.getElementById('SLG_lng_from').value!="auto"){
			                                var TMP=doc.getElementById('SLG_lng_to').value;
			                                doc.getElementById('SLG_lng_to').value = doc.getElementById('SLG_lng_from').value;
		        	                        doc.getElementById('SLG_lng_from').value = TMP;
                                                        TranslatorIM.AutoFlipState=1;
							TranslatorIM.FlippedByAuto=1;
		                	        }else{
							// AVOIDING AUTO DETETECT TAG 
							var autopattern = TranslatorIM.AUTOhandler(doc,AUTO,DetLang);
		                        	        if(doc.getElementById('SLG_lng_from').value!=autopattern){
		                        	                cnt=0;
								for (var i = 0; i < LANGS.length; i++){
									var templang = LANGS[i].split(":");
									if(DetLang == templang[0]) cnt=1;
								}
								if(cnt==1){TranslatorIM.FlippedByAuto=1; doc.getElementById('SLG_lng_from').value=DetLang;}
							}
						}
					        TranslatorIM.SLG_SETINTERVAL_ST=1;


					} else 	{
						var DetLang = "en";

                                                TranslatorIM.SLG_FLAG=0;
						var LANGSALL = FExtension.element(TranslatorIM.SLG_LOC,'extLanguages').split(",");
						var LANGS = FExtension.element(TranslatorIM.SLG_LOC,'extLanguagesNew').split(",");
						for (var i = 0; i < LANGSALL.length; i++){
							var templang = LANGSALL[i].split(":");
							if(DetLang == templang[0]){ 
							        var tmp = doc.getElementById('SLG_lng_from').value;
								if(tmp == "" || tmp == "auto") tmp = TranslatorIM.SLG_langSrc;
								DetLang=tmp;
								TranslatorIM.SLG_FLAG=1;
							}
						}

                                                
		                        	TranslatorIM.LNGforHISTORY = DetLang;
			                        TranslatorIM.SLG_SID_FROM = doc.getElementById('SLG_lng_from').value;
						TranslatorIM.SLG_SID_TO   = doc.getElementById('SLG_lng_to').value;
						        if(TranslatorIM.SLG_SID_TO!=""){
								doc.getElementById('SLG_lng_from').value=TranslatorIM.SLG_SID_FROM;
								doc.getElementById('SLG_lng_to').value=TranslatorIM.SLG_SID_TO;
							}



			                        if(doc.getElementById('SLG_lng_to').value==resp && doc.getElementById('SLG_lng_from').value!="auto"){
			                                var TMP=doc.getElementById('SLG_lng_to').value;
			                                doc.getElementById('SLG_lng_to').value = doc.getElementById('SLG_lng_from').value;
		        	                        doc.getElementById('SLG_lng_from').value = TMP;
		                	        }else{
		                        	        if(doc.getElementById('SLG_lng_from').value!="auto"){
		                        	                cnt=0;
								for (var i = 0; i < LANGS.length; i++){
									var templang = LANGS[i].split(":");
									if(DetLang == templang[0]) cnt=1;
								}
								if(cnt==1) doc.getElementById('SLG_lng_from').value=DetLang;
							}


						}
					        TranslatorIM.SLG_SETINTERVAL_ST=1;
					}
				    } else {
					doc.getElementById('SLG_lng_from').value=TranslatorIM.SLG_langSrc; 
					doc.getElementById('SLG_lng_to').value=TranslatorIM.SLG_langDst; 
					TranslatorIM.SLG_SETINTERVAL_ST=1;
				    }
				}
			}
			ajaxRequest.open("POST", SLDImTranslator_url, true);
			ajaxRequest.send(null); 
		  }
		 }else{
		      	TranslatorIM.SLG_SID_FROM = doc.getElementById('SLG_lng_from').value;
			TranslatorIM.SLG_SID_TO  = doc.getElementById('SLG_lng_to').value;
	        		if(TranslatorIM.SLG_SID_TO!=""){
					doc.getElementById('SLG_lng_from').value=TranslatorIM.SLG_SID_FROM;
					doc.getElementById('SLG_lng_to').value=TranslatorIM.SLG_SID_TO;
				}

			TranslatorIM.SLG_SETINTERVAL_ST=1;
		 }
		}, 300);
	},


        theLastStageTranslator: function (){

	},

	truncStrByWord: function(str, length){
		if(str != "undefined"){
			if(str.length > 25){
				length = length - 25;
				var thestr = str;
				if (str.length > length) {
					str = str.substring(0, length);
					str = str.replace(new RegExp("/(.{1,"+length+"})\b.*/"), "$1");    // VK - cuts str to max length without splitting words.
					var str2 = thestr.substring(length, (length+25));
					var tempstr = str2.split(" ");
					var tmp = "";
					for (var i = 0; i < tempstr.length - 1; i++){
						tmp = tmp + tempstr[i] + " ";
					} 
					str = str + tmp;
				}
			} else 
				str = str + " ";
		}
		return str;
	},

	SLG_IF_DETECT_IS_PRESENT: function(dl, ob){
		var resp=dl, out=0;
		var doc = FExtension.browserInject.getDocument();
		if(doc.getElementById('SLG_locer').checked==true){
			dl = "";
			TranslatorIM.SLG_DETECTED="";
			for(var i=0; i < ob.length; i++) if(ob[i].value == dl) out=1;
			if(out==0 && ob.value != "auto") resp = ob.value;
		} else resp = dl;
		return resp;
	},



	SLG_Voice: function(){
	   TranslatorIM.TTS_btn_location=1;
           var doc = FExtension.browserInject.getDocument();

	   var TTStext=TranslatorIM.SLG_TEMP_TEXT.replace(/@/g, " ");
	   var text = TTStext;
	   text = TranslatorIM.truncStrByWord(text,1200);

	   var SLG_from = TranslatorIM.SLG_IF_DETECT_IS_PRESENT(TranslatorIM.SLG_DETECTED, doc.getElementById("SLG_lng_from"));

	   SLG_from = SLG_from.replace("-TW","");
	   SLG_from = SLG_from.replace("-CN","");
	   switch(TranslatorIM.SLG_SLVoices){
		case "0": if(TranslatorIM.SLG_ALLvoices.indexOf(SLG_from)!=-1){
                              if(SLG_TTS.indexOf(SLG_from)!=-1){
				if(text.length>TranslatorIM.GTTS_length) {
					if(SLG_from == "en-gb") SLG_from = "g_en-UK_f";
					window.open("https://text-to-speech.imtranslator.net/?dir="+SLG_from+"&text="+encodeURIComponent(text)); 
				}else TranslatorIM.Google_TTS_ON_TOP(text,SLG_from);
			      } else TranslatorIM.Google_TTS_ON_TOP(text,SLG_from);
			  } else TranslatorIM.SLG_alert(FExtension.element(TranslatorIM.SLG_LOC,"extNo_Voice"));
			  break;
		case "1": if(TranslatorIM.SLG_ALLvoices.indexOf(SLG_from)!=-1){
				if(G_TTS.indexOf(SLG_from)!=-1) TranslatorIM.Google_TTS_ON_TOP(text,SLG_from);
				else TranslatorIM.SLG_alert(FExtension.element(TranslatorIM.SLG_LOC,"extNo_Voice"));
			  } else TranslatorIM.SLG_alert(FExtension.element(TranslatorIM.SLG_LOC,"extNo_Voice"));
			  break;
		case "2": if(TranslatorIM.SLG_ALLvoices.indexOf(SLG_from)!=-1){
                              if(SLG_TTS.indexOf(SLG_from)!=-1) {
					if(SLG_from == "en-gb") SLG_from = "g_en-UK_f";
					window.open("https://text-to-speech.imtranslator.net/?dir="+SLG_from+"&text="+encodeURIComponent(text));
			      }else TranslatorIM.Google_TTS_ON_TOP(text,SLG_from);
			  } else TranslatorIM.SLG_alert(FExtension.element(TranslatorIM.SLG_LOC,"extNo_Voice"));
			  break;
	   }

	},

	SetTTStextLimit: function(text,limit){
	 text=text.replace(/(\r\n|\n|\r)/gm,"");
	 var ttstexttmp=text.split(" ");
	 var OutPut="";
	 var OutPut_="";
	 for(var i=0; i<ttstexttmp.length; i++){
	     OutPut=OutPut+ttstexttmp[i]+" ";
	     if(OutPut.length>limit) break;
	     else OutPut_=OutPut_+ttstexttmp[i]+" ";
	 }
	 return(OutPut_);
	},

	REMOTE_Voice: function(dir, text){

	   TranslatorIM.GOOGLE_TTS_backup_loader=0;
	   var BackUpDir = dir;
	   var BackUpText = text;

	   dir = dir.replace("-TW","");
	   dir = dir.replace("-CN","");
	   if(dir=="en") dir = dir.replace("en","en-BR");
	   dir = dir.replace("es","es-419");
	   if(dir=="fr-CA") dir="fr";
	   if(dir=="lzh") dir="zh";
	   if(dir=="yue") dir="zh";
	   if(dir=="pt") dir="pt-BR";


	   var a=Math.floor((new Date).getTime()/36E5)^123456;
	   var TK = a+"|"+Math.floor((Math.sqrt(5)-1)/2*(a^654321)%1*1048576);

	   var length = text.length;
	   var num = Math.floor((Math.random() * SLG_GEO.length)); 
	   var theRegion = SLG_GEO[num];
           if(TranslatorIM.SLG_DOM!="auto") theRegion=TranslatorIM.SLG_DOM;
	   var baseUrl = "https://translate.google."+theRegion;

           var doc = FExtension.browserInject.getDocument();

	   if(text=="") text=doc.getElementById("SLG_shadow_translation_result").outerHTML.replace(/<[^>]*>?/g,'').substring(0,100);

	   var client = "tw-ob";

//	   if(BackUpDir=="es") client="t";


	   baseUrl = baseUrl+'/translate_tts?tk='+TK+'&ie=UTF-8&tl='+dir+'&total=1&idx=0&textlen='+length+'&client='+client+'&q='+encodeURIComponent(text);  
	    FExtension.browserInject.runtimeSendMessage({greeting: "TTS_BBL_on:>"+TranslatorIM.TTS_btn_location +"||"+ baseUrl}, function(response) {
            TranslatorIM.SLG_DETECT = "";	


	     
		     if(doc.getElementById("PL_lbplayer")){
			doc.getElementById("PL_lbplayer").style.display='none';
			TranslatorIM.synth.cancel();
		     }


			setTimeout(function(){

			   try{
		        	 if(TranslatorIM.TTS_status=="off") {					
					if(PLATFORM=="Chrome" && TranslatorIM.TTSbackupLangs.indexOf(BackUpDir)!=-1)TranslatorIM.GOOGLE_TTS_backup(BackUpText,BackUpDir);
					else{
				        	var furl = FExtension.browserInject.getURL('content/html/options/options.html?feed');
						doc.getElementById("SLG_player2").innerHTML="<div id='noplmsg' align=center><font color='#BD3A33'>"+FExtension.element(TranslatorIM.SLG_LOC,"extADVstu")+"</font><br><a href='"+furl+"' target='_blank' class='SLG_links'>"+FExtension.element(TranslatorIM.SLG_LOC,"extFeedback")+"</a></div>";     
				     		doc.getElementById('SLG_player2').style.height="35px";
//					     	if(doc.getElementById("SLG_alert100")) doc.getElementById("SLG_alert100").style.display="none";
					}
				 }
			   } catch (ex) {if(PLATFORM=="Chrome" && TranslatorIM.TTSbackupLangs.indexOf(BackUpDir)!=-1 && TranslatorIM.GOOGLE_TTS_backup_loader==0)TranslatorIM.GOOGLE_TTS_backup(BackUpText,BackUpDir);}

       		TranslatorIM.SLG_bring_DOWN();


			}, 100);  

	    }); 
	},


	REMOTE_Voice_Close: function(){
	    try{
	       FExtension.browserInject.runtimeSendMessage({greeting: "TTS_BBL_off:>"}, function(response) {}); 
	       if(window.event.target.lang==""){
	  	  var doc = FExtension.browserInject.getDocument();
		  TranslatorIM.synth.cancel();
		  if(window.event.target.id!="SLG_volume" && window.event.target.id!="SLG_controls"){
			  if(doc.getElementById("PL_lbplayer"))doc.getElementById("PL_lbplayer").style.display='none';
//			  if(doc.getElementById('SLG_alert100')) doc.getElementById('SLG_alert100').style.display="none";
			  if(doc.getElementById('SLG_player2')) doc.getElementById('SLG_player2').style.display="none";
		  }
		  var frame = doc.getElementById('lbframe');
		  if(frame)	frame.parentNode.removeChild(frame);
	          var target = window.event.target || window.event.srcElement;
	          var id = target.id;
	          if(id!="SLG_controls" && id!="SLG_volume" && id!="SLG_myRange"){
			  doc.getElementById("SLG_player2").innerText="";
		  } else {
			if(id=="SLG_controls"){
				if(doc.getElementById(id).className=="SLG_play") TranslatorIM.handleSpeechResume();
				else TranslatorIM.handleSpeechPause();
			}
			if(id=="SLG_volume") TranslatorIM.handleSpeechVolume();
		  }
		}
//		if(doc.getElementById('SLG_alert100')) doc.getElementById('SLG_alert100').style.display="none";
		if(doc.getElementById('SLG_player2')) doc.getElementById('SLG_player2').style.display="none";
	    } catch (ex){}
            TranslatorIM.GOOGLE_TTS_backup_loader=1;
	},


	SLG_CopyToClipBoard: function(){
	  	var doc = FExtension.browserInject.getDocument();
		var OBJ = doc.getElementById('SLG_shadow_translation_result');
		OBJ.contentEditable = true;
		OBJ.unselectable = "off";
		OBJ.focus();
		var ZIPtext = OBJ.innerHTML;
		//This line is for plant text only
		var preZIPtext = ZIPtext.replace(/<br>/ig,'~');
		preZIPtext = preZIPtext.replace(/(<([^>]+)>)/ig,'').replace(/&nbsp;/ig,'');
		preZIPtext = preZIPtext.replace(/~/ig,'<br>');
		OBJ.innerHTML = preZIPtext;
	        FExtension.browserInject.getDocument().execCommand('SelectAll');
		FExtension.browserInject.getDocument().execCommand("Copy", false, null);
		OBJ.innerHTML = ZIPtext;
                OBJ.style.opacity=0.2;
		setTimeout(function(){ 
			OBJ.style.opacity=1; 
			if (FExtension.browserInject.getDocument().getSelection) {
			    if (FExtension.browserInject.getDocument().getSelection().empty) {  // Chrome
			        FExtension.browserInject.getDocument().getSelection().empty();
			    } else if (FExtension.browserInject.getDocument().getSelection().removeAllRanges) {  // Firefox
			        FExtension.browserInject.getDocument().getSelection().removeAllRanges();
			    }
			} else if (FExtension.browserInject.getDocument().selection) {  // IE?
			    FExtension.browserInject.getDocument().selection.empty();
			}
       	                doc.getElementById('SLG_copy_tip').style.display="block";
               	        doc.getElementById('SLG_copy_tip').innerHTML=FExtension.element(TranslatorIM.SLG_LOC,"extTextCopied");
			setTimeout(function(){ 
	       	                doc.getElementById('SLG_copy_tip').style.display="none";
			}, 1500);
		}, 350);
		OBJ.contentEditable = false;
	},

	SLG_Font: function(){
	  	var doc = FExtension.browserInject.getDocument();
		var OBJ = doc.getElementById('SLG_shadow_translation_result');
		var OBJ2 = doc.getElementById('SLG_shadow_translation_result2');
		var OBJ3 = doc.getElementById('SLG_bbl_font');
		if(TranslatorIM.SLG_FontSize_bbl == OBJ.style.fontSize){
			if(TranslatorIM.SLG_FontSize_bbl=="14px"){
				OBJ.style.fontSize = "16px";
				OBJ.style.lineHeight = "22px";
				OBJ2.style.fontSize = "16px";
				OBJ2.style.lineHeight = "22px";
				OBJ3.className = "SLG_font_off";
				OBJ3.style.background="url("+FExtension.browserInject.getURL('content/img/util/font-on.png')+")";
				TranslatorIM.SLG_FontSize_bbl = "16px";
			}else{
				OBJ.style.fontSize = "14px";
				OBJ.style.lineHeight = "20px";
				OBJ2.style.fontSize = "14px";
				OBJ2.style.lineHeight = "20px";
				OBJ3.className = "SLG_font_on";
				OBJ3.style.background="url("+FExtension.browserInject.getURL('content/img/util/font.png')+")";
				TranslatorIM.SLG_FontSize_bbl = "14px";
			}

			TranslatorIM.SLG_FONT_SID = TranslatorIM.SLG_FontSize_bbl;
		}
                TranslatorIM.SLG_JUMP(doc);
		TranslatorIM.SAVE_SES_PARAMS();

	},
	SLG_pinme: function(){                 
	  if(TranslatorIM.SLG_FRAME==0){
	        var doc = FExtension.browserInject.getDocument();
		var OBJ = doc.getElementById('SLG_pin');
		var SLdivField = doc.getElementById("SLG_shadow_translator");
		if(OBJ.style.background.indexOf("pin-off.png")!=-1){
			setTimeout(function() {
				OBJ.style.background="url("+FExtension.browserInject.getURL('content/img/util/pin-on.png')+")";
				OBJ.className = "SLG_pin_on";
				OBJ.title = FExtension.element(TranslatorIM.SLG_LOC,"extUnPin_ttl");
				TranslatorIM.SLG_NEST="FLOAT";
				TranslatorIM.SLG_FLOATER();
			        var bodyScrollTop = doc.documentElement.scrollTop || doc.body.scrollTop;
				var bodyScrollLeft = doc.documentElement.scrollLeft || doc.body.scrollLeft;
				TranslatorIM.SLG_MoveY=Math.ceil(SLdivField.style.top.replace("px",""))+"px";
				TranslatorIM.SLG_MoveX=Math.ceil(SLdivField.style.left.replace("px",""))+"px";
				TranslatorIM.GlobalBoxY=(parseInt(TranslatorIM.SLG_MoveY.replace("px",""))-bodyScrollTop);
//				TranslatorIM.GlobalBoxX=(parseInt(TranslatorIM.SLG_MoveX.replace("px",""))-bodyScrollLeft+SLdivField.offsetWidth);
				TranslatorIM.GlobalBoxX=3000;
		               	FExtension.browserInject.runtimeSendMessage({greeting: "SAVE_COORD:>"+TranslatorIM.GlobalBoxX+","+TranslatorIM.GlobalBoxY}, function(response) {});
			}, 100);
		    TranslatorIM.SLG_SID_PIN="true";
		}else{
			TranslatorIM.SLG_NEST="";
			OBJ.className = "SLG_pin_off";
			OBJ.title = FExtension.element(TranslatorIM.SLG_LOC,"extPin_ttl");
			OBJ.style.background="url("+FExtension.browserInject.getURL('content/img/util/pin-off.png')+")";
			TranslatorIM.SLG_SID_PIN="false";
	               	FExtension.browserInject.runtimeSendMessage({greeting: "SAVE_COORD:>0,0"}, function(response) {});
			TranslatorIM.SLG_MoveY="-10000px";
			TranslatorIM.SLG_MoveX="-10000px";
//			SLdivField.style.left=Math.ceil(SLdivField.style.left.replace("px","")-20)+"px";
			doc.onscroll = function(){}; 
		}   
		TranslatorIM.SAVE_SES_PARAMS();
	    }
	},
	SLG_FLOATER: function(){
	  if(TranslatorIM.SLG_FRAME==0){
	    	try{ 

			//ALWAYS KEEPS FLOATING MODE FOR 'SAVE RESENT WORK'

			if(TranslatorIM.SLG_SAVETEXT == 1) TranslatorIM.SLG_NEST= "FLOAT";

			if(TranslatorIM.SLG_NEST=="FLOAT"){
			        var doc = FExtension.browserInject.getDocument();
				var THEobj = doc.getElementById("SLG_shadow_translator");
				if(TranslatorIM.GlobalBoxY<0)TranslatorIM.GlobalBoxY=1;
				if(parseInt(TranslatorIM.SLG_MoveX.replace("px",""))<0) TranslatorIM.SLG_MoveX = TranslatorIM.GlobalBoxX +"px";
				if(TranslatorIM.GlobalBoxX>0){
					THEobj.style.top = TranslatorIM.SLG_getScrollY() + TranslatorIM.GlobalBoxY + "px";
					THEobj.style.left = TranslatorIM.SLG_MoveX;
				}else{
					THEobj.style.top = TranslatorIM.SLG_getScrollY() + (window.innerHeight / 2 - 150) + "px";
					THEobj.style.left = (window.innerWidth - 460 - 30) + "px";
				}
				TranslatorIM.WINDOW_and_BUBBLE_alignment(doc,THEobj);
				doc.onscroll = TranslatorIM.SLG_FLOATER; 
				window.addEventListener("resize", TranslatorIM.SLG_FLOATER);
				doc.getElementById("SLG_arrow_up").style.display="none";
			} else doc.onscroll = function(){}; 
		} catch(e){}
	  }
	},

	SLG_getScrollX: function(){
		var scrOfX = 0;
	        var doc = FExtension.browserInject.getDocument();
		if( doc.body && doc.body.scrollLeft ) scrOfX = doc.body.scrollLeft;
		else if( doc.documentElement && doc.documentElement.scrollLeft  ) scrOfX = doc.documentElement.scrollLeft;
		return scrOfX;
	},

	SLG_getScrollY: function(){
		var scrOfY = 0;
	        var doc = FExtension.browserInject.getDocument();
		if( doc.body && doc.body.scrollTop ) scrOfY = doc.body.scrollTop;
		else if( doc.documentElement && doc.documentElement.scrollTop  ) scrOfY = doc.documentElement.scrollTop;
		return scrOfY;
	},

	SLG_GOOGLE_WPT: function(){
		if(FExtension.browserInject.getDocument().getElementById("wtgbr")){ 
			FExtension.browserInject.getDocument().getElementById("wtgbr").style.display = 'none';
			FExtension.browserInject.getDocument().getElementById("gt-bbar").style.display = 'none';
			FExtension.browserInject.getDocument().getElementById("clp-btn").style.display = 'none';
			FExtension.browserInject.getDocument().getElementById("contentframe").style.marginTop = '-60px';

			var frames = FExtension.browserInject.getDocument().getElementsByTagName('iframe');
			for(var i = 0; i < frames.length; i++){
			   if(frames[i].name=='c'){ frames[i].sandbox="allow-same-origin allow-forms allow-scripts allow-top-navigation"; break; }
			}

		} 
	},
	HotKeysWindow: function(e, st){
		 var s = FExtension.browserInject.getSelectionText();

		 s=s.substring(0,TranslatorIM.SLG_PLANSHET_LIMIT);
//		 if(st==0) s="";
//		 if(s!=""){
		  chrome.extension.sendMessage({greeting: "hello"}, function(response) {
	              if(response){
		        //console.log(response.farewell);
        	      }
		  });
		  s=s.replace(/(^[\s]+|[\s]+$)/g, '');
		  var theQ=s.split(" ").length;
	          if(s.match(/[-/‧·﹕﹗！：，。﹖？:-?!.,:{-~!"^_`、\[\]]/g)!=null) theQ=100;
		  
 		  //if(TranslatorIM.SLG_dict_bbl=="false") theQ=100;
		  if (s.match(/[\u3400-\u9FBF]/) && s.length>1) theQ=100;

		  if(theQ==1 && s!=""){
			  TranslatorIM.SLG_MODE=1;
		          FExtension.browserInject.runtimeSendMessage({greeting: "PUSH:>"+s}, function(response) {});
		   }else{
			  TranslatorIM.SLG_MODE=0;
		          FExtension.browserInject.runtimeSendMessage({greeting: "PUSH:>"+s}, function(response) {});
		   }
//		 }
	},

	SLG_BALLOON_TRANSLATION: function(myTransText,evt,st) {   
//	   FExtension.browserInject.runtimeSendMessage({greeting: "CM_BBL:>" + TranslatorIM.SLG_SID_TO}, function(response) {}); 
	   if(myTransText!=""){
		var doc = FExtension.browserInject.getDocument();


		doc.getElementById('SLG_loading').style.display='block';
		TranslatorIM.SLG_IS_DICTIONARY=0;
		doc.getElementById('SLG_TTS_voice').style.display='block';
		doc.getElementById('SLG_bbl_font_patch').style.display='none';

		if(TranslatorIM.AVOIDAUTODETECT==0){
		     var resp = TranslatorIM.i18n_LanguageDetect(myTransText,0);
		     if (resp != ""){
	                TranslatorIM.SLG_DETECT = resp;
		        TranslatorIM.SLG_FLAG=0;
			var DetLang = resp;

                       	var AUTO = doc.getElementById('SLG_locer').checked;
			if(AUTO==false || doc.getElementById('SLG_lng_from').value=="auto"){

                                var cnt=0;
                        	var LANGSALL = FExtension.element(TranslatorIM.SLG_LOC,'extLanguages').split(",");
				var LANGS = TranslatorIM.SLG_LNG_LIST.split(",");


                        	for (var i = 0; i < LANGSALL.length; i++){
					var templang = LANGSALL[i].split(":");
					if(DetLang == templang[0]){ 
					        var tmp = doc.getElementById('SLG_lng_from').value;
						if(tmp == "" || tmp == "auto") tmp = TranslatorIM.SLG_langSrc;
						TranslatorIM.SLG_FLAG=1;
						cnt=1;
					}
				}


                       	        TranslatorIM.SLG_WRONGLANGUAGEDETECTED=0;
				if(cnt==0){
       	                                TranslatorIM.SLG_DETECT = DetLang;
					TranslatorIM.SLG_setTMPdata("BL_D_PROV","Google");
					TranslatorIM.SLG_setTMPdata("BL_T_PROV","Google");
					TranslatorIM.SLG_WRONGLANGUAGEDETECTED=1;
				}
                                TranslatorIM.SLG_HideShowTTSicon(); 
       	                	TranslatorIM.LNGforHISTORY = DetLang;

        	                TranslatorIM.SLG_SID_FROM = doc.getElementById('SLG_lng_from').value;
				TranslatorIM.SLG_SID_TO   = doc.getElementById('SLG_lng_to').value;
			        if(TranslatorIM.SLG_SID_TO!=""){
					doc.getElementById('SLG_lng_from').value=TranslatorIM.SLG_SID_FROM;
					doc.getElementById('SLG_lng_to').value=TranslatorIM.SLG_SID_TO;
				}


		                if(doc.getElementById('SLG_lng_to').value==resp && doc.getElementById('SLG_lng_from').value!="auto"){
		                        var TMP=doc.getElementById('SLG_lng_to').value;
		                        doc.getElementById('SLG_lng_to').value = doc.getElementById('SLG_lng_from').value;
	        	                doc.getElementById('SLG_lng_from').value = TMP;
					TranslatorIM.SLG_SID_FROM=doc.getElementById('SLG_lng_from').value;
					TranslatorIM.SLG_SID_TO=doc.getElementById('SLG_lng_to').value;
                                        TranslatorIM.AutoFlipState=1;
					TranslatorIM.FlippedByAuto=1;
	       	        	}else{
				// AVOIDING AUTO DETETECT TAG 
					var autopattern = TranslatorIM.AUTOhandler(doc,AUTO,DetLang);
	       	        		if(doc.getElementById('SLG_lng_from').value!=autopattern){
	                       	                cnt=0;
						for (var i = 0; i < LANGS.length; i++){
							var templang = LANGS[i].split(":");
							if(DetLang == templang[0]) cnt=1;
						}
						if(cnt==1) doc.getElementById('SLG_lng_from').value=DetLang;
					}
				}
        		        TranslatorIM.SLG_SETINTERVAL_ST=1;
        	       } else  TranslatorIM.SLG_SETINTERVAL_ST=1;   
		     } else {
			var big5 = TranslatorIM.DetectBig5(myTransText);
			if(big5 == 0){
				if(DET == 0) TranslatorIM.DODetection(myTransText);
				else         TranslatorIM.SLDetector(myTransText);
			}else{
				TranslatorIM.SLDetector(myTransText);
			}

		     }
		}else 		TranslatorIM.SLG_SETINTERVAL_ST=1;
		TranslatorIM.AVOIDAUTODETECT=0;
		var Tobj = doc.getElementById('SLG_shadow_translation_result');
		var Tobj2 = doc.getElementById('SLG_shadow_translation_result2');

                var SLdivField=doc.getElementById('SLG_shadow_translator');
               	Tobj.innerText = "";
                Tobj2.innerText = "";

       		doc.getElementById('SLG_loading').style.display='block';

		SLdivField.style.display='block';

		var cntr = 0;

		setTimeout(function(){
		    var SLIDL = setInterval(function(){
			if(cntr<250) {
			  if(TranslatorIM.SLG_SETINTERVAL_ST==1) {
				clearInterval(SLIDL);
                                TranslatorIM.SLG_SETINTERVAL_ST=0;
				TranslatorIM.SLG_EXECUTE_TRANSLATION(myTransText,evt,st);
					if(Tobj.outerHTML.replace(/<[^>]*>?/g,'')==""){
						doc.getElementById('SLG_loading').style.display = 'block';
		                                TranslatorIM.SLG_JUMP(doc);
						doc.getElementById('SLG_loading').style.display = 'none';
		                        }
				doc.getElementById('SLG_loading').style.display = 'none';
				return true;
			  }
			} else {cntr=0;TranslatorIM.SLG_SETINTERVAL_ST=1;}
			cntr++;
		    },10);  
 	         },50);  
          }	
	},

	InlineDataTransmitter: function (data){
	    data = unescape(data);
	    inlinerInjectHandleMessage({name: "inlinerSelectionResponse", message: data});
	},

        SLG_SET_PROVIDERS: function(mode){
          TranslatorIM.ListProviders="";
 	  var doc = FExtension.browserInject.getDocument();
 	  var from = doc.getElementById("SLG_lng_from").value;

	  var list = TranslatorIM.SLG_LNG_CUSTOM_LIST;

	  if(list=="all") list = TranslatorIM.LISTofPRpairs[0];

	  var L1 = list.split(",");
	  var finded = 0;
	  for(var i=0; i<L1.length; i++){
	  	if(L1[i] == TranslatorIM.SLG_DETECT) finded = 1;
	  }


//	  if(finded==0)	  if(TranslatorIM.SLG_DETECT!="" && from=="auto") from = TranslatorIM.SLG_DETECT;
//	  else	  if(TranslatorIM.SLG_DETECT!="") from = TranslatorIM.SLG_DETECT;

	  if(finded==1)	  if(TranslatorIM.SLG_DETECT!="") from = TranslatorIM.SLG_DETECT;


	  if(doc.getElementById("SLG_locer").checked==true)  from = doc.getElementById("SLG_lng_from").value;

 	  var to = doc.getElementById("SLG_lng_to").value;

 	  try{

 	  if(to!=""){
 	   for(var I=0; I<TranslatorIM.LISTofPR.length; I++){
            if(mode==1){
		    if(TranslatorIM.BL_D_PROV == TranslatorIM.LISTofPR[I]) 	doc.getElementById("SLG_P"+I).className="SLG_BL_LABLE_ON";
		    else doc.getElementById("SLG_P"+I).className="SLG_BL_LABLE_OFF";
	    }else{
		    if(TranslatorIM.BL_T_PROV == TranslatorIM.LISTofPR[I]) 	doc.getElementById("SLG_P"+I).className="SLG_BL_LABLE_ON";
		    else doc.getElementById("SLG_P"+I).className="SLG_BL_LABLE_OFF";
	    }

	    if(from!="auto"){
	     var ftemp = from;
	     if(TranslatorIM.SLG_DETECT!=from) ftemp = TranslatorIM.SLG_DETECT;
	     if(doc.getElementById('SLG_locer').checked==true) ftemp = from;
	     if(TranslatorIM.LISTofPR[I]!="Translator"){
		     if(TranslatorIM.FIND_PROVIDER(TranslatorIM.LISTofPRpairs[I],ftemp) ==-1 || TranslatorIM.FIND_PROVIDER(TranslatorIM.LISTofPRpairs[I],to)==-1) doc.getElementById("SLG_P"+I).className="SLG_BL_LABLE_DEACT";
		     else TranslatorIM.ListProviders=TranslatorIM.ListProviders+TranslatorIM.LISTofPR[I]+",";
             } else {
	      if(TranslatorIM.LISTofPRpairs[I].indexOf(ftemp + "/" + to)==-1){
		 doc.getElementById("SLG_P"+I).className="SLG_BL_LABLE_DEACT";
                 TranslatorIM.ListProviders=TranslatorIM.ListProviders.replace(TranslatorIM.LISTofPR[I]+",","");
	      } else TranslatorIM.ListProviders=TranslatorIM.ListProviders+TranslatorIM.LISTofPR[I]+",";
	     }
	    } else {
	     if(TranslatorIM.LISTofPR[I]!="Translator"){
		     if(TranslatorIM.FIND_PROVIDER(TranslatorIM.LISTofPRpairs[I],TranslatorIM.SLG_DETECT) ==-1 || TranslatorIM.FIND_PROVIDER(TranslatorIM.LISTofPRpairs[I],to)==-1) doc.getElementById("SLG_P"+I).className="SLG_BL_LABLE_DEACT";
		     else TranslatorIM.ListProviders=TranslatorIM.ListProviders+TranslatorIM.LISTofPR[I]+",";
             } else {
	      if(TranslatorIM.LISTofPRpairs[I].indexOf(TranslatorIM.SLG_DETECT + "/" + to)==-1){
		 doc.getElementById("SLG_P"+I).className="SLG_BL_LABLE_DEACT";
                 TranslatorIM.ListProviders=TranslatorIM.ListProviders.replace(TranslatorIM.LISTofPR[I]+",","");
	      } else TranslatorIM.ListProviders=TranslatorIM.ListProviders+TranslatorIM.LISTofPR[I]+",";
	     }


	    }
            TranslatorIM.ListProviders=TranslatorIM.ListProviders.replace("Translator,Translator","Translator");
           }
	  }

	  } catch(ex){}

	  if(TranslatorIM.SLG_SHOW_PROVIDERS==0) {
	        var PR = "Google";
		TranslatorIM.ListProviders= PR + ",";	  
		TranslatorIM.SLG_setTMPdata("BL_D_PROV",PR);
		TranslatorIM.SLG_setTMPdata("BL_T_PROV",PR);
	  }           
        },



	FIND_PROVIDER: function(list,ln){
	  var arr = list.split(",");
	  var cnt=-1
	  for(var i=0; i<arr.length; i++){
		if(arr[i]==ln) cnt++;
	  }
	  return cnt;
	},



	SET_FIRST_AVAILABLE_PROV: function(){

	  if(TranslatorIM.SLG_SHOW_PROVIDERS!=0) {
	    var doc = FExtension.browserInject.getDocument();
	    var s = FExtension.browserInject.getSelectionText();
	    if(s=="" && TranslatorIM.SLG_temp_result!="") s=TranslatorIM.SLG_temp_result;

	    s=s.replace(/(^[\s]+|[\s]+$)/g, '');
	    var theQ=s.split(" ").length;

  	    if(s.match(/[-/ΓÇº┬╖∩╣ò∩╣ù∩╝ü∩╝Ü∩╝îπÇé∩╣û∩╝ƒ:-?!.,:{-~!"^_`\[\]]/g)!=null) theQ=100;
	    //if(TranslatorIM.SLG_dict_bbl=="false") theQ=100;

	    if (s.match(/[\u3400-\u9FBF]/) && s.length>1) theQ=100;
	    TranslatorIM.SLG_SET_PROVIDERS(theQ);
	    var theList = TranslatorIM.ListProviders.split(",");

	    if(theQ==1){
	      TranslatorIM.SLG_MODE=1;	
	      if(TranslatorIM.BL_D_PROV=="" || TranslatorIM.BL_D_PROV==null || TranslatorIM.BL_D_PROV=="undefined"){
		  if(TranslatorIM.SLG_dict_bbl=="true"){
			  var arr1 = TranslatorIM.SLG_DICT_PRESENT.split(",");
			  for(I=0; I<(theList.length-1); I++){
			    for(J=0; J<arr1.length; J++){
		        	var arr2=arr1[J].split(":");
				if(arr2[1]==1 && theList[I]==arr2[0]){				
					TranslatorIM.SLG_setTMPdata("BL_D_PROV",arr2[0]);
					I=1000;J=1000;
				}
			    }
			  }
		 } else {
			TranslatorIM.SLG_setTMPdata("BL_D_PROV",theList[0]);
		 }

		  var arr = TranslatorIM.SLG_ALL_PROVIDERS_BBL.split(",");	
		  for(I=0; I<arr.length; I++){
			if(arr[I]==TranslatorIM.BL_D_PROV){
				doc.getElementById("SLG_P"+I).className="SLG_BL_LABLE_ON";
				I=1000;
			}
		  }
	      } else {
		 if(TranslatorIM.ListProviders.indexOf(TranslatorIM.BL_D_PROV)==-1){
		  var arr1 = TranslatorIM.SLG_DICT_PRESENT.split(",");
		  for(I=0; I<(theList.length-1); I++){
		    for(J=0; J<arr1.length; J++){
		        var arr2=arr1[J].split(":");
			if(arr2[1]==1 && theList[I]==arr2[0]){
//				TranslatorIM.SLG_setTMPdata("BL_D_PROV",arr2[0]);
				doc.getElementById("SLG_P"+I).className="SLG_BL_LABLE_ON";
				I=1000;J=1000;
			}
		    }
		  }
		 }
	         if(TranslatorIM.ListProviders.indexOf(TranslatorIM.BL_D_PROV) == -1){
			TranslatorIM.SLG_setTMPdata("BL_D_PROV",theList[0]);	
			TranslatorIM.SET_FIRST_AVAILABLE_PROV();
		 }
	      }

	    }else{
	      TranslatorIM.SLG_MODE=0;
	      if(TranslatorIM.BL_T_PROV=="" || TranslatorIM.BL_T_PROV==null || TranslatorIM.BL_T_PROV=="undefined"){
		  TranslatorIM.SLG_setTMPdata("BL_T_PROV",theList[0]);
		  var arr = TranslatorIM.SLG_ALL_PROVIDERS_BBL.split(",");	
		  for(I=0; I<arr.length; I++){
			if(theList[0]==arr[I]){
				doc.getElementById("SLG_P"+I).className="SLG_BL_LABLE_ON";
				break;
			}
		  }
	      } else {
		 if(TranslatorIM.ListProviders.indexOf(TranslatorIM.BL_T_PROV)!=-1){
		  var arr = TranslatorIM.SLG_ALL_PROVIDERS_BBL.split(",");	
		  for(I=0; I<arr.length; I++){
			if(arr[I]==TranslatorIM.BL_T_PROV){
				doc.getElementById("SLG_P"+I).className="SLG_BL_LABLE_ON";
				I=1000;
			}
		  }
		 } else {
		
		  var arr = TranslatorIM.ListProviders.split(",");	
		  TranslatorIM.SLG_setTMPdata("BL_T_PROV",arr[0]);
//		  doc.getElementById("SLG_P0").className="SLG_BL_LABLE_ON";
	   	  TranslatorIM.SET_FIRST_AVAILABLE_PROV();
		 }
	      }

            }	


	    if(TranslatorIM.SLG_WRONGLANGUAGEDETECTED==1){
		var pattern = doc.getElementById("SLG_Bproviders").getElementsByTagName("div");
		var cnt=0;
		for(var j=0; j<pattern.length; j++){
		    if(pattern[j].id.indexOf("SLG_PN")==-1){
			if(pattern[j].title.toLowerCase()=="google"){
				pattern[j].className="SLG_BL_LABLE_ON";
			} else {
				pattern[j].className="SLG_BL_LABLE_DEACT";
			}
		    }
		}
		TranslatorIM.SLG_setTMPdata("BL_D_PROV","Google");
		TranslatorIM.SLG_setTMPdata("BL_T_PROV","Google");
	    }


	 } else{
		TranslatorIM.SLG_setTMPdata("BL_D_PROV","Google");
		TranslatorIM.SLG_setTMPdata("BL_T_PROV","Google");
	 }

        },

/////////

	SLG_EXECUTE_TRANSLATION: function(myTransText,evt,st, win) {
         var doc = FExtension.browserInject;
 	 var doc2 = doc.getDocument();
	 var tmptext = FExtension.browserInject.getSelectionText();
	 if(tmptext !="") myTransText = tmptext;
         else myTransText = TranslatorIM.SLG_TEMP_TEXT;

	 if(myTransText != TranslatorIM.SLG_TEMP_TEXT) myTransText=TranslatorIM.SLG_TEMP_TEXT;
         var t1 = new Date().getTime();
         var S = doc2.getElementById('SLG_lng_from').value;
         var T = doc2.getElementById('SLG_lng_to').value;
                if(doc2.getElementById("SLG_player2")) {
			doc2.getElementById("SLG_player2").innerHTML="";
			doc2.getElementById("SLG_player2").style.display="none";
			doc2.getElementById("SLG_player2").style.height="0px";
		}
	 var ttl = TranslatorIM.SLG_DETECT;
	 if(ttl == "") ttl = 	doc2.getElementById('SLG_lng_from').value;
//	 TranslatorIM.SLG_DETECT = ttl;

         doc2.getElementById('SLG_TTS_voice').title=TranslatorIM.SLG_GetLongName(ttl);

   	 TranslatorIM.SET_FIRST_AVAILABLE_PROV();
	 if(TranslatorIM.ListProviders=="" && TranslatorIM.SLG_SHOW_PROVIDERS == 1) TranslatorIM.NoProvidersAlert();
	 else {
           var STATUS = TranslatorIM.DETERMIN_IF_LANGUAGE_IS_AVAILABLE_BBL();

	   if(STATUS == 0 && TranslatorIM.SLG_SHOW_PROVIDERS == 0) TranslatorIM.NoProvidersAlert();
	   else {
	           if(doc2.getElementById("SLG_locer").checked==true){
		 	if(doc2.getElementById('SLG_lng_from').value!="auto"){
				doc2.getElementById('SLG_lng_from').title="";
			}
		   }



//		   FExtension.browserInject.runtimeSendMessage({greeting: "CM_BBL:>" + T}, function(response) {}); 


		   if(TranslatorIM.SLG_DETECT != "" && doc2.getElementById("SLG_locer").checked==false && S != "auto") {
			var LANGS = TranslatorIM.SLG_LNG_LIST.split(",");
	        	cnt=0;
			for (var i = 0; i < LANGS.length; i++){
				var templang = LANGS[i].split(":");
				if(TranslatorIM.SLG_DETECT == templang[0]) cnt=1;
			}
			if(cnt==1) doc2.getElementById('SLG_lng_from').value=TranslatorIM.SLG_DETECT;		
		   }
		   var PR = TranslatorIM.BL_T_PROV;
		   if(TranslatorIM.SLG_MODE==1) PR = TranslatorIM.BL_D_PROV;
		   doc2.getElementById('SLG_shadow_translation_result').innerHTML="";
		   doc2.getElementById('SLG_shadow_translation_result2').innerHTML="";

	           myTransText = myTransText.replace(/\t/g,"");

	 	   if(T!="") TranslatorIM.SLG_SAVE_FAVORITE_LANGUAGES(T, 'SLG_lng_to', 0, TranslatorIM.SLG_FAV_LANGS_BBL, "BBL");
		   else TranslatorIM.SLG_SAVE_FAVORITE_LANGUAGES(TranslatorIM.SLG_langDst_bbl2, 'SLG_lng_to', 0, TranslatorIM.SLG_FAV_LANGS_BBL, "BBL");


		   if(PR == "" && TranslatorIM.ListProviders!="") {
			var theList = TranslatorIM.ListProviders.split(",");
			PR = theList[0];
			TranslatorIM.BL_D_PROV = PR;
			TranslatorIM.SET_FIRST_AVAILABLE_PROV();
		   }
		   if(PR == "Google"){
			doc2.getElementById('SLG_loading').style.display = 'block';
	           	myTransText = myTransText.trim();
//			myTransText = myTransText.replace(/#/g,"");

	                if(myTransText.length<=TranslatorIM.SLG_Balloon_translation_limit){
				if(myTransText != ""){

					TranslatorIM.SLG_SETINTERVAL_PROXY=0;
        	        	        doc2.getElementById('SLG_balloon_obj').alt="1";

			        	myTransText=myTransText.replace(/(^[\s]+|[\s]+$)/g, '');
				       	var theQ=myTransText.split(" ").length;
					if(myTransText.match(/[-/ΓÇº┬╖∩╣ò∩╣ù∩╝ü∩╝Ü∩╝îπÇé∩╣û∩╝ƒ:-?!.,:{-~!"^_`\[\]]/g)!=null) theQ=100;

//				        if(TranslatorIM.SLG_dict_bbl=="false") theQ=100;
					var num = Math.floor((Math.random() * SLG_GEO.length)); 
					var theRegion = SLG_GEO[num];
					if(TranslatorIM.SLG_DOM!="auto") theRegion=TranslatorIM.SLG_DOM;
					var baseUrl ="https://translate.google."+theRegion+"/translate_a/single";
					var Stemp=S;
                		        if(doc2.getElementById("SLG_locer").checked==false) Stemp = TranslatorIM.SLG_DETECT;

//					if(Stemp=="en" || TranslatorIM.SLG_FLAG==0) Stemp="auto";

					if(TranslatorIM.SLG_WRONGLANGUAGEDETECTED==1) Stemp="auto";
			
					var a=Math.floor((new Date).getTime()/36E5)^123456;
					var tk = a+"|"+Math.floor((Math.sqrt(5)-1)/2*(a^654321)%1*1048576);

					if(Stemp == "srsl") Stemp = "sr";
					if(Stemp == "tlsl") Stemp = "tl";
					if(T == "srsl") T = "sr";
					if(T == "tlsl") T = "tl";

					var SLG_Params = "client=gtx&dt=t&dt=bd&dj=1&source=input&q="+encodeURIComponent(myTransText)+"&sl="+Stemp+"&tl="+T+"&hl=en&tk="+tk;

					if(theQ==1){
						TranslatorIM.SLG_MODE=1;
					        if(TranslatorIM.SLG_DOM!="auto") theRegion=TranslatorIM.SLG_DOM;
						myTransText=myTransText.replace(/\./gi,"");
						myTransText=myTransText.replace(/\)/gi,"");
						myTransText=myTransText.replace(/\(/gi,"");
						myTransText=myTransText.replace(/\"/gi,"");
						SLG_Params = "client=gtx&dt=t&dt=bd&dj=1&source=input&q="+encodeURIComponent(myTransText.toLowerCase())+"&sl="+Stemp+"&tl="+T+"&hl=en&tk="+tk;
					}

					SLG_Params = SLG_Params.replace("sl=&","sl=auto&");
				        FExtension.browserInject.runtimeSendMessage({greeting: "TR_GOOGLE:>"+baseUrl+","+ SLG_Params+","+ theQ}, function(response) {});

					setTimeout(function(){
					    var SLIDL="";
					    clearInterval(SLIDL);
					    SLIDL = setInterval(function(){
					           FExtension.browserInject.extensionSendMessage({greeting: 1}, function(response) {
				        	     if(response && response.farewell){
					        	var theresponse = response.farewell.split("~");
							TranslatorIM.BBL_RESULT=theresponse[52].replace(/\^/ig,"~");
					                TranslatorIM.BBL_RESULT=TranslatorIM.BBL_RESULT.replace(/\\"/g,"'");
					                TranslatorIM.BBL_RESULT=TranslatorIM.BBL_RESULT.replace(/\\n/g,"<br>");
					                TranslatorIM.BBL_RESULT=TranslatorIM.BBL_RESULT.replace(/\\u0027/g,"'");
						
							if(TranslatorIM.BBL_RESULT!="") {

								var resp = TranslatorIM.BBL_RESULT;

								TranslatorIM.BBL_RESULT="";
								clearInterval(SLIDL);
								if(doc2.getElementById("SLG_shadow_translator").style.display=='block'){	
									var S = doc2.getElementById('SLG_lng_from').value;
							           	var T = doc2.getElementById('SLG_lng_to').value;
							           	var myTransText = doc.getSelectionText();
									if(myTransText == "") myTransText = TranslatorIM.SLG_TEMP_TEXT;
									if(myTransText != TranslatorIM.SLG_TEMP_TEXT) myTransText=TranslatorIM.SLG_TEMP_TEXT;
						       	   		var theQ=100;

							       	   	if(resp.indexOf('"reverse_translation":')>-1)theQ=1;
								   	var NoDict=0;
							                if(resp.indexOf('{"trans":')>-1){
							       		 	if(theQ>1){
							                                  var ReadyToUseGoogleText="";
							                                  var Gr1=resp.split('"trans":"');
							                               	  for(var h=1; h<Gr1.length; h++){
							                      	              var Gr2 = Gr1[h].split('","orig"');
							               	                      var Gr3 = Gr2[0].replace(/\\n/ig,"<br>");
							               	                      Gr3 = Gr3.replace(/\\r/ig,"");
						      		                              Gr3 = Gr3.replace(/\\"/ig,"'");
						       	        	                      Gr3 = Gr3.replace(/\\u0026/ig,"&");
						       	                	              Gr3 = Gr3.replace(/\\u003c/ig,"<");
							                        	      Gr3 = Gr3.replace(/\\u003e/ig,">");
								                              Gr3 = Gr3.replace(/\\u0027/ig,"'");
								                              Gr3 = Gr3.replace(/\\u003d/ig,"=");
								                              Gr3 = Gr3.replace(/\\/g,"");
                        	                                                              //Gr3 = Gr3.charAt(0).toUpperCase() + Gr3.slice(1);
							                                      ReadyToUseGoogleText=ReadyToUseGoogleText+Gr3;
							                                   }
											   resp = ReadyToUseGoogleText;
								 			   var nmr = myTransText.split(" ").length;
											   if(nmr > 1) TranslatorIM.CNTR('2221',Stemp+"/"+T, myTransText.length);
											   else TranslatorIM.CNTR('2231',Stemp+"/"+T, myTransText.length);
							                       	}
										var HID=2;
									} 
						
									if(resp.indexOf('sentences":')>-1){
							                        TranslatorIM.SLG_SETINTERVAL_PROXY++;
							               		if(theQ==1 && resp.indexOf('src":"')==-1){
							       		         	if(resp.indexOf('","')!=-1){
									                      	resp = resp.replace('["',''); 
							        				var R1 = resp.split('","');
							                	                resp = R1[0];
						        	                	} else resp = resp.replace(/"/ig,'');
						                	                NoDict = 1;
										}

									        if(NoDict==0 && resp.indexOf('sentences":')>-1){
											TranslatorIM.SLG_SETINTERVAL_PROXY++;
											resp = TranslatorIM.SLG_DICTparser(resp);
//											resp = resp.replace(/\"/ig,"'");
											resp = resp.replace(/\''/ig,"'");
											resp = resp.replace(/\\/g,"");
											TranslatorIM.CNTR('2231',Stemp+"/"+T, myTransText.length);
									        } else {
											resp="";
											TranslatorIM.SLG_OTHER_PROVIDERS(myTransText,st);
										}

										var idtmp="";
										var HID=6;
										if(resp.indexOf('id=_X')==-1) HID=2;
									}else{
										if(resp.indexOf('word_postproc":')>-1){
								                        TranslatorIM.SLG_SETINTERVAL_PROXY++;
								               		if(theQ==1 && resp.indexOf('word_postproc":')==-1){
							       			         	if(resp.indexOf('","')!=-1){
										                      	resp = resp.replace('["',''); 
							        					var R1 = resp.split('","');
							                	        	        resp = R1[0];
								                        	} else resp = resp.replace(/"/ig,'');
							        	                        NoDict = 1;
											}
									        	if(NoDict==0 && resp.indexOf('sentences":')>-1){
												TranslatorIM.SLG_SETINTERVAL_PROXY++;
												resp = TranslatorIM.SLG_DICTparser(resp);
										        } else {
											resp="";
											TranslatorIM.SLG_OTHER_PROVIDERS(myTransText,st);
											}
											var idtmp="";
											var HID=6;
											if(resp.indexOf('id=_X')==-1) HID=2;
										}
									}
								
									if(resp != "" && resp != "<#>"){	
								                var resptmp = resp;
										if(resp.indexOf('<div')==-1) resptmp = TranslatorIM.PPB_tts_icon(T,resp);

										doc2.getElementById('SLG_shadow_translation_result').innerHTML=resptmp;
										doc2.getElementById('SLG_shadow_translation_result2').innerHTML=resptmp;

										TranslatorIM.ACTIVATE_THEMEbbl(TranslatorIM.THEMEmode);
								                TranslatorIM.SLG_JUMP(doc2);
						        	                TranslatorIM.SLG_temp_result=resp;
										if (TranslatorIM.SLG_TH_2 == 1){

											var SLnow = new Date();
											SLnow = SLnow.toString();
											var TMPtime = SLnow.split(" ");
											var CurDT = TMPtime[1] + " " + TMPtime[2] + " " + TMPtime[3] + ", " + TMPtime[4];
								                        var LNGfrom = S;
								                        if(S=="auto" || doc2.getElementById("SLG_locer").checked == false) var LNGfrom = TranslatorIM.LNGforHISTORY;
											if(TranslatorIM.SLG_WRONGLANGUAGEDETECTED==1) LNGfrom="auto";
						        	                        var ImtranslatorGoogleResult="";
						                	                myTransText=myTransText.replace(/~/ig," ");
						                        		        var ImtranslatorGoogleResult4 = resp.replace(/~/ig," ");
							 				if(theQ==1){
												var TEMresp = ImtranslatorGoogleResult4.split("<br>");
												if(TEMresp.length>2){
													for(var k=0; k<TEMresp.length; k++){
														if(k>0)ImtranslatorGoogleResult = ImtranslatorGoogleResult + TEMresp[k];
													}
												} else ImtranslatorGoogleResult = ImtranslatorGoogleResult4;
											} else ImtranslatorGoogleResult = ImtranslatorGoogleResult4;
									
										        myTransText=myTransText.replace(/\^/g,"@");


											doc.runtimeSendMessage({greeting: "[b]" + myTransText + "~~" + ImtranslatorGoogleResult + "~~" + LNGfrom + "|" + T + "~~"+ doc2.location+"~~"+CurDT+"~~"+HID+"~~G^^"}, function(response) {
												if(response){ 
												//	console.log(response.farewell); 
												}
											});
										}
									} else 	TranslatorIM.SLG_OTHER_PROVIDERS(myTransText,0);

									doc2.getElementById('SLG_shadow_translation_result').style.direction = "ltr";
									doc2.getElementById('SLG_shadow_translation_result').style.textAlign = "left";
									if(T=="ar" || T=="iw" || T=="fa" || T=="yi" || T=="ur" || T=="ps" || T=="sd" || T=="ckb" || T=="ug" || T=="dv" || T=="prs"){
										doc2.getElementById('SLG_shadow_translation_result').style.direction = "rtl";
										doc2.getElementById('SLG_shadow_translation_result').style.textAlign = "right";
									}
									doc2.getElementById('SLG_shadow_translator').style.display = 'block';
									TranslatorIM.SLG_temp_result = resp;
									if(doc2.getElementById('SLG_shadow_translator').offsetHeight > 100) TranslatorIM.SLG_BALLON_H = doc2.getElementById('SLG_shadow_translator').offsetHeight;
								   }	
				        	    	}
						     }
					           });
					    },50);  
 		        		 },50);  

				  } 

		            } else TranslatorIM.SLG_OTHER_PROVIDERS(myTransText,st);
		  } else {
			   if(PR == "Microsoft") TranslatorIM.MS(S,T,myTransText,st);
			   else TranslatorIM.SLG_OTHER_PROVIDERS(myTransText,st);	
		  }
		}
	      }
	      TranslatorIM.SAVE_SES_PARAMS();
	},

	SLG_OTHER_PROVIDERS: function(text,st){
	     var doc = FExtension.browserInject;
	     var doc2 = doc.getDocument();
	     if(doc2.getElementById('SLG_shadow_translation_result').outerHTML.replace(/(<([^>]+)>)/ig,"")==""){
		doc2.getElementById('SLG_shadow_translation_result').innerHTML="";
		doc2.getElementById('SLG_shadow_translation_result2').innerHTML="";
                doc2.getElementById('SLG_loading').style.display="block";

	        var S = doc2.getElementById('SLG_lng_from').value;

	//        if(TranslatorIM.SLG_DETECT != "") S=TranslatorIM.SLG_DETECT;
       	        if(doc2.getElementById("SLG_locer").checked==false && TranslatorIM.SLG_DETECT != "") S = TranslatorIM.SLG_DETECT;

	        var T = doc2.getElementById('SLG_lng_to').value;
	        var Tbk = T;
		var PR = TranslatorIM.BL_T_PROV;
		if(TranslatorIM.SLG_MODE==1) PR = TranslatorIM.BL_D_PROV;
	        if(PR.toLowerCase()=="yandex") { 
			TranslatorIM.SLG_YANDEX(text,S,T); return false;
		}
		if(text != ""){
			var baseUrl = ImTranslator_theurl+"dotrans.asp";
			if(TranslatorIM.LNGforHISTORY=="")TranslatorIM.LNGforHISTORY="en";
			if(S=="auto")S=TranslatorIM.LNGforHISTORY;

                        if(PR.toLowerCase()=="google"){
		  		text = text.trim();
  				var nmr = text.split(" ").length;
  				if(nmr > 1) TranslatorIM.CNTRP('2221',S+"/"+T, text.length);
				else TranslatorIM.CNTRP('2231',S+"/"+T, text.length);
                        }

			var TT = T;
		        if(PR.toLowerCase()=="microsoft"){
				if(T == "zh") T = "zh-CHS";
				if(T == "zt") T = "zh-CHT";
				if(T == "iw") T = "he";
				if(T == "bs") T = "bs-Latn";
				if(T == "tlsl") T = "fil";
				if(T == "tl") T = "fil";
				if(T == "hmn") T = "mww";
				if(T == "srsl") T = "sr-Cyrl";
				if(T == "sr") T = "sr-Cyrl";
				if(T == "ku") T = "kmr";
				if(T == "ckb") T = "ku";

				if(S == "zh") S = "zh-CHS";
				if(S == "zt") S = "zh-CHT";
				if(S == "iw") S = "he";
				if(S == "bs") S = "bs-Latn";
				if(S == "tlsl") S = "fil";
				if(S == "tl") S = "fil";
				if(S == "hmn") S = "mww";
				if(S == "srsl") S = "sr-Cyrl";
				if(S == "sr") S = "sr-Cyrl";
				if(S == "ku") S = "kmr";
				if(S == "ckb") S = "ku";
		
				text=text.replace(/</g,"< ");
				text=TranslatorIM.truncStrByWord(text,3000);
			}


			var cgi = "dir="+S+"/"+T+"&provider="+PR.toLowerCase()+"&text="+encodeURIComponent(text);


			var ajaxRequest;  
			try{
				ajaxRequest = new XMLHttpRequest();
			} catch (e){
				try{
					ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
				} catch (e) {
					try{
						ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
					} catch (e){
						TranslatorIM.SLG_alert(FExtension.element(TranslatorIM.SLG_LOC,"extError1"));
						return false;
					}
				}
			}
			ajaxRequest.onreadystatechange = function(){

				if(ajaxRequest.readyState == 4){
			             var resp = ajaxRequest.responseText;
			             if(resp.indexOf('>Url Too Long<')!=-1 || resp.indexOf('>Request URL Too Long<')!=-1 || resp.indexOf('"ArgumentOutOfRangeException')!=-1) resp=PR + ": "+ FExtension.element(TranslatorIM.SLG_LOC,'extADVstu').replace("XXX","4000");
			             if(resp.indexOf('<#<')!=-1 || resp.indexOf('&lt;#')!=-1) resp=PR + ": "+ FExtension.element(TranslatorIM.SLG_LOC,"extnotrsrv");
				     if(resp=="" || resp.indexOf("<h1>Not Found</h1>")>-1) resp=PR + ": "+ FExtension.element(TranslatorIM.SLG_LOC,"extnotrsrv");

				     if(ajaxRequest.status!=200) resp=PR + ": "+ FExtension.element(TranslatorIM.SLG_LOC,"extnotrsrv");
				     if(ajaxRequest.status==414) resp=PR + ": "+ FExtension.element(TranslatorIM.SLG_LOC,'extADVstu').replace("XXX","4000");;
			             if(resp.indexOf('<#<')!=-1 || resp.indexOf('&lt;#')!=-1) resp=PR + ": "+ FExtension.element(TranslatorIM.SLG_LOC,"extnotrsrv");
				     if(resp.indexOf("ID=V2_Json_Translate")!=-1) resp=FExtension.element(TranslatorIM.SLG_LOC,"extnotrsrv");

					//-------------
				     	if(PR.toLowerCase()=="google") {
		                             	resp=resp.replace(/\\n/g,"<br>");
				     	}

				     	if(PR.toLowerCase()=="microsoft") {
		                             	resp=resp.replace(/\\n/g,"<br>");
						resp=resp.replace(/\\r/ig,"");
						resp=resp.replace(/< /g,"<");
						resp=resp.replace(/ >/g,">");
						resp=resp.replace(/\\"/g,"'");
				     	}

				     	if(PR.toLowerCase()=="translator") {
						resp=resp.replace(/&lt;/g,"<");
						resp=resp.replace(/&gt;/g,">");
					}
	                             	resp=resp.replace(/\\/g,"");
					//-------------


					doc2.getElementById('SLG_shadow_translator').style.display = 'block';

					TranslatorIM.SLG_temp_result=resp;

			                var resptmp = resp;
			                var resptmp = TranslatorIM.PPB_tts_icon(Tbk,resp);

				        if(PR.toLowerCase()!="translator") {
						doc2.getElementById('SLG_shadow_translation_result').innerHTML=resptmp.replace(/\\n/ig,'<br>');
						doc2.getElementById('SLG_shadow_translation_result2').innerHTML=resptmp.replace(/\\n/ig,'<br>');
					} else {
						doc2.getElementById('SLG_shadow_translation_result').innerHTML=resptmp.replace(/\n/ig,'<br>');
						doc2.getElementById('SLG_shadow_translation_result2').innerHTML=resptmp.replace(/\n/ig,'<br>');
					}

					doc2.getElementById('SLG_shadow_translation_result').style.direction = "ltr";
					doc2.getElementById('SLG_shadow_translation_result').style.textAlign = "left";

					if(T == "ar" || T == "he" || T == "fa" || T == "yi" || T == "ur" || T == "ps" || T == "sd" || T == "ku" || T == "ug" || T == "dv" || T == "prs"){
						doc2.getElementById('SLG_shadow_translation_result').style.direction = "rtl";
						doc2.getElementById('SLG_shadow_translation_result').style.textAlign = "right";
					}
                                        doc2.getElementById('SLG_loading').style.display="none";

                                       	TranslatorIM.SLG_JUMP(doc2);

					setTimeout(function() {	
         					var HID=2;
					        if (TranslatorIM.SLG_TH_2 == 1){

							var SLnow = new Date();
							SLnow = SLnow.toString();
							var TMPtime = SLnow.split(" ");
							var CurDT = TMPtime[1] + " " + TMPtime[2] + " " + TMPtime[3] + ", " + TMPtime[4];
				                        var LNGfrom = S;
				                        if(S=="auto" || doc2.getElementById("SLG_locer").checked == false) var LNGfrom = TranslatorIM.LNGforHISTORY;
							if(TranslatorIM.SLG_WRONGLANGUAGEDETECTED==1) LNGfrom="auto";

	                                                text=text.replace(/~/ig," ");
        	                                        resp=resp.replace(/~/ig," ");
						        text=text.replace(/\^/g,"@");
						        var DICT = TranslatorIM.BL_T_PROV;
							if(TranslatorIM.SLG_MODE==1) DICT = TranslatorIM.BL_D_PROV;
							doc.runtimeSendMessage({greeting:"[b]" + text + "~~" + resp + "~~" + LNGfrom + "|" + TT + "~~"+ doc2.location+"~~"+CurDT+"~~"+HID+"~~"+DICT[0]+"^^"}, function(response) {
								if(response){ 
								//	console.log(response.farewell); 
								}
							});
					        }
					}, 500);					


				}
			}
			ajaxRequest.open("POST", baseUrl, true);
			ajaxRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			ajaxRequest.send(cgi); 

		    }
	     }
	},





	SLG_DICTparser: function (resp){

		TranslatorIM.SLG_IS_DICTIONARY=1;
	        var ext = FExtension.browserInject;
		var doc = ext.getDocument();
		doc.getElementById('SLG_player2').style.display="none";

		var parsedRES="",parsedTRANS="";
		var PARTS = new Array();
		var SLG_to = doc.getElementById('SLG_lng_to').value;
		var SLG_from = doc.getElementById('SLG_lng_from').value;
		var ttsurl=ext.getURL('content/img/util/tts.png');


		var SLDetLngCodes =    new Array ();
		var SLDetLngNames =    new Array ();
//		var SLG_Lnum = SLG_Languages.split(",");
		var SLG_Lnum = TranslatorIM.SLG_LNG_LIST.split(",");
		for(var i = 0; i < SLG_Lnum.length; i++){
		        var SLG_tmp = SLG_Lnum[i].split(":");
			SLDetLngCodes.push(SLG_tmp[0]);
			SLDetLngNames.push(SLG_tmp[1]);
		}


		var Dt1=resp.split('src":"');
		var Dt2=Dt1[1].split('"');
		var DETECTEDlng=Dt2[0];
		var DETECTEDlongName="English";
		for (var z=0; z<SLDetLngCodes.length; z++){
			if(DETECTEDlng==SLDetLngCodes[z]) { DETECTEDlongName=SLDetLngNames[z];break; }
		}
		for (var z=0; z<SLDetLngNames.length; z++){
			if(SLG_from==SLDetLngNames[z]) { SLG_from=SLDetLngCodes[z];break; }
		}
		var Tr1=resp.split('dict":[');
		var Tr2=Tr1[0].split('orig":"');

		var Tr3=Tr2[1].split('"');
		var TRANSLATION = Tr3[0];


		var Gurl=FExtension.browserInject.getURL('content/html/popup/dictionary.html');
		var WAY = TranslatorIM.SLG_TTSicn(DETECTEDlng);

		var WAY2 = TranslatorIM.SLG_TTSicn(SLG_to);
		var SLG_DETECT = DETECTEDlng;

		if(TranslatorIM.SLG_ALLvoices.indexOf(SLG_DETECT)!=-1){
			if(resp.indexOf("reverse_translation")!=-1){
				if(WAY == 1) 	parsedTRANS = "<div id=_X><div id=_XL><div class=TTS"+WAY+" id=SLG_000 style=\"background:url("+ttsurl+");\" lang=\""+DETECTEDlng+"\" title=\""+TRANSLATION+"\"></div></div><div id=_XR align=left style='margin-left:5px;font-weight:bold;font-size:14px;'>" + TRANSLATION + "</div></div>";
				else    	parsedTRANS = "<div id=_X><div id=_FL><div class=TTS"+WAY+" id=SLG_000 style=\"background:url("+ttsurl+");\" lang=\""+DETECTEDlng+"\" title=\""+TRANSLATION+"\"></div></div><div id=_FR>" + TRANSLATION + "</div></div>";
			} else {
				if(WAY == "1") parsedTRANS = "<div dir=rtl>"+TRANSLATION+"</div>";
				else parsedTRANS = "<div dir=ltr>"+TRANSLATION+"</div>";
			}

		} else {
			if(resp.indexOf("reverse_translation")!=-1){
				if(WAY == 1) 	parsedTRANS = "<div id=_X><div id=_XR align=left style='margin-left:5px;font-weight:bold;font-size:14px;'>" + TRANSLATION + "</div></div>";
				else    	parsedTRANS = "<div id=_X><div id=_FR>" + TRANSLATION + "</div></div>";
			} else {
				if(WAY == "1") parsedTRANS = "<div dir=rtl>"+TRANSLATION+"</div>";
				else parsedTRANS = "<div dir=ltr>"+TRANSLATION+"</div>";
			}
		}




		if(resp.indexOf('pos":"')!=-1){
		   try{
		        var Rline,article;
			const obj = JSON.parse(resp);
			for(var i = 0; i < obj.dict.length; i++){
				parsedRES = parsedRES + "<div id=_Y>" +obj.dict[i].pos + "</div>";
				for (var j=0; j < obj.dict[i].entry.length; j++){
				        article="<x id=_ART>" + obj.dict[i].entry[j].word + "</x> ";
                               		Rline = "";

					for(var k = 0; k < obj.dict[i].entry[j].reverse_translation.length; k++){
						var tmpLNK = obj.dict[i].entry[j].reverse_translation[k].replace(/\\'/g,'~');
						tmpLNK = tmpLNK.replace(/\\u0027/g,'~');

						var F = SLG_from;
						var T = SLG_to;
						if(k < obj.dict[i].entry[j].reverse_translation.length-1){
							Rline = Rline + "<a class=_ALNK title=\""+tmpLNK+"\" id='SLG_" +i+"_"+ j+"_"+ k + "' href='"+Gurl+"?dir="+ SLG_from + "|" + SLG_to +"&text=" + encodeURIComponent(tmpLNK) + "'>" + tmpLNK + "</a>, ";
						} else {
							Rline = Rline + "<a class=_ALNK title=\""+tmpLNK+"\" id='SLG_" +i+"_"+ j+"_"+ k + "' href='"+Gurl+"?dir="+ SLG_from + "|" + SLG_to +"&text=" + encodeURIComponent(tmpLNK) + "'>" + tmpLNK + "</a>";
						}
					}

					var REV=obj.dict[i].entry[j].reverse_translation;
					var WORD=obj.dict[i].entry[j].word;
					var SLG_myTTS = article;// + REV;
				        if(SLG_TTS.indexOf(SLG_to)!=-1 || (G_TTS.indexOf(SLG_to)!=-1 && localStorage["SLG_GVoices"]!="0")){
					   if(WAY2==1) SLG_myTTS = "<div id=_X><div id=_XL><div class=_V id=\"SLG_"+i+j+"\" style=\"background:url("+ttsurl+");\" lang=\""+SLG_to+"\" title=\"" + WORD + "\"></div></div><div id=_XR>" + article + "</div></div>";
					   else SLG_myTTS = "<div id=_X><div id=_FL><div class=TTS"+WAY2+" id=\"SLG_"+i+j+"\" style=\"background:url("+ttsurl+");\" lang=\""+SLG_to+"\" title=\"" + WORD + "\"></div></div><div id=_XR>" + article + "</div></div>";
					}			
					parsedRES = parsedRES + "<div id=_A><div id=_AL>" + SLG_myTTS + "</div><div id=_AR>" + Rline + "</div></div>";
				}
				parsedRES = parsedRES + "<br>";
			}

		        doc.getElementById('SLG_TTS_voice').style.display='none';
		        doc.getElementById('SLG_bbl_font_patch').style.display='block';

		      } catch(ex){
			const obj = JSON.parse(resp);
		       	parsedRES="";
			parsedTRANS=obj.sentences[0].trans;
		      }	



		    } else {
		   	Tr2=Tr1[0].split('trans":"');
	   		Tr3=Tr2[1].split('"');
		   	parsedTRANS = Tr3[0];
		        doc.getElementById('SLG_TTS_voice').style.display='block';
		    }

		 if(parsedRES==""){
		   doc.getElementById('SLG_shadow_translation_result').style.direction="ltr";
		   doc.getElementById('SLG_shadow_translation_result').style.textAlign="left";
		   if(SLG_to=="ar" || SLG_to=="iw" || SLG_to=="fa" || SLG_to=="yi" || SLG_to=="ur" || SLG_to=="ps" || SLG_to=="sd" || SLG_to=="ckb" || SLG_to=="ug" || SLG_to=="dv" || SLG_to=="prs"){
			 doc.getElementById('SLG_shadow_translation_result').style.direction="rtl";
			 doc.getElementById('SLG_shadow_translation_result').style.textAlign="right";
		   }
		 } 
		 parsedRES = parsedTRANS +"<br>"+ parsedRES;
		 SLG_temp_result2 = parsedRES;
		 setTimeout(function(){
		     TranslatorIM.SLG_ALIGNER1(SLG_to);
		     TranslatorIM.SLG_ALIGNER2(DETECTEDlng);
		 },5);
		 
		 return parsedRES;

	},


SLG_ALIGNER1: function (SLG_to){
 var doc = FExtension.browserInject.getDocument();
 var nums=doc.getElementsByTagName("div").length;
 if(SLG_to!="ar" && SLG_to!="iw" && SLG_to!="fa" && SLG_to!="yi" && SLG_to!="ur" && SLG_to!="ps" && SLG_to!="sd" && SLG_to!="ckb" && SLG_to!="ug" && SLG_to!="dv" && SLG_to!="prs"){
      for(var I = 0; I < nums; I++){
       if(doc.getElementsByTagName("div")[I].id == "_AL")	 doc.getElementsByTagName("div")[I].style.textAlign="left";
      }
 } else {
      for(var I = 0; I < nums; I++){
       if(doc.getElementsByTagName("div")[I].id == "_AL")	 doc.getElementsByTagName("div")[I].style.textAlign="right";
      }
 }
},

SLG_ALIGNER2: function (SLG_from){
 var doc = FExtension.browserInject.getDocument();
 var nums=doc.getElementsByTagName("div").length;
 if(SLG_from!="ar" && SLG_from!="iw" && SLG_from!="fa" && SLG_from!="yi" && SLG_from!="ur" && SLG_from!="ps" && SLG_from!="sd" && SLG_from!="ckb" && SLG_from!="ug" && SLG_from!="dv" && SLG_from!="prs"){
      for(var I = 0; I < nums; I++){
       if(doc.getElementsByTagName("div")[I].id == "_AR")	 doc.getElementsByTagName("div")[I].style.textAlign="left";
      }
 } else {
      for(var I = 0; I < nums; I++){
       if(doc.getElementsByTagName("div")[I].id == "_AR")	 doc.getElementsByTagName("div")[I].style.textAlign="right";
      }
 }
},

SLG_TTSicn: function (lng){
 var doc = FExtension.browserInject.getDocument();
 var OUT="";
 if(lng!="ar" && lng!="iw" && lng!="fa" && lng!="yi" && lng!="ur" && lng!="ps" && lng!="sd" && lng!="ckb" && lng!="ug" && lng!="dv" && lng!="prs")   OUT=1;
 else   OUT=2;
 return(OUT);
},





	ClickInside: function(event){
		var target = event.target || event.srcElement;
		var id = target.id
           
		var className = target.className;

		if(className == "_V") 	 TranslatorIM.tagClick(event,id);
		if(className == "TTS1") TranslatorIM.tagClick(event,id);
		if(className == "TTS2") TranslatorIM.tagClick(event,id);

		if(className == "_ALNK") {
		    var tags = FExtension.browserInject.getDocument().getElementsByClassName("_ALNK");
		    for (var j=0; j<tags.length; j++){
		         tags[j].href='javascript:void(0);';
			 tags[j].addEventListener('mouseup', function(e){ TranslatorIM.UrltagClick(e) }, false);
			 TranslatorIM.AVOIDAUTODETECT=1;
		    }
		}
	},


	tagClick: function(event,id){
		var doc = FExtension.browserInject.getDocument();
                if(doc.getElementById("SLG_player2")) {
			doc.getElementById("SLG_player2").innerHTML="";
			doc.getElementById("SLG_player2").style.display="none";
			doc.getElementById("SLG_player2").style.height="0px";
		}


		   var SLG_from = doc.getElementById('SLG_lng_from').value;
		   if(doc.getElementById("SLG_000")) doc.getElementById("SLG_000").lang=SLG_from;
		   event.target.onmousemove = function () {TranslatorIM.SLG_ShowBalloon();}
		   var SLG_to = doc.getElementById(id).lang;
		   SLG_to=SLG_to.replace("zh-CN","zh");
		   SLG_to=SLG_to.replace("zh-TW","zh");

		   if(doc.getElementById('SLG_lng_from').value=="auto" || doc.getElementById("SLG_locer").checked == false) {if(id=="SLG_000") SLG_to = TranslatorIM.LNGforHISTORY;}
		   else{ 
			if(id=="SLG_000"){
				SLG_to = SLG_from;

				// By VK . A patch------------------------------------
				if(SLG_to.length>7)SLG_to="en";
				// By VK . A patch------------------------------------
			}

		   }

	   var text = doc.getElementById(event.target.id).title;
	   text = TranslatorIM.truncStrByWord(text,1200);
	   switch(TranslatorIM.SLG_SLVoices){
		case "0": if(TranslatorIM.SLG_ALLvoices.indexOf(SLG_to)!=-1){
                              if(SLG_TTS.indexOf(SLG_to)!=-1){
				if(text.length>TranslatorIM.GTTS_length) {
					if(SLG_to == "en-gb") SLG_to = "g_en-UK_f";
					window.open("https://text-to-speech.imtranslator.net/?dir="+SLG_to+"&text="+encodeURIComponent(text)); 
				}else TranslatorIM.Google_TTS(text,SLG_to);
			      } else TranslatorIM.Google_TTS(text,SLG_to);
			  } else TranslatorIM.SLG_alert(FExtension.element(TranslatorIM.SLG_LOC,"extNo_Voice"));
			  break;
		case "1": if(TranslatorIM.SLG_ALLvoices.indexOf(SLG_to)!=-1){
				if(G_TTS.indexOf(SLG_to)!=-1) TranslatorIM.Google_TTS(text,SLG_to);
				else TranslatorIM.SLG_alert(FExtension.element(TranslatorIM.SLG_LOC,"extNo_Voice"));
			  } else TranslatorIM.SLG_alert(FExtension.element(TranslatorIM.SLG_LOC,"extNo_Voice"));
			  break;
		case "2": if(TranslatorIM.SLG_ALLvoices.indexOf(SLG_to)!=-1){
                              if(SLG_TTS.indexOf(SLG_to)!=-1) {
					if(SLG_to == "en-gb") SLG_to = "g_en-UK_f";
					window.open("https://text-to-speech.imtranslator.net/?dir="+SLG_to+"&text="+encodeURIComponent(text));
			      }else TranslatorIM.Google_TTS(text,SLG_to);
			  } else TranslatorIM.SLG_alert(FExtension.element(TranslatorIM.SLG_LOC,"extNo_Voice"));
			  break;
	   }

	},



        Google_TTS: function(text,SLG_to){
		text = TranslatorIM.truncStrByWord(text,1200);
                var doc = FExtension.browserInject.getDocument();
		if(TranslatorIM.SLG_GVoices=="1"){
			if(text.length>TranslatorIM.GTTS_length){
			   text=text.substring(0,TranslatorIM.GTTS_length);
			   doc.getElementById('SLG_alert100').style.display="block";
			}
	        	TranslatorIM.REMOTE_Voice(SLG_to,text);			
		} else {
			if(SLG_to == "en-gb") SLG_to = "g_en-UK_f";
			window.open("https://text-to-speech.imtranslator.net/?dir="+SLG_to+"&text="+encodeURIComponent(text));
		}
	},


        Google_TTS_ON_TOP: function(text,SLG_to){
		text = TranslatorIM.truncStrByWord(text,1200);
                var doc = FExtension.browserInject.getDocument();
		if(TranslatorIM.SLG_GVoices=="1"){
			if(text.length>TranslatorIM.GTTS_length){
			   text=text.substring(0,TranslatorIM.GTTS_length);
			   doc.getElementById('SLG_alert100').style.display="block";
			}
	        	TranslatorIM.REMOTE_Voice(SLG_to,text);			
		} else {
			if(SLG_to == "en-gb") SLG_to = "g_en-UK_f";
			window.open("https://text-to-speech.imtranslator.net/?dir="+SLG_to+"&text="+encodeURIComponent(text));
		}
	},


	UrltagClick: function(e){
  	    if(e.which != 3){
		e.target.onmousemove = function () {TranslatorIM.SLG_ShowBalloon();}
		FExtension.browserInject.getDocument().getElementById(e.target.id).href='#';
		FExtension.browserInject.getDocument().getElementById(e.target.id).style.cursor='pointer';
		var txt = FExtension.browserInject.getDocument().getElementById(e.target.id).title;
                TranslatorIM.SLG_TEMP_TEXT=txt;
		setTimeout(function() { 
			TranslatorIM.SLG_BALLOON_TRANSLATION(txt,null,3); 
		    	TranslatorIM.SLG_removeBalloonColor();
		    	TranslatorIM.SLG_addBalloonColor();
		}, 150);   
		e.stopPropagation();
		e.cancelBubble = true;       
	    }	
	},



	SLG_SCROLL: function(){
		TranslatorIM.SLG_bring_UP();
	},


	SLG_OBJ_BUILDER: function(){

                  ImTranslatorDataEvent.mousedown();
                  
                  var doc = FExtension.browserInject.getDocument();
                  var btn = doc.getElementById('SLG_button');
                  if(btn){			
                      return;
                  }

	          var container = doc.body;



                  if(container){

		  var newElem = doc.createElement ("div");
		  var newElemid = doc.createAttribute("id");
		  newElemid.value = "SLG_balloon_obj";
	          newElem.setAttributeNode(newElemid);

		  var newElemtp = doc.createAttribute("alt");
		  newElemtp.value = "0";
	          newElem.setAttributeNode(newElemtp);

		  //---------------------------
		  

			  var OB = doc.createElement('div');
			  var id = doc.createAttribute("id");
			  id.value = "SLG_button";
		          OB.setAttributeNode(id);
 			  var cl = doc.createAttribute("class");
			  cl.value = "SLG_ImTranslatorLogo";
	        	  OB.setAttributeNode(cl);
		          newElem.appendChild(OB);

		        
			  OB1 = doc.createElement('div');
			  id = doc.createAttribute("id");
			  id.value = "SLG_shadow_translation_result2";
		          OB1.setAttributeNode(id);
		          newElem.appendChild(OB1);

			  OB2 = doc.createElement('div');
			  id = doc.createAttribute("id");
			  id.value = "SLG_shadow_translator";
	        	  OB2.setAttributeNode(id);
		          newElem.appendChild(OB2);

				  OB3 = doc.createElement('div');
				  id = doc.createAttribute("id");
				  id.value = "SLG_planshet";
	        		  OB3.setAttributeNode(id);

 				    OBup = doc.createElement('div');
				    OBup.id = "SLG_arrow_up";
			            OB3.appendChild(OBup);


					OB4 = doc.createElement('div');
					id = doc.createAttribute("id");
					id.value = "SLG_TB";
	        			OB4.setAttributeNode(id);


				        	var OB6 = doc.createElement("div");
						id = doc.createAttribute("id");
						id.value = "SLG_tables";
						OB6.setAttributeNode(id);
						var cs = doc.createAttribute("cellspacing");
						cs.value = "1";
						OB6.setAttributeNode(cs);

						        var OB7 = doc.createElement("tr");
						        OB6.appendChild(OB7); 

							        var OB8 = doc.createElement("td");
								cl = doc.createAttribute("class");
								cl.value = "SLG_td";
								OB8.setAttributeNode(cl);
								var w = doc.createAttribute("width");
								w.value = "10%";
								OB8.setAttributeNode(w);
								var a = doc.createAttribute("align");
								a.value = "right";
								OB8.setAttributeNode(a);
							        OB7.appendChild(OB8);

								        var OB9 = doc.createElement("input");
									id = doc.createAttribute("id");
									id.value = "SLG_locer";
									OB9.setAttributeNode(id);
									var ty = doc.createAttribute("type");
									ty.value = "checkbox";
									OB9.setAttributeNode(ty);
									var va = doc.createAttribute("checked");
									va.value = Boolean(TranslatorIM.SLG_TMPbox);

									OB9.setAttributeNode(va);
									var ti = doc.createAttribute("title");
									ti.value = FExtension.element(TranslatorIM.SLG_LOC,"extLock_in_language");
									OB9.setAttributeNode(ti);
				        				OB8.appendChild(OB9); 



							        var OB10 = doc.createElement("td");
								cl = doc.createAttribute("class");
								cl.value = "SLG_td";
								OB10.setAttributeNode(cl);
								w = doc.createAttribute("width");
								w.value = "20%";
								OB10.setAttributeNode(w);
								a = doc.createAttribute("align");
								a.value = "left";
								OB10.setAttributeNode(a);
							        OB7.appendChild(OB10);

									var OB11 = doc.createElement("select");
									id = doc.createAttribute("id");
									id.value = "SLG_lng_from";
									OB11.setAttributeNode(id);

									cl = doc.createAttribute("class");
									cl.value = "SLG_lngs";
									OB11.setAttributeNode(cl);


										if(TranslatorIM.SLG_LNG_CUSTOM_LIST.indexOf("auto")!=-1 || TranslatorIM.SLG_LNG_CUSTOM_LIST=="all"){
											var OB12 = doc.createElement('option');
											var v = document.createAttribute("value");
											v.value = "auto";
											OB12.setAttributeNode(v);
											OB12.appendChild(doc.createTextNode(FExtension.element(TranslatorIM.SLG_LOC,"extDetect_language_from_box")));
											OB11.appendChild(OB12); 
										}

										var MENU = TranslatorIM.SLG_LNG_LIST.split(",");
										for(var J=0; J < MENU.length; J++){
										    var CURlang3 = MENU[J].split(":");
										    var OB12 = doc.createElement('option');
										    var v = doc.createAttribute("value");
										    v.value = CURlang3[0];
										    OB12.setAttributeNode(v);
										    OB12.appendChild(doc.createTextNode(CURlang3[1]));
										    OB11.appendChild(OB12);
										}							                       

								        OB10.appendChild(OB11);

							        var OB13 = doc.createElement("td");
								cl = doc.createAttribute("class");
								cl.value = "SLG_td";
								OB13.setAttributeNode(cl);
								w = doc.createAttribute("width");
								w.value = "3";
								OB13.setAttributeNode(w);
								a = doc.createAttribute("align");
								a.value = "center";
								OB13.setAttributeNode(a);
							        OB7.appendChild(OB13);

									var OB14 = doc.createElement('div');
									id = doc.createAttribute("id");
									id.value = "SLG_switch_b";
								        OB14.setAttributeNode(id);
							 		ti = doc.createAttribute("title");
									ti.value = FExtension.element(TranslatorIM.SLG_LOC,"extSwitch_languages_ttl");
					        			OB14.setAttributeNode(ti);
								        OB13.appendChild(OB14);

							        var OB15 = doc.createElement("td");
								cl = doc.createAttribute("class");
								cl.value = "SLG_td";
								OB15.setAttributeNode(cl);
								w = doc.createAttribute("width");
								w.value = "20%";
								OB15.setAttributeNode(w);
								a = doc.createAttribute("align");
								a.value = "left";
								OB15.setAttributeNode(a);
							        OB7.appendChild(OB15);

									var OB16 = doc.createElement("select");
									id = doc.createAttribute("id");
									id.value = "SLG_lng_to";
									OB16.setAttributeNode(id);
									cl = doc.createAttribute("class");
									cl.value = "SLG_lngs";
									OB16.setAttributeNode(cl);


									     var SEL = 0
									     if(MENU.length>=TranslatorIM.SLG_FAV_START){
										var SLG_FAV_LANGS_LONG = TranslatorIM.SLG_ADD_LONG_NAMES(TranslatorIM.SLG_FAV_LANGS_BBL);

										if(SLG_FAV_LANGS_LONG!=""){
											var favArr=SLG_FAV_LANGS_LONG.split(","); 
											for(var J=0; J < favArr.length; J++){
											    var CURlang3 = favArr[J].split(":");
											    var OB_FAV = doc.createElement('option');
											    var v = doc.createAttribute("value");
											    v.value = CURlang3[0];

											    if(J == 0){
												    var sel = doc.createAttribute("selected");
												    sel.value = "selected";
												    OB_FAV.setAttributeNode(sel);
												    SEL = 1;
												    TranslatorIM.SLG_langDst_bbl2=CURlang3[0];
											    }

											    OB_FAV.setAttributeNode(v);
											    OB_FAV.appendChild(doc.createTextNode(CURlang3[1]));
											    OB16.appendChild(OB_FAV);
											}
											OB_FAV = doc.createElement('option');
											var d = doc.createAttribute("disabled");
											d.value = true;
											OB_FAV.setAttributeNode(d);
											var all = FExtension.element(TranslatorIM.SLG_LOC,"extwptDAll");
										    	OB_FAV.appendChild(doc.createTextNode("-------- [ "+ all +" ] --------"));

										    	OB16.appendChild(OB_FAV);
										}
									     }	


									        var thelang = "es";
										if(TranslatorIM.SLG_langDst!="" && TranslatorIM.SLG_SID_TO=="") thelang = TranslatorIM.SLG_langDst_bbl2;
										for(J=0; J < MENU.length; J++){
										    CURlang3 = MENU[J].split(":");
										    option = doc.createElement('option');
										    if(SEL == 0){	
											    if(CURlang3[0] == thelang){
												    var sel = doc.createAttribute("selected");
												    sel.value = "selected";
												    option.setAttributeNode(sel);
											    }
										    }
										    v = doc.createAttribute("value");
										    v.value = CURlang3[0];
										    option.setAttributeNode(v);
										    option.appendChild(doc.createTextNode(CURlang3[1]));
										    OB16.appendChild(option);
										}							                       

								        OB15.appendChild(OB16);									

							        var OB17 = doc.createElement("td");
								cl = doc.createAttribute("class");
								cl.value = "SLG_td";
								OB17.setAttributeNode(cl);
								w = doc.createAttribute("width");
								w.value = "5%";
								OB17.setAttributeNode(w);
								a = doc.createAttribute("align");
								a.value = "center";
								OB17.setAttributeNode(a);
							        OB7.appendChild(OB17);

									OB17.appendChild(doc.createTextNode(" "));

							        var OB18 = doc.createElement("td");
								cl = doc.createAttribute("class");
								cl.value = "SLG_td";
								OB18.setAttributeNode(cl);
								w = doc.createAttribute("width");
								w.value = "8%";
								OB18.setAttributeNode(w);
								a = doc.createAttribute("align");
								a.value = "center";
								OB18.setAttributeNode(a);
							        OB7.appendChild(OB18);

									var OB19 = doc.createElement('div');
									id = doc.createAttribute("id");
									id.value = "SLG_TTS_voice";
								        OB19.setAttributeNode(id);
							 		ti = doc.createAttribute("title");                 
									ti.value = TranslatorIM.SLG_GetLongName(TranslatorIM.SLG_DETECT);
					        			OB19.setAttributeNode(ti);
								        OB18.appendChild(OB19);

							        var OB20 = doc.createElement("td");
								cl = doc.createAttribute("class");
								cl.value = "SLG_td";
								OB20.setAttributeNode(cl);
								w = doc.createAttribute("width");
								w.value = "8%";
								OB20.setAttributeNode(w);
								a = doc.createAttribute("align");
								a.value = "center";
								OB20.setAttributeNode(a);
							        OB7.appendChild(OB20);

									var OB21 = doc.createElement('div');
									id = doc.createAttribute("id");
									id.value = "SLG_copy";
								        OB21.setAttributeNode(id);
							 		ti = doc.createAttribute("title");
									ti.value = FExtension.element(TranslatorIM.SLG_LOC,"extCopy_ttl");
					        			OB21.setAttributeNode(ti);
							 		cl = doc.createAttribute("class");
									cl.value = "SLG_copy";
					        			OB21.setAttributeNode(cl);
								        OB20.appendChild(OB21);
										var OB21tip = doc.createElement('div');
										id = doc.createAttribute("id");
										id.value = "SLG_copy_tip";
									        OB21tip.setAttributeNode(id);
								        	OB21.appendChild(OB21tip);


							        var OB22 = doc.createElement("td");
								cl = doc.createAttribute("class");
								cl.value = "SLG_td";
								OB22.setAttributeNode(cl);
								w = doc.createAttribute("width");
								w.value = "8%";
								OB22.setAttributeNode(w);
								a = doc.createAttribute("align");
								a.value = "center";
								OB22.setAttributeNode(a);
							        OB7.appendChild(OB22);

									var OB23 = doc.createElement('div');
									id = doc.createAttribute("id");
									id.value = "SLG_bbl_font_patch";
								        OB23.setAttributeNode(id);
//							 		var js = doc.createAttribute("onclick");
//									js.value = "TranslatorIM.SLG_alert(FExtension.element(TranslatorIM.SLG_LOC,"extNot_available"))";
//					        			OB23.setAttributeNode(js);
								        OB22.appendChild(OB23);

									var OB24 = doc.createElement('div');
									id = doc.createAttribute("id");
									id.value = "SLG_bbl_font";
								        OB24.setAttributeNode(id);
							 		ti = doc.createAttribute("title");
									ti.value = FExtension.element(TranslatorIM.SLG_LOC,"extFont_Size_ttl");
					        			OB24.setAttributeNode(ti);
							 		cl = doc.createAttribute("class");
									cl.value = "SLG_bbl_font";
					        			OB24.setAttributeNode(cl);
								        OB22.appendChild(OB24);

							        var OB25 = doc.createElement("td");
								cl = doc.createAttribute("class");
								cl.value = "SLG_td";
								OB25.setAttributeNode(cl);
								w = doc.createAttribute("width");
								w.value = "8%";
								OB25.setAttributeNode(w);
								a = doc.createAttribute("align");
								a.value = "center";
								OB25.setAttributeNode(a);
							        OB7.appendChild(OB25);


									var OB26 = doc.createElement('div');
									id = doc.createAttribute("id");
									id.value = "SLG_bbl_help";
								        OB26.setAttributeNode(id);
							 		ti = doc.createAttribute("title");
									ti.value = FExtension.element(TranslatorIM.SLG_LOC,"extHelp");
					        			OB26.setAttributeNode(ti);
								        OB25.appendChild(OB26);



							        var OB28 = doc.createElement("td");
								cl = doc.createAttribute("class");
								cl.value = "SLG_td";
								OB28.setAttributeNode(cl);
								w = doc.createAttribute("width");
								w.value = "15%";
								OB28.setAttributeNode(w);
								a = doc.createAttribute("align");
								a.value = "right";
								OB28.setAttributeNode(a);
							        OB7.appendChild(OB28);

									var OB29 = doc.createElement('div');
									id = doc.createAttribute("id");
									id.value = "SLG_pin";
								        OB29.setAttributeNode(id);
									cl = doc.createAttribute("class");
									cl.value = "SLG_pin_off";
								        OB29.setAttributeNode(cl);
							 		ti = doc.createAttribute("title");
									ti.value = FExtension.element(TranslatorIM.SLG_LOC,"extPin_ttl");
					        			OB29.setAttributeNode(ti);
								        OB28.appendChild(OB29);


						OB4.appendChild(OB6);


						var OBpr = doc.createElement('div');
						id = doc.createAttribute("id");
						id.value = "SLG_Bproviders";
						
						if(TranslatorIM.SLG_SHOW_PROVIDERS!="1"){
							st = doc.createAttribute("style");
							st.value = "visibility:hidden;";
							OBpr.setAttributeNode(st);
						}
					        OBpr.setAttributeNode(id);
					        OB4.appendChild(OBpr);

					        for(var p=0; p<TranslatorIM.LISTofPR.length; p++){
							var OBprov = doc.createElement('div');
							id = doc.createAttribute("id");
							id.value = "SLG_P"+p;

							cl = doc.createAttribute("class");
							cl.value = "SLG_BL_LABLE_ON";
							OBprov.setAttributeNode(cl);

							ti = doc.createAttribute("title");
							ti.value = TranslatorIM.LISTofPR[p];
						        OBprov.setAttributeNode(ti);

						        OBprov.setAttributeNode(id);

							var span = doc.createElement('div');
							span.id = "SLG_PN"+p;
						        OBprov.appendChild(span);

                                                        span.appendChild(doc.createTextNode(TranslatorIM.LISTofPR[p][0]));
						        OBpr.appendChild(OBprov);

					        }
						OB3.appendChild(OBpr);

						var OBalert = doc.createElement('div');
						OBalert.id = "SLG_alert_bbl";
						OBalert.height = "30px;";
					        OB3.appendChild(OBalert);

							var OBclose = doc.createElement('div');
							OBclose.id = "SLHKclose";
						        OBalert.appendChild(OBclose);

							var OBalertcont = doc.createElement('div');
							OBalertcont.id = "SLG_alert_cont";
						        OBalert.appendChild(OBalertcont);



			        	OB3.appendChild(OB4);
		        	OB2.appendChild(OB3);

				var OB30 = doc.createElement('div');
				id = doc.createAttribute("id");
				id.value = "SLG_shadow_translation_result";
			        OB30.setAttributeNode(id);

			        OB2.appendChild(OB30);

					        var eUL16 = doc.createElement("div");
						st30 = doc.createAttribute("id");
						st30.value = "SLG_loading";
						eUL16.setAttributeNode(st30);
						var st30 = doc.createAttribute("class");
						st30.value = "SLG_loading";
						eUL16.setAttributeNode(st30);
						OB2.appendChild(eUL16);


				var OB31 = doc.createElement('div');
				id = doc.createAttribute("id");
				id.value = "SLG_player2";
			        OB31.setAttributeNode(id);
			        OB2.appendChild(OB31);

				var OB32 = doc.createElement('div');
				id = doc.createAttribute("id");
				id.value = "SLG_alert100";
			        OB32.setAttributeNode(id);
			        OB2.appendChild(OB32);

					OB32.appendChild(doc.createTextNode(FExtension.element(TranslatorIM.SLG_LOC,"extTTS_Limit")));


				var OB34 = doc.createElement('div');
				id = doc.createAttribute("id");
				id.value = "SLG_Balloon_options";
			        OB34.setAttributeNode(id);
			        OB2.appendChild(OB34);

				  OBdown = doc.createElement('div');
				  OBdown.id = "SLG_arrow_down";
			          OB34.appendChild(OBdown);

		var OBtbl = doc.createElement("div");
		id = doc.createAttribute("id");
		id.value = "SLG_tbl_opt";
		OBtbl.setAttributeNode(id);
		OBtbl.width = "100%";
		OBtbl.height = "16";


               	        var OBtr = doc.createElement("tr");
		        OBtbl.appendChild(OBtr); 

			        var OBtd3_ = doc.createElement("td");
				cl = doc.createAttribute("class");
				cl.value = "SLG_td";
				OBtd3_.setAttributeNode(cl);
				OBtd3_.width = "5%";
				OBtd3_.align = "center";
			        OBtr.appendChild(OBtd3_);

				        var OB9_ = doc.createElement("input");
					id = doc.createAttribute("id");
					id.value = "SLG_BBL_locer";
					OB9_.setAttributeNode(id);
					var ty = doc.createAttribute("type");
					ty.value = "checkbox";
					OB9_.setAttributeNode(ty);
					var va = doc.createAttribute("checked");
					va.value = Boolean(TranslatorIM.SLG_OnOff_BTN2);
					OB9_.setAttributeNode(va);
					var ti = doc.createAttribute("title");
					ti.value = FExtension.element(TranslatorIM.SLG_LOC,'extSTB') + " "+ TranslatorIM.Timing +" " +FExtension.element(TranslatorIM.SLG_LOC,'extSeconds');
					OB9_.setAttributeNode(ti);
        				OBtd3_.appendChild(OB9_); 

			        var OBtd3__ = doc.createElement("td");
				cl = doc.createAttribute("class");
				cl.value = "SLG_td";
				OBtd3__.setAttributeNode(cl);
				OBtd3__.width = "5%";
				OBtd3__.align = "left";
			        OBtr.appendChild(OBtd3__);
			                          


				        var OB9__ = doc.createElement("div");
					id = doc.createAttribute("id");
					id.value = "SLG_BBL_IMG";
					OB9__.setAttributeNode(id);
					var ti = doc.createAttribute("title");
					ti.value = FExtension.element(TranslatorIM.SLG_LOC,'extSTB') + " "+ TranslatorIM.Timing +" " +FExtension.element(TranslatorIM.SLG_LOC,'extSeconds');
					OB9__.setAttributeNode(ti);
        				OBtd3__.appendChild(OB9__); 






			        var OBtd2 = doc.createElement("td");
				cl = doc.createAttribute("class");
				cl.value = "SLG_td";
				OBtd2.setAttributeNode(cl);
				OBtd2.width = "100%";
				OBtd2.align = "center";
			        OBtr.appendChild(OBtd2);


					var OB35 = doc.createElement('span');
			 		var id = doc.createAttribute("id");
					id.value = "BBL_OPT";
	        			OB35.setAttributeNode(id);

					cl = doc.createAttribute("class");
					cl.value = "SLG_options";
				        OB35.setAttributeNode(cl);
					ti = doc.createAttribute("title");
					ti.value = FExtension.element(TranslatorIM.SLG_LOC,"extOptions_ttl");
				        OB35.setAttributeNode(ti);
				        OBtd2.appendChild(OB35);

					OB35.appendChild(doc.createTextNode(FExtension.element(TranslatorIM.SLG_LOC,"extOptions")));

					OBtd2.appendChild(doc.createTextNode(" : "));

					var OB36 = doc.createElement('span');

			 		var id = doc.createAttribute("id");
					id.value = "HIST_OPT";
	        			OB36.setAttributeNode(id);
					cl = doc.createAttribute("class");
					cl.value = "SLG_options";
				        OB36.setAttributeNode(cl);
					ti = doc.createAttribute("title");
					ti.value = FExtension.element(TranslatorIM.SLG_LOC,"extHistory_ttl");
				        OB36.setAttributeNode(ti);
				        OBtd2.appendChild(OB36);

					OB36.appendChild(doc.createTextNode(FExtension.element(TranslatorIM.SLG_LOC,"extHistory")));

					OBtd2.appendChild(doc.createTextNode(" : "));


					var OB38 = doc.createElement('span');
			 		var id = doc.createAttribute("id");
					id.value = "FEED_OPT";
	        			OB38.setAttributeNode(id);

					cl = doc.createAttribute("class");
					cl.value = "SLG_options";
				        OB38.setAttributeNode(cl);
					ti = doc.createAttribute("title");
					ti.value = FExtension.element(TranslatorIM.SLG_LOC,"extFeedback_ttl");
				        OB38.setAttributeNode(ti);
				        OBtd2.appendChild(OB38);

					OB38.appendChild(doc.createTextNode(FExtension.element(TranslatorIM.SLG_LOC,"extFeedback")));

					OBtd2.appendChild(doc.createTextNode(" : "));

					var OB37 = doc.createElement('span');
			 		var id = doc.createAttribute("id");
					id.value = "DONATE_OPT";
	        			OB37.setAttributeNode(id);

					cl = doc.createAttribute("class");
					cl.value = "SLG_options";
				        OB37.setAttributeNode(cl);
					ti = doc.createAttribute("title");
					ti.value = FExtension.element(TranslatorIM.SLG_LOC,"extContribution_ttl");
				        OB37.setAttributeNode(ti);
				        OBtd2.appendChild(OB37);

					OB37.appendChild(doc.createTextNode('Donate'));



        				            
			        var OBtd3 = doc.createElement("td");
				cl = doc.createAttribute("class");
				cl.value = "SLG_td";
				OBtd3.setAttributeNode(cl);
				OBtd3.width = "15%";
				OBtd3.align = "right";
			        OBtr.appendChild(OBtd3);
				var nw = doc.createAttribute("nowrap");
				nw.value = "nowrap";
				OBtd3.setAttributeNode(nw);



					var OB39 = doc.createElement('span');
					id = doc.createAttribute("id");
					id.value = "SLG_Balloon_Close";
				        OB39.setAttributeNode(id);
					cl = doc.createAttribute("class");
					cl.value = "SLG_options";
				        OB39.setAttributeNode(cl);

					ti = doc.createAttribute("title");
					ti.value = FExtension.element(TranslatorIM.SLG_LOC,"extClose");
				        OB39.setAttributeNode(ti);
				        OBtd3.appendChild(OB39);

					OB39.appendChild(doc.createTextNode(FExtension.element(TranslatorIM.SLG_LOC,"extClose")));

			        OBtbl.appendChild(OBtr);

		        OB34.appendChild(OBtbl); 
                        OB2.classList.add("notranslate");

		  //---------------------------
	  
		  TranslatorIM.idleCounter = 0;
                  if(container.tagName == "FRAMESET"){
                      container.parentNode.insertBefore(newElem, container.nextSibling);
                  }else{
                    container.appendChild (newElem);
		    doc.getElementById("SLG_balloon_obj").style.display='block';
                  }
                  doc.getElementById('SLG_shadow_translation_result2').style.display="none";
		  TranslatorIM.SLG_IMG_LOADER();
		  }
                  if(doc.getElementById("SLG_balloon_obj")){
			//STOP WORKING ON IFRAMES
			  if(self!=top){
                               if(String(window.location).indexOf('mail.live.')!=-1) container.removeChild (doc.getElementById("SLG_balloon_obj"));
			  }

/*
        	          var id = TranslatorIM.TempActiveObjId;                                                                                    
       	        	  if(!window.getSelection().anchorNode && id != "SLG_button" && id !="SLG_TTS_voice" && id !="SLG_lng_from" && id !="SLG_lng_to" && id !="SLG_locer") container.removeChild (doc.getElementById("SLG_balloon_obj"));
	               	  else {doc.getElementById("SLG_balloon_obj").style.display='block';}
*/
			  if(doc.getElementById('SLG_tables')){						
	        	         var escaper = doc.getElementById('SLG_tables').offsetWidth;		
       	          		 if((escaper != 0 && escaper > 410) && TranslatorIM.TempActiveObjId !="SLG_button") container.removeChild (doc.getElementById("SLG_balloon_obj"));
			  }

		  }



		  //STOP WORKING ON OLD FORUMS
		  if(container.tagName=="BODY" && doc.body.id=="check") container.removeChild (doc.getElementById("SLG_balloon_obj"));
		  //STOP WORKING ON WP WIDGETS
		  if(container.tagName=="BODY" && doc.body.id=="tinymce") container.removeChild (doc.getElementById("SLG_balloon_obj"));	     


		if(doc.getElementById('SLG_lng_from')){
	                doc.getElementById('SLG_lng_from').value=TranslatorIM.SLG_langSrc_bbl2;
	       	        doc.getElementById('SLG_lng_to').value=TranslatorIM.SLG_langDst_bbl2;
        		TranslatorIM.SLG_locker_settler();
		}
	},


	fade: function (){
	 var doc = FExtension.browserInject.getDocument();
	 TranslatorIM.unfade();
	 setTimeout(function() { 
		var THEobj = doc.getElementById('SLG_button');
		if(THEobj){
			 THEobj.style.opacity=0;
			 THEobj.style.transition='opacity 1s linear';
		}
	 }, (TranslatorIM.Timing*1000));
	},

	dofade: function (){
	 var doc = FExtension.browserInject.getDocument();
	 var THEobj = doc.getElementById('SLG_button');
	   setTimeout(function() { 
		if(THEobj){
			THEobj.style.opacity=0;
			THEobj.style.transition='opacity 1s linear';
			THEobj.addEventListener('transitionend', function() {
			    THEobj.style.display='none';
			}, false );
		}
	   }, (TranslatorIM.Timing*1000));
	},

	unfade: function (){
	 var doc = FExtension.browserInject.getDocument();
	 if(doc.getElementById("SLG_button")){
		doc.getElementById("SLG_button").style.opacity=0;
		var THEobj = doc.getElementById('SLG_button');
		if(THEobj){
			 THEobj.style.opacity=1;
			 THEobj.style.transition='';
		}
	 }
	},


	SLShowHideAlert: function(){
	  var doc = FExtension.browserInject.getDocument();
	  if(doc.getElementById('SLG_alert_bbl')) doc.getElementById('SLG_alert_bbl').style.display='none'; 
	},
                

	SLG_alert: function(txt){
	  var doc = FExtension.browserInject.getDocument();
	  if(doc.getElementById('SLG_alert_bbl')){
		doc.getElementById('SLG_alert_bbl').style.display="block";
		doc.getElementById('SLG_alert_bbl').style.marginTop="-1px";
		doc.getElementById('SLG_alert_bbl').style.marginLeft="0px";
		doc.getElementById("SLG_alert_cont").innerText=txt;
          }
	},

/*
        getObjPosition: function (el){
	    var _x = event.clientX + document.body.scrollLeft - document.body.clientLeft;
	    var _y = event.clientY + document.body.scrollTop - document.body.clientTop;

	    TranslatorIM.SLG_L = _x;
	    TranslatorIM.SLG_R = _x;
	    TranslatorIM.SLG_T = _y;
	    TranslatorIM.SLG_B = _y;
	    if(_y<265) {
		TranslatorIM.SLG_NEST="BOTTOM";
		TranslatorIM.SLG_T=TranslatorIM.SLG_T+10;
		TranslatorIM.SLG_B=TranslatorIM.SLG_B+10;
	    }
	},

*/


	getSelectionCoords: function(e) {
	  var doc = FExtension.browserInject.getDocument();

	  try{
		  var range = doc.getSelection().getRangeAt(0);
		  var rect = range.getBoundingClientRect();

		  var l = Math.ceil(rect.left);
		  var t = Math.ceil(rect.top);
		  var r = Math.ceil(rect.right);
		  var b = Math.ceil(rect.bottom);


		  if(l==0 && t==0 && b==0 && r==0){
			if(TranslatorIM.SLG_GLOBAL_X1>TranslatorIM.SLG_GLOBAL_X2){
				l = TranslatorIM.SLG_GLOBAL_X2;
				r = TranslatorIM.SLG_GLOBAL_X1;
			} else {
				l = TranslatorIM.SLG_GLOBAL_X1;
				r = TranslatorIM.SLG_GLOBAL_X2;
			}

			if(TranslatorIM.SLG_GLOBAL_Y1>TranslatorIM.SLG_GLOBAL_Y2){
				t = TranslatorIM.SLG_GLOBAL_Y2-document.body.scrollTop;
				b = TranslatorIM.SLG_GLOBAL_Y1-document.body.scrollTop;
			} else {
				t = TranslatorIM.SLG_GLOBAL_Y1-document.body.scrollTop;
				b = TranslatorIM.SLG_GLOBAL_Y2-document.body.scrollTop;
			}
			t=t-8;
			b=b+8;
		  }



	//	  if(l!=t){

			  TranslatorIM.SLG_L = l; 
			  TranslatorIM.SLG_T = t;
			  TranslatorIM.SLG_R = r;
			  TranslatorIM.SLG_B = b;
			  if(t<265) TranslatorIM.SLG_NEST="BOTTOM";
			  else TranslatorIM.SLG_NEST="TOP";
			  var bodyScrollTop = doc.documentElement.scrollTop || doc.body.scrollTop;
			  var deltab=window.innerHeight*1-140-b;
			  var deltat=t;


			  if(deltab>deltat && deltat<270)TranslatorIM.SLG_NEST="BOTTOM";
			  else if(bodyScrollTop>270)TranslatorIM.SLG_NEST="TOP";


			  if((bodyScrollTop+b)>(bodyScrollTop + window.innerHeight-200) && b-t> window.innerHeight-200 && t<260) TranslatorIM.SLG_NEST="FLOAT";
			  TranslatorIM.SLG_SID_PIN=TranslatorIM.SLG_OnOff_PIN;
			  //TranslatorIM.SAVE_SES_PARAMS();
			  if(TranslatorIM.SLG_FRAME==0){
			  	if(TranslatorIM.SLG_NEST!="FLOAT" && TranslatorIM.SLG_SID_PIN == "true") TranslatorIM.SLG_NEST="FLOAT";
			  }

	//	  }

	 } catch(e){}
	 },

	 SLG_JUMP: function (doc){
		setTimeout(function() {
			TranslatorIM.SLG_bring_UP();
			TranslatorIM.SLG_bring_DOWN();
        		if(TranslatorIM.SLG_NEST!="FLOAT"){
				var SLdivField = doc.getElementById("SLG_shadow_translator");

		 		if(TranslatorIM.SLG_NEST=="TOP"){
		//			if(TranslatorIM.SLG_MoveY.replace("px","") < 0){
				        	var bodyScrollTop = doc.documentElement.scrollTop || doc.body.scrollTop;
						var tp = Math.abs((bodyScrollTop*1)+TranslatorIM.SLG_T-(SLdivField.offsetHeight*1)-9);
						if(TranslatorIM.SLG_SAVETEXT==0) SLdivField.style.top = tp +"px";
		//			}
				}
				TranslatorIM.WINDOW_and_BUBBLE_alignment(doc,SLdivField);
			} else {
			 	doc.getElementById("SLG_arrow_up").style.display="none";
			}
			var e = window.event;
		}, 50);
	},




	WINDOW_and_BUBBLE_alignment: function(doc,SLdivField){
		if(TranslatorIM.SLG_FRAME==1 && (TranslatorIM.GlobalBoxX+TranslatorIM.GlobalBoxY)>0){
			TranslatorIM.SLG_NEST="";
			var OBJ = doc.getElementById('SLG_pin');
			OBJ.className = "SLG_pin_off";
			OBJ.title = FExtension.element(TranslatorIM.SLG_LOC,"extPin_ttl");
			OBJ.style.background="url("+FExtension.browserInject.getURL('content/img/util/pin-off.png')+")";

			TranslatorIM.SLG_SID_PIN="false";

	        	var bodyScrollTop = doc.documentElement.scrollTop || doc.body.scrollTop;
			if(parseInt(TranslatorIM.SLG_MoveX.replace("px",""))<0){
				var tp = Math.abs((bodyScrollTop*1)+TranslatorIM.SLG_T-(SLdivField.offsetHeight*1)-9);
			}else{
				var tp = TranslatorIM.SLG_MoveX;
				TranslatorIM.SLG_MoveX="-10000px";
			}
			SLdivField.style.top = tp +"px";			

	        	var bodyScrollLeft = doc.documentElement.scrollLeft || doc.body.scrollLeft;
			if(parseInt(TranslatorIM.SLG_MoveY.replace("px",""))<0){
				var lt = Math.abs((bodyScrollLeft*1)+((TranslatorIM.SLG_L+TranslatorIM.SLG_R)/2)-(SLdivField.offsetWidth*1)/2);
			}else{
				var lt = TranslatorIM.SLG_MoveY;
				TranslatorIM.SLG_MoveY="-10000px";
			}
			SLdivField.style.left = lt +"px";

			TranslatorIM.SLG_arrows('up'); 
		} else {
	        	var bodyScrollTop = doc.documentElement.scrollTop || doc.body.scrollTop;	  	
        	        var Wy1 = bodyScrollTop;
	                var Wy2 = window.innerHeight + bodyScrollTop;
                	var By1 = parseInt(SLdivField.style.top.replace("px",""));
        	        var By2 = By1+SLdivField.offsetHeight;
			var DELTAy = 1;
			if (doc.body.offsetHeight > window.innerHeight)	var DELTAy = 5;
			if (By1 < Wy1) SLdivField.style.top = (Wy1+TranslatorIM.GlobalBoxY) +"px";
			if (By2 > Wy2) SLdivField.style.top = (Wy2-SLdivField.offsetHeight-DELTAy) +"px";

	        	var bodyScrollLeft = doc.documentElement.scrollLeft || doc.body.scrollLeft;	  	
        	        var Wx1 = bodyScrollLeft;
	                var Wx2 = window.innerWidth + bodyScrollLeft;
                	var Bx1 = parseInt(SLdivField.style.left.replace("px",""));
			if(TranslatorIM.SLG_NEST == "FLOAT") Bx1 = TranslatorIM.GlobalBoxX;
	                var Bx2 = Bx1+SLdivField.offsetWidth;
			var DELTAx = 1;
			if (doc.body.offsetWidth < window.innerWidth)	var DELTAx = 25;
			var cnt=0;
			if (Bx1 < Wx1) {cnt++;SLdivField.style.left = (Wx1+TranslatorIM.GlobalBoxX+DELTAx) +"px";}
			if (Bx2 > Wx2) {cnt++;SLdivField.style.left = (Wx2-SLdivField.offsetWidth-DELTAx) +"px";}

			if(TranslatorIM.SLG_NEST == "FLOAT"){
				if(cnt==0 && TranslatorIM.GlobalBoxX!=0){
					SLdivField.style.left = TranslatorIM.GlobalBoxX+"px";
				}
			}
		}

	},


	SLG_arrows: function (st){
		var doc = FExtension.browserInject.getDocument();
		doc.getElementById('SLG_arrow_up').style.display='block';
		doc.getElementById('SLG_arrow_down').style.display='block';
	   	switch(st){
			case "up": doc.getElementById('SLG_arrow_up').style.display='none'; break;
			case "down": doc.getElementById('SLG_arrow_down').style.display='none'; break;
	                case "all": doc.getElementById('SLG_arrow_up').style.display='none'; doc.getElementById('SLG_arrow_down').style.display='none'; break;
	        }
	},


        SLG_NotAllowed: function(){
	    var doc = FExtension.browserInject.getDocument();
		 if(doc.getElementById('SLG_lng_from').value=="auto"){
			//doc.getElementById('SLG_switch_b').title=TranslatorIM.SLG_LOC("disabled");
			doc.getElementById('SLG_switch_b').style.cursor='not-allowed';
		 }else{
			//doc.getElementById('SLG_switch_b').title=TranslatorIM.SLG_LOC("switch");
			doc.getElementById('SLG_switch_b').style.cursor='pointer';
		 }
	},



	SLG_WEB_PAGE_TRANSLATION_FROM_TB: function(st, act, tb, tip){       
		TranslatorIM.SLG_set_LNG_TRIGGER("SLG_LNG_TRIGGER",0);
		if(TranslatorIM.SLG_wptGlobTip!=tip || TranslatorIM.SLG_wptGlobTb != tb){
			ImTranslatorDataEvent.mousedown();
			setTimeout(function() {
				TranslatorIM.SLG_WEB_PAGE_TRANSLATION(st,act);
			}, 100);
		}else TranslatorIM.SLG_WEB_PAGE_TRANSLATION(st,act);
	},


	SLG_WEB_PAGE_TRANSLATION_FROM_CM_AND_HK: function(st, act){       
		TranslatorIM.SLG_set_LNG_TRIGGER("SLG_LNG_TRIGGER",0);
		TranslatorIM.SLG_WEB_PAGE_TRANSLATION(st,act);
	},


	SLG_WPT: function(st){
                TranslatorIM.SLG_WPT_DETECT_4_GB_CALLS();
		setTimeout(function() {
		    var SLIDL = setInterval(function(){
			if(TranslatorIM.SLG_WPT_TRG_LNG) {
		                var url = window.location; 	  		  
				if(st==0) FExtension.browserInject.runtimeSendMessage({greeting: "wpt1:>"+url+"*"+TranslatorIM.SLG_WPT_TRG_LNG}, function(response) {}); 
				else FExtension.browserInject.runtimeSendMessage({greeting: "wpt2:>"+url+"*"+TranslatorIM.SLG_WPT_TRG_LNG}, function(response) {}); 
				TranslatorIM.SLG_WPT_TRG_LNG="";
				clearInterval(SLIDL);
			}
 	            },5); 
		}, 500);	
	},




	SLG_WEB_PAGE_TRANSLATION: function(st, act){       
		TranslatorIM.SLG_getDATA();
		setTimeout(function() {
			TranslatorIM.SLG_LoadGoogleTranslateWidget(TranslatorIM.SLG_WPTsrclang,TranslatorIM.SLG_wptGlobLang,st,act);
		}, 500);
	},


	SLG_BUBBLE_FROM_CM: function(e){
	      	var doc = FExtension.browserInject.getDocument();
		TranslatorIM.SLG_BBL_OBJ_OFF(0);
		TranslatorIM.SLG_OBJ_BUILDER();
		TranslatorIM.getSelectionCoords(e);
		TranslatorIM.SLG_ShowBalloon();
	},


        SLG_runinlinerNOW: function(info, tab){
		runinliner();
	},



	MS: function(f,t,text,id){
        if(f=="auto" && TranslatorIM.SLG_DETECT != "") f=TranslatorIM.SLG_DETECT;
	TranslatorIM.SLG_OTHER_PROVIDERS(text,id);
	},

	CUSTOM_LANGS: function(list){
		var OUT = "";
	        //list = list.replace(/&#160;/ig," ");
        	var list2 = TranslatorIM.SLG_LNG_CUSTOM_LIST;

		if(list2=="all") OUT = list;
		else{
		    var L1 = list.split(",");
		    for(var i=0; i<L1.length; i++){
	     		var L1base = L1[i].split(":");
		     	var L1short = list2.split(",");
			for(var j=0; j<L1short.length; j++){
			   if(L1base[0] == L1short[j]) OUT=OUT+L1short[j]+":"+L1base[1]+",";
			}
		    }
 		    OUT = OUT.substring(0,OUT.length-1);		    
		}

		var GLOBAL_LANG_LIST=LISTofPRpairsDefault.split(",");

		var tmp = OUT.split(",");
		OUT="";
		for(var i=0; i<tmp.length; i++){
	     		var L1 = tmp[i].split(":");
			for(var X=0; X<GLOBAL_LANG_LIST.length; X++){
				if(L1[0]==GLOBAL_LANG_LIST[X]) OUT=OUT+L1[0]+":"+L1[1]+",";
	        	}	
		}
 		OUT = OUT.substring(0,OUT.length-1);		    
		return OUT;
	},

	CleanUpAll: function(e){
	     try{
		var OBJ_ID = e.target.id;
		if(OBJ_ID.indexOf('SLG_')==-1){
		    try{
		        var doc = FExtension.browserInject.getDocument();
		        for(var I = 0; I < doc.getElementsByTagName("iframe").length; I++){
                	    var ID = doc.getElementsByTagName("iframe")[I].id;
	                    if(ID!=""){
				if(doc.getElementById(ID).contentWindow.document.getElementById('SLG_balloon_obj')) {
					doc.getElementById(ID).contentWindow.document.getElementById('SLG_balloon_obj').remove();
					//window.frames[ID].document.getElementById('SLG_balloon_obj').remove();
				}
			    }
			}
		    } catch(e){}
		}
	     } catch(e){}
	},

	TSgetSelectionCoords: function() {
 	    var doc = FExtension.browserInject.getDocument();
	    var sel = doc.selection, range, rect;
	    var x = 0, y = 0;
	    if (sel) {
	        if (sel.type != "Control") {
        	    range = sel.createRange();
	            range.collapse(true);
        	    x = range.boundingLeft;
	            y = range.boundingTop;
        	}
	    } else if (window.getSelection) {
        	sel = window.getSelection();
	        if (sel.rangeCount) {
        	    range = sel.getRangeAt(0).cloneRange();
		    if (range.getClientRects) {
	                range.collapse(true);
        	        if (range.getClientRects().length>0){
                	    rect = range.getClientRects()[0];
	                    x = rect.left;
        	            y = rect.top;
                	}
	            }
        	    // Fall back to inserting a temporary element
	            if (x == 0 && y == 0) {
        	        var span = doc.createElement("span");
                	if (span.getClientRects) {
	                    // Ensure span has dimensions and position by
        	            // adding a zero-width space character
                	    span.appendChild( doc.createTextNode("\u200b") );
	                    range.insertNode(span);
        	            rect = span.getClientRects()[0];
                	    x = rect.left;
	                    y = rect.top;
        	            var spanParent = span.parentNode;
                	    spanParent.removeChild(span);

	                    // Glue any broken text nodes back together
        	            spanParent.normalize();
                	}
	            }
        	}
	    }
	    return { x: x, y: y };
	},


    SLG_LoadGoogleTranslateWidget: function (sourceLang, targetLang, trauto, act) {      

      var doc = FExtension.browserInject.getDocument();
      TranslatorIM.SLG_getLNG_TMP("SLG_G_WPT_TO");
      TranslatorIM.SLG_WPT_DETECT(0);

/*
//OLD
      if(TranslatorIM.SLG_wptGlobLangTmp!="" && TranslatorIM.SLG_wptGlobLangTmp!=targetLang){
		targetLang=TranslatorIM.SLG_wptGlobLangTmp;
      }
*/
//NEW
      if(TranslatorIM.SLG_wptGlobLangTmp!=""){
		targetLang=TranslatorIM.SLG_wptGlobLangTmp;
      }







      if(targetLang != TranslatorIM.SLG_WPT_TEMP_LANG && TranslatorIM.SLG_WPT_TEMP_LANG!="") targetLang=TranslatorIM.SLG_WPT_TEMP_LANG;



      TranslatorIM.SLG_RemoveExistingGoogleTranslateWidget();

	      if(act=="reset"){			
			TranslatorIM.SLG_WPT_TEMP_LANG="";
			TranslatorIM.SLG_DATA_LOADING_CASCADE();
			//TranslatorIM.SLG_setLNG_TMP("SLG_G_WPT_TO",TranslatorIM.SLG_wptGlobLang);
			TranslatorIM.SLG_setSHOW_HIDE_TB_TMP("SLG_GWPT_Show_Hide_tmp",TranslatorIM.SLG_WPT_TB_DEFAULT);
			TranslatorIM.SLG_set_AUTO_TMP("SLG_AUTO_TMP",1);
	      }


	      if(act=="reopen"){
			TranslatorIM.SLG_GWPT_Show_Hide_tmp=1;
		      	TranslatorIM.SLG_setSHOW_HIDE_TB_TMP("SLG_GWPT_Show_Hide_tmp",1);
	      }

	      if(act==undefined){
			TranslatorIM.SLG_GWPT_Show_Hide_tmp=0;	
	      }



	      if(act=="hide"){		
			TranslatorIM.SLG_GWPT_Show_Hide_tmp=0;
		      	TranslatorIM.SLG_setSHOW_HIDE_TB_TMP("SLG_GWPT_Show_Hide_tmp",0);
	      }

	      if(act=="continue"){		
		      TranslatorIM.SLG_getSHOW_HIDE_TB_TMP("SLG_GWPT_Show_Hide_tmp");
	      }

	      if(TranslatorIM.SLG_wptGlobAutoTmp == 0){
		      if(TranslatorIM.SLG_WPT_TEMP_LANG=="" || TranslatorIM.SLG_WPT_TEMP_LANG=="null" || TranslatorIM.SLG_WPT_TEMP_LANG==undefined){
			  TranslatorIM.SLG_setLNG_TMP("SLG_G_WPT_TO",TranslatorIM.SLG_wptGlobLang);
		      }	else{
        	          if(targetLang!=TranslatorIM.SLG_WPT_TEMP_LANG) targetLang=TranslatorIM.SLG_WPT_TEMP_LANG;
		      }
	      }	
/*
	      if(act=="reset"){
		TranslatorIM.SLG_setLNG_TMP("SLG_G_WPT_TO",targetLang);
	      }
*/
	      TranslatorIM.SLG_WPT_LANG = targetLang;

	      var head = document.querySelector('HEAD');
	      var body = document.querySelector('BODY');
	      var trautoStr = trauto === '1' ? "true" : "false";

	      //By VK
	      trautoStr="true";
	      if(TranslatorIM.SLG_WPT_IGRORE==1) trautoStr="false";
	      var uid = Math.floor(Math.random() * 1e16)

/*
	      if(TranslatorIM.SLG_wptGlobAutoTmp!=1){
		      TranslatorIM.SLG_LNG_LIST = TranslatorIM.CUSTOM_LANGS(FExtension.element(TranslatorIM.SLG_LOC,'extLanguages'));
		      var MENU = TranslatorIM.SLG_LNG_LIST.split(",");
		      if(MENU.length>=TranslatorIM.SLG_FAV_START){
			if(TranslatorIM.SLG_FAV_LANGS_WPT!=""){
				var favArr=TranslatorIM.SLG_FAV_LANGS_WPT.split(","); 
				targetLang=favArr[0];
			}
		      }	
	      }
*/

	      setTimeout(function() {


			/////////VK FLIP
		      	TranslatorIM.SLG_getWPT_DET_LNG("SLG_WPT_DET_LNG");
		      	if(TranslatorIM.WPTflip=="1" && TranslatorIM.SLG_WPTsrclang!="auto"){
			      if(TranslatorIM.SLG_WPT_TRG_LNG == targetLang && TranslatorIM.SLG_WPT_FLAG==0){
			            	if(targetLang != TranslatorIM.SLG_WPTsrclang){
			        	 	var tt = TranslatorIM.SLG_WPTdstlang;
						targetLang = TranslatorIM.SLG_WPTsrclang;
						sourceLang = tt;
					} else {
				 		targetLang = TranslatorIM.SLG_WPTdstlang;
					}
			      }
		      	}
			//////;
			var SRC_ = sourceLang;
			if(SRC_=="srsl") SRC_ = "sr";
			if(SRC_=="tlsl") SRC_ = "tl";

			var TRG_ = targetLang;
			if(TRG_=="srsl") TRG_ = "sr";
			if(TRG_=="tlsl") TRG_ = "tl";
	      		TranslatorIM.SLG_SAVE_FAVORITE_LANGUAGES(targetLang, '', 1, TranslatorIM.SLG_FAV_LANGS_WPT, "WPT");
	      		TranslatorIM.SLG_GET_WPT_DATA();
		      	var SLG_JS_OB;
	      		SLG_JS_OB = document.createElement('script');
	      		SLG_JS_OB.type = "text/javascript";
	      		SLG_JS_OB.className = "skiptranslate"; 
	      		SLG_JS_OB.textContent =
	        		["function googleTrButton" + uid + "() {",
	        	 		'  var el = new google.translate.TranslateElement({',
				//      '    pageLanguage: "' + SRC_ + '", ',
		         		'    includedLanguages: "' + TRG_ + '", ',
	         			'    layout: google.translate.TranslateElement.InlineLayout.HORIZONTAL,',
	        	 		'    autoDisplay: false,',
		         		'    multilanguagePage: true,',
		         		'    floatPosition: 0',
	         			'  });',
	        	 		'  el.onTurnOffLanguageClick = function() {',
		         		'    var event = document.createEvent("Event");',
		         		'    event.initEvent("te_disable_lang", true, true);',
	         			'    document.body.dispatchEvent(event);',
	        	 		'  };',
		         		'  el.showBanner(' + trautoStr + ');',
		         		'}'
	        		].join('\n');


		      FExtension.browserInject.runtimeSendMessage({greeting: "WPT_CURL:>"+targetLang}, function(response) {}); 

		      body.appendChild(SLG_JS_OB);
		      if(window.location.host.indexOf("ebay.")!=-1) body.style.overflow="visible";

		      document.body.addEventListener('te_disable_lang', function(e) {
        		opera.extension.postMessage({
	        	  action: 'disableLang',
	        	  data: {
		            lang: targetLang
        		  }
		        });
		      }, false);

		      var translateElementScript = document.createElement('script');
		      translateElementScript.type = "text/javascript"
	              var theRegion ="com";
		      if(TranslatorIM.SLG_DOM!="auto") theRegion=TranslatorIM.SLG_DOM;
		      translateElementScript.src = '//translate.google.'+theRegion+'/translate_a/element.js?cb=googleTrButton' + uid + '&hl=' + TranslatorIM.SLG_LOC;


		      body.appendChild(translateElementScript);

		      TranslatorIM.SLG_getLNG_TMP("SLG_G_WPT_TO");
		      TranslatorIM.SLWPT = setInterval(function(){

			if(top.window.frames[":0.container"]){
				if(top.window.frames[":0.container"].contentWindow.document.getElementById(':0.close')) {				
					clearInterval(TranslatorIM.SLWPT);
			      		var obs = document.getElementsByTagName('div');
				 	for (var i=0; i<obs.length; i++){
		        		  if(obs[i].className == "skiptranslate") obs[i].style.display="block"; 
					}
        				TranslatorIM.SLG_Bar_Cover(targetLang,trauto);
				}
			}
		   	if(TranslatorIM.SLG_get_TIP_TRIGGER("SLG_wptGlobTipTmp") != 1){
				if(doc.getElementById("SLG_fix"))head.removeChild(doc.getElementById("SLG_fix"));
				var style_tip = document.createElement('style');
				style_tip.setAttribute('type', 'text/css');
				style_tip.setAttribute('id', 'SLG_fix');
				style_tip.appendChild(document.createTextNode('.goog-tooltip, .goog-tooltip:hover{ display: none !important; }'));
				style_tip.appendChild(document.createTextNode('.goog-text-highlight { background-color: transparent !important; border: none !important; box-shadow: none !important; }'));
				head.appendChild(style_tip);
				if(doc.getElementById("goog-gt-tt")) doc.getElementById("goog-gt-tt").style.marginLeft="-5000px";
			}else{
				if(doc.getElementById("SLG_fix"))head.removeChild(doc.getElementById("SLG_fix"));
				var style_tip = document.createElement('style');
				style_tip.setAttribute('type', 'text/css');
				style_tip.setAttribute('id', 'SLG_fix');
				style_tip.appendChild(document.createTextNode('.goog-tooltip, .goog-tooltip:hover{ display: block !important; }'));
				style_tip.appendChild(document.createTextNode('.goog-text-highlight { background-color: transparent !important; border: none !important; box-shadow: none !important; }'));
				head.appendChild(style_tip);
				if(doc.getElementById("goog-gt-tt")) doc.getElementById("goog-gt-tt").style.marginLeft="0px";
			}

		        FExtension.browserInject.runtimeSendMessage({greeting: "wptCM:>"+TranslatorIM.SLG_WPT_TEMP_LANG}, function(response) {}); 
			TranslatorIM.SLG_SAVE_TO_TH(sourceLang,targetLang);
			TranslatorIM.ACTIVATE_THEMEwpt(TranslatorIM.THEMEmode);

			if(doc.getElementById("SLG_TBpatchid")) doc.getElementById("SLG_TBpatchid").style.display="none";

	          },1000);                
		}, 500);
	//Allways DETECT on WPT run
        TranslatorIM.SLG_WPT_DETECT_4_GB_CALLS();
    },


    SLG_SAVE_TO_TH: function(sourceLang, targetLang){
	var SLnow = new Date();
	SLnow=SLnow.toString();
	var TMPtime=SLnow.split(" ");
	var CurDT=TMPtime[1]+" "+TMPtime[2]+" "+TMPtime[3]+", "+TMPtime[4];      		
	var URL_host = document.location;
	FExtension.browserInject.runtimeSendMessage({greeting:"[wp]"+ URL_host + "~~" + URL_host + "~~" + sourceLang + "|" + targetLang + "~~"+ URL_host+"~~"+CurDT+"~~4^^"}, function(response) { });
    },


    SLG_WPTmsg: function(text){
   	var doc = FExtension.browserInject.getDocument();
	var SLG_MSG = doc.createElement("button");
	var SLG_MSGid = doc.createAttribute("id");
	SLG_MSGid.value = "SLG_MSG";
        SLG_MSG.setAttributeNode(SLG_MSGid);
        SLG_MSG.appendChild(doc.createTextNode(text));
        doc.body.appendChild(SLG_MSG);
    },


    SLG_WPT_DETECT_4_GB_CALLS: function(st){
	      	var rootTranslateNode = TranslatorIM.getRootNode();
	      	var analysisText = TranslatorIM.getAnalysisText(rootTranslateNode);
		TranslatorIM.SLG_WPT_DODetection(analysisText);
    },

    SLG_WPT_DETECT: function(st){
	var AcumStatus = TranslatorIM.SLG_wptDp4*1 + TranslatorIM.SLG_wptLp2*1;	
	var LHistStatus = 0;
	if(TranslatorIM.SLG_wptLHist!="") LHistStatus = 1;
	if(st==2) {AcumStatus=1;LHistStatus=1;}
	if(st==0) {AcumStatus=0;LHistStatus=0;}
	if(AcumStatus>0 || LHistStatus == 1){
	      	var rootTranslateNode = TranslatorIM.getRootNode();
	      	var analysisText = TranslatorIM.getAnalysisText(rootTranslateNode);
		TranslatorIM.SLG_WPT_DODetection(analysisText);
	}else{
		TranslatorIM.SLG_DETLANG="skip";
		TranslatorIM.SLG_WPT_LANG="skip";
	}
    },

    SLG_Bar_Cover: function(targetLang,trauto){
   	var doc = FExtension.browserInject.getDocument();
	var r = doc.getElementsByClassName("goog-te-banner-frame");
	if(r[0]) r[0].style = "display:block !important";
	TranslatorIM.SLG_getSHOW_HIDE_TB_TMP("SLG_GWPT_Show_Hide_tmp");
        if(TranslatorIM.SLG_GWPT_Show_Hide_tmp==0) TranslatorIM.SLG_WPT_HIDDEN_MODE();
        TranslatorIM.SLG_GMENU_BAR_LOADER(targetLang, trauto);
    },

    SLG_RemoveExistingGoogleTranslateWidget: function() {
      var doc = FExtension.browserInject.getDocument();
      var ObFound = false;
      var theRegion = "com";
      if(TranslatorIM.SLG_DOM!="auto") theRegion=TranslatorIM.SLG_DOM;

      var TrScrs = document.querySelectorAll('script[src*="//translate.google.'+theRegion+'/"]');
      for (var i = 0; i < TrScrs.length; ++i) { ObFound = true; TrScrs[i].parentNode.removeChild(TrScrs[i]); }
      var TrObs = document.querySelectorAll('*[class~="skiptranslate"]');
      for (var i = 0; i < TrObs.length; ++i) { ObFound = true; TrObs[i].parentNode.removeChild(TrObs[i]); }
      if(ObFound) TranslatorIM.SLG_HideExistingGoogleTranslateWidget(0);
      TranslatorIM.SLG_CNT=0;
      if(doc.getElementById("SLG_TBpatchid")) doc.getElementById("SLG_TBpatchid").style.display="none";
    },

    SLG_HideExistingGoogleTranslateWidget: function(st) {
        var bodyEl = document.querySelector('BODY');
        if(st==0) var H = 40;
        else      var H = 0;	
        var PosOnTop = parseInt(bodyEl.style.top || 0, 10) - H;
       	bodyEl.style.top = (PosOnTop > 0 ? PosOnTop : 0) + "px";
    },

    SLG_WPT_HIDDEN_MODE: function(){
        var doc = FExtension.browserInject.getDocument();
	var obs = document.getElementsByTagName('div');
	var cnt = 0;
        for (var i=0; i<obs.length; i++){
	   if(obs[i].className=="skiptranslate") {
		cnt++;
		obs[i].style.display='none';
		doc.body.style.top='0px';
	   } 
	}
	if(cnt!=0){
		var M = doc.createElement("input");
		M.onclick = function(){
			TranslatorIM.SLG_setSHOW_HIDE_TB_TMP("SLG_GWPT_Show_Hide_tmp",1);
			TranslatorIM.SLG_SHOW_ORIGINAL();
			setTimeout(function() {
				TranslatorIM.SLG_LoadGoogleTranslateWidget(TranslatorIM.SLG_LOC,TranslatorIM.SLG_wptGlobLang,TranslatorIM.SLG_wptGlobAuto,"reopen");
			}, 100);

		};

		var trbtn = doc.getElementById('SLG_WPT_SHOW');
		if(trbtn)	trbtn.parentNode.removeChild(trbtn);

	        if(!doc.getElementById("SLG_WPT_SHOW")){
			var id = doc.createAttribute("id");
			id.value = "SLG_WPT_SHOW";
			M.setAttributeNode(id);
			var ty = doc.createAttribute("type");
			ty.value = "button";
			M.setAttributeNode(ty);
			var st = doc.createAttribute("style");
			st.value = "outline:none !important;z-index:9999999;border:0px;position:fixed;top:0px;right:0px;background:transparent url("+FExtension.browserInject.getURL('content/img/util/show.png')+"); width:30px; height:25px;cursor:pointer;";

			var ttl = doc.createAttribute("title");
			ttl.value = FExtension.element(TranslatorIM.SLG_LOC,"extwptTBshow");

			M.setAttributeNode(ttl);

			M.setAttributeNode(st);
	        	doc.body.appendChild(M);
		}
	}
    },

    SLG_GMENU_BAR_LOADER: function(cur, trauto){

	if(cur=="") cur=TranslatorIM.SLG_wptGlobLang;
   	var doc = FExtension.browserInject.getDocument();
	TranslatorIM.SLG_LNG_LIST = TranslatorIM.CUSTOM_LANGS(FExtension.element(TranslatorIM.SLG_LOC,'extLanguages'));

//	var MENU = FExtension.element(TranslatorIM.SLG_LOC,'extLanguages').split(",");
	var MENU = TranslatorIM.SLG_LNG_LIST.split(",");

	var SLG_TB = doc.createElement("div");
	var SLG_TBid = doc.createAttribute("id");
	SLG_TBid.value = "SLG_WPT_TB";
        SLG_TB.setAttributeNode(SLG_TBid);
	var SLG_TBc = doc.createAttribute("style");
	SLG_TBc.value = "background:#ffffff;z-index:9999999999;position:absolute;text-align:right;right:35px;margin-top: -28px;";
        SLG_TB.setAttributeNode(SLG_TBc);
	       	var OBtable = doc.createElement("table");
			SLG_TB.appendChild(OBtable);

		        var OBtr = doc.createElement("tr");
		        OBtable.appendChild(OBtr); 

			        var OBtd1 = doc.createElement("td");        

					var SLG_trto = doc.createElement("div");
					var SLG_trtoid = doc.createAttribute("id");
					SLG_trtoid.value = "SLG_trto";
					SLG_trto.setAttributeNode(SLG_trtoid);
					SLG_trto.appendChild(doc.createTextNode(FExtension.element(TranslatorIM.SLG_LOC,"extCMTransPageTo")));
				        OBtd1.appendChild(SLG_trto);

			        OBtr.appendChild(OBtd1);
			        var OBtd2 = doc.createElement("td");

	var M = doc.createElement("select");
	M.onchange = function(){
		TranslatorIM.SLG_set_LNG_TRIGGER("SLG_LNG_TRIGGER",1);
		TranslatorIM.SLG_WPT_IGRORE=0;
		cur= this.value;
	        TranslatorIM.SLG_SAVE_FAVORITE_LANGUAGES(cur, '', 1, TranslatorIM.SLG_FAV_LANGS_WPT, "WPT");
		TranslatorIM.SLG_G_RETRANSLATE(cur);
	};
	var id = doc.createAttribute("id");
	id.value = "SLG_G_M_to";
	M.setAttributeNode(id);
	var st = doc.createAttribute("style");
	st.value = "width:115px;margin-left:5px;margin-top:-0px;";

	M.setAttributeNode(st);
        var thelang = cur;
        var cnt=0;
	for(var J=0; J < MENU.length; J++){
	    var CURlang3 = MENU[J].split(":");
	    if(CURlang3[0] == thelang) cnt++;
	}

        if(cnt==0 && TranslatorIM.SLG_WPT_TEMP_LANG!="") {
		thelang = TranslatorIM.SLG_WPT_TEMP_LANG;
		TranslatorIM.SLG_WPT_TEMP_LANG="";
	}//else thelang = TranslatorIM.SLG_wptGlobLang;
     	var SEL = 0
	if(MENU.length>=TranslatorIM.SLG_FAV_START){
		var SLG_FAV_LANGS_LONG = TranslatorIM.SLG_ADD_LONG_NAMES(TranslatorIM.SLG_FAV_LANGS_WPT);
       		if(SLG_FAV_LANGS_LONG!=""){
			var favArr=SLG_FAV_LANGS_LONG.split(","); 
			for(var J=0; J < favArr.length; J++){
			    var CURlang3 = favArr[J].split(":");
			    var OB_FAV = doc.createElement('option');
			    var v = doc.createAttribute("value");
			    v.value = CURlang3[0];
       			    if(J == 0){
				    var sel = doc.createAttribute("selected");
				    sel.value = "selected";
				    OB_FAV.setAttributeNode(sel);
				    SEL = 1;
				    TranslatorIM.SLG_wptGlobLang=CURlang3[0];
			    }
       			    OB_FAV.setAttributeNode(v);
			    OB_FAV.appendChild(doc.createTextNode(CURlang3[1]));
			    M.appendChild(OB_FAV);
			}
			OB_FAV = doc.createElement('option');
			var d = doc.createAttribute("disabled");
			d.value = true;
			OB_FAV.setAttributeNode(d);
			var all = FExtension.element(TranslatorIM.SLG_LOC,"extwptDAll");
		    	OB_FAV.appendChild(doc.createTextNode("-------- [ "+ all +" ] --------"));
                       	M.appendChild(OB_FAV);
		}
	}
	for(J=0; J < MENU.length; J++){
	    CURlang3 = MENU[J].split(":");
	    option = doc.createElement('option');
	    if(SEL == 0){	
		    if(CURlang3[0] == thelang){
			    var sel = doc.createAttribute("selected");
			    sel.value = "selected";
			    option.setAttributeNode(sel);
		    }
	   }
	   v = doc.createAttribute("value");
	   v.value = CURlang3[0];
	   option.setAttributeNode(v);
	   option.appendChild(doc.createTextNode(CURlang3[1]));
	   M.appendChild(option);
	}							                       

        OBtd2.appendChild(M);
	OBtr.appendChild(OBtd2);
        var OBtd3 = doc.createElement("td");					
	var SLG_TBoptions = doc.createElement("div");
	var SLG_TBoptionsid = doc.createAttribute("id");
	SLG_TBoptionsid.value = "SLG_TBoptions";
        SLG_TBoptions.setAttributeNode(SLG_TBoptionsid);
	var SLG_TBoptionsst = doc.createAttribute("style");
	SLG_TBoptionsst.value = "padding:7px;height:14px;background:#1186BB;text-align:center;color:#ffffff;margin-top:-0px;cursor:pointer;";
        SLG_TBoptions.setAttributeNode(SLG_TBoptionsst);
        SLG_TBoptions.appendChild(doc.createTextNode(FExtension.element(TranslatorIM.SLG_LOC,"extOptions")));
        OBtd3.appendChild(SLG_TBoptions);
        OBtr.appendChild(OBtd3);

        var OBtd4 = doc.createElement("td");					
	var SLG_Hide = doc.createElement("div");
	var SLG_Hideid = doc.createAttribute("id");
	SLG_Hideid.value = "SLG_Hide";
        SLG_Hide.setAttributeNode(SLG_Hideid);
	var SLG_Hidest = doc.createAttribute("style");
	SLG_Hidest.value = "margin-top:-3px;margin-left:10px;border:0px;background-image:url("+FExtension.browserInject.getURL('content/img/util/hide.png')+"); width:15px; height:15px;cursor:pointer;";;
        SLG_Hide.setAttributeNode(SLG_Hidest);

	var ttl = doc.createAttribute("title");
	ttl.value = FExtension.element(TranslatorIM.SLG_LOC,"extwptTBhide");

	SLG_Hide.setAttributeNode(ttl);

        OBtd4.appendChild(SLG_Hide);
        OBtr.appendChild(OBtd4);
        SLG_TB.appendChild(OBtable);

	if(SLG_TB){ 
	   try{
	      var win = top.window.frames[":0.container"].contentWindow;
	      var obs = win.document.getElementsByTagName('div');
        	for (var i=0; i<obs.length; i++){
	           if(obs[i].className=="goog-te-button" && i==8) {
			obs[i].style.display='none';
		   } else obs[i].style='padding-top:2px;border:0px;height:24px;background:#1186BB;z-index:1000;position:relative;border:0px;color:#ffffff;';
	        }
	        var style='border:0px;background:#1186BB;color:#ffffff;';
	        win.document.getElementById(':0.restore').style=style;
	        win.document.getElementById(':0.confirm').style=style;
	        win.document.getElementById(':0.cancel').style=style;
	        win.document.getElementById(':0.noAutoPopup').style=style;
	        win.document.body.style.background="#ffffff";

	      var obs = win.document.getElementsByTagName('a');
        	for (var i=0; i<obs.length; i++){
	           if(obs[i].className=="goog-te-menu-value") {
			obs[i].style='color:#4787ed';
		   }
	        }


	      var obs =	win.document.getElementById('options');
	      obs.appendChild(SLG_TB);
              TranslatorIM.SLG_WPT_ERROR=0;
	      win.document.getElementById('SLG_TBoptions').addEventListener('mousedown', TranslatorIM.SLG_WPT_OPTIONS_MENU,!0);
	      win.document.getElementById('SLG_Hide').addEventListener('mousedown', TranslatorIM.SLG_BAR_CLOSE,!0);
	      win.document.getElementById(':0.close').addEventListener('mousedown', TranslatorIM.SLG_BAR_STOP,!1);
	      win.document.getElementById(':0.close').title=FExtension.element(TranslatorIM.SLG_LOC,"extClearTr");
	      win.document.getElementById(':0.restore').addEventListener('mousedown', TranslatorIM.SLG_WPT_OPTIONS_CLOSE,!1);
	      win.document.getElementById(':0.confirm').addEventListener('mousedown', TranslatorIM.SLG_WPT_OPTIONS_CLOSE,!1);
	      win.document.getElementById(':0.cancel').addEventListener('mousedown', TranslatorIM.SLG_WPT_OPTIONS_CLOSE,!1);
	      win.document.getElementById(':0.noAutoPopup').addEventListener('mousedown', TranslatorIM.SLG_WPT_OPTIONS_CLOSE,!1);
	      win.document.getElementById(':0.noAutoPopup').style.display='none';  

	      TranslatorIM.DETERMIN_IF_LANGUAGE_IS_AVAILABLE(thelang);

	   } catch (e){}
	}            
	
    },

    DETERMIN_IF_LANGUAGE_IS_AVAILABLE: function(lng){
	try{
		var lngarr = LISTofLANGsets[0].split(",");
		var cnt = 0;
		if(lngarr.length>1 && lng!=""){
			for(var i=1; i<lngarr.length; i++){
				if(lngarr[i]==lng) cnt++;
			}
		} else cnt=1;
      		if(cnt==0){
			var LONG_NAME="";
			var MENU = TranslatorIM.SLG_LNG_LIST.split(",");
			for(var J=0; J < MENU.length; J++){
			    var CURlang = MENU[J].split(":");		    
			    if(CURlang[0] == lng) LONG_NAME = CURlang[1];
			}

			TranslatorIM.InitiateWPT_target_lang(LONG_NAME);
        	        TranslatorIM.SLG_WPT_ERROR=1;
	        }
	} catch(ex){}
    },

    DETERMIN_IF_LANGUAGE_IS_AVAILABLE_BBL: function(){
	try{
		var doc = FExtension.browserInject.getDocument();
		var T = doc.getElementById('SLG_lng_to').value;
		var F = doc.getElementById('SLG_lng_from').value;
		var lngarr = LISTofLANGsets[0].split(",");
		var cnt = 0;
		var cnt1 = 0;
		var cnt2 = 0;
		if(lngarr.length>1 && T!=""){
			for(var i=1; i<lngarr.length; i++){
				if(lngarr[i]==T) cnt1++;
				if(lngarr[i]==F) cnt2++;
			}
		}
		if(cnt1>0 && cnt2>0) cnt=1;
		return(cnt);
	} catch(ex){}
    },

    SLG_BAR_STOP: function(){
	var doc = FExtension.browserInject.getDocument();
	TranslatorIM.SLG_setSHOW_HIDE_TB_TMP("SLG_GWPT_Show_Hide_tmp",2);
	TranslatorIM.SLG_SHOW_ORIGINAL();
	TranslatorIM.SLG_WPT_OPTIONS_CLOSE(0);
	if(TranslatorIM.SLG_WPT_ERROR==1){
		setTimeout(function() {
		      doc.getElementById(":0.container").style.display="none";
		      doc.getElementById("SLG_WPT_SHOW").style.display="none";
		}, 100);
	}
	if(doc.getElementById("SLG_TBpatchid")) doc.getElementById("SLG_TBpatchid").style.display="none";	
    },

    SLG_BAR_CLOSE: function(){
	var doc = FExtension.browserInject.getDocument();
	TranslatorIM.SLG_setSHOW_HIDE_TB_TMP("SLG_GWPT_Show_Hide_tmp",0);
	TranslatorIM.SLG_SHOW_ORIGINAL();
	TranslatorIM.SLG_WPT_OPTIONS_CLOSE(0);
	setTimeout(function() {
		TranslatorIM.SLG_LoadGoogleTranslateWidget(TranslatorIM.SLG_LOC,TranslatorIM.SLG_wptGlobLang,TranslatorIM.SLG_wptGlobAuto,"hide");
	}, 100);
	if(doc.getElementById("SLG_TBpatchid")) doc.getElementById("SLG_TBpatchid").style.display="none";
	//TranslatorIM.SLG_G_RETRANSLATE(TranslatorIM.SLG_WPT_LANG);
    },

    SLG_WPT_OPTIONS_CLOSE: function(st){
 	var doc = FExtension.browserInject.getDocument();
 	if(doc.getElementById("SLG_OPT_MENUid")) doc.getElementById("SLG_OPT_MENUid").style.display='none';
 	if(doc.getElementById("SLG_TBpatchid")) doc.getElementById("SLG_TBpatchid").style.display='none';
	if(doc.getElementById("SLG_WPT_SHOW") && st==0) doc.getElementById("SLG_WPT_SHOW").style.display='none';	
    },




    SLG_WPT_OPTIONS_MENU: function(st){
        //TranslatorIM.SLG_SHOW_ORIGINAL();
        if(st!=2) st=1;

	TranslatorIM.SLG_GWHOST = TranslatorIM.SLG_GetHost();
	TranslatorIM.SLG_WPT_OPTIONS_CLOSE();
 	var doc = FExtension.browserInject.getDocument();
	var obs = doc.getElementsByTagName('div');
	for (var i=0; i<obs.length; i++){
		if(obs[i].id == "SLG_OPT_MENUcontainerid"){
			var list=document.getElementById("SLG_OPT_MENUcontainerid");
			list.parentNode.removeChild(list);
		}
        }


/*
 	if(doc.getElementById("goog-gt-tt")){
		doc.getElementById("goog-gt-tt").innerHTML="";
		doc.getElementById("goog-gt-tt").style.marginLeft="-1000px";
	}
*/
 	if(doc.getElementById("goog-gt-")){
		doc.getElementById("goog-gt-").innerHTML="";
		doc.getElementById("goog-gt-").style.marginLeft="-5000px";
	}


	var SLG_OPT_MENU = doc.createElement("div");
	var SLG_OPT_MENUid = doc.createAttribute("id");
	SLG_OPT_MENUid.value = "SLG_OPT_MENUid";
        SLG_OPT_MENU.setAttributeNode(SLG_OPT_MENUid);
	var SLG_OPT_MENUclass = doc.createAttribute("class");
	SLG_OPT_MENUclass.value = "SLG_OPT_MENU";
        SLG_OPT_MENU.setAttributeNode(SLG_OPT_MENUclass);

	 var SLG_WPT_TABS = doc.createElement("div");
	 var id = doc.createAttribute("id");
	 id.value = "SLG_WPT_TABS";
	 SLG_WPT_TABS.setAttributeNode(id);

		var SLG_WPT_TAB1div = doc.createElement("div");
		var id = doc.createAttribute("id");
		id.value = "SLG_WPT_TAB1divid";
		SLG_WPT_TAB1div.setAttributeNode(id);

		var SLG_WPT_TAB1 = doc.createElement("input");
		var ty = doc.createAttribute("type");
		ty.value = "button";
		SLG_WPT_TAB1.setAttributeNode(ty);
		var v = doc.createAttribute("value");
		v.value = FExtension.element(TranslatorIM.SLG_LOC,"extwptDName");
		SLG_WPT_TAB1.setAttributeNode(v);
		var SLG_WPT_TAB1id = doc.createAttribute("id");
		SLG_WPT_TAB1id.value = "SLG_WPT_TAB1";
	        SLG_WPT_TAB1.setAttributeNode(SLG_WPT_TAB1id);

		var SLG_WPT_TAB1cl = doc.createAttribute("class");
		SLG_WPT_TAB1cl.value = "SLG_WPT_TAB1";
	        SLG_WPT_TAB1.setAttributeNode(SLG_WPT_TAB1cl);

		var SLG_WPT_TAB1st = doc.createAttribute("style");
		SLG_WPT_TAB1st.value = "margin-left:0px;";
	        SLG_WPT_TAB1.setAttributeNode(SLG_WPT_TAB1st);
       	  SLG_WPT_TAB1div.appendChild(SLG_WPT_TAB1);

	  SLG_WPT_TAB1div.onclick = function(){
		TranslatorIM.SLG_WPT_OPTIONS_MENU(1);
	  };

       	 SLG_WPT_TABS.appendChild(SLG_WPT_TAB1div);

		var SLG_WPT_TAB2div = doc.createElement("div");
		var id = doc.createAttribute("id");
		id.value = "SLG_WPT_TAB2divid";
		SLG_WPT_TAB2div.setAttributeNode(id);

		var SLG_WPT_TAB2 = doc.createElement("input");
		var ty = doc.createAttribute("type");
		ty.value = "button";
		SLG_WPT_TAB2.setAttributeNode(ty);
		var v = doc.createAttribute("value");
		v.value = FExtension.element(TranslatorIM.SLG_LOC,"extwptLanguage");
		SLG_WPT_TAB2.setAttributeNode(v);
		var SLG_WPT_TAB2id = doc.createAttribute("id");
		SLG_WPT_TAB2id.value = "SLG_WPT_TAB2";
	        SLG_WPT_TAB2.setAttributeNode(SLG_WPT_TAB2id);

		var SLG_WPT_TAB2cl = doc.createAttribute("class");
		SLG_WPT_TAB2cl.value = "SLG_WPT_TAB2";
	        SLG_WPT_TAB2.setAttributeNode(SLG_WPT_TAB2cl);

		var SLG_WPT_TAB2st = doc.createAttribute("style");
		SLG_WPT_TAB2st.value = "margin-left:0px;";
	        SLG_WPT_TAB2.setAttributeNode(SLG_WPT_TAB2st);
       	  SLG_WPT_TAB2div.appendChild(SLG_WPT_TAB2);
	  SLG_WPT_TAB2div.onclick = function(){
		TranslatorIM.SLG_WPT_OPTIONS_MENU(2);
	  };
         SLG_WPT_TABS.appendChild(SLG_WPT_TAB2div);
             //IMAGE for options
		var SLG_WPT_TAB3div = doc.createElement("div");
		SLG_WPT_TAB3div.onclick = function(){
		    TranslatorIM.OPEN_BG_OPTIONS("wpt");
		};
		var id = doc.createAttribute("id");
		id.value = "SLG_WPT_TAB3divid";
		SLG_WPT_TAB3div.setAttributeNode(id);

		var ti = doc.createAttribute("title");
		ti.value = FExtension.element(TranslatorIM.SLG_LOC,'extOptions');
		SLG_WPT_TAB3div.setAttributeNode(ti);

		var SLG_WPT_TAB3st = doc.createAttribute("style");
		SLG_WPT_TAB3st.value = "background-image:url("+FExtension.browserInject.getURL('content/img/util/settings.png')+"); width:21px; height:21px;opacity:0.6; margin-left:229px;margin-top:5px;cursor:pointer;position:absolute;";
	        SLG_WPT_TAB3div.setAttributeNode(SLG_WPT_TAB3st);

         SLG_WPT_TABS.appendChild(SLG_WPT_TAB3div);

             //IMAGE for help
		var SLG_WPT_TAB4div = doc.createElement("div");
		SLG_WPT_TAB4div.onclick = function(){
		    TranslatorIM.OPEN_BG_OPTIONS("hist");
		};
		var id = doc.createAttribute("id");
		id.value = "SLG_WPT_TAB4divid";
		SLG_WPT_TAB4div.setAttributeNode(id);

		var ti = doc.createAttribute("title");
		ti.value = FExtension.element(TranslatorIM.SLG_LOC,'extHistory');
		SLG_WPT_TAB4div.setAttributeNode(ti);

		var SLG_WPT_TAB4st = doc.createAttribute("style");
		SLG_WPT_TAB4st.value = "background-image:url("+FExtension.browserInject.getURL('content/img/util/history.png')+"); width:23px; height:21px;opacity:0.6; margin-left:256px;margin-top:5px;cursor:pointer;position:absolute;";
	        SLG_WPT_TAB4div.setAttributeNode(SLG_WPT_TAB4st);

         SLG_WPT_TABS.appendChild(SLG_WPT_TAB4div);

             //IMAGE for help
		var SLG_WPT_TAB5div = doc.createElement("div");
		SLG_WPT_TAB5div.onclick = function(){
		    window.open("https://about.imtranslator.net/tutorials/presentations/google-translate-for-opera/google-translate-webpage-translation/","ImTranslator:Help");
		};
		var id = doc.createAttribute("id");
		id.value = "SLG_WPT_TAB5divid";
		SLG_WPT_TAB5div.setAttributeNode(id);

		var ti = doc.createAttribute("title");
		ti.value = FExtension.element(TranslatorIM.SLG_LOC,'extHelp');
		SLG_WPT_TAB5div.setAttributeNode(ti);

		var SLG_WPT_TAB5st = doc.createAttribute("style");
		SLG_WPT_TAB5st.value = "background-image:url("+FExtension.browserInject.getURL('content/img/util/help.png')+"); width:21px; height:21px;opacity:0.6; margin-left:286px;margin-top:5px;cursor:pointer;position:absolute;";
	        SLG_WPT_TAB5div.setAttributeNode(SLG_WPT_TAB5st);

         SLG_WPT_TABS.appendChild(SLG_WPT_TAB5div);

             //IMAGE for donate
		var SLG_WPT_TAB6div = doc.createElement("div");
		SLG_WPT_TAB6div.onclick = function(){
		    window.open("https://imtranslator.net"+_CGI+"&a=0","ImTranslator: Buy a coffee");
		};
		var id = doc.createAttribute("id");
		id.value = "SLG_WPT_TAB6divid";
		SLG_WPT_TAB6div.setAttributeNode(id);

		var ti = doc.createAttribute("title");
		ti.value = FExtension.element(TranslatorIM.SLG_LOC,'extContribution_ttl');
		SLG_WPT_TAB6div.setAttributeNode(ti);

		var SLG_WPT_TAB6st = doc.createAttribute("style");
		SLG_WPT_TAB6st.value = "background-image:url("+FExtension.browserInject.getURL('content/img/util/donate.png')+"); width:30px; height:21px;opacity:0.6; margin-left:313px;margin-top:5px;cursor:pointer;position:absolute;";
	        SLG_WPT_TAB6div.setAttributeNode(SLG_WPT_TAB6st);

         SLG_WPT_TABS.appendChild(SLG_WPT_TAB6div);



       	SLG_OPT_MENU.appendChild(SLG_WPT_TABS);

	var SLG_OPT_MENUcontainer = doc.createElement("div");
	var SLG_OPT_MENUcontainerid = doc.createAttribute("id");
	SLG_OPT_MENUcontainerid.value = "SLG_OPT_MENUcontainerid";
        SLG_OPT_MENUcontainer.setAttributeNode(SLG_OPT_MENUcontainerid);

	var SLG_OPT_MENUcontainerdir = doc.createAttribute("dir");
	SLG_OPT_MENUcontainerdir.value = "ltr";
        SLG_OPT_MENUcontainer.setAttributeNode(SLG_OPT_MENUcontainerdir);


	if(st==1) TranslatorIM.SLG_WPT_CREATE_DOMAIN_TAB(SLG_OPT_MENU);
	else TranslatorIM.SLG_WPT_CREATE_LANGUAGE_TAB(SLG_OPT_MENU);

//DEBUG
//	var MENU = doc.createElement("div");
//	var MENUid = doc.createAttribute("id");
//	MENUid.value = "info";
//      MENU.setAttributeNode(MENUid);
//      SLG_OPT_MENU.appendChild(MENU);
//DEBUG
       	SLG_OPT_MENUcontainer.appendChild(SLG_OPT_MENU);

	var obs = doc.getElementsByTagName('div');
	      	for (var i=0; i<obs.length; i++){
		if(obs[i].className == "skiptranslate"){
			obs[i].appendChild(SLG_OPT_MENUcontainer);
		}
	}


       	if(!doc.getElementById("SLG_TBpatchid")){
		var SLG_TBpatch = doc.createElement("div");
		var SLG_TBpatchid = doc.createAttribute("id");
		SLG_TBpatchid.value = "SLG_TBpatchid";
		SLG_TBpatch.appendChild(doc.createTextNode(" "));
       		SLG_TBpatch.setAttributeNode(SLG_TBpatchid);
		doc.body.appendChild(SLG_TBpatch);
	}else doc.getElementById("SLG_TBpatchid").style.display='block';

        if(doc.getElementById('SLG_TBsave1')) doc.getElementById('SLG_TBsave1').addEventListener('mousedown', TranslatorIM.SLG_WPT_SAVE_D,!1);
        if(doc.getElementById('SLG_TBsave2')) doc.getElementById('SLG_TBsave2').addEventListener('mousedown', TranslatorIM.SLG_WPT_SAVE_L,!1);
        if(st==2){
       		doc.getElementById("SLG_WPT_TAB1divid").className="SLG_WPT_TAB1divid_b";
       		doc.getElementById("SLG_WPT_TAB2divid").className="SLG_WPT_TAB2divid_b";
	}
//DEBUG
//	doc.getElementById("info").innerHTML="DOMAINS: "+TranslatorIM.SLG_wptDHist +"<br>LANGS: " + TranslatorIM.SLG_wptLHist;
//DEBUG

//	if(doc.getElementById("goog-gt-tt")) doc.getElementById("goog-gt-tt").style.display="block";
	if(doc.getElementById("goog-gt-")) doc.getElementById("goog-gt-").style.marginLeft="0px";

	TranslatorIM.ACTIVATE_THEMEwpt_dom(TranslatorIM.THEMEmode);
    },

    SLG_SHOW_ORIGINAL: function(){
        if(top.window.frames[":0.container"]){
	      	var win = top.window.frames[":0.container"].contentWindow;
		if(win.document) win.document.getElementById(':0.restore').click();
	}
    },

    SLG_WPT_SAVE_D: function(){
        TranslatorIM.SLG_SHOW_ORIGINAL();
 	var doc = FExtension.browserInject.getDocument();
	doc.getElementById('SLG_WPT_SAVE_LOAD').style.display = "block";

	//DOM param 0
	var D0 = TranslatorIM.SLG_GWHOST;

	//DOM param 1
	var D1 = doc.getElementById('SLG_wptSDName');
	if(D1.checked==true) D1="1";
	else D1="0";

	//DOM param 2
	var D2 = doc.getElementById("SLG_wptTrTo").value;

	//DOM param 3
	var D3 = doc.getElementById('SLG_Dautobox');
	if(D3.checked==true) D3="1";
	else D3="0";

	//DOM param 4
	var D4 = doc.getElementById('SLG_Dtbbox');
	if(D4.checked==true) D4="1";
	else D4="0";

	//DOM param 5
	var D5 = doc.getElementById('SLG_Dtipbox');
	if(D5.checked==true) D5="1";
	else D5="0";

        if(D2=="None") D3=0; 

	var PARAMS = "{"+D0+","+D1+","+D2+","+D3+","+D4+","+D5+"}";
	
	if(D4==0){
		TranslatorIM.SLG_GWPT_Show_Hide_tmp=0;
		TranslatorIM.SLG_setSHOW_HIDE_TB_TMP("SLG_GWPT_Show_Hide_tmp",0);
	}


	FExtension.browserInject.runtimeSendMessage({greeting: "SAVE_D:>"+PARAMS}, function(response) {});
	doc.getElementById('SLG_WPT_SAVE_LOAD').style.display = "block";
	setTimeout(function() {
		doc.getElementById('SLG_WPT_SAVE_LOAD').style.display = "none";
		TranslatorIM.SLG_WPT_OPTIONS_CLOSE();
	        var win = top.window.frames[":0.container"].contentWindow;
//                TranslatorIM.SLG_G_RETRANSLATE(win.document.getElementById("SLG_G_M_to").value);
//VK
                if(D2!="" && D2!="None"){
			TranslatorIM.SLG_WPT_TEMP_LANG=win.document.getElementById("SLG_G_M_to").value;
			TranslatorIM.SLG_WPT_IGRORE=0;
			if(D2=="All"){
				TranslatorIM.SLG_G_RETRANSLATE(TranslatorIM.SLG_wptGlobLang);
			} else {
				TranslatorIM.SLG_setSHOW_HIDE_TB_TMP("SLG_GWPT_Show_Hide_tmp",D4);
				win.document.getElementById("SLG_G_M_to").value=D2;
       		                TranslatorIM.SLG_wptGlobLangTmp=D2;
				TranslatorIM.SLG_G_RETRANSLATE(D2);
			}
		} else {
			TranslatorIM.SLG_getDATA();
			TranslatorIM.SLG_setLNG_TMP("SLG_G_WPT_TO",TranslatorIM.SLG_WPTdstlang);
			TranslatorIM.SLG_BAR_STOP();
			TranslatorIM.SLG_RemoveExistingGoogleTranslateWidget();
		}

	}, 1000);
    },

    SLG_WPT_SAVE_L: function(){
        TranslatorIM.SLG_SHOW_ORIGINAL();

 	var doc = FExtension.browserInject.getDocument();
	doc.getElementById('SLG_WPT_SAVE_LOAD').style.display = "block";

	//LNG param 0
	var L0 = doc.getElementById("SLG_wptLang").value;

	//LNG param 1
	var L1 = doc.getElementById('SLG_Lautobox');
	if(L1.checked==true) L1="1";
	else L1="0";

	//LNG param 2
	var L2 = doc.getElementById('SLG_Ltbbox');
	if(L2.checked==true) L2="1";
	else L2="0";

	//LNG param 3
	var L3 = doc.getElementById('SLG_Ltipbox');
	if(L3.checked==true) L3="1";
	else L3="0";


	var PARAMS = "{"+L0+","+L1+","+L2+","+L3+"}";
	FExtension.browserInject.runtimeSendMessage({greeting: "SAVE_L:>"+PARAMS}, function(response) {});

	setTimeout(function() {
		doc.getElementById('SLG_WPT_SAVE_LOAD').style.display = "none";
		TranslatorIM.SLG_getDATA();
		TranslatorIM.SLG_setLNG_TMP("SLG_G_WPT_TO",TranslatorIM.SLG_WPTdstlang);
		TranslatorIM.SLG_BAR_STOP();

//		TranslatorIM.SLG_LoadGoogleTranslateWidget(TranslatorIM.SLG_LOC,TranslatorIM.SLG_wptGlobLang,TranslatorIM.SLG_wptGlobAuto,"continue");
		TranslatorIM.SLG_LoadGoogleTranslateWidget(TranslatorIM.SLG_LOC,TranslatorIM.SLG_WPT_TEMP_LANG,TranslatorIM.SLG_wptGlobAuto,"continue");
	}, 1000);
    },

    SLG_GET_WPT_DATA: function(){
    	FExtension.browserInject.extensionSendMessage({greeting: 1}, function(response) {
		if(response && response.farewell){
       			var theresponse = response.farewell.split("~");
			TranslatorIM.SLG_FAV_MAX=theresponse[79];
			TranslatorIM.SLG_FAV_LANGS_BBL=theresponse[80];
			TranslatorIM.SLG_FAV_LANGS_IT=theresponse[81];
			TranslatorIM.SLG_FAV_LANGS_WPT=theresponse[82];
			TranslatorIM.WPTflip=theresponse[83];
		}
       	});
    },

    SLG_G_RETRANSLATE: function(cur){
        TranslatorIM.SLG_SAVE_FAVORITE_LANGUAGES(cur, '', 1, TranslatorIM.SLG_FAV_LANGS_WPT, "WPT");
	TranslatorIM.SLG_WPT_TEMP_LANG = cur;
	TranslatorIM.SLG_GET_WPT_DATA();
	TranslatorIM.SLG_SHOW_ORIGINAL();
        TranslatorIM.SLG_getSHOW_HIDE_TB_TMP("SLG_GWPT_Show_Hide_tmp");
	setTimeout(function() {
		TranslatorIM.SLG_getDATA();
		TranslatorIM.SLG_WPT_OPTIONS_CLOSE();
        	var win = top.window.frames[":0.container"].contentWindow;
	 	var doc = FExtension.browserInject.getDocument();
 		var CUR_lang = cur;
		TranslatorIM.SLG_WPT_FLAG=1;
	 	if(cur != win.document.getElementById("SLG_G_M_to").value) CUR_lang = win.document.getElementById("SLG_G_M_to").value;
		TranslatorIM.SLG_setLNG_TMP("SLG_G_WPT_TO",TranslatorIM.SLG_WPT_TEMP_LANG);
	        TranslatorIM.SLG_LoadGoogleTranslateWidget(TranslatorIM.SLG_LOC,cur,TranslatorIM.SLG_wptGlobAuto,"continue");
		TranslatorIM.SLG_WPT_FLAG=0;
	}, 100);
    },

    SLG_getDATA: function(){
	  chrome.extension.sendMessage({greeting: "1"}, function(response) { TranslatorIM.SLG_DATA_LOADING_CASCADE(); });
    },




    getAnalysisText: function (target) {
      var iterator = TranslatorIM.getIterator(target), textnode, analysisText = "";
      while ((textnode = iterator.nextNode())) {
        if(textnode.data.length>20){
	        analysisText += textnode.data + ". ";
        	if (analysisText.length >= 4096) {
	          break;
        	}
	}
      }
      return analysisText;
    },

    getIterator: function(root) {
      var doc = FExtension.browserInject.getDocument();
      var NodeFilter = window.NodeFilter,
          Node = window.Node,
          target = root || doc.body;

      return doc.createNodeIterator(target, NodeFilter.SHOW_TEXT, {
        acceptNode: function(node) {
          if (/^\s*$/.test(node.textContent) || node.parentNode.nodeType !== Node.ELEMENT_NODE || node.isChunked) {
            return NodeFilter.FILTER_REJECT;
          }
          while ((node = node.parentNode) !== target) {
            var tag = node ? node.nodeName : 'SCRIPT';
            if (TranslatorIM.invalidElements[tag]) {
              return NodeFilter.FILTER_REJECT;
            }
          }

          return NodeFilter.FILTER_ACCEPT;
        }
      }, false);
    },

    getRootNode: function() {
   	var doc = FExtension.browserInject.getDocument();
      var host = window.location.host;
      switch (host) {
      case 'twitter.com':
        return doc.querySelector(".js-tweet-text");
        break;
      case 'github.com':
        return doc.querySelector(".announce");
        break;
      case 'bitbucket.org':
        return doc.querySelector("#wiki");
        break;
      }
      return null;
    },





    SLG_WPT_DODetection: function(myTransText) {

	  if(myTransText != "" && TranslatorIM.ONCE_DETECT == ""){
	     var resp = TranslatorIM.i18n_LanguageDetect(myTransText,1);
	     TranslatorIM.BBL_DETECT="";
	     TranslatorIM.SLG_setWPT_DET_LNG("SLG_WPT_DET_LNG",resp);
             TranslatorIM.SLG_WPT_LANG=resp;
	     TranslatorIM.SLG_DETLANG=resp;
             TranslatorIM.SLG_WPT_TRG_LNG=resp;
	     if(resp == ""){
		    var num = Math.floor((Math.random() * SLG_GEO.length)); 
		    var theRegion = SLG_GEO[num];
		    var cntr = myTransText.split(" ");
                    var newTXT = truncStrByWord(myTransText,100);

		    var baseUrl ="https://translate.google."+theRegion+"/translate_a/single";
		    var SLG_Params = "client=gtx&dt=t&dt=bd&dj=1&source=input&q="+encodeURIComponent(newTXT)+"&sl=auto&tl=en&hl=en";


			    FExtension.browserInject.runtimeSendMessage({greeting: "DET_GOOGLE:>"+baseUrl+","+SLG_Params}, function(response) {});

			    setTimeout(function(){
				    var SLIDL = setInterval(function(){
				           FExtension.browserInject.extensionSendMessage({greeting: 1}, function(response) {

				             if(response && response.farewell){
					        var theresponse = response.farewell.split("~");
						TranslatorIM.BBL_DETECT=theresponse[51];

						clearInterval(SLIDL);
						if(TranslatorIM.BBL_DETECT!="" && TranslatorIM.BBL_DETECT!="<#>") {
							var resp = TranslatorIM.BBL_DETECT;
							TranslatorIM.BBL_DETECT="";
							TranslatorIM.SLG_setWPT_DET_LNG("SLG_WPT_DET_LNG",resp);
        	                                        TranslatorIM.SLG_WPT_LANG=resp;
							TranslatorIM.SLG_DETLANG=resp;
                        	                        TranslatorIM.SLG_WPT_TRG_LNG=resp;
                                                        TranslatorIM.ONCE_DETECT = 1;
						        TranslatorIM.CNTR('2411',resp+"/"+resp, newTXT.length);

							TranslatorIM.SLG_SETINTERVAL_ST=1;
			        	    	}else TranslatorIM.SLG_WPT_Detector(myTransText);
					        TranslatorIM.ACTIVATE_THEMEwpt_lng(TranslatorIM.THEMEmode);
					     }
				           });
				    },50);  
 		            },500);  

	     }		
	  }	
	},


	SLG_WPT_Detector: function(myTransText) {
		  var doc = FExtension.browserInject.getDocument();
		  if(myTransText!=""){
		    var theLIMIT = 100;
		    var newTXT = truncStrByWord(myTransText,theLIMIT);
		    var SLDImTranslator_url = TranslatorIM.ImTranslator_theurl+"ld.asp?tr=bl&text="+encodeURIComponent(newTXT);
			var ajaxRequest;  
			try{
				ajaxRequest = new XMLHttpRequest();
			} catch (e){
				try{
					ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
				} catch (e) {
					try{
						ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
					} catch (e){
						TranslatorIM.SLG_alert(FExtension.element(TranslatorIM.SLG_LOC,"extError1"));
						return false;
					}
				}
			}
			ajaxRequest.onreadystatechange = function(){
				if(ajaxRequest.readyState == 4){
		                   var resp = ajaxRequest.responseText;
		                   if(resp!=""){     
					if(resp.indexOf('#|#')!=-1){
				 	  	var tmp=decodeURIComponent(resp);
						var tmp2 = tmp.split("#|#");
					  	resp=tmp2[0];

					        TranslatorIM.CNTRP('2411',resp+"/"+resp, newTXT.length);

						resp = resp.replace("zh","zh-CN")
						resp = resp.replace("zt","zh-TW")

						TranslatorIM.SLG_setWPT_DET_LNG("SLG_WPT_DET_LNG",resp);
                                                TranslatorIM.SLG_WPT_LANG=resp;
						TranslatorIM.SLG_DETLANG=resp;
                                                TranslatorIM.SLG_WPT_TRG_LNG=resp;
                                                TranslatorIM.ONCE_DETECT = 1;
					}
				    }
				}
			}
			ajaxRequest.open("POST", SLDImTranslator_url, true);
			ajaxRequest.send(null); 
		  }
	},



	SLG_GetLongName: function(code){
		var LANGSALL = FExtension.element(TranslatorIM.SLG_LOC,'extLanguages').split(",");
		var LANGS = TranslatorIM.SLG_LNG_LIST.split(",");


		for (var i = 0; i < LANGSALL.length; i++){
			var templang = LANGSALL[i].split(":");
			if(code == templang[0]){ 
				return (templang[1]);
			}
		}

	},

	SLG_GetHost: function(){
		var HOST = top.location.host;
		HOST = HOST.replace(/^www\./i,"");
		TranslatorIM.SLG_GWHOST = HOST;
		return HOST;
	},


	SLG_GetMAINHost: function(){
	        if(TranslatorIM.SLG_wptDp2!=1){
			var H = top.location.host.replace(/[a-z0-9][a-z0-9-]*\.[a-z]{2,6}$/i,"");
			var HOST = top.location.host.replace(H,"");
		}else HOST = top.location.host;
		HOST = HOST.replace(/^www\./i,"");
		if(TranslatorIM.SLG_DETECTsubDomain() == true){
			if(top.location.host.indexOf(".co.")!=-1 || top.location.host.indexOf(".com.")!=-1) HOST = top.location.host;
		}
		return HOST;
	},

	SLG_GetMAINHostName: function(){
		var H = top.location.host.replace(/[a-z0-9][a-z0-9-]*\.[a-z]{2,6}$/i,"");
		var HOST = top.location.host.replace(H,"");
		if(top.location.host.indexOf(".co.")!=-1 || top.location.host.indexOf(".com.")!=-1){
			HOST = top.location.host;
			HOST = HOST.replace(/^www\./i,"");
		}
		var NEWHOST="";
		if(TranslatorIM.SLG_DETECTsubDomain() == true){
			var arr = top.location.host.split(".");
			for(var i=1; i < arr.length; i++){
				if(i < arr.length-1) NEWHOST = NEWHOST+arr[i]+".";
				else NEWHOST = NEWHOST+arr[i];
			}	
			HOST = NEWHOST;
		}
		return HOST;
	},


    	SLG_getDParams: function(){
        	var OUTarr = new Array("","");
		TranslatorIM.SLG_GWHOST = TranslatorIM.SLG_GetHost();
		var Dmass = new Array(TranslatorIM.SLG_GWHOST,0,TranslatorIM.SLG_WPTdstlang,TranslatorIM.SLG_wptGlobAuto,TranslatorIM.SLG_wptGlobTb,TranslatorIM.SLG_wptGlobTip);
		if(TranslatorIM.SLG_wptDHist.indexOf(TranslatorIM.SLG_GWHOST) !=-1){
			var Darr1 = TranslatorIM.SLG_wptDHist.split(":");

			for(var i=0; i<Darr1.length; i++){
				var Darr2 = Darr1[i].replace(/{|}/ig,"");
				var Darr3 = Darr2.split(",")
				if(Darr3[0] == TranslatorIM.SLG_GWHOST){
					Dmass = Darr2.split(",");
				}
			}

		} else {
			var MH = TranslatorIM.SLG_GetMAINHost();
			if(TranslatorIM.SLG_wptDHist.indexOf(MH) !=-1){
				var Darr1 = TranslatorIM.SLG_wptDHist.split(":");
				for(var i=0; i<Darr1.length; i++){
					var Darr2 = Darr1[i].replace(/{|}/ig,"");
					var Darr3 = Darr2.split(",")				
					if(Darr3[0] == MH && Darr3[1] == 1){
						Dmass = Darr2.split(",");
					}
				}
			}

		}
		var cnt=0;
		var Lmass = new Array(TranslatorIM.SLG_DETLANG,TranslatorIM.SLG_wptGlobAuto,TranslatorIM.SLG_wptGlobTb,TranslatorIM.SLG_wptGlobTip);
		if(TranslatorIM.SLG_wptLHist.indexOf(TranslatorIM.SLG_DETLANG) !=-1){
			var Larr1 = TranslatorIM.SLG_wptLHist.split(":");
			for(var i=0; i<Larr1.length; i++){
				var Larr2 = Larr1[i].replace(/{|}/ig,"");
				if(Larr2.indexOf(TranslatorIM.SLG_DETLANG)!=-1){
					Lmass = Larr2.split(",");
					cnt++;
				}
			}
		}
		if(cnt==0){
			if(TranslatorIM.SLG_wptLHist.indexOf("All") !=-1){
				var Larr1 = TranslatorIM.SLG_wptLHist.split(":");
				for(var i=0; i<Larr1.length; i++){
					var Larr2 = Larr1[i].replace(/{|}/ig,"");
					if(Larr2.indexOf("All")!=-1){
						Lmass = Larr2.split(",");
					}
				}
			}
		}

		OUTarr[0] = Dmass;
		OUTarr[1] = Lmass;

		return(OUTarr);
	},

        SLG_INIT_PARAMS: function(){
	        var params = TranslatorIM.SLG_getDParams();
		TranslatorIM.SLG_wptDp1=params[0][0];
		TranslatorIM.SLG_wptDp2=params[0][1];
		TranslatorIM.SLG_wptDp3=params[0][2];
		TranslatorIM.SLG_wptDp4=params[0][3];
		TranslatorIM.SLG_wptDp5=params[0][4];
		TranslatorIM.SLG_wptDp6=params[0][5];

		TranslatorIM.SLG_wptLp1=params[1][0];
		TranslatorIM.SLG_wptLp2=params[1][1];
		TranslatorIM.SLG_wptLp3=params[1][2];
		TranslatorIM.SLG_wptLp4=params[1][3];
	},

	SLG_DefaultFromDB: function(){
	        //Param 1
		TranslatorIM.SLG_wptGlobLangTmp = TranslatorIM.SLG_GetProperLanguage(TranslatorIM.SLG_wptDp3, TranslatorIM.SLG_GWHOST);
                TranslatorIM.SLG_wptGlobLang = TranslatorIM.SLG_wptGlobLangTmp;
	        //Param 2
		TranslatorIM.SLG_wptGlobAutoTmp = TranslatorIM.SLG_wptDp4;
		if(TranslatorIM.SLG_get_AUTO_TMP("SLG_AUTO_TMP")!="undefined"){
			if(TranslatorIM.SLG_get_AUTO_TMP("SLG_AUTO_TMP")!=TranslatorIM.SLG_wptDp4) TranslatorIM.SLG_wptGlobAutoTmp = TranslatorIM.SLG_get_AUTO_TMP("SLG_AUTO_TMP");
		} else TranslatorIM.SLG_set_AUTO_TMP("SLG_AUTO_TMP",TranslatorIM.SLG_wptDp4);
	        //Param 3
		TranslatorIM.SLG_WPT_SHOWHIDE_CONSTRUCTOR(TranslatorIM.SLG_wptDp5);
	        //Param 4
		TranslatorIM.SLG_wptGlobTipTmp = TranslatorIM.SLG_wptDp6;
		//TranslatorIM.SLG_set_TIP_TRIGGER("SLG_wptGlobTipTmp",TranslatorIM.SLG_wptDp6);
	},


	SLG_FromHistory: function(THE_HOST){
		var tmp1D = TranslatorIM.SLG_wptDHist.split(":");
		for (var i=0; i<tmp1D.length; i++){
			var tmp2D = tmp1D[i].replace(/{|}/ig,"");
			tmp2D = tmp2D.split(",");
			if(tmp2D[0] == THE_HOST){
				if(tmp2D[1]==1){
					TranslatorIM.SLG_D_List = TranslatorIM.SLG_D_List + tmp2D[0] +",";
		 		        //Param 1
					TranslatorIM.SLG_wptGlobLangTmp = TranslatorIM.SLG_GetProperLanguage(tmp2D[2], THE_HOST);
		                	TranslatorIM.SLG_wptGlobLang = TranslatorIM.SLG_wptGlobLangTmp;
					TranslatorIM.SLG_wptDp3=tmp2D[2];
	 			        //Param 2
					TranslatorIM.SLG_wptGlobAutoTmp = tmp2D[3];
	                                TranslatorIM.SLG_wptDp4 = tmp2D[3];
					if(TranslatorIM.SLG_get_AUTO_TMP("SLG_AUTO_TMP")!="undefined"){
						if(TranslatorIM.SLG_get_AUTO_TMP("SLG_AUTO_TMP")!=TranslatorIM.SLG_wptDp4) TranslatorIM.SLG_wptGlobAutoTmp = TranslatorIM.SLG_get_AUTO_TMP("SLG_AUTO_TMP");
					} else TranslatorIM.SLG_set_AUTO_TMP("SLG_AUTO_TMP",TranslatorIM.SLG_wptDp4);
		 		        //Param 3
					TranslatorIM.SLG_WPT_SHOWHIDE_CONSTRUCTOR(tmp2D[4]);
	 			        //Param 4
					TranslatorIM.SLG_set_TIP_TRIGGER("SLG_wptGlobTipTmp",tmp2D[5]);
					TranslatorIM.SLG_wptGlobTipTmp = tmp2D[5];
        	                        TranslatorIM.SLG_wptDp6 = tmp2D[5];
					TranslatorIM.SLG_NONE_HANDLER();
					return true;
				} else TranslatorIM.SLG_DefaultFromDB();
			} 
		}
		return false
	},

	SLG_FromHistorySubst: function(THE_HOST){
		var tmp1D = TranslatorIM.SLG_wptDHist.split(":");
		for (var i=0; i<tmp1D.length; i++){
			var tmp2D = tmp1D[i].replace(/{|}/ig,"");
			tmp2D = tmp2D.split(",");

			if(tmp2D[0] == THE_HOST){
				TranslatorIM.SLG_D_List = TranslatorIM.SLG_D_List + tmp2D[0] +",";
	 		        //Param 1
				TranslatorIM.SLG_wptGlobLangTmp = TranslatorIM.SLG_GetProperLanguage(tmp2D[2], THE_HOST);
	                	TranslatorIM.SLG_wptGlobLang = TranslatorIM.SLG_wptGlobLangTmp;
				TranslatorIM.SLG_wptDp3=tmp2D[2];
 			        //Param 2
				TranslatorIM.SLG_wptGlobAutoTmp = tmp2D[3];

                                TranslatorIM.SLG_wptDp4 = tmp2D[3];
				if(TranslatorIM.SLG_get_AUTO_TMP("SLG_AUTO_TMP")!="undefined"){
					if(TranslatorIM.SLG_get_AUTO_TMP("SLG_AUTO_TMP")!=TranslatorIM.SLG_wptDp4) TranslatorIM.SLG_wptGlobAutoTmp = TranslatorIM.SLG_get_AUTO_TMP("SLG_AUTO_TMP");
				} else TranslatorIM.SLG_set_AUTO_TMP("SLG_AUTO_TMP",TranslatorIM.SLG_wptDp4);
	 		        //Param 3
				TranslatorIM.SLG_WPT_SHOWHIDE_CONSTRUCTOR(tmp2D[4]);
 			        //Param 4
				TranslatorIM.SLG_set_TIP_TRIGGER("SLG_wptGlobTipTmp",tmp2D[5]);
				TranslatorIM.SLG_wptGlobTipTmp = tmp2D[5];
       	                        TranslatorIM.SLG_wptDp6 = tmp2D[5];
				return true;
			}
		}
		return false;
	},

        SLG_NONE_HANDLER: function(){
                TranslatorIM.SLG_WPT_IGRORE=0;
		if(TranslatorIM.SLG_wptDp3=="None") TranslatorIM.SLG_WPT_IGRORE=1;
        },

	
	SLG_DATA_LOADING_CASCADE: function(){
 		TranslatorIM.SLG_INIT_PARAMS();
		//CASCADE: 1 level                
		var MH = TranslatorIM.SLG_GetMAINHostName();
                if(TranslatorIM.SLG_IS_SUBDOMAIN==true){
	 		if(TranslatorIM.SLG_wptDHist.indexOf(TranslatorIM.SLG_GWHOST)!=-1){
				if(TranslatorIM.SLG_FromHistorySubst(TranslatorIM.SLG_GWHOST)==true) return true;
			} else {
		 		if(TranslatorIM.SLG_wptDHist.indexOf(MH)!=-1){
					if(TranslatorIM.SLG_FromHistory(MH)==true) return true;
			        }  
			} 	
			//TranslatorIM.SLG_DefaultFromDB();
		} else {
	 		if(TranslatorIM.SLG_wptDHist.indexOf(MH)!=-1){
				if(TranslatorIM.SLG_FromHistorySubst(MH)==true) return true;
			}// else TranslatorIM.SLG_DefaultFromDB();
		}


		//CASCADE: 2 level
		if(TranslatorIM.SLG_wptLp1!="skip"){
			TranslatorIM.SLG_WPT_SKIP=1;
			var tmp1D = TranslatorIM.SLG_wptLHist.split(":");
			for (var i=0; i<tmp1D.length; i++){
				var tmp2D = tmp1D[i].replace(/{|}/ig,"");
				tmp2D = tmp2D.split(",");
				TranslatorIM.SLG_L_List = TranslatorIM.SLG_L_List + tmp2D[0] +",";
			}
			
 		        //Param 1
			TranslatorIM.SLG_wptGlobLangTmp = TranslatorIM.SLG_WPTdstlang;
        	        TranslatorIM.SLG_wptGlobLang = TranslatorIM.SLG_wptGlobLangTmp;
	        	//Param 2
			TranslatorIM.SLG_wptGlobAutoTmp = TranslatorIM.SLG_wptLp2;
			if(TranslatorIM.SLG_get_AUTO_TMP("SLG_AUTO_TMP")!="undefined"){
				if(TranslatorIM.SLG_get_AUTO_TMP("SLG_AUTO_TMP")!=TranslatorIM.SLG_wptLp2) TranslatorIM.SLG_wptGlobAutoTmp = TranslatorIM.SLG_get_AUTO_TMP("SLG_AUTO_TMP");
			} else TranslatorIM.SLG_set_AUTO_TMP("SLG_AUTO_TMP",TranslatorIM.SLG_wptLp2);

 		        //Param 3
			if(TranslatorIM.SLG_wptLp1=="All") TranslatorIM.SLG_wptGlobTbTmp = TranslatorIM.SLG_wptLp3;
			TranslatorIM.SLG_WPT_SHOWHIDE_CONSTRUCTOR(TranslatorIM.SLG_wptLp3);

 			//Param 4
			TranslatorIM.SLG_set_TIP_TRIGGER("SLG_wptGlobTipTmp",TranslatorIM.SLG_wptLp4);
			TranslatorIM.SLG_wptGlobTipTmp = TranslatorIM.SLG_wptLp4;
			return true;
		}


		//CASCADE: 3 level (defaults from DB)

		if(TranslatorIM.SLG_WPT_SKIP==1){
			TranslatorIM.SLG_wptGlobLangTmp = TranslatorIM.SLG_WPTdstlang;
        	        TranslatorIM.SLG_wptGlobLang = TranslatorIM.SLG_wptGlobLangTmp;        		
			TranslatorIM.SLG_WPT_SHOWHIDE_CONSTRUCTOR(TranslatorIM.SLG_wptGlobTbTmp);	
		} else {
			TranslatorIM.SLG_wptGlobLangTmp = TranslatorIM.SLG_WPTdstlang;
        	        TranslatorIM.SLG_wptGlobLang = TranslatorIM.SLG_wptGlobLangTmp;        		
			TranslatorIM.SLG_WPT_SHOWHIDE_CONSTRUCTOR(TranslatorIM.SLG_wptDp5);
       			TranslatorIM.SLG_wptGlobTipTmp = TranslatorIM.SLG_wptDp6;
			TranslatorIM.SLG_set_TIP_TRIGGER("SLG_wptGlobTipTmp",TranslatorIM.SLG_wptDp6);
		}
	        return false;
	},


	SLG_WPT_SHOWHIDE_CONSTRUCTOR: function(ob){
		TranslatorIM.SLG_WPT_TB_DEFAULT=ob;
		if(ob==0) {
			if(TranslatorIM.SLG_GWPT_Show_Hide_tmp==0) TranslatorIM.SLG_WPT_HIDDEN_MODE();
			else TranslatorIM.SLG_GWPT_Show_Hide_tmp = ob;
		}
		var tmp = TranslatorIM.SLG_getSHOW_HIDE_TB_TMP("SLG_GWPT_Show_Hide_tmp");

		if(tmp==null || tmp==undefined || tmp==2) {
			TranslatorIM.SLG_setSHOW_HIDE_TB_TMP("SLG_GWPT_Show_Hide_tmp",ob);
//By VK: Vova's request
			TranslatorIM.SLG_wptGlobTbTmp = TranslatorIM.SLG_wptGlobTb;
//			TranslatorIM.SLG_wptGlobTbTmp = ob;

		} else TranslatorIM.SLG_wptGlobTbTmp = tmp;
	},



	SLG_WPT_CREATE_DOMAIN_TAB: function(SLG_OPT_MENU){
 	var doc = FExtension.browserInject.getDocument();
//-Domain items
	var tmn = doc.createElement("font");
        var title = doc.createTextNode(FExtension.element(TranslatorIM.SLG_LOC,"extwptDName")+": ");
        tmn.appendChild(title);
	var span = doc.createElement("span");
        var title = doc.createTextNode(TranslatorIM.SLG_GWHOST);
        span.appendChild(title);
	var cl = doc.createAttribute("style");
	cl.value = "color:#1186BB !important";
	span.setAttributeNode(cl);
	var id = doc.createAttribute("id");
	id.value = "SLG_domain";
	span.setAttributeNode(id);

        tmn.appendChild(span);
        SLG_OPT_MENU.appendChild(tmn);
	var SLG_TBbr = doc.createElement("br");
       	SLG_OPT_MENU.appendChild(SLG_TBbr);
       	//-Subdomain patch
       	   if(TranslatorIM.SLG_IS_SUBDOMAIN==true){
		var SLG_wptSDNamePatch = doc.createElement("div");
		var SLG_wptSDNamePatchid = doc.createAttribute("id");
		SLG_wptSDNamePatchid.value = "SLG_wptSDNamePatch";
	        SLG_wptSDNamePatch.setAttributeNode(SLG_wptSDNamePatchid);
		SLG_wptSDNamePatch.appendChild(doc.createTextNode(" "));
	       	SLG_OPT_MENU.appendChild(SLG_wptSDNamePatch);
	   }
	//-Subdomain item
		var SLG_wptSDName = doc.createElement("input");
		var ty = doc.createAttribute("type");
		ty.value = "checkbox";
		SLG_wptSDName.setAttributeNode(ty);
		var SLG_wptSDNameid = doc.createAttribute("id");
		SLG_wptSDNameid.value = "SLG_wptSDName";
	        SLG_wptSDName.setAttributeNode(SLG_wptSDNameid);
        	if(TranslatorIM.SLG_wptDp2==1){
			var SLG_ch1 = doc.createAttribute("checked");
			SLG_ch1.value = "true";
		        SLG_wptSDName.setAttributeNode(SLG_ch1);
		}
        	SLG_OPT_MENU.appendChild(SLG_wptSDName);
		var span = doc.createElement("span");
        	var title = doc.createTextNode(" "+FExtension.element(TranslatorIM.SLG_LOC,"extwptSDName"));
	        span.appendChild(title);
        	SLG_OPT_MENU.appendChild(span);
		//------------
		var SLG_TBbr = doc.createElement("br");
       		SLG_OPT_MENU.appendChild(SLG_TBbr);
		//------------
	//-Translate to X item
		var span = doc.createElement("span");
	        var title = doc.createTextNode(" "+FExtension.element(TranslatorIM.SLG_LOC,"extwptTrTo"));
	        span.appendChild(title);
	        SLG_OPT_MENU.appendChild(span);
		var SLG_wptTrTo = doc.createElement("select");
		var SLG_wptTrToid = doc.createAttribute("id");
		SLG_wptTrToid.value = "SLG_wptTrTo";
	        SLG_wptTrTo.setAttributeNode(SLG_wptTrToid);
		var SLG_wptTrTost = doc.createAttribute("style");
		SLG_wptTrTost.value = "margin-left:5px;";
	        SLG_wptTrTo.setAttributeNode(SLG_wptTrTost);

	        var locNone = FExtension.element(TranslatorIM.SLG_LOC,'extwptDNone');
	        var locAll = FExtension.element(TranslatorIM.SLG_LOC,'extwptDAll');

		TranslatorIM.SLG_LNG_LIST = TranslatorIM.CUSTOM_LANGS(FExtension.element(TranslatorIM.SLG_LOC,'extLanguages'));
		var MENU = ("None:"+locNone + ",All:" + locAll +","+FExtension.element(TranslatorIM.SLG_LOC,'extLanguages')).split(",");


//		if(TranslatorIM.SLG_wptDp3!="") TranslatorIM.SLG_wptDp3 = TranslatorIM.SLG_wptGlobLang;


		for(var J=0; J < MENU.length; J++){
		    var CURlang3 = MENU[J].split(":");
		    var option = doc.createElement('option');
		    var v = doc.createAttribute("value");
		    v.value = CURlang3[0];
		    option.setAttributeNode(v);

		    if(v.value==TranslatorIM.SLG_wptGlobLang){
			var s = doc.createAttribute("selected");
			s.value="true";
			option.setAttributeNode(s);
			switch(TranslatorIM.SLG_wptGlobLang){
			  case "None": CURlang3[1]=locNone; break;
			  case "All": CURlang3[1]=locAll; break;
			  default: CURlang3[1]=TranslatorIM.SLG_GetLongName(TranslatorIM.SLG_wptGlobLang); break;
			}

		    }                 
		    option.appendChild(doc.createTextNode(CURlang3[1]));
		    SLG_wptTrTo.appendChild(option);
		}

        	SLG_OPT_MENU.appendChild(SLG_wptTrTo);
		//------------
		var SLG_TBbr = doc.createElement("br");
       		SLG_OPT_MENU.appendChild(SLG_TBbr);
		//------------
	//-Domain always item
		var SLG_Dautobox = doc.createElement("input");
		var ty = doc.createAttribute("type");
		ty.value = "checkbox";
		SLG_Dautobox.setAttributeNode(ty);
		var SLG_Dautoboxid = doc.createAttribute("id");
		SLG_Dautoboxid.value = "SLG_Dautobox";
	        SLG_Dautobox.setAttributeNode(SLG_Dautoboxid);
        	if(TranslatorIM.SLG_wptDp4==1){
			var SLG_TBch2 = doc.createAttribute("checked");
			SLG_TBch2.value = "true";
		        SLG_Dautobox.setAttributeNode(SLG_TBch2);
		}
        	SLG_OPT_MENU.appendChild(SLG_Dautobox);
		var span = doc.createElement("span");
        	var title = doc.createTextNode(" " + FExtension.element(TranslatorIM.SLG_LOC,"extwptDAlways"));
	        span.appendChild(title);
        	SLG_OPT_MENU.appendChild(span);
		//------------
		var SLG_TBbr = doc.createElement("br");
        	SLG_OPT_MENU.appendChild(SLG_TBbr);
		//------------
	//-Domain toolbar item 
		var SLG_Dtbbox = doc.createElement("input");
		var ty = doc.createAttribute("type");
		ty.value = "checkbox";
		SLG_Dtbbox.setAttributeNode(ty);
		var SLG_Dtbboxid = doc.createAttribute("id");
		SLG_Dtbboxid.value = "SLG_Dtbbox";
	        SLG_Dtbbox.setAttributeNode(SLG_Dtbboxid);
        	if(TranslatorIM.SLG_wptDp5==1){
			var SLG_TBch3 = doc.createAttribute("checked");
			SLG_TBch3.value = "true";
		        SLG_Dtbbox.setAttributeNode(SLG_TBch3);
		}
        	SLG_OPT_MENU.appendChild(SLG_Dtbbox);
		var span = doc.createElement("span");
        	var title = doc.createTextNode(" " + FExtension.element(TranslatorIM.SLG_LOC,"extwptDTb"));
	        span.appendChild(title);
        	SLG_OPT_MENU.appendChild(span);
		//------------
		var SLG_TBbr = doc.createElement("br");
        	SLG_OPT_MENU.appendChild(SLG_TBbr);
		//------------
	//-Domain tip item 
		var SLG_Dtipbox = doc.createElement("input");
		var ty = doc.createAttribute("type");
		ty.value = "checkbox";
		SLG_Dtipbox.setAttributeNode(ty);
		var SLG_Dtipboxid = doc.createAttribute("id");
		SLG_Dtipboxid.value = "SLG_Dtipbox";
	        SLG_Dtipbox.setAttributeNode(SLG_Dtipboxid);
        	if(TranslatorIM.SLG_wptDp6=="1"){
			var SLG_TBch4 = doc.createAttribute("checked");
			SLG_TBch4.value = "true";
		        SLG_Dtipbox.setAttributeNode(SLG_TBch4);
		}
        	SLG_OPT_MENU.appendChild(SLG_Dtipbox);
		var span = doc.createElement("span");
        	var title = doc.createTextNode(" " + FExtension.element(TranslatorIM.SLG_LOC,"extwptDOrTip"));
	        span.appendChild(title);
        	SLG_OPT_MENU.appendChild(span);
		//------------
		var SLG_TBhr = doc.createElement("div");
		var cl = doc.createAttribute("class");
		cl.value = "SLG_hr";
		SLG_TBhr.setAttributeNode(cl);
		SLG_OPT_MENU.appendChild(SLG_TBhr);
		//------------
//--Save button
		var SLG_TBsave = doc.createElement("input");
		var SLG_TBsaveid = doc.createAttribute("id");
		SLG_TBsaveid.value = "SLG_TBsave1";
        	SLG_TBsave.setAttributeNode(SLG_TBsaveid);

		var ty = doc.createAttribute("type");
		ty.value = "button";
		SLG_TBsave.setAttributeNode(ty);

	       	SLG_TBsave.value = FExtension.element(TranslatorIM.SLG_LOC,"extSaveButton");
        	SLG_OPT_MENU.appendChild(SLG_TBsave);

		var SLG_TBload = doc.createElement("div");
		var SLG_TBloadid = doc.createAttribute("id");
		SLG_TBloadid.value = "SLG_WPT_SAVE_LOAD";
	        SLG_TBload.setAttributeNode(SLG_TBloadid);
		var SLG_TBloadst = doc.createAttribute("style");
		var BG = FExtension.browserInject.getURL('content/img/util/loading.gif');
		SLG_TBloadst.value = "background-image:url("+BG+");height:36px;width:36px;position:absolute;margin-left:150px;margin-top:-115px;display:none;z-index:999999999999;opacity: 0.5;";
	        SLG_TBload.setAttributeNode(SLG_TBloadst);

      

        	SLG_OPT_MENU.appendChild(SLG_TBload);

	},

	SLG_WPT_CREATE_LANGUAGE_TAB: function(SLG_OPT_MENU){
 	var doc = FExtension.browserInject.getDocument();
//-Language items
	//-Language item
		var span = doc.createElement("span");
	        var title = doc.createTextNode(" "+FExtension.element(TranslatorIM.SLG_LOC,"extwptTrFrom"));
	        span.appendChild(title);
        	SLG_OPT_MENU.appendChild(span);

		var SLG_wptLang = doc.createElement("select");
		var SLG_wptLangid = doc.createAttribute("id");
		SLG_wptLangid.value = "SLG_wptLang";
	        SLG_wptLang.setAttributeNode(SLG_wptLangid);
		var SLG_wptLangst = doc.createAttribute("style");
		SLG_wptLangst.value = "margin-left:5px;opacity:0.2;";
	        SLG_wptLang.setAttributeNode(SLG_wptLangst);
	        // Option 0
		var Op0 = doc.createElement("option");
		var v = doc.createAttribute("value");
		v.value = "All";
		Op0.setAttributeNode(v);
		Op0.appendChild(doc.createTextNode(FExtension.element(TranslatorIM.SLG_LOC,"extwptLAll")));
		SLG_wptLang.appendChild(Op0);

		SLG_wptLang.onchange = function(){
			TranslatorIM.SLG_SLG_WPT_LANG_OPT_RESET();
		};

		TranslatorIM.SLG_LNG_LIST = TranslatorIM.CUSTOM_LANGS(FExtension.element(TranslatorIM.SLG_LOC,'extLanguages'));
//		var MENU = FExtension.element(TranslatorIM.SLG_LOC,'extLanguages').split(",");
		var MENU = TranslatorIM.SLG_LNG_LIST.split(",");
		for(var J=0; J < MENU.length; J++){
		    var CURlang3 = MENU[J].split(":");
		    var option = doc.createElement('option');
		    if(TranslatorIM.SLG_wptLp1=="" || TranslatorIM.SLG_wptLp1=="skip") TranslatorIM.SLG_wptLp1 = TranslatorIM.SLG_DETLANG;
		    v = doc.createAttribute("value");
		    v.value = CURlang3[0];
		    if(v.value == TranslatorIM.SLG_wptLp1){
			var s = doc.createAttribute("selected");
			s.value="true";
			option.setAttributeNode(s);
			CURlang3[1]=TranslatorIM.SLG_GetLongName(TranslatorIM.SLG_wptLp1);
		    }	
		    option.setAttributeNode(v);
		    option.appendChild(doc.createTextNode(CURlang3[1]));
//		    option.appendChild(doc.createTextNode(TranslatorIM.SLG_GetLongName(TranslatorIM.SLG_WPT_TRG_LNG)));

		    SLG_wptLang.appendChild(option);
		}

        	SLG_OPT_MENU.appendChild(SLG_wptLang);
		//------------
		var SLG_TBbr = doc.createElement("br");
       		SLG_OPT_MENU.appendChild(SLG_TBbr);
		//------------
	//-Language always item
		var SLG_Lautobox = doc.createElement("input");
		var ty = doc.createAttribute("type");
		ty.value = "checkbox";
		SLG_Lautobox.setAttributeNode(ty);
		var SLG_Lautoboxid = doc.createAttribute("id");
		SLG_Lautoboxid.value = "SLG_Lautobox";
	        SLG_Lautobox.setAttributeNode(SLG_Lautoboxid);
        	if(TranslatorIM.SLG_wptLp2==1){
			var SLG_TBch1 = doc.createAttribute("checked");
			SLG_TBch1.value = "true";
		        SLG_Lautobox.setAttributeNode(SLG_TBch1);
		}
        	SLG_OPT_MENU.appendChild(SLG_Lautobox);
		var span = doc.createElement("span");
        	var title = doc.createTextNode(" " + FExtension.element(TranslatorIM.SLG_LOC,"extwptLAlways"));
	        span.appendChild(title);
        	SLG_OPT_MENU.appendChild(span);
		//------------
		var SLG_TBbr = doc.createElement("br");
        	SLG_OPT_MENU.appendChild(SLG_TBbr);
		//------------
	//-Language toolbar item 
		var SLG_Ltbbox = doc.createElement("input");
		var ty = doc.createAttribute("type");
		ty.value = "checkbox";
		SLG_Ltbbox.setAttributeNode(ty);
		var SLG_Ltbboxid = doc.createAttribute("id");
		SLG_Ltbboxid.value = "SLG_Ltbbox";
	        SLG_Ltbbox.setAttributeNode(SLG_Ltbboxid);
        	if(TranslatorIM.SLG_wptLp3==1){
			var SLG_TBch0 = doc.createAttribute("checked");
			SLG_TBch0.value = "true";
		        SLG_Ltbbox.setAttributeNode(SLG_TBch0);
		}
        	SLG_OPT_MENU.appendChild(SLG_Ltbbox);
		var span = doc.createElement("span");
        	var title = doc.createTextNode(" " + FExtension.element(TranslatorIM.SLG_LOC,"extwptLTb"));
	        span.appendChild(title);
        	SLG_OPT_MENU.appendChild(span);
		//------------
		var SLG_TBbr = doc.createElement("br");
        	SLG_OPT_MENU.appendChild(SLG_TBbr);
		//------------
	//-Language tip item 
		var SLG_Ltipbox = doc.createElement("input");
		var ty = doc.createAttribute("type");
		ty.value = "checkbox";
		SLG_Ltipbox.setAttributeNode(ty);
		var SLG_Ltipboxid = doc.createAttribute("id");
		SLG_Ltipboxid.value = "SLG_Ltipbox";
	        SLG_Ltipbox.setAttributeNode(SLG_Ltipboxid);

        	if(TranslatorIM.SLG_wptLp4==1){
			var SLG_TBch4 = doc.createAttribute("checked");
			SLG_TBch4.value = "true";
		        SLG_Ltipbox.setAttributeNode(SLG_TBch4);
		}
        	SLG_OPT_MENU.appendChild(SLG_Ltipbox);
		var span = doc.createElement("span");
        	var title = doc.createTextNode(" " + FExtension.element(TranslatorIM.SLG_LOC,"extwptLOrTip"));
	        span.appendChild(title);
        	SLG_OPT_MENU.appendChild(span);
		//------------
		var SLG_TBbr = doc.createElement("br");
        	SLG_OPT_MENU.appendChild(SLG_TBbr);
		//------------

//------------
		//------------
		var SLG_TBhr = doc.createElement("div");
		var cl = doc.createAttribute("class");
		cl.value = "SLG_hr";
		SLG_TBhr.setAttributeNode(cl);
		SLG_OPT_MENU.appendChild(SLG_TBhr);
		//------------
//--Save button
		var SLG_TBsave = doc.createElement("input");
		var SLG_TBsaveid = doc.createAttribute("id");
		SLG_TBsaveid.value = "SLG_TBsave2";
        	SLG_TBsave.setAttributeNode(SLG_TBsaveid);

		var ty = doc.createAttribute("type");
		ty.value = "button";
		SLG_TBsave.setAttributeNode(ty);

	       	SLG_TBsave.value = FExtension.element(TranslatorIM.SLG_LOC,"extSaveButton");
        	SLG_OPT_MENU.appendChild(SLG_TBsave);

		var SLG_TBload = doc.createElement("div");
		var SLG_TBloadid = doc.createAttribute("id");
		SLG_TBloadid.value = "SLG_WPT_SAVE_LOAD";
	        SLG_TBload.setAttributeNode(SLG_TBloadid);
		var SLG_TBloadst = doc.createAttribute("style");
		var BG = FExtension.browserInject.getURL('content/img/util/loading.gif');
		SLG_TBloadst.value = "background-image:url("+BG+");height:36px;width:36px;position:absolute;margin-left:150px;margin-top:-115px;display:none;z-index:999999999999;opacity: 0.5;";
	        SLG_TBload.setAttributeNode(SLG_TBloadst);

        	SLG_OPT_MENU.appendChild(SLG_TBload);

//		TranslatorIM.SLG_WPT_DETECT(2);
		setTimeout(function() {
 			doc.getElementById('SLG_WPT_SAVE_LOAD').style.display = "block";
			setTimeout(function() {
			  var SLG_WPTOPTid = setInterval(function(){
				if(TranslatorIM.SLG_WPT_LANG!="") {
		        	        doc.getElementById("SLG_wptLang").style.opacity="1";
					TranslatorIM.SLG_wptLp1=TranslatorIM.SLG_WPT_LANG;
					clearInterval(SLG_WPTOPTid);
					doc.getElementById("SLG_wptLang").value=TranslatorIM.SLG_wptLp1;
					TranslatorIM.SLG_SLG_WPT_LANG_OPT_RESET();
					doc.getElementById('SLG_WPT_SAVE_LOAD').style.display = "none";
				}
			    },5);  
			}, 5);    
		}, 1);    

	},

	SLG_DETECTsubDomain: function() {
	 	var doc = FExtension.browserInject.getDocument();
		var url = doc.location.host;
		// IF THERE, REMOVE WHITE SPACE FROM BOTH ENDS
		url = url.replace(new RegExp(/^\s+/),""); // START
		url = url.replace(new RegExp(/\s+$/),""); // END
 
		// IF FOUND, CONVERT BACK SLASHES TO FORWARD SLASHES
		url = url.replace(new RegExp(/\\/g),"/");
 
		// IF THERE, REMOVES 'http://', 'https://' or 'ftp://' FROM THE START
		url = url.replace(new RegExp(/^http\:\/\/|^https\:\/\/|^ftp\:\/\//i),"");
 
		// IF THERE, REMOVES 'www.' FROM THE START OF THE STRING
		url = url.replace(new RegExp(/^www\./i),"");
 
		// REMOVE COMPLETE STRING FROM FIRST FORWARD SLASH ON
		url = url.replace(new RegExp(/\/(.*)/),"");
 
		// REMOVES '.??.??' OR '.???.??' FROM END - e.g. '.CO.UK', '.COM.AU'
		if (url.match(new RegExp(/\.[a-z]{2,3}\.[a-z]{2}$/i))) {
		      url = url.replace(new RegExp(/\.[a-z]{2,3}\.[a-z]{2}$/i),"");
 
		// REMOVES '.??' or '.???' or '.????' FROM END - e.g. '.US', '.COM', '.INFO'
		} else if (url.match(new RegExp(/\.[a-z]{2,4}$/i))) {
		      url = url.replace(new RegExp(/\.[a-z]{2,4}$/i),"");
		}
 
		// CHECK TO SEE IF THERE IS A DOT '.' LEFT IN THE STRING
		var subDomain = (url.match(new RegExp(/\./g))) ? true : false;
		return(subDomain);
 
	},

	SLG_GetProperLanguage: function(lng,mh){
		var out=lng;
		if(TranslatorIM.SLG_WPT_TEMP_LANG=="") TranslatorIM.SLG_WPT_TEMP_LANG=lng;
		if(TranslatorIM.SLG_get_LNG_TRIGGER("SLG_LNG_TRIGGER")!=1) TranslatorIM.SLG_WPT_TEMP_LANG=lng;
		if(TranslatorIM.SLG_WPT_TEMP_LANG == lng){
			TranslatorIM.SLG_LNG_LIST = TranslatorIM.CUSTOM_LANGS(FExtension.element(TranslatorIM.SLG_LOC,'extLanguages'));
			var MENU = FExtension.element(TranslatorIM.SLG_LOC,'extLanguages').split(",");
			var tmp = TranslatorIM.SLG_wptDHist.split(":");
			var cnt=0;
			for (var i=0; i<tmp.length; i++){
				var tmp2 = tmp[i].replace(/{|}/ig,"");
				tmp2 = tmp2.split(",");
				if(tmp2[0]==mh){
				   for (var j=0; j<MENU.length; j++){
					var arr = MENU[j].split(":");
					if(arr[0]==lng){j=10000;i=100000; cnt++;}
				   }
				}
			}
			if(cnt==0) out = TranslatorIM.SLG_WPTdstlang;
		} else out = TranslatorIM.SLG_WPT_TEMP_LANG;
		TranslatorIM.SLG_setLNG_TMP("SLG_G_WPT_TO",out);
                TranslatorIM.SLG_WPT_IGRORE=0;
		if(TranslatorIM.SLG_wptDp3=="None") TranslatorIM.SLG_WPT_IGRORE=1;
		return out;
	},

	SLG_SLG_WPT_LANG_OPT_RESET: function(){
	 	var doc = FExtension.browserInject.getDocument();
	        var cur = doc.getElementById("SLG_wptLang").value;
		var Lmass = new Array(cur,0,TranslatorIM.SLG_wptGlobTb,TranslatorIM.SLG_wptGlobTip);
		var Larr1 = TranslatorIM.SLG_wptLHist.split(":");
		for(var i=0; i<Larr1.length; i++){
			var Larr2 = Larr1[i].replace(/{|}/ig,"");
			if(Larr2.indexOf(cur) !=-1){
				Lmass = Larr2.split(",");
			}
		}
                if(Lmass[1]==1) doc.getElementById("SLG_Lautobox").checked = true;
		else doc.getElementById("SLG_Lautobox").checked = false;
                if(Lmass[2]==1) doc.getElementById("SLG_Ltbbox").checked = true;
		else doc.getElementById("SLG_Ltbbox").checked = false;
                if(Lmass[3]==1) doc.getElementById("SLG_Ltipbox").checked = true;
		else doc.getElementById("SLG_Ltipbox").checked = false;
	},

    	SLG_getWPT_DET_LNG: function(cname){
	    var name = cname + "=";
	    var ca = document.cookie.split(';');
	    for(var i=0; i<ca.length; i++) {
	        var c = ca[i];
	        while (c.charAt(0)==' ') c = c.substring(1);
	        if (c.indexOf(name) == 0){
		  var resp = c.substring(name.length,c.length);
		  TranslatorIM.SLG_WPT_DET_LNG = resp; 
		  return resp;
		}
	    }
    	},

    	SLG_setWPT_DET_LNG: function(cname, cvalue, exdays) {
	    var s = ""; 
	    if(String(document.location).indexOf('https:')!=-1) s=" secure;"; 
	    document.cookie = cname + "=" + cvalue + "; path=/;"+s;
	    TranslatorIM.SLG_WPT_DET_LNG = cvalue; 
    	},

    	SLG_getLNG_TMP: function(cname){
	    var name = cname + "=";
	    var ca = document.cookie.split(';');
	    for(var i=0; i<ca.length; i++) {
	        var c = ca[i];
	        while (c.charAt(0)==' ') c = c.substring(1);
	        if (c.indexOf(name) == 0){
		  var resp = c.substring(name.length,c.length);
		  TranslatorIM.SLG_WPT_TEMP_LANG = resp; 
		  return resp;
		}
	    }
    	},

    	SLG_setLNG_TMP: function(cname, cvalue, exdays) {
	    var s = ""; 
	    if(String(document.location).indexOf('https:')!=-1) s=" secure;"; 
	    document.cookie = cname + "=" + cvalue + "; path=/;"+s;
	    TranslatorIM.SLG_WPT_TEMP_LANG = cvalue; 
    	},


	SLG_setSHOW_HIDE_TB_TMP: function(cname, cvalue, exdays) {
	    var s = ""; 
	    if(String(document.location).indexOf('https:')!=-1) s=" secure;"; 
	    document.cookie = cname + "=" + cvalue + "; path=/;"+s;
	},


	SLG_getSHOW_HIDE_TB_TMP: function(cname) {
	    var name = cname + "=";
	    var ca = document.cookie.split(';');
	    for(var i=0; i<ca.length; i++) {
	        var c = ca[i];
	        while (c.charAt(0)==' ') c = c.substring(1);
	        if (c.indexOf(name) == 0){
		 var resp = c.substring(name.length,c.length);
		 TranslatorIM.SLG_GWPT_Show_Hide=resp;
		 TranslatorIM.SLG_GWPT_Show_Hide_tmp=resp;
		 return resp;
		}
	    }
	},

	SLG_set_TIP_TRIGGER: function(cname, cvalue, exdays) {
	    var s = ""; 
	    if(String(document.location).indexOf('https:')!=-1) s=" secure;"; 
	    document.cookie = cname + "=" + cvalue + "; path=/;"+s;
	},


	SLG_get_TIP_TRIGGER: function(cname) {
	    var name = cname + "=";
	    var ca = document.cookie.split(';');
	    for(var i=0; i<ca.length; i++) {
	        var c = ca[i];
	        while (c.charAt(0)==' ') c = c.substring(1);
	        if (c.indexOf(name) == 0){
		 return c.substring(name.length,c.length);
		}
	    }
	},



	SLG_set_LNG_TRIGGER: function(cname, cvalue, exdays) {
	    var s = ""; 
	    if(String(document.location).indexOf('https:')!=-1) s=" secure;"; 
	    document.cookie = cname + "=" + cvalue + "; path=/;"+s;
	},


	SLG_get_LNG_TRIGGER: function(cname) {
	    var name = cname + "=";
	    var ca = document.cookie.split(';');
	    for(var i=0; i<ca.length; i++) {
	        var c = ca[i];
	        while (c.charAt(0)==' ') c = c.substring(1);
	        if (c.indexOf(name) == 0){
		 return c.substring(name.length,c.length);
		}
	    }
	},

	SLG_set_AUTO_TMP: function(cname, cvalue, exdays) {
	    var s = ""; 
	    if(String(document.location).indexOf('https:')!=-1) s=" secure;"; 
	    document.cookie = cname + "=" + cvalue + "; path=/;"+s;
	},


	SLG_get_AUTO_TMP: function(cname) {
            var resp = TranslatorIM.SLG_wptGlobAutoTmp;
	    var name = cname + "=";
	    var ca = document.cookie.split(';');
	    for(var i=0; i<ca.length; i++) {
	        var c = ca[i];
	        while (c.charAt(0)==' ') c = c.substring(1);
	        if (c.indexOf(name) == 0){
	         var resp = c.substring(name.length,c.length);
	         if(resp=="undefined") resp = TranslatorIM.SLG_wptGlobAutoTmp;
		 else TranslatorIM.SLG_wptGlobAutoTmp=resp;
		 if(resp==0){
			TranslatorIM.SLG_setSHOW_HIDE_TB_TMP("SLG_GWPT_Show_Hide_tmp",2);
		 }
		 return resp;
		}
	    }
	 return resp;
	},

	SLG_IS_DOMAIN_IN_THE_LIST: function(DOMAINS,HOST){
	    var DLIST = DOMAINS.split(",");
	    for(var i=0; i<(DLIST.length-1); i++){
	     	if(DLIST[i]==HOST) return 1;
	    }
	    return 0;
	},

	GOOGLE_TTS_backup: function(speechText,TTSlang){	        
	     	var doc = FExtension.browserInject.getDocument();
		TranslatorIM.synth.cancel();

			var voices = TranslatorIM.synth.getVoices();
			const utterance = new SpeechSynthesisUtterance();
			var LNG="";
			TranslatorIM.TheNewLang=TTSlang;
			switch(TTSlang){
			 	case "zt":LNG = "zh-HK"; break;
			 	case "zh":LNG = "zh-TW"; break;
//			 	case "en":LNG = "en-GB|Male"; break;
			 	case "en":LNG = "en-US"; break;
			 	case "de":LNG = "de-DE"; break;
			 	case "hi":LNG = "hi-IN"; break;
			 	case "id":LNG = "id-ID"; break;
			 	case "it":LNG = "it-IT"; break;
			 	case "nl":LNG = "nl-NL"; break;
			 	case "pl":LNG = "pl-PL"; break;
			 	case "es":LNG = "es-US"; break;

			 	case "ru":LNG = "ru-RU"; break;
			 	case "ja":LNG = "ja-JP"; break;
			 	case "ko":LNG = "ko-KR"; break;
			 	case "fr":LNG = "fr-FR"; break;
			 	case "pt":LNG = "pt-BR"; break;

			}

                        

			for (var a=0; a<voices.length; a++){
			    if(LNG.indexOf("|")!=-1){
				var ARR=LNG.split("|");
				if(ARR[0]==voices[a].lang && voices[a].name.indexOf(ARR[1])!=-1){
					utterance.voice = voices[a];
				}
			    }else{
				if(LNG==voices[a].lang){
					utterance.voice = voices[a];
				}
			    }
			}
			var SP = 1.0;

			var PLANSHET = doc.getElementById("SLG_player2");
		 	PLANSHET.style.display='block';
		        var ext = FExtension.browserInject;
		 	var PLAYER = "<div id='PL_lbplayer'><table width='50' colspan='3' style='padding:6px;' bgcolor='#fff'><tr><td width=20><div id='SLG_controls' class='SLG_pause'></div></td><td width=5></td><td align='left' width=20><div id='SLG_volume' class='SLG_volume'></div></td></tr></table></div>";
			PLANSHET.innerHTML=PLAYER;
	            	doc.getElementById('SLG_volume').style.background='url('+ext.getURL('content/img/util/volume.png')+')';
	            	doc.getElementById('SLG_controls').style.background='url('+ext.getURL('content/img/util/pause.png')+')';


			TranslatorIM.TheNewText = speechText;

			utterance.text = speechText;
			utterance.rate = SP;
                        if(TranslatorIM.TTSvolume==null || TranslatorIM.TTSvolume=="undefined" || TranslatorIM.TTSvolume=="") TranslatorIM.SLG_setTMPdata("TTSvolume",TranslatorIM.TheVolume);
			utterance.volume = TranslatorIM.TTSvolume*1/10;


			utterance.addEventListener('end', TranslatorIM.handleSpeechEvent);
			utterance.addEventListener('pause', TranslatorIM.handleSpeechPause);
			utterance.addEventListener('resume', TranslatorIM.handleSpeechResume);

			TranslatorIM.synth.speak(utterance);
                        TranslatorIM.handleSpeechSetVolume();
			setTimeout(function() {
				doc.getElementById("SLG_alert100").style.display="block";				
			}, 500);

	},

	handleSpeechPause: function(){
		var doc = FExtension.browserInject.getDocument();
		var ext = FExtension.browserInject;
            	doc.getElementById('SLG_controls').style.background='url('+ext.getURL('content/img/util/play.png')+')';
		doc.getElementById("SLG_controls").className="SLG_play";			
	},

	handleSpeechResume: function(){
		var doc = FExtension.browserInject.getDocument();
		var ext = FExtension.browserInject;
            	doc.getElementById('SLG_controls').style.background='url('+ext.getURL('content/img/util/pause.png')+')';
		doc.getElementById("SLG_controls").className="SLG_pause";
		TranslatorIM.Reload();
	},

	handleSpeechEvent: function(){
		var doc = FExtension.browserInject.getDocument();
		var ext = FExtension.browserInject;
            	doc.getElementById('SLG_controls').style.background='url('+ext.getURL('content/img/util/play.png')+')';
		doc.getElementById("SLG_controls").className="SLG_play";
	},

	handleSpeechVolume: function(){
	   var doc = FExtension.browserInject.getDocument();
		var ext = FExtension.browserInject;
		if(doc.getElementById("SLG_volume").className=="SLG_novolume"){
			doc.getElementById('SLG_volume').style.background='url('+ext.getURL('content/img/util/volume.png')+')';
			doc.getElementById("SLG_volume").className="SLG_volume";
			TranslatorIM.SLG_setTMPdata("TTSvolume",TranslatorIM.TheVolume);
		} else {
			doc.getElementById('SLG_volume').style.background='url('+ext.getURL('content/img/util/novolume.png')+')';
			doc.getElementById("SLG_volume").className="SLG_novolume";
			TranslatorIM.SLG_setTMPdata("TTSvolume",1);
		}
	},

	handleSpeechSetVolume: function(){
	   var doc = FExtension.browserInject.getDocument();
		var ext = FExtension.browserInject;
		if(TranslatorIM.TTSvolume!=TranslatorIM.TheVolume){
			doc.getElementById('SLG_volume').style.background='url('+ext.getURL('content/img/util/novolume.png')+')';
			doc.getElementById("SLG_volume").className="SLG_novolume";
		}else{
			doc.getElementById('SLG_volume').style.background='url('+ext.getURL('content/img/util/volume.png')+')';
			doc.getElementById("SLG_volume").className="SLG_volume";
		}
	},

	Reload: function(ob){
	    var doc = FExtension.browserInject.getDocument();
	    TranslatorIM.synth.cancel();    
	    TranslatorIM.GOOGLE_TTS_backup(TranslatorIM.TheNewText,TranslatorIM.TheNewLang);
	},

	PPB_tts_icon: function (T,resp){
		var doc = FExtension.browserInject;
	   	var doc2 = doc.getDocument();
		var resptmp = resp;
		if(TranslatorIM.SLG_ALLvoices.indexOf(T)!=-1){
			var ttsurl=FExtension.browserInject.getURL('content/img/util/tts.png');
			if(T=="ar" || T=="iw" || T=="fa" || T=="yi" || T=="ur" || T=="ps" || T=="sd" || T=="ckb" || T=="ug" || T=="dv" || T=="prs"){
				var tmpTTSicn='<div class="PPB_voice2" title="'+FExtension.element(TranslatorIM.SLG_LOC,"extListen_ttl")+'" id="SLG_BBL_VOICE" style="background: url('+FExtension.browserInject.getURL("content/img/util/tts.png")+');" lang="'+doc2.getElementById("SLG_lng_to").value+'">&nbsp;</div>';
				resptmp = tmpTTSicn+"<div style='margin-right:20px;line-height:19px;'>"+resptmp+"</div>";
			} else {
				var tmpTTSicn='<div class="PPB_voice1" title="'+FExtension.element(TranslatorIM.SLG_LOC,"extListen_ttl")+'" id="SLG_BBL_VOICE" style="background: url('+FExtension.browserInject.getURL("content/img/util/tts.png")+');" lang="'+doc2.getElementById("SLG_lng_to").value+'">&nbsp;</div>';
				resptmp = tmpTTSicn+"<div style='margin-left:20px;line-height:19px;'>"+resptmp+"</div>";
			}
		}

		return resptmp;

	},

	AUTOhandler: function(doc,AUTO,DetLang){
		var LNGlist = FExtension.element(TranslatorIM.SLG_LOC,'extLanguages');
		var LNGS = FExtension.element(TranslatorIM.SLG_LOC,'extLanguages').split(",");
		for(var I=0; I<LNGS.length; I++){
			var LN = LNGS[I].split(":");
		 	if(LN[0]==DetLang){
				doc.getElementById('SLG_lng_from').title=FExtension.element(TranslatorIM.SLG_LOC,'extDetected') + " " + LN[1];
				break;
			}
		}			
		var autopattern = "auto";
		if(AUTO != true ) autopattern = "XautoX";
		return autopattern;
	},
	
	ACTIVATE_THEMEwpt_lng: function (st){
	 	if(st==1){
	 	        var bg = "#191919";
			var doc = FExtension.browserInject.getDocument();
			var SLG_lng = doc.getElementById("SLG_wptLang");
			for(var j=0; j<SLG_lng.options.length; j++) SLG_lng.options[j].setAttribute("style", "background:"+bg+" !important;color:#fff;");
		}
	},

	ACTIVATE_THEMEwpt_dom: function (st){
	 	if(st==1){
	 	        var bg = "#191919";
			var doc = FExtension.browserInject.getDocument();
			if(doc.getElementById("SLG_OPT_MENUid")) doc.getElementById("SLG_OPT_MENUid").style.filter=TranslatorIM.SLG_DARK;
			if(doc.getElementById("SLG_TBpatchid")) doc.getElementById("SLG_TBpatchid").style.filter=TranslatorIM.SLG_DARK;
			if(doc.getElementById("SLG_TBsave1")) doc.getElementById("SLG_TBsave1").style.filter=TranslatorIM.SLG_DARK;
			if(doc.getElementById("SLG_TBsave2")) doc.getElementById("SLG_TBsave2").style.filter=TranslatorIM.SLG_DARK;
			if(doc.getElementById("SLG_WPT_TAB1")) doc.getElementById("SLG_WPT_TAB1").style.filter=TranslatorIM.SLG_DARK;
			if(doc.getElementById("SLG_WPT_TAB2")) doc.getElementById("SLG_WPT_TAB2").style.filter=TranslatorIM.SLG_DARK;
			if(doc.getElementById("SLG_domain")) doc.getElementById("SLG_domain").style.filter=TranslatorIM.SLG_DARK;
			var SLG_lng = doc.getElementById("SLG_wptTrTo");
			for(var j=0; j<SLG_lng.options.length; j++) SLG_lng.options[j].setAttribute("style", "background:"+bg+" !important;color:#fff;");
		}
	},

	ACTIVATE_THEMEwpt: function (st){
	 	if(st==1){
	 	        var bg = "#191919";
			var doc = FExtension.browserInject.getDocument();
			if(doc.getElementById(":0.container")) doc.getElementById(":0.container").style.filter=TranslatorIM.SLG_DARK;
		      	var win = top.window.frames[":0.container"].contentWindow;
			var hrefs = win.document.getElementsByClassName('goog-te-button');
			for(var i=0; i<hrefs.length; i++) hrefs[i].setAttribute("style", "filter:"+TranslatorIM.SLG_DARK);
			var hrefs = win.document.getElementsByClassName("goog-logo-link");
			for(var i=0; i<hrefs.length; i++) hrefs[i].style.filter=TranslatorIM.SLG_DARK;
			win.document.getElementById("SLG_TBoptions").style.filter=TranslatorIM.SLG_DARK;
			var SLG_lng = win.document.getElementById("SLG_G_M_to");
			for(var j=0; j<SLG_lng.options.length; j++) SLG_lng.options[j].setAttribute("style", "background:"+bg+" !important;color:#fff;");
		}
	},

	ACTIVATE_THEMEbbl: function (st){
	 	if(st==1){
	 	        var bg = "#191919";
			var doc = FExtension.browserInject.getDocument();
		        if(doc.getElementById("SLG_shadow_translator")){
			doc.getElementById("SLG_shadow_translator").style.filter=TranslatorIM.SLG_DARK;

			var SLG_lng = doc.getElementsByClassName("SLG_lngs");
			for(var i=0; i<SLG_lng.length; i++) {
				for(var j=0; j<SLG_lng[i].options.length; j++) SLG_lng[i].options[j].setAttribute("style", "background:"+bg+" !important;color:#fff;");
			}

			var hrefs = doc.getElementsByClassName("SLG_options");
			for(var i=0; i<hrefs.length; i++) hrefs[i].setAttribute("style", "filter:"+TranslatorIM.SLG_DARK);
			var hrefs = doc.getElementsByClassName("_ALNK");
			for(var i=0; i<hrefs.length; i++) hrefs[i].setAttribute("style", "filter:"+TranslatorIM.SLG_DARK);

//			var hrefs = doc.getElementsByClassName("skiptranslate");
//			for(var i=0; i<hrefs.length; i++) hrefs[i].setAttribute("style", "filter:"+TranslatorIM.SLG_DARK);

			doc.getElementById("SLG_PN0").style.filter=(TranslatorIM.SLG_DARK-90);
                        doc.getElementById("SLG_PN1").style.filter=(TranslatorIM.SLG_DARK-90);
			doc.getElementById("SLG_PN2").style.filter=(TranslatorIM.SLG_DARK-90);
			//doc.getElementById("SLG_PN3").style.filter=(TranslatorIM.SLG_DARK-90);

			setTimeout(function() {
				var lbl = doc.getElementsByClassName("SLG_BL_LABLE_ON");	
				for(var i=0; i<lbl.length; i++) {
					var ind = lbl[i].id.replace("SLG_P","");
					if(lbl[i].id.indexOf(ind)!=-1) doc.getElementById("SLG_PN"+ind).style.filter=TranslatorIM.SLG_LIGHT;
				}
			}, 700);
			}
		}
	},

	SLG_YANDEX: function(text,f,t){
	     	var doc = FExtension.browserInject.getDocument();
	     	var doc2 = FExtension.browserInject;

        	f = f.replace("zh-CN","zh");
        	f = f.replace("jw","jv");
	        f = f.replace("iw","he");
		f = f.replace("srsl","sr");
        	f = f.replace("tlsl","tl");

	        t = t.replace("zh-CN","zh");
	        t = t.replace("jw","jv");
        	t = t.replace("iw","he");
		t = t.replace("srsl","sr");
        	t = t.replace("tlsl","tl");


                if(text.length<=TranslatorIM.SLG_Balloon_translation_limit) text = TranslatorIM.truncStrByWord(text,TranslatorIM.SLG_Balloon_translation_limit);
                if(text!=""){
		        var dir = f+"-"+t;
			if(f=="auto") dir = t;
		        FExtension.browserInject.runtimeSendMessage({greeting: "TR_YANDEX:>"+dir+","+encodeURIComponent(text)}, function(response) {});
			setTimeout(function(){
			    var SLIDL = setInterval(function(){
			           FExtension.browserInject.extensionSendMessage({greeting: 1}, function(response) {
			             if(response && response.farewell){
				        var theresponse = response.farewell.split("~");
					TranslatorIM.BBL_RESULT=theresponse[52];
					if(TranslatorIM.BBL_RESULT!="") {
						text = TranslatorIM.BBL_RESULT;
						TranslatorIM.BBL_RESULT="";
						clearInterval(SLIDL);
						//text=text.replace(/#/ig,"'");
					    	if(text!="" && text!="<#>"){
							TranslatorIM.SLG_temp_result = text;
							//text=text.replace(/@/ig,'<br>');
	       					        var resptmp = TranslatorIM.PPB_tts_icon(t,text);

							setTimeout(function() {
					 			var nmr = text.trim().split(" ").length;
								if(nmr > 1) TranslatorIM.CNTR('2222',f+"/"+t, text.length);
								else TranslatorIM.CNTR('2232',f+"/"+t, text.length);
							}, 100);

			        			doc.getElementById('SLG_shadow_translation_result').innerHTML=resptmp.replace(/\\n/ig,'<br>');
							doc.getElementById('SLG_shadow_translation_result2').innerHTML=resptmp.replace(/\\n/ig,'<br>');
			                		doc.getElementById('SLG_shadow_translation_result').style.direction = "ltr";
							doc.getElementById('SLG_shadow_translation_result').style.textAlign = "left";
				

							if(t == "ar" || t == "he" || t == "fa" || t == "yi" || t == "ur" || t == "ps" || t == "sd" || t == "ckb" || t == "ug" || t == "dv" || t == "prs"){
								doc.getElementById('SLG_shadow_translation_result').style.direction = "rtl";
								doc.getElementById('SLG_shadow_translation_result').style.textAlign = "right";
							}
				       		        TranslatorIM.SLG_JUMP(doc);
							setTimeout(function() {	
								var HID=2;
							        if (TranslatorIM.SLG_TH_2 == 1){
					     				var doc2 = FExtension.browserInject;
									var SLnow = new Date();
									SLnow = SLnow.toString();
									var TMPtime = SLnow.split(" ");
									var CurDT = TMPtime[1] + " " + TMPtime[2] + " " + TMPtime[3] + ", " + TMPtime[4];
		        			                	var LNGfrom = f;
						                        if(f=="auto" || doc.getElementById("SLG_locer").checked == false) var LNGfrom = TranslatorIM.LNGforHISTORY;
									if(TranslatorIM.SLG_WRONGLANGUAGEDETECTED==1) LNGfrom="auto";
                	                        			text=text.replace(/~/ig," ");
								        text=text.replace(/\^/g,"@");
								        var DICT = TranslatorIM.BL_T_PROV;
									if(TranslatorIM.SLG_MODE==1) DICT = TranslatorIM.BL_D_PROV;
									doc2.runtimeSendMessage({greeting:"[b]" + TranslatorIM.SLG_TEMP_TEXT + "~~" + text + "~~" + LNGfrom + "|" + t + "~~"+ doc.location+"~~"+CurDT+"~~"+HID+"~~"+DICT[0]+"^^"}, function(response) {
										if(response){ }
									});
								}
							}, 500);
					    	}else{
							var msg = "Due to too many requests coming from your IP address, access to the free Yandex Translator has been temporarily disabled. Please try again later.";
			                		doc.getElementById('SLG_shadow_translation_result').innerHTML=msg;
			                		doc.getElementById('SLG_shadow_translation_result2').innerHTML=msg;
					    	}
						doc.getElementById('SLG_loading').style.display = 'none';
			            }
				}
			      });
			    },50);  
 		         },50);  
		}
	},

	SLG_BBL_OBJ_OFF: function(st){		
	     	var doc = FExtension.browserInject.getDocument();
		TranslatorIM.CONTROL_SUM="";
		if (st == 0){ 
			if(TranslatorIM.SLG_SAVETEXT == 0){
				if(doc.getElementById("SLG_balloon_obj")) doc.body.removeChild (doc.getElementById("SLG_balloon_obj"));			
			}
		} else{
			if(doc.getElementById("SLG_balloon_obj")) doc.body.removeChild (doc.getElementById("SLG_balloon_obj"));			
		}
	},

	BBL_IfMouseIsInside: function(e){
		var doc = FExtension.browserInject.getDocument();
		var st = 0;
		var THEobj = doc.getElementById('SLG_shadow_translator');
		if(THEobj){
			var divRect = THEobj.getBoundingClientRect();
			if (e.clientX >= (divRect.left-20) && e.clientX <= divRect.right && e.clientY >= divRect.top && e.clientY <= divRect.bottom) st=1;
		}
		return(st);
	},

	InitiateIT_target_lang: function(){
	     	var doc = FExtension.browserInject.getDocument();
	        var container = doc.body;
	        if(FExtension.browserInject.getSelectionText()!=""){
                  if(container){
		          var ext = FExtension.browserInject;
			  var theObj = doc.getElementById("SLG_MENU");
                          if(theObj) theObj.parentNode.removeChild(theObj);
			  var OB = doc.createElement('div');
			  var id = doc.createAttribute("id");
			  id.value = "SLG_MENU";
		          OB.setAttributeNode(id);
			  var cl = doc.createAttribute("class");
			  cl.value = "skiptranslate";
		          OB.setAttributeNode(cl);

        		  container.appendChild (OB);
                          var OB2="";
		          var act = "";
			  var MENU = TranslatorIM.SLG_LNG_LIST.split(",");
			  var splt = 0;
		     	  if(MENU.length>=TranslatorIM.SLG_FAV_START){
				  var SLG_FAV_LANGS_LONG = TranslatorIM.SLG_ADD_LONG_NAMES(TranslatorIM.SLG_FAV_LANGS_IT);
				  if(SLG_FAV_LANGS_LONG!=""){
					var favArr=SLG_FAV_LANGS_LONG.split(","); 
					for(var I=0; I < favArr.length; I++){
					    var CURlang = favArr[I].split(":");
					    act = "";
					    if (I==0) {
						act=" selected ";
					        TranslatorIM.SLG_langDst_bbl2 = CURlang[0];
						TranslatorIM.SLG_SAVE_FAVORITE_LANGUAGES(CURlang[0], '', 1, TranslatorIM.SLG_FAV_LANGS_IT, "IT");
					    }
					    OB2 = OB2 + "<option " + act +" value='"+CURlang[0]+"'>"+CURlang[1]+"</option>";
					}
					var all = FExtension.element(TranslatorIM.SLG_LOC,"extwptDAll");
				        OB2 = OB2 + "<option disabled value=''>-------- [ "+ all +" ] --------</option>";
				  }
				  splt=1;
			  }

			  TranslatorIM.SLG_LNG_LIST = TranslatorIM.CUSTOM_LANGS(FExtension.element(TranslatorIM.SLG_LOC,'extLanguages'));
			  var MENU = TranslatorIM.SLG_LNG_LIST.split(",");
			  for(var J=0; J < MENU.length; J++){
			    CURlang = MENU[J].split(":");
			    if(splt == 1 ){
				    if(SLG_FAV_LANGS_LONG==""){
					    var act2 = "";
					    if(TranslatorIM.SLG_langDst_it == CURlang[0] ) act2=" selected ";
				    }
			    } else { 
				    var act2 = "";
				    if(TranslatorIM.SLG_langDst_it == CURlang[0] ) act2=" selected ";
			    }
			    OB2 = OB2 + "<option "+ act2 +" value='"+CURlang[0]+"'>"+CURlang[1]+"</option>";
			  }
			  var OBCLOSE = "<div src='#'  title='"+FExtension.element(TranslatorIM.SLG_LOC,'extClose')+"' id='SLG_MENU_CLOSE'></div>";
			  var OBMENU = "<select id='SLG_IT_MENU'>" + OB2 + "</select>";
			  var OBLINKS = "<div id='SLG_MENU_LINKS' align=center><a id='SLG_MENU_LINK_OPT' href='"+FExtension.browserInject.getURL('content/html/options/options.html?it')+"' target='_blank'>"+FExtension.element(TranslatorIM.SLG_LOC,"extOptions")+"</a> : <a id='SLG_MENU_LINK_HIS' href='"+FExtension.browserInject.getURL('content/html/options/options.html?hist')+"' target='_blank'>"+FExtension.element(TranslatorIM.SLG_LOC,"extHistory")+"</a></div>";
			  doc.getElementById("SLG_MENU").innerHTML=OBCLOSE+"<span id='SLG_MENU_TTL'>" + FExtension.element(TranslatorIM.SLG_LOC,"extSeTa")+"</span><br>"+OBMENU + OBLINKS ;
		  	  doc.getElementById('SLG_MENU_CLOSE').style.background='url('+ext.getURL('content/img/util/close.png')+')';
		  	  doc.getElementById('SLG_IT_MENU').style.background='#fff url('+ext.getURL('content/img/util/select.png')+')  no-repeat 100% 0';

		  }
		}
	},




	InitiateWPT_target_lang: function(LN){
	     	var doc = FExtension.browserInject.getDocument();
	        var container = doc.body;
                  if(container){
		          var ext = FExtension.browserInject;
			  var OB = doc.createElement('div');
			  var id = doc.createAttribute("id");
			  id.value = "SLG_MENU_WPT";
		          OB.setAttributeNode(id);
			  var cl = doc.createAttribute("class");
			  cl.value = "skiptranslate";
		          OB.setAttributeNode(cl);

        		  container.appendChild (OB);
                          var msg = "<b>'"+LN+"'</b><br>" + FExtension.element(TranslatorIM.SLG_LOC,"extnotsupported");
                          //var msg = "Google Translate does not support<br> '<b>"+LN+"</b>' language yet";

			  var OBCLOSE = "<div src='#' title='"+FExtension.element(TranslatorIM.SLG_LOC,'extClose')+"' id='SLG_WPT_MENU_CLOSE'></div>";
			  doc.getElementById("SLG_MENU_WPT").innerHTML=OBCLOSE+"<div id='SLG_MENU_TTL' style='margin-top:10px;'>" + msg + "</div><br>";
		  	  doc.getElementById('SLG_WPT_MENU_CLOSE').style.background='url('+ext.getURL('content/img/util/close.png')+')';
		  }
	},


	CloseIT_target_lang: function(){
	     	var doc = FExtension.browserInject.getDocument();
		var theObj = doc.getElementById("SLG_MENU");
                if(theObj) theObj.parentNode.removeChild(theObj);
	},

	SLG_IT_retranslate: function(){
	     	var doc = FExtension.browserInject.getDocument();
		FExtension.browserInject.runtimeSendMessage({greeting: "SES_IT:>" + doc.getElementById("SLG_IT_MENU").value}, function(response) {}); 
		TranslatorIM.SLG_langDst_it=doc.getElementById("SLG_IT_MENU").value;
	        TranslatorIM.SLG_SAVE_FAVORITE_LANGUAGES(TranslatorIM.SLG_langDst_it, '', 1, TranslatorIM.SLG_FAV_LANGS_IT, "IT");
		runinliner();
		TranslatorIM.SLG_ONETIMERUN=1;
		TranslatorIM.CloseIT_target_lang();
	},

	SLG_IT_retranslate_and_close: function(){
	     	var doc = FExtension.browserInject.getDocument();
		runinliner();
		TranslatorIM.SLG_ONETIMERUN=1;
		TranslatorIM.CloseIT_target_lang();
	},

	SAVE_SES_PARAMS: function(){
	     	var doc = FExtension.browserInject.getDocument();
//		if(doc.getElementById("SLG_balloon_obj")) {
			//if(TranslatorIM.SLG_langDst!=TranslatorIM.SLG_langDst_bbl2) doc.getElementById("SLG_lng_to").value=TranslatorIM.SLG_langDst_bbl2;
			var dofrom = doc.getElementById("SLG_lng_from").value;
			var doto = doc.getElementById("SLG_lng_to").value;
/*
			if(TranslatorIM.FlippedByAuto == 1){
				var dofrom = TranslatorIM.SLG_langSrc;
				var doto = TranslatorIM.SLG_langDst;
			}
*/
			if(doto == "") doto = TranslatorIM.SLG_langDst;
			FExtension.browserInject.runtimeSendMessage({greeting: "SES:>" + dofrom +","+doto+","+TranslatorIM.SLG_FONT_SID+","+TranslatorIM.SLG_SID_PIN+","+doc.getElementById('SLG_locer').checked+","+TranslatorIM.SLG_OnOff_BTN2}, function(response) {}); 

//		}
	},

	i18n_LanguageDetect: function(text, st){
   		var lng="";
   		if(st==1){	
	  	      if(text.length>1){
				chrome.i18n.detectLanguage(text, function(result) {
					lng = result.languages[0].language;
				});
				if(lng=="zh") lng = "zh-CN";
				if(lng=="zh-Hant") lng = "zh-TW";
			}
		
			if(lng !=""){
				var LANGSALL = FExtension.element(TranslatorIM.SLG_LOC,'extLanguages').split(",");
				var cntr = 0;
       			        for (var i=0;i<LANGSALL.length;i++){
					var templang = LANGSALL[i].split(":");
		   			if(templang[0]==lng) cntr++;
				}
				if(cntr==0) lng="";
			}
		}
	
                TranslatorIM.ONCE_DETECT = 1;
		TranslatorIM.SLG_WPT_LANG=lng;
	    	return lng;
	},

	CNTR: function(id,dir,nmb){
	    FExtension.browserInject.runtimeSendMessage({greeting: "CNTR:>"+id+","+dir+","+nmb}, function(response) {}); 
	},

	CNTRP: function(id,dir,nmb){
	    FExtension.browserInject.runtimeSendMessage({greeting: "CNTRP:>"+id+","+dir+","+nmb}, function(response) {}); 
	},

	SLG_ADD_LONG_NAMES: function(codes){
		var OUT = "";
		var MENU = TranslatorIM.SLG_LNG_LIST.split(",");
		var FAV = codes.split(",");
		for (var i=0; i<FAV.length; i++){
			var MARKER = 0;
			for (var j=0; j<MENU.length; j++){
				var M = MENU[j].split(":");
				if(FAV[i] == M[0]){
					OUT = OUT + M[0] + ":" + M[1];
					MARKER=1;
				}
			}
			if(MARKER==1){
				if(i <= FAV.length) OUT = OUT + ","
			}
		}
		if(OUT.slice(-1)==",") 	OUT = OUT.slice(0, OUT.length - 1);
		return OUT;	
	},

	SLG_SAVE_FAVORITE_LANGUAGES: function(ln, ob, st, TR, TP){
		var OUT = "";
		var OUT2 = "";
		if(TR.indexOf(ln)!=-1){
			TR = TR.replace(ln+",",""); 
			if(TR.indexOf(",")==-1) TR = TR.replace(ln,""); 
		}

		OUT = ln + ",";	
		var ARR = TR.split(",");
		for (var i = 0; i < ARR.length; i++){
		 	OUT = OUT + ARR[i]+",";
		}
		if(OUT.slice(-1)==",") 	OUT = OUT.slice(0, OUT.length - 1);
		var TMP = OUT.split(",");
		if(TMP.length > TranslatorIM.SLG_FAV_MAX) {
			for (var j = 0; j < TMP.length-1; j++){
			 	OUT2 = OUT2 + TMP[j]+",";
			}		
			OUT = OUT2 
		}
		if(OUT.slice(-1)==",") 	OUT = OUT.slice(0, OUT.length - 1);
		FExtension.browserInject.runtimeSendMessage({greeting: "FAV_"+TP+":>" + OUT}, function(response) {}); 

		if(st == 0){
			if(OUT!=""){
				var MENU = TranslatorIM.SLG_LNG_LIST.split(",");
				if(MENU.length>=TranslatorIM.SLG_FAV_START){
					TranslatorIM.SLG_REBUILD_TARGET_LANGUAGE_MENU(OUT,ob);
				}
			}
		}

	},

	SLG_REBUILD_TARGET_LANGUAGE_MENU: function (FAV, ob){
		var doc = FExtension.browserInject.getDocument();
		var MENU = TranslatorIM.SLG_LNG_LIST.split(",");
		if(MENU.length>=TranslatorIM.SLG_FAV_START){
        	        doc.getElementById(ob).innerText="";
			var SEL = 0;
			if(FAV!=""){
                        	FAV = TranslatorIM.SLG_ADD_LONG_NAMES(FAV);
				var favArr=FAV.split(","); 
				for(var J=0; J < favArr.length; J++){
				    var CURlang = favArr[J].split(":");
				    var OB_FAV = doc.createElement('option');

				    var v = doc.createAttribute("value");				    		
				    v.value = CURlang[0];
				    OB_FAV.setAttributeNode(v);

				    if(J == 0){
					    var sel = doc.createAttribute("selected");
					    sel.value = "selected";
					    OB_FAV.setAttributeNode(sel);
					    TranslatorIM.SLG_langDst = CURlang[0];
					    SEL = 1;	
				    }

				    OB_FAV.appendChild(doc.createTextNode(CURlang[1]));
				    doc.getElementById(ob).appendChild(OB_FAV);
				}
				OB_FAV = doc.createElement('option');
				var d = doc.createAttribute("disabled");
				d.value = true;
				OB_FAV.setAttributeNode(d);
				var all = FExtension.element(TranslatorIM.SLG_LOC,"extwptDAll");
			    	OB_FAV.appendChild(doc.createTextNode("-------- [ "+ all +" ] --------"));
			    	doc.getElementById(ob).appendChild(OB_FAV);
			}
			var tmp =favArr[0].split(":");
		        var thelang = tmp[0];
			for(J=0; J < MENU.length; J++){
			    CURlang = MENU[J].split(":");
			    var option = doc.createElement('option');
			    if(SEL == 0){
				    if(CURlang[0] == thelang){
					    var sel = doc.createAttribute("selected");
					    sel.value = "selected";
					    option.setAttributeNode(sel);
				    }
			    }
			    v = doc.createAttribute("value");
			    v.value = CURlang[0];
			    option.setAttributeNode(v);
			    option.appendChild(doc.createTextNode(CURlang[1]));
			    doc.getElementById(ob).appendChild(option);
			}
		} else {
			doc.getElementById(ob).innerText="";
		        var thelang = TranslatorIM.SLG_langDst;
			if(TranslatorIM.SLG_langDst!="" && TranslatorIM.SLG_SID_TO=="") thelang = TranslatorIM.SLG_langDst_bbl2;
			for(J=0; J < MENU.length; J++){
			    CURlang = MENU[J].split(":");
			    var option = doc.createElement('option');
			    if(CURlang[0] == thelang){
				    var sel = doc.createAttribute("selected");
				    sel.value = "selected";
				    option.setAttributeNode(sel);
			    }
			    v = doc.createAttribute("value");
			    v.value = CURlang[0];
			    option.setAttributeNode(v);
			    option.appendChild(doc.createTextNode(CURlang[1]));
			    doc.getElementById(ob).appendChild(option);
			}

		}
	},

	OPEN_BG_OPTIONS: function(st){
		FExtension.browserInject.runtimeSendMessage({greeting: "OPEN_O:>"+st}, function(response) {});
        },

	CloseAnyOpenTranslator: function(){
	        if(top.window.frames[":0.container"]){
		      	var win = top.window.frames[":0.container"].contentWindow;
			if(win.document){
				win.document.getElementById(':0.close').click();
				TranslatorIM.SLG_BAR_STOP();
			}
		}
	},

	closeWPT_ERROR_MSG: function(){
		var doc = FExtension.browserInject.getDocument();
//		doc.getElementById("SLG_MENU_WPT").style.display='none';
		doc.getElementById("SLG_MENU_WPT").style.top='-1000px';
	},

	NoProvidersAlert: function(){
		var doc = FExtension.browserInject.getDocument();
		var T = doc.getElementById('SLG_lng_to').value;
	   	var msg = FExtension.element(TranslatorIM.SLG_LOC,"extLPNotSupported");
	   	var selectDst = doc.getElementById('SLG_lng_to');
	   	var selectedDstIndex = selectDst.selectedIndex;
	   	var selectedDstText = selectDst.options[selectedDstIndex].text; 

	   	var selectSrc = doc.getElementById('SLG_lng_from');
	   	var selectedSrcIndex = selectSrc.selectedIndex;
	   	var selectedSrcText = selectSrc.options[selectedSrcIndex].text; 
		if(selectSrc.value=="auto") selectedSrcText=TranslatorIM.SLG_GetLongName(TranslatorIM.SLG_DETECT);
	   	msg = msg.replace("XXX",selectedSrcText);
	   	msg = msg.replace("YYY",selectedDstText);
		msg = msg + "<br><br>" + "Please activate all providers in the Options";
	   	doc.getElementById('SLG_shadow_translation_result').style.visibility="visible";
	   	doc.getElementById('SLG_shadow_translation_result2').style.visibility="visible";

	   	doc.getElementById('SLG_shadow_translation_result').innerHTML="<div align=center style='color:red;margin-top:20px;'>"+msg+"</div>";
	   	doc.getElementById('SLG_shadow_translation_result2').innerHTML="<div align=center style='color:red;margin-top:20px;'>"+msg+"</div>";
	   	TranslatorIM.SLG_SAVE_FAVORITE_LANGUAGES(T, 'SLG_lng_to', 0, TranslatorIM.SLG_FAV_LANGS_BBL, "BBL");
	},

	DetectBig5: function(myTransText){
	    	var all = myTransText.length;
		var count = 0;
		for (var i = 0, len = myTransText.length; i < len; i++) {
			var rr = myTransText[i].match(/[\u3400-\u9FBF]/);
			if(rr) count ++;
	    	}
		var other = all-count;
		var OUT = 0	
		if(other<=count) OUT=1
		return(OUT);
	}

}


if(FExtension.browser.isLocalStoragePreset()){
	TranslatorIM.init();
}else{
	var appcontent = window.document.getElementById("appcontent");
	appcontent.addEventListener("DOMContentLoaded", function(){
		TranslatorIM.init();
       		init();
	}, false);
}


window.addEventListener("DOMContentLoaded", TranslatorIM.SLG_GOOGLE_WPT(), false);

}catch(e){
//	TranslatorIM.SLG_alert(FExtension.element(TranslatorIM.SLG_LOC,"extError2"));
}


