'use strict';
var FBOX="";
var TBOX="";
var AVOIDAUTODETECT=FExtension.store.get("AVOIDAUTODETECT");
var SLG_DARK="invert(95%)";
var SLG_DETECT="";
var DetLangName="";
var STOPLOOP=0;
var SLG_TEMPKEYSTRING="";
var SLG_KEYCOUNT={ length: 0 };
var SLG_KEYSTRING = "";
var SLG_WRONGLANGUAGEDETECTED=0;
var TEMPresult="";
var GTTS_length=200;
var ListProviders="";
var PROV = "";
var SLDetLngCodes =    new Array ();
var SLDetLngNames =    new Array ();
var TTSbackupLangs="zh,zt,en,de,hi,id,it,nl,pl,es,ru,ja,ko,fr,pt";
var synth = window.speechSynthesis;
var TheVolume=10;
var TheNewText = "";
var TheNewLang = "";
var FirstLoop = 0;
var SLG_EVENT = "";
var YSID = "";
var YSIDold = "";
var YSIDstatus = false;
var BOXCONTENT = "";
var globaltheQ = "";
var GLOBAL_WIDTH = 555;
var GLOBAL_HEIGHT = 570; //540
var WINDOW_TYPE = FExtension.store.get("WINDOW_TYPE");

var SLG_BaseLanguages = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLanguages');
var SLG_Languages = CUSTOM_LANGS(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLanguages'));
var SLG_LanguagesExt = CUSTOM_LANGS(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLanguagesNew'));
var ALLvoices = FExtension.bg.ImTranslatorBG.ALLvoices;
var SLG_FAV_LANGS_IMT = FExtension.store.get("SLG_FAV_LANGS_IMT");
var SLG_FAV_MAX = FExtension.store.get("SLG_FAV_MAX");
var SLG_FAV_START = FExtension.store.get("SLG_FAV_START");

var BASELANGSCodes =    new Array ();
var BASELANGSNames =    new Array ();

window.addEventListener('resize', function(e){ GLOBAL_WIDTH = window.innerWidth; SLG_GLOBAL_RESIZER(); }, false);

var SLWINDOW = setInterval(function(){
	localStorage["WINDOW_TOP"]=window.screenTop;
	localStorage["WINDOW_LEFT"]=window.screenLeft;
},1500);

if(localStorage["SLG_other_gt"]=="1"){   
	LISTofPR = FExtension.store.get("SLG_ALL_PROVIDERS_GT").split(",");
} else LISTofPR[0]="Google";


for (var SLG_I = 0; SLG_I < LISTofPR.length; SLG_I++){
    switch(LISTofPR[SLG_I]){
	case "Google": LISTofPRpairs[SLG_I]=LISTofLANGsets[0];break;
	case "Microsoft": LISTofPRpairs[SLG_I]=LISTofLANGsets[1];break;
	case "Translator": LISTofPRpairs[SLG_I]=LISTofLANGsets[2];break;
	case "Yandex": LISTofPRpairs[SLG_I]=LISTofLANGsets[3];break;
    }	
}



var SLG_BaseLnum = SLG_BaseLanguages.split(",");
for(var i = 0; i < SLG_BaseLnum.length; i++){
        var SLG_basetmp = SLG_BaseLnum[i].split(":");
	BASELANGSCodes.push(SLG_basetmp[0]);
	BASELANGSNames.push(SLG_basetmp[1]);
}



var SLG_Lnum = SLG_Languages.split(",");
for(var i = 0; i < SLG_Lnum.length; i++){
        var SLG_tmp = SLG_Lnum[i].split(":");
	SLDetLngCodes.push(SLG_tmp[0]);
	SLDetLngNames.push(SLG_tmp[1]);
}

var SLDetLngCodesExt =    new Array ();
var SLDetLngNamesExt =    new Array ();
var SLG_LnumExt = SLG_LanguagesExt.split(",");
for(var i = 0; i < SLG_LnumExt.length; i++){
        var SLG_tmpExt = SLG_LnumExt[i].split(":");
	SLDetLngCodesExt.push(SLG_tmpExt[0]);
	SLDetLngNamesExt.push(SLG_tmpExt[1]);
}

(function(){document.addEventListener("mousedown",function(){
 try{
   var id = event.target.id;

	 var target = event.target || event.srcElement;
	 var className = target.className;
	 if(className == "_ALNK") {
	    var tags = document.getElementsByClassName("_ALNK");
	    for (var j=0; j<tags.length; j++){
		FExtension.store.set("AVOIDAUTODETECT",1);
		FExtension.store.set("AVOIDAUTODETECT_LNG",SLG_DETECT);
		j=1000; 
	    }
	 }


   SLG_EVENT=event;
   if(id=="SLG_00")   tagClick(event);

   if(GEBI("SLG_myRange")){
	if(SLG_getTEMP("TTSvolume")==null || SLG_getTEMP("TTSvolume")=="undefined" || SLG_getTEMP("TTSvolume")=="") SLG_setTEMP("TTSvolume","5");
	else SLG_setTEMP("TTSvolume",GEBI("SLG_myRange").value);
	if(GEBI("SLG_myRange").value==0) GEBI("SLG_volume").className="SLG_novolume";
	else GEBI("SLG_volume").className="SLG_volume";
	TheVolume = GEBI("SLG_myRange").value;
   }	
   if(id == "SLG_controls"){
	//var FirstLoop = 0;
	PlayPause("SLG_controls", event);
   }	
   if(id == "SLG_volume"){
	synth.cancel();
        if(GEBI(id).className=="SLG_novolume") {
		GEBI("SLG_myRange").value = 5;
		GEBI("SLG_volume").className="SLG_volume";
	} else { 
		GEBI("SLG_myRange").value = 0;
		GEBI("SLG_volume").className="SLG_novolume";
	}
	SLG_setTEMP("TTSvolume",GEBI("SLG_myRange").value);
	Start_GOOGLE_TTS_backup();

   }	
   if(id == "SLG_myRange"){
	synth.cancel();
	if(GEBI("SLG_myRange").value>0)	GEBI("SLG_volume").className="SLG_volume";
	else 	GEBI("SLG_volume").className="SLG_novolume";
    	setTimeout(function(){
		SLG_setTEMP("TTSvolume",GEBI("SLG_myRange").value);
		Start_GOOGLE_TTS_backup();
        },500);

   }
 }catch(ext){}
},!1);} )();


document.onkeydown=function(event){
  if(localStorage["SLG_HK_btnbox"]=="true"){
        var keyCode = ('which' in event) ? event.which : event.keyCode;
    	setTimeout(function(){
	    	if(!SLG_KEYCOUNT[keyCode] && SLG_KEYCOUNT.length<3)   {
        		SLG_KEYCOUNT[keyCode] = true;
		        SLG_KEYCOUNT.length++;
			SLG_KEYSTRING=SLG_KEYSTRING+keyCode+":|";
                	if(SLG_KEYSTRING!="")SLG_TEMPKEYSTRING=SLG_KEYSTRING;
		}
        },35);
  }
};

document.onkeyup=function(event){
  if(localStorage["SLG_HK_btnbox"]=="true"){
	var SLG_HKL = SLG_HK_TRANSLATE().toLowerCase();
	var SLG_DBL = localStorage["SLG_HK_btn"]+":|";
        SLG_DBL=SLG_DBL.replace(/ \+ /g,":|").toLowerCase();
	if(SLG_HKL == SLG_DBL || event.keyCode == 13) {
		SLG_DICT();
	}
  }	
};

(function(){var c2=GEBI("SLG_logo-link");c2.addEventListener("click",function(){startCopyright();},!1);} )();
(function(){var w=GEBI("SLG_switch");w.addEventListener("click",function(){langSWITCHER();SLG_DICT();},!1);} )();
(function(){var t=GEBI("SLG_trans_button");t.addEventListener("click",function(){SLG_INIT_DICT();},!1);} )();
(function(){var l1=GEBI("SLG_langSrc");l1.addEventListener("change",function(){Switch();SLG_DICT();},!1);} )();
(function(){var l2=GEBI("SLG_langDst");l2.addEventListener("change",function(){Switch();SLG_DICT();},!1);} )();
(function(){var c=GEBI("SLG_dst_delete");c.addEventListener("click",function(){DICTClear();},!1);} )();
(function(){var tts=GEBI("SLG_dict_tts");tts.addEventListener("click",function(){SLG_Voice();},!1);} )();
(function(){var pp=GEBI("SLG_PP");pp.addEventListener("click",function(){startURL("https://imtranslator.net"+_CGI+"&a=0");},!1);} )();
(function(){var loc=GEBI("SLlocpl");loc.addEventListener("click",function(){GEBI("SLG_DETECTED").style.display="none";SLG_DETECT = "";LOCcontrol();SLG_DICT();},!1);} )();
(function(){GEBI("SLG_CloseAlert").addEventListener("click",function(){SLShowHideAlert();},!1);} )();
(function(){GEBI("SLG_CloseAlertBTN").addEventListener("click",function(){SLShowHideAlert();},!1);} )();
(function(){GEBI("SLG_tab1").addEventListener("click",function(){GoToTranslator();},!1);} )();
(function(){
    window.addEventListener('click',function(){
	  var id = event.target.id;
	  if(id.indexOf("SLG_P")!=-1){
		SLG_FindTranslator(id);
	  }
    },!1);
})();


(function(){GEBI("SLG_DICTtext").addEventListener("click",function(){REMOTE_Voice_Close();},!1);} )();
(function(){GEBI("SLG_dst_delete").addEventListener("click",function(){REMOTE_Voice_Close();},!1);} )();
(function(){GEBI("SLG_DICTtext").addEventListener("change",function(){SAVEtheSTATE();},!1);} )();

function SLG_FindTranslator(ob){ 
 if(SLG_WRONGLANGUAGEDETECTED==0){
  var tr = GEBI(ob).outerHTML.replace(/(<([^>]+)>)/ig,"");
  if(ListProviders.indexOf(tr)!=-1)SLG_SET_DICT_PRIVIDER(tr);
 } else {
	for(var i=0; i<LISTofPR.length; i++){
		if(GEBI("SLG_P"+i).title.toLowerCase() == "google"){GEBI("SLG_P"+i).className="SLG_TAB_DICT";}
		else GEBI("SLG_P"+i).className="SLG_TAB_DEACT_DICT";
	}
 }
}

(function(){
    window.addEventListener('blur',function(){
        FExtension.browserPopup.addOnMessageListener(
            function(request, sender, sendResponse) {
                if (request.greeting == "hello"){
                    self.close();
                }
                if (request.greeting == "hello2"){
                    self.close();
                }
            }
        );
    },!1);
})();
	
(function(event){
 SESSION();
 setTimeout(function(){ LOCcontrol();},350);
})();

SLG_Tabs_Maker();

for(var I=0; I<LISTofPR.length; I++){
   (function(){GEBI("SLG_P"+I).addEventListener("click",function(){SLG_Tabs_Settler();},!1);} )();
}


function SLG_Tabs_Maker(){
  for(var I=0; I<LISTofPR.length; I++){
	  var OB = document.createElement('div');
	  var id = document.createAttribute("id");
	  id.value = "SLG_P"+I;
          OB.setAttributeNode(id);
	  var cl = document.createAttribute("class");
	  cl.value = "SLG_LABLE";
       	  OB.setAttributeNode(cl);
	  var tl = document.createAttribute("title");
	  tl.value = LISTofPR[I];
       	  OB.setAttributeNode(tl);
	  var st = document.createAttribute("style");
	  st.value = "margin-left:"+(75*I+10)+"px;position:absolute;margin-top:-29px;height:19px;width:64px";
	  if(I==(LISTofPR.length-1)) st.value = st.value + ";border-right:1px solid #BDBDBD";
       	  OB.setAttributeNode(st);
	  OB.appendChild(document.createTextNode(LISTofPR[I]));
          GEBI("SLG_PROVIDERS_DICT").appendChild(OB);

  }
  GEBI('SLG_PROVIDERS_DICT').style.marginTop='35px';
  GEBI('SLG_DICTsource').style.borderTop='1px solid #BDBDBD';
  if(localStorage["SLG_other_gt"]!="1"){
   if(GEBI('ClosedTab')) GEBI('ClosedTab').style.display='block';
  } 
  ACTIVATE_THEME_TABS(FExtension.store.get("THEMEmode"));
}


function SLG_Tabs_Settler(){
 var id = SLG_EVENT.target.id;
 var ind = id.replace("SLG_P","");
 if(GEBI(id).className!="SLG_LABLE_DEACT"){
	 SLG_setTEMP("DPROV",LISTofPR[ind]);
	 REMOTE_Voice_Close();
 }
 SET_PROV(ind);
}






function SLG_Voice (){
   var TTStext=GEBI('SLG_DICTtext').value.replace(/<br>/g, " ");
   GEBI("SLG_DETECTED").style.visibility="hidden";
   GEBI("SLG_DETECTED").style.display="none";
   //SLG_DETECT="";
   var MAYAK = 0;
   if(BOXCONTENT == GEBI("SLG_DICTtext").value) MAYAK = 1;
   if(MAYAK == 0){
	   BOXCONTENT = GEBI("SLG_DICTtext").value;
	   if(GEBI('SLlocpl').checked==false || GEBI('SLG_langSrc').value=="auto"){
		   if(DET==0) TTSDODetection(TTStext);
		   else       TTSSLDetectPATCH(TTStext);  	
	   }	
   }

   if(GEBI('SLG_alert100'))GEBI('SLG_alert100').style.display="none";
   var SLG_lng = GEBI("SLG_langSrc").value;
   SLG_lng = SLG_lng.replace("-TW","");
   SLG_lng = SLG_lng.replace("-CN","");

   GEBI('SLG_DICTtext').style.direction="ltr";
   GEBI('SLG_DICTtext').style.textAlign="left";
   if(SLG_lng=="ar" || SLG_lng=="iw" || SLG_lng=="fa" || SLG_lng=="yi" || SLG_lng=="ur" || SLG_lng=="ps" || SLG_lng=="sd" || SLG_lng=="ckb" || SLG_lng=="ug" || SLG_lng=="dv" || SLG_lng=="prs"){
  	 GEBI('SLG_DICTtext').style.direction="rtl";
	 GEBI('SLG_DICTtext').style.textAlign="right";
   }
   var tm = 2000;
   if(GEBI('SLlocpl').checked==true && GEBI('SLG_langSrc').value!="auto") tm=0;

   setTimeout(function(){
    if(GEBI('SLlocpl').checked==false || GEBI('SLG_langSrc').value=="auto"){
	   var SLG_from = SLG_IF_DETECT_IS_PRESENT(SLG_DETECT, GEBI("SLG_langSrc"));
	   GEBI("SLG_DETECTED").style.visibility="visible";
	   var DETECTEDlongName=DetLangName;

	   for (var z=0; z<BASELANGSCodes.length; z++){
       		if(SLG_from==BASELANGSCodes[z]) { DETECTEDlongName=BASELANGSNames[z];break; }
	   }
//     	   if(GEBI("SLG_langSrc").value=="auto") {SLG_from=SLG_DETECT; GEBI('SLG_DETECTED').innerTEXT = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetected') + " " + DETECTEDlongName;}
	   SLG_DETECT = SLG_from;
    }else  var SLG_from = GEBI("SLG_langSrc").value;
	   var text = TTStext;
	   TheNewText = TTStext;
	   switch(localStorage["SLG_SLVoices"]){
		case "0": if(ALLvoices.indexOf(SLG_from)!=-1){
                              if(SLG_TTS.indexOf(SLG_from)!=-1){
				if(text.length>GTTS_length) {
					if(SLG_from == "en-gb") SLG_from = "g_en-UK_f";
					window.open("https://text-to-speech.imtranslator.net/?dir="+SLG_from+"&text="+encodeURIComponent(text)); 
				}else Google_TTS(text,SLG_from);
			      } else Google_TTS(text,SLG_from);
			  } else {
				SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Voice'));
				//GEBI("SLG_DETECTED").style.display="none";
			  }
			  break;
		case "1": if(ALLvoices.indexOf(SLG_from)!=-1){
				if(G_TTS.indexOf(SLG_from)!=-1) Google_TTS(text,SLG_from);
				else SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Voice'));
			  } else {
				SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Voice'));
				//GEBI("SLG_DETECTED").style.display="none";
			  }

			  break;
		case "2": if(ALLvoices.indexOf(SLG_from)!=-1){
                              if(SLG_TTS.indexOf(SLG_from)!=-1) {
					if(SLG_from == "en-gb") SLG_from = "g_en-UK_f";
					window.open("https://text-to-speech.imtranslator.net/?dir="+SLG_from+"&text="+encodeURIComponent(text));
			      }else Google_TTS(text,SLG_from);
			  } else {
				SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Voice'));
				//GEBI("SLG_DETECTED").style.display="none";
			  }

			  break;
	   }

   },tm);
}

function SLG_IF_DETECT_IS_PRESENT(dl, ob){
	var resp=dl, out=0;
	if(GEBI('SLlocpl').checked==true){
		for(var i=0; i < ob.length; i++) if(ob[i].value == dl) out=1;
		if(out==0 && ob.value != "auto") resp = ob.value;
	} else resp = dl;
	return resp;
}


function Google_TTS(text,dir){
  text = text.replace(/`/ig,"'");
  if(localStorage["SLG_GVoices"]=="1"){
	if(text.length>GTTS_length){
	   text=text.substring(0,GTTS_length);
	   GEBI('SLG_alert100').style.display="block";
	}else REMOTE_Voice(dir,text);
  } else {
	if(dir == "en-gb") dir = "g_en-UK_f";
	startURL("https://text-to-speech.imtranslator.net/?dir="+dir+"&text="+encodeURIComponent(text));
  }	
}


function ___SLG_DICTSUBMIT(){ document.location="../popup/dictionary.html?key=0&text="+encodeURIComponent(GEBI('SLG_DICTtext').value); }

function tagClick(e){
   var SLG_to = GEBI(e.target.id).lang;
   SLG_to=SLG_to.replace("-TW","");
   SLG_to=SLG_to.replace("-CN","");
	   var text = GEBI(e.target.id).title;

	   TheNewText=text;
	   switch(localStorage["SLG_SLVoices"]){
		case "0": if(ALLvoices.indexOf(SLG_to)!=-1){
                              if(SLG_TTS.indexOf(SLG_to)!=-1){
				if(text.length>GTTS_length) {
					if(SLG_to == "en-gb") SLG_to = "g_en-UK_f";
					window.open("https://text-to-speech.imtranslator.net/?dir="+SLG_to+"&text="+encodeURIComponent(text)); 
				}else Google_TTS(text,SLG_to);
			      } else Google_TTS(text,SLG_to);
			  } else SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Voice'));
			  break;
		case "1": if(ALLvoices.indexOf(SLG_to)!=-1){
				if(G_TTS.indexOf(SLG_to)!=-1) Google_TTS(text,SLG_to);
				else SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Voice'));
			  } else SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Voice'));
			  break;
		case "2": if(ALLvoices.indexOf(SLG_to)!=-1){
                              if(SLG_TTS.indexOf(SLG_to)!=-1) {
					if(SLG_to == "en-gb") SLG_to = "g_en-UK_f";
					window.open("https://text-to-speech.imtranslator.net/?dir="+SLG_to+"&text="+encodeURIComponent(text));
			      }else Google_TTS(text,SLG_to);
			  } else SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Voice'));
			  break;
	   }

   e.stopPropagation();
   e.cancelBubble = true;
}


function CONSTRUCTOR(){
	if(localStorage["SLG_other_gt"]!="1"){
		GEBI('ClosedTabD').style.display='block';
	}


	window.addEventListener('load',function(){

	if(GEBI('SLG_DICTtext').value=="")  GEBI('SLG_DICTtext').value = GET_CGI();
	GEBI('SLG_DICTtext').value = GEBI('SLG_DICTtext').value.trim();

	SET_PROV();
	SET_FIRST_AVAILABLE_PROV();

	var OB = GEBI('SLG_langSrc');

	if(FExtension.store.get("SLG_LNG_LIST").indexOf("auto")!=-1 || FExtension.store.get("SLG_LNG_LIST")=="all"){
		var OB1 = document.createElement('option');
		var v = document.createAttribute("value");
		v.value = "auto";
		OB1.setAttributeNode(v);
		OB1.appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetect_language_from_box')));
		OB.appendChild(OB1); 
	}
	var SLG_TMP = SLG_Languages.split(",");
	for(var J=0; J < SLG_TMP.length; J++){
	    var SLG_TMP2=SLG_TMP[J].split(":");
	    var OB2 = document.createElement('option');
	    var v = document.createAttribute("value");
	    v.value = SLG_TMP2[0];
	    OB2.setAttributeNode(v);
	    OB2.appendChild(document.createTextNode(SLG_TMP2[1]));
	    OB.appendChild(OB2);
	}
	var SEL = 0;
	var OB3 = GEBI('SLG_langDst');
	var MENU = SLG_Languages.split(",");
        if(MENU.length>=SLG_FAV_START){
	        var SLG_FAV_LANGS_IMT_LONG = SLG_ADD_LONG_NAMES(SLG_FAV_LANGS_IMT);
		if(SLG_FAV_LANGS_IMT_LONG!=""){
			var favArr=SLG_FAV_LANGS_IMT_LONG.split(","); 
			for(var J=0; J < favArr.length; J++){
			    var CURlang3 = favArr[J].split(":");
			    var OB_FAV = document.createElement('option');
			    var v = document.createAttribute("value");
			    v.value = CURlang3[0];
			    OB_FAV.setAttributeNode(v);
			    if(J == 0){
				    var sel = document.createAttribute("selected");
				    sel.value = "selected";
				    OB_FAV.setAttributeNode(sel);
				    SEL = 1;
			//	    localStorage["SLG_langDst"]=CURlang3[0];
			//	    localStorage["SLG_langDst2"]=CURlang3[0];
			    }
			    OB_FAV.appendChild(document.createTextNode(CURlang3[1]));
			    OB3.appendChild(OB_FAV);
			}
			OB_FAV = document.createElement('option');
			var d = document.createAttribute("disabled");
			d.value = true;
			OB_FAV.setAttributeNode(d);
			var all = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extwptDAll');
	    		OB_FAV.appendChild(document.createTextNode("-------- [ "+ all +" ] --------"));
	            	OB3.appendChild(OB_FAV);
		}
	}

	for(var J=0; J < SLG_TMP.length; J++){
	    var SLG_TMP2=SLG_TMP[J].split(":");
	    var OB2 = document.createElement('option');
	    v = document.createAttribute("value");
	    v.value = SLG_TMP2[0];
	    OB2.setAttributeNode(v);
	    if(SEL == 0){	
		    if(J == 0){
			    var sel = document.createAttribute("selected");
			    sel.value = "selected";
			    OB2.setAttributeNode(sel);
//			    localStorage["SLG_langDst"]=SLG_TMP2[0];
//			    localStorage["SLG_langDst2"]=SLG_TMP2[0];
		    }
	    }
	    OB2.appendChild(document.createTextNode(SLG_TMP2[1]));
	    OB3.appendChild(OB2);
	}

	  SET_DICT_PROVIDER();


	  if(SLG_getTEMP("LOC")==""){
	        if(localStorage["SLG_no_detect"]=="false") GEBI('SLlocpl').checked=true;
		else GEBI('SLlocpl').checked=false;
	  }else{
		if(SLG_getTEMP("LOC")=="true")	GEBI('SLlocpl').checked = true;
		else                            GEBI('SLlocpl').checked = false;
	  }


	  GEBI('SLG_langSrc').value = localStorage["SLG_langSrc2"];
	  GEBI('SLG_langDst').value = localStorage["SLG_langDst2"];
	  FExtension.store.set("SLG_Flag", "TRUE");
	  FExtension.bg.ImTranslatorBG.SLG_Planshet_Reset();

	},!1);
	GEBI('SLG_h3').innerText="v."+FExtension.bg.ImTranslatorBG.Version();	
	GEBI('SLG_h2').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extTITLE')));

	GEBI('SLoptions_ttl').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extOptions');
	GEBI('SLhistory_ttl').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extHistory');
	GEBI('SLhelp_ttl').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extHelp');
	GEBI('SLG_PP').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extContribution_ttl');


	GEBI('SLG_dst_delete').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extClearText');
	GEBI('SLG_dict_tts').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extListen');
//	GEBI('SLG_DETECTED').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetected')));
	GEBI('SLG_DETECTED').appendChild(document.createTextNode(" "));
	GEBI('SLG_switch').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSwitch_languages_ttl');
	GEBI('SLG_trans_button').value=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extTrButton');

//	GEBI('SLG_powered').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extPowered')));
//	GEBI('SLG_DICTsource').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDictionary')));
	GEBI('SLlocpl').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLock_in_language');
	GEBI('SLG_tab1').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'exttabTrans')));
	GEBI('SLG_tab1').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'exttabTrans');
	GEBI('SLG_tab2').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'exttabDict')));
	GEBI('SLG_tab2').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'exttabDict');


	GEBI('SLcompare_ttl').title=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extView');


       	GEBI('SLG_translate_container_app').style.opacity="1";
	switch(PLATFORM){
	 case "Opera" : GEBI('SLhelp_a').href="https://about.imtranslator.net/tutorials/presentations/google-translate-for-opera/opera-translator-dictionary/"; break;
	 case "Chrome": GEBI('SLhelp_a').href="https://about.imtranslator.net/tutorials/presentations/imtranslator-for-chrome/google-dictionary/"; break;
	 default      : GEBI('SLhelp_a').href="https://about.imtranslator.net/tutorials/presentations/";break;
	}


	if(GEBI('SLG_donate')) GEBI('SLG_donate').addEventListener("mouseover",function(){SLG_DONATE_manu(1);},!1);
	if(GEBI('SLG_donate')) GEBI('SLG_donate').addEventListener("mouseout",function(){SLG_DONATE_manu(0);},!1);
	if(GEBI('SLG_donate_menu')) GEBI('SLG_donate_menu').addEventListener("mouseover",function(){SLG_DONATE_manu(1);},!1);
	if(GEBI('SLG_donate_menu')) GEBI('SLG_donate_menu').addEventListener("mouseout",function(){SLG_DONATE_manu(0);},!1);

	if(GEBI('M_D1')) GEBI('M_D1').addEventListener("click",function(){SLG_DONATE_links(1);},!1);
	if(GEBI('M_D2')) GEBI('M_D2').addEventListener("click",function(){SLG_DONATE_links(2);},!1);
	if(GEBI('M_D3')) GEBI('M_D3').addEventListener("click",function(){SLG_DONATE_links(3);},!1);
	if(GEBI('M_D4')) GEBI('M_D4').addEventListener("click",function(){SLG_DONATE_links(4);},!1);

	if(GEBI('SLcompare_ttl')) GEBI('SLcompare_ttl').addEventListener("mouseover",function(){SLG_VIEW_manu(1);},!1);
	if(GEBI('SLcompare_ttl')) GEBI('SLcompare_ttl').addEventListener("mouseout",function(){SLG_VIEW_manu(0);},!1);
	if(GEBI('SLG_view_menu')) GEBI('SLG_view_menu').addEventListener("mouseover",function(){SLG_VIEW_manu(1);},!1);
	if(GEBI('SLG_view_menu')) GEBI('SLG_view_menu').addEventListener("mouseout",function(){SLG_VIEW_manu(0);},!1);

	if(GEBI('M_V1')) GEBI('M_V1').addEventListener("click",function(){SLG_VIEW_link(1);},!1);
	if(GEBI('M_V2')) GEBI('M_V2').addEventListener("click",function(){SLG_VIEW_link(2);},!1);
	if(GEBI('M_V3')) GEBI('M_V3').addEventListener("click",function(){SLG_VIEW_link(3);},!1);

	SLG_GLOBAL_RESIZER();

}



function SESSION(){     
  CONSTRUCTOR();
  window.addEventListener('load', function(){
   setTimeout(function(){
    SLG_Flip_Langs(GEBI('SLG_langSrc').value);	
    var tags1 = document.getElementsByClassName("TTS1");
    for (var i=0; i<tags1.length; i++) tags1[i].addEventListener('mousedown', function(e){ tagClick(e) }, false);
    var tags2 = document.getElementsByClassName("TTS2");
    for (var i=0; i<tags2.length; i++) tags2[i].addEventListener('mousedown', function(e){ tagClick(e) }, false);
    var tags3 = document.getElementsByClassName("_V");
    for (var i=0; i<tags3.length; i++) tags3[i].addEventListener('mousedown', function(e){ tagClick(e) }, false);
   },1000);
  }, false);

   if(top!=self){
	GEBI('SLG_LR').align='left';
	GEBI('SLG_LR').style.marginLeft='5px';
	GEBI('SLG_body').style.overflowX='auto';
	GEBI('SLG_body').style.overflowY='auto';
	GEBI('SLG_l1').target='_parent';
	GEBI('SLG_l2').target='_parent';
	GEBI('SLG_l4').target='_parent';
//        FExtension.store.set("CUR_URL","undefined");
   }

   var resp = 1;
   if(localStorage["SLG_session"] != resp){
       	localStorage["SLG_session"]=resp;
	localStorage["SLG_Flag"]="FALSE";
	FExtension.store.set("SLG_GWPTHist", "");
   }

   if(localStorage["SLG_TS"]!=SLG_getTEMP("OLD_TS")){
   	localStorage["SLG_Flag"]="FALSE";
   	SLG_setTEMP("OLD_TS",localStorage["SLG_TS"]);
	SLG_setTEMP("DPROV","");
	PROV="";
	SLG_setTEMP("DIC_FIRSTRUN","");
   }

   setTimeout(function(){
	var cnt = 0;
	var tries = 10;
        var SLG_AUTRUN = setInterval(function(){
	   SET_PROV();
	   if(cnt < tries){
		   if(GEBI('SLG_DICTtext').value!=""){
			SLG_DICT();
			clearInterval(SLG_AUTRUN);
		   } else GEBI('SLG_loading').style.display='none';
	   } else clearInterval(SLG_AUTRUN);
	   cnt++;
	}, 10);  
   },250);
   ACTIVATE_THEME(FExtension.store.get("THEMEmode"));

}



function SLG_INIT_DICT(){
// if(GEBI('SLG_DICTtext').value=="") GEBI('SLG_DICTtext').value = GET_CGI();
 
 if(GEBI('SLG_DICTtext').value!=""){
	SLG_DICT();
 } else {
//	SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Text'));
	GEBI('SLG_loading').style.display="none";
	GEBI('SLG_DETECTED').style.display="none";
 }	

}



function SLG_DICT(){	

	SET_PROV();
        SET_FIRST_AVAILABLE_PROV();
	REMOTE_Voice_Close ();
	GEBI("SLG_DICTsource").innerText="";
	SLG_PROVIDER_ROUTER();
	ACTIVATE_THEME_TABS(FExtension.store.get("THEMEmode"));
}

function SLG_PROVIDER_ROUTER(){
   var DELAY = 550;
   var text = GEBI('SLG_DICTtext').value;

   if(text != ""){
	 text = text.trim();
	 GEBI('SLG_DICTtext').value = text;
   }

   GEBI('SLG_DETECTED').style.display="none";
   if(GEBI('SLlocpl').checked==false || GEBI('SLG_langSrc').value=="auto"){
      if(FExtension.store.get("AVOIDAUTODETECT")==0){

	var resp = i18n_LanguageDetect(text);

   	if(BOXCONTENT == GEBI("SLG_DICTtext").value){
		resp = SLG_DETECT;
	}

	if(resp == ""){
		BOXCONTENT = GEBI("SLG_DICTtext").value;
		var big5 = DetectBig5(text);
		if(big5 == 0){
			setTimeout(function(){
				if(DET==0) DODetection(text);
				else       SLDetectPATCH(text);		
			}, 50);
		}else{
			SLDetectPATCH(text);		
		}
	}else{
		var cnt=0;
        	for (var i=0;i<BASELANGSCodes.length;i++){
			if(resp == BASELANGSCodes[i]){
				cnt=1; 
				SLG_DETECT = BASELANGSCodes[i];
				if(SLG_WRONGLANGUAGEDETECTED==0){
		               	        GEBI("SLG_DETECTED").innerText = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetected')+" "+BASELANGSNames[i];
					GEBI("SLG_DETECTED").style.display='block';	
				}
			}
		}

		if(cnt==0){
                        SLG_WRONGLANGUAGEDETECTED=1;
		}else SLG_WRONGLANGUAGEDETECTED=0;

//	   SLG_Flip_Langs(SLG_DETECT);
    
	   SET_PROV();
           SET_FIRST_AVAILABLE_PROV();
	   DELAY = 0;
	}
      } else {
	SLG_DETECT=FExtension.store.get("AVOIDAUTODETECT_LNG");
      }	
      FExtension.store.set("AVOIDAUTODETECT",0);
      GEBI('SLG_DETECTED').style.display="block";
      GEBI("SLG_DETECTED").style.visibility="visible";

   } else { DELAY=0; SLG_DETECT=GEBI('SLG_langSrc').value;}

   GEBI('SLG_loading').style.display="block";	



   SLG_Flip_Langs(GEBI('SLG_langSrc').value);
   setTimeout(function(){

	SLG_SAVE_FAVORITE_LANGUAGES(GEBI('SLG_langDst').value);
	if(SLG_WRONGLANGUAGEDETECTED==1) SLG_setTEMP("DPROV","Google"); 
	if(ListProviders=="" && localStorage["SLG_other_gt"]=="1" && window.location.href.indexOf("dir=")==-1) NoProvidersAlert();
	else {
           var STATUS = DETERMIN_IF_LANGUAGE_IS_AVAILABLE();
	   if(STATUS == 0 && localStorage["SLG_other_gt"]=="0") NoProvidersAlert();
	   else {
		SET_PROV(0);
		switch(SLG_getTEMP("DPROV")){
			case "Google": GET_G_DICT();break;
			case "Microsoft": GET_M_DICT(); break;
			case "Translator": GET_T_DICT(); break;
			case "Yandex": GET_Y_DICT(); break;
		}
           }
	}

   },DELAY);
}




function GET_M_DICT(){  
   GEBI('SLG_DICTtext').value=GEBI('SLG_DICTtext').value.replace(/</ig,"");
   GEBI('SLG_DICTtext').value=GEBI('SLG_DICTtext').value.replace(/>/ig,"");
   var text = GEBI('SLG_DICTtext').value;
   GEBI('SLG_loading').style.display="block";	
        if(ListProviders.indexOf("Microsoft")!=-1){
	        var text = GEBI('SLG_DICTtext').value;
		var f = GEBI('SLG_langSrc').value;
		var t = GEBI('SLG_langDst').value;
		MS(f,t,text); 
	}
}
function GET_T_DICT(){ 
   GEBI('SLG_DICTtext').value=GEBI('SLG_DICTtext').value.replace(/</ig,"");
   GEBI('SLG_DICTtext').value=GEBI('SLG_DICTtext').value.replace(/>/ig,"");
   var text = GEBI('SLG_DICTtext').value;
   GEBI('SLG_loading').style.display="block";	
        if(ListProviders.indexOf("Translator")!=-1){
		var f = GEBI('SLG_langSrc').value;
		var t = GEBI('SLG_langDst').value;
		SLG_OTHER_PROVIDERS(text,f,t);
	}
}


function GET_G_DICT(){
 if(GEBI("SLG_DICTtext").value=="" && window.location.href.indexOf("&text=")==-1 && FExtension.store.get("SLG_SaveText_box_gt")==1) GEBI("SLG_DICTtext").value=FExtension.store.get("SLG_SavedText_gt").substring(0,100).replace(/\^/ig,"%");

 GEBI('SLG_DICTsource').innerTEXT="";
 var num = Math.floor((Math.random() * SLG_GEO.length)); 
 var theRegion = SLG_GEO[num];
 if(FExtension.store.get("SLG_DOM")!="auto") theRegion=FExtension.store.get("SLG_DOM");
 var baseUrl = "https://translate.google."+theRegion+"/translate_a/single";

 var text = GEBI('SLG_DICTtext').value;


 GEBI('SLG_loading').style.display="block";
 if(GEBI('SLG_DICTtext').value=="")text = GET_CGI();
 text=text.trim();
// text=text.replace(/#/g,"");
// text=text.replace(/%/g,"");
// text=text.replace(/\./gi,"");
 text=text.replace(/\)/gi,"");
 text=text.replace(/\(/gi,"");
// text=text.replace(/\"/gi,"'");
 text=text.replace(/\�/gi,"");
 text=text.replace(/\�/gi,"");
 text=text.replace(/>/gi,"");
 text=text.replace(/</gi,"");
 text = truncStrByWord(text,100);
 text=text.trim();

 FExtension.store.set("SLG_SavedText_gt",text);
// if(GEBI("SLG_langSrc").value=="")GEBI("SLG_langSrc").value=localStorage["SLG_langSrc"];
// if(GEBI("SLG_langDst").value=="")GEBI("SLG_langDst").value=localStorage["SLG_langDst"];



 GEBI('SLG_DICTtext').value=text;
 if(text!=""){
//  if(localStorage["SLG_Flag"]=="FALSE") {var mySLG_langSrc = localStorage["SLG_langSrc"]; localStorage["SLG_langSrc2"]=localStorage["SLG_langSrc"];}
//  else	var mySLG_langSrc = localStorage["SLG_langSrc2"];
//  GEBI('SLG_langSrc').value = mySLG_langSrc;
  GEBI('SLG_DICTtext').style.direction="ltr";
  GEBI('SLG_DICTtext').style.textAlign="left";
  if(GEBI('SLG_langSrc').value=="ar" || GEBI('SLG_langSrc').value=="iw" || GEBI('SLG_langSrc').value=="fa" || GEBI('SLG_langSrc').value=="yi" || GEBI('SLG_langSrc').value=="ur" || GEBI('SLG_langSrc').value=="ps" || GEBI('SLG_langSrc').value=="sd" || GEBI('SLG_langSrc').value=="ckb" || GEBI('SLG_langSrc').value=="ug" || GEBI('SLG_langSrc').value=="dv" || GEBI('SLG_langSrc').value=="prs"){
  	GEBI('SLG_DICTtext').style.direction="rtl";
	GEBI('SLG_DICTtext').style.textAlign="right";
  }
  var text = GEBI('SLG_DICTtext').value;
          var SLIDL = setInterval(function(){

		if(SLG_DETECT!="") {
        	        clearInterval(SLIDL);
			if(GEBI('SLlocpl').checked==false || GEBI('SLG_langSrc').value=="auto") GEBI("SLG_DETECTED").style.visibility="visible";
			else GEBI("SLG_DETECTED").style.visibility="hidden";

			FExtension.store.set("SLG_langDst_name", GEBI("SLG_langDst").options[GEBI("SLG_langDst").selectedIndex].text);         
			FExtension.bg.ImTranslatorBG.SLG_Planshet_Reset();//SLG_callbackRequest2();


		        var SrcLng = GEBI('SLG_langSrc').value;
		        var DstLng = GEBI('SLG_langDst').value;

		        if(localStorage["SLG_no_detect"]=="true" || GEBI('SLG_langSrc').value=="auto"  || GEBI('SLlocpl').checked==false){
				SrcLng = SLG_DETECT;
			}
			var fromHistory=0;

			if(window.location.href.indexOf("dir=")!=-1){
			   try{
				var URI_LOCATION_TMP = window.location.href.split("dir=");
				var URI_LOCATION_TMP2 = URI_LOCATION_TMP[1].split("&");
				if(URI_LOCATION_TMP2[0].indexOf("|")!=-1){
					var URI_LOCATION_TMP3 = URI_LOCATION_TMP2[0].split("|");

					FBOX = URI_LOCATION_TMP3[0];
					TBOX = URI_LOCATION_TMP3[1];
					SrcLng = URI_LOCATION_TMP3[0];
					
					if(top==self) {
						//ImTranslator DICTIONARY links
						if(SLG_DETECT!="") SrcLng = SLG_DETECT;
						DstLng = localStorage["SLG_langDst2"];
					} else {
						//HISTORY ImTranslator DICTIONARY links
	                    			DstLng = URI_LOCATION_TMP3[1];
        	            			GEBI('SLG_langDst').value = DstLng;
				                //DstLng = localStorage["SLG_langDst2"];
						GEBI('SLG_langSrc').value = SrcLng;

						if(GEBI('SLG_langSrc').value==""){SrcLng=URI_LOCATION_TMP3[0]; }
						if(GEBI('SLG_langDst').value==""){DstLng=URI_LOCATION_TMP3[1]; }

					}
					fromHistory=1;
					SLG_DETECT = SrcLng;
				}
			   } catch (ex){}
			}

                        if(SLG_WRONGLANGUAGEDETECTED==1) SrcLng = "auto";
                        var dtxt = GEBI('SLG_DICTtext').value;

	  		localStorage["SLG_langSrc2"]=GEBI('SLG_langSrc').value;
			localStorage["SLG_langDst2"]=GEBI('SLG_langDst').value;


			SrcLng = SrcLng.replace("tlsl","tl");
			SrcLng = SrcLng.replace("srsl","sr");

			DstLng = DstLng.replace("tlsl","tl");
			DstLng = DstLng.replace("srsl","sr");


			var SLG_Params="client=gtx&dt=t&dt=bd&dj=1&source=input&q="+encodeURIComponent(dtxt.toLowerCase())+"&sl="+SrcLng+"&tl="+DstLng+"&hl=en";
//		        baseUrl = baseUrl + "?" + SLG_Params;
			var ajaxRequest;	
			try{
				ajaxRequest = new XMLHttpRequest();
			} catch (e){
				try{
					ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
				} catch (e) {
					try{
						ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
					} catch (e){
						SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extError1'));
						return false;
					}
				}
			}
			ajaxRequest.onreadystatechange = function(){
				if(ajaxRequest.readyState == 4){
					var mySourceLang = GEBI("SLG_langSrc").value;
					var myTargetLang = GEBI("SLG_langDst").value;
		                        var resp = ajaxRequest.responseText;
                                        var temp = new Array();
					if(resp.indexOf('trans":')!=-1){
                        		   if(resp.indexOf('reverse_translation')==-1){
                        		         if(resp.indexOf('"trans":"')!=-1){
	                                           resp = resp.replace(/\\"/ig,"'");
						   resp = resp.replace(/u0027/g,"'");
                	                           var R1 = resp.split('"trans":"'); 
                	                           var R2 = R1[1].split('"'); 
                                	           resp = R2[0];
                        	                 } else resp = resp.replace(/"/ig,'');
                        	                 
                                                 temp[0]=resp;

						 GEBI('SLG_DICTtext').style.direction="ltr";
						 GEBI('SLG_DICTtext').style.textAlign="left";
						 var SLG_lng = GEBI('SLG_langSrc').value;
						 if(localStorage["SLG_no_detect"]=="true" || SLG_lng=="auto") SLG_lng=SLG_DETECT;
						 if(SLG_lng=="ar" || SLG_lng=="iw" || SLG_lng=="fa" || SLG_lng=="yi" || SLG_lng=="ur" || SLG_lng=="ps" || SLG_lng=="sd" || SLG_lng=="ckb" || SLG_lng=="ug" || SLG_lng=="dv" || SLG_lng=="prs"){
						  	 GEBI('SLG_DICTtext').style.direction="rtl";
							 GEBI('SLG_DICTtext').style.textAlign="right";
						 }

						 GEBI('SLG_DICTsource').style.direction="ltr";
						 GEBI('SLG_DICTsource').style.textAlign="left";

						 if(GEBI('SLG_langDst').value=="ar" || GEBI('SLG_langDst').value=="iw" || GEBI('SLG_langDst').value=="fa" || GEBI('SLG_langDst').value=="yi" || GEBI('SLG_langDst').value=="ur" || GEBI('SLG_langDst').value=="ps" || GEBI('SLG_langDst').value=="sd" || GEBI('SLG_langDst').value=="ckb" || GEBI('SLG_langDst').value=="ug" || GEBI('SLG_langDst').value=="dv" || GEBI('SLG_langDst').value=="prs"){
						  	GEBI('SLG_DICTsource').style.direction="rtl";
							GEBI('SLG_DICTsource').style.textAlign="right";
						 }

//						 if(fromHistory==0) SLG_Flip_Langs(SLG_DETECT);

					   	 FExtension.bg.ImTranslatorBG.DIC_TRIGGER = 0;
					   } else {
						 FExtension.bg.ImTranslatorBG.DIC_TRIGGER = 0;
	                		         temp = SLG_DICTparser(resp);
						 temp[1] = temp[1].replace(/\"/ig,"'");
						 temp[1] = temp[1].replace(/\''/ig,"'");
						 temp[1] = temp[1].replace(/\\/g,"");
						 temp[0] = temp[0].replace(/u0027/g,"'");
		                                 temp[0] = temp[0].replace(/\\u0026/ig,"&");
               			                 temp[0] = temp[0].replace(/\\u003c/ig,"<");
               	                		 temp[0] = temp[0].replace(/\\u003e/ig,">");

			                         resp = temp[1] + temp[0];

					   }
					} else {

						FExtension.bg.ImTranslatorBG.DIC_TRIGGER=1;
						resp=""; 
						//resp='["VALERA"]'	
						if(resp.indexOf('[')!=-1 && resp.indexOf(']')!=-1 && resp.indexOf('[{')==-1){						
							resp=resp.replace('["','');
							resp=resp.replace('"]','');
						} else SLG_OTHER_PROVIDERS(text,SrcLng,DstLng);

					}

			                if(resp=="" || resp.indexOf("<h1>Not Found</h1>")>-1) SLG_OTHER_PROVIDERS(text,SrcLng,DstLng);
			                else{
					 CNTR('2331',SrcLng+"/"+DstLng, text.length);

       					 resp=resp.replace(/ \\u0026 /gi," & ");
       					 resp=resp.replace(/\\u0026/gi,"&");
       					 resp=resp.replace(/\\u003d/gi,"=");

		       			 resp = resp.replace(/\\/g,"");

					 var ForHistory=temp[0];			

       					 if(resp.indexOf("<div ")==-1) {
						resp = PseudoDICT(resp);
						ForHistory = resp;
					 }

					 GEBI('SLG_DICTsource').innerHTML=resp;
                                         GEBI('SLG_loading').style.display="none";

				   	 if(SLG_WRONGLANGUAGEDETECTED==1) {
						SLG_setTEMP("PROV","Google"); 
						for(var i=0; i<LISTofPR.length; i++){
				 			if(GEBI("SLG_P"+i).title.toLowerCase() == "google"){GEBI("SLG_P"+i).className="SLG_TAB_DICT";}
						}

						//SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Voice')); 
						//return false;
				   	 }


      				         if (localStorage["SLG_TH_1"]==1){
		                          var SLnow = new Date();
					  SLnow=SLnow.toString();
		                          var TMPtime=SLnow.split(" ");
                		          var CurDT=TMPtime[1]+" "+TMPtime[2]+" "+TMPtime[3]+", "+TMPtime[4];
		                          var HISTORYtype=6;
                		          if(resp.indexOf('id=_X')==-1) HISTORYtype=1;
		                          var LNGfrom = GEBI("SLG_langSrc").value;
                		          if(GEBI("SLG_langSrc").value=="auto" || localStorage["SLG_no_detect"]=="true" ) LNGfrom = SLG_DETECT;

					  if(SLG_WRONGLANGUAGEDETECTED==1) LNGfrom="auto";
					  setTimeout(function(){
					         var URL = localStorage["THE_URL"];
					         if(top.document.URL.indexOf("/options/options.html")!=-1)  URL = "";
						 localStorage["THE_URL"]="";

						 var txt = GEBI('SLG_DICTtext').value;
                                                 txt=txt.replace(/~/ig," ");
       	                                         ForHistory=ForHistory.replace(/~/ig," ");

	        		                 localStorage["SLG_History"]=txt + "~~" + ForHistory + "~~" + LNGfrom + "|" + GEBI("SLG_langDst").value + "~~"+ URL +"~~"+CurDT+"~~"+HISTORYtype+"^^" + localStorage["SLG_History"];
					  },500);
                		         }
                                         ACTIVATE_THEME_PARSER(FExtension.store.get("THEMEmode"));
                		        }

				    	setTimeout(function(){
						if(GEBI("_XR")){
							GEBI("_XR").style.float="left";
						}
				        },5);

				}
			}

			ajaxRequest.open("POST", baseUrl, true);
		        ajaxRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		        ajaxRequest.send(SLG_Params);
			setTimeout(function(){
			    var tags1 = document.getElementsByClassName("TTS1");
			    for (var i=0; i<tags1.length; i++) tags1[i].addEventListener('mousedown', function(e){ tagClick(e) }, false);
			    var tags2 = document.getElementsByClassName("TTS2");
			    for (var i=0; i<tags2.length; i++) tags2[i].addEventListener('mousedown', function(e){ tagClick(e) }, false);
			    var tags3 = document.getElementsByClassName("_V");
			    for (var i=0; i<tags3.length; i++) tags3[i].addEventListener('mousedown', function(e){ tagClick(e) }, false);
			},800);

		} 
	}, 900);  


 } else {
	GEBI("SLG_DETECTED").style.display='none';
        GEBI('SLG_loading').style.display="none";
 }	
}



function GEBI(id){ return document.getElementById(id);}

function GET_CGIforDir(){
 var resp="";
  if(window.location.search.indexOf("dir=")>-1){
   var text=window.location.search.split("dir=");
   if(text[1].indexOf("&text=")>-1){
    var text2=text[1].split("&text=");
    resp=text2[0];
   }else  resp=text[1];
  }
 return resp;
}


function GET_CGI(){
 var resp="";
 var ob = decodeURIComponent(String(window.location.search));

  if(ob.indexOf("text=")>-1){
   var text=ob.split("text=");
   resp=text[1].replace(/~/g,"'");
  }
 return resp;
}


function langSWITCHER(){
 if(GEBI("SLG_langSrc").value!="auto"){
  var temp=GEBI("SLG_langDst").value;
  GEBI("SLG_langDst").value=GEBI("SLG_langSrc").value;
  GEBI("SLG_langSrc").value=temp;
  Switch();
 }else SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDisabled'));
}

function Switch(){
 BOXCONTENT="";
 SLG_DETECT="";
 localStorage["SLG_langSrc2"]=GEBI('SLG_langSrc').value;
 localStorage["SLG_langDst2"]=GEBI('SLG_langDst').value;
 localStorage["SLG_langDst_name"] = GEBI("SLG_langDst").options[GEBI("SLG_langDst").selectedIndex].text;
 FExtension.bg.ImTranslatorBG.SLG_Planshet_Reset();//SLG_callbackRequest2();
 
 SET_PROV();
 SET_FIRST_AVAILABLE_PROV();
 ACTIVATE_THEME_TABS(FExtension.store.get("THEMEmode"));
}


function DICTClear(){
 GEBI('SLG_DICTsource').innerText="";
 GEBI('SLG_DICTtext').value="";
 GEBI('SLG_DICTtext').focus();
// GEBI('SLG_dict_tts').style.display='none';
 GEBI('SLG_DETECTED').style.visibility='hidden';
 FExtension.store.set("SLG_SavedText_gt","");
}


function REMOTE_Voice (dir, text){
 if(text!=""){
  if(dir==""){
    if(SLG_DETECT == "") dir = GEBI("SLG_langSrc").value;
    else dir = SLG_DETECT;
  }
   REMOTE_Voice_Close();
   var BackUpDir = dir;
   dir = dir.replace("-TW","");
   dir = dir.replace("-CN","");
   if(dir=="en") dir = dir.replace("en","en-BR");
   dir = dir.replace("es","es-419");
   dir = dir.replace("pt","pt-BR");

//  var TK = Math.floor(Date.now() / 1000);
  var a=Math.floor((new Date).getTime()/36E5)^123456;
  var TK = a+"|"+Math.floor((Math.sqrt(5)-1)/2*(a^654321)%1*1048576);

  var length = text.length;
  var num = Math.floor((Math.random() * SLG_GEO.length)); 
  var theRegion = SLG_GEO[num];
  if(FExtension.store.get("SLG_DOM")!="auto") theRegion=FExtension.store.get("SLG_DOM");
  var baseUrl = "https://translate.google."+theRegion;

  var client = "tw-ob";
//  if(dir=="es") client="t";
//  if(BackUpDir=="es") client="t";

  baseUrl = baseUrl+'/translate_tts?tk='+TK+'&ie=UTF-8&tl='+dir+'&total=1&idx=0&textlen='+length+'&client='+client+'&q='+encodeURIComponent(text);

  var frame = document.getElementById('PL_lbframe');
  if(frame)	frame.parentNode.removeChild(frame);
  if(!document.getElementById("PL_lbframe")){
    GEBI("SLG_player3").innerHTML="";
    var die=document.createElement("iframe");
    die.src="";
    die.name="PL_lbframe";
    die.id="PL_lbframe";
    die.width="446px";
    die.height="35px";
    die.scrolling="no";
    die.frameBorder="0";
    document.getElementById('SLG_player3').appendChild(die);

            const http = new XMLHttpRequest
            http.onload = e => {
                const reader = new FileReader();
                reader.onloadend = function() {

		  var frame = window.frames["PL_lbframe"].document.getElementById('SLmedia');
		  if(frame)	frame.parentNode.removeChild(frame);

		     var audioElement = document.createElement('audio');
		     audioElement.setAttribute('src', reader.result);
		     audioElement.setAttribute('preload', 'auto');
		     audioElement.setAttribute('controls', 'controls');
		     audioElement.setAttribute('autoplay', 'autoplay');
		     audioElement.setAttribute('id', 'SLmedia');
		     audioElement.setAttribute('name', 'SLmedia');
		     audioElement.setAttribute('style', 'width:470px;margin-top:-17px;margin-left:-15px;');
		     window.frames["PL_lbframe"].document.body.appendChild (audioElement);
		     GEBI('SLG_player3').style.display="block";
		     GEBI('SLG_player3').style.height="35px";
		     GEBI('SLG_player3').style.width="480px";
		     GEBI('SLG_player3').style.marginLeft="2px";
			setTimeout(function(){
			   try {
			     var TTSstatus = String((window.frames["PL_lbframe"].document.getElementById("SLmedia").duration));
		        	 if(TTSstatus=="NaN") {
					if(PLATFORM=="Chrome" && TTSbackupLangs.indexOf(BackUpDir)!=-1) GOOGLE_TTS_backup(BackUpDir);
					else {
						GEBI("SLG_player3").innerHTML="<div align=center><font color='#BD3A33'>"+FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extADVstu')+"</font><br><a href='../options/options.html?feed' target='_blank' class='SLG_links'>"+FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extFeedback')+"</a></div>";
					}
				 }
			   } catch (ex) {if(PLATFORM=="Chrome" && TranslatorIM.TTSbackupLangs.indexOf(BackUpDir)!=-1)TranslatorIM.GOOGLE_TTS_backup(BackUpText,BackUpDir);}
			}, 3000);  

                }
                reader.readAsDataURL(e.target.response)
            }
    
            http.onerror = e => {
                console.error(e)
                reject(e)
            }
            http.open("GET", baseUrl)
            http.responseType = "blob"
            http.send()


  }

   setTimeout(function(){
	  GEBI("SLG_DETECTED").style.display="block";
	  if(GEBI("PL_lbframe").style.display!="block"){
		 SetProperHeight(325);
	  }
   }, 300);  
 }
}


function SLG_TTSicn(lng,st){
 var OUT="";

 if(lng!="ar" && lng!="iw" && lng!="fa" && lng!="yi" && lng!="ur" && lng!="ps" && lng!="sd" && lng!="ckb" && lng!="ug" && lng!="dv" && lng!="prs"){
  if(st==0){
   GEBI("SLG_DICTtext").style.direction="ltr";
   GEBI("SLG_DICTtext").style.textAlign="left";
  }
  OUT=1;
 } else {
  if(st==0){
   GEBI("SLG_DICTtext").style.direction="rtl";
   GEBI("SLG_DICTtext").style.textAlign="right";
  }
  OUT=2;
 }
 return(OUT);
}

function SLG_Flip_Langs(lng){

	if(GEBI("SLG_langSrc").value != "auto" && GEBI('SLlocpl').checked==false){
	  lng = lng.replace("or-IN","or")
	  lng = lng.replace("ku-Latn","ku")
	  lng = lng.replace("ku-Arab","ckb")
	  lng = lng.replace("sr-Latn-RS","sr-Latn")  
	  if(GEBI("SLG_langDst").value == "tlsl" && lng == "tl") lng = "tlsl";
	  if(GEBI("SLG_langDst").value == "srsl" && lng == "sr") lng = "srsl";
	  if(GEBI("SLG_langDst").value == "tl" && lng == "tlsl") lng = "tl";
	  if(GEBI("SLG_langDst").value == "sr" && lng == "srsl") lng = "sr";
	  if(GEBI("SLG_langDst").value == lng){
	      	var tmp = GEBI("SLG_langDst").value;
	      	GEBI("SLG_langDst").value = GEBI("SLG_langSrc").value;
      	      	GEBI("SLG_langSrc").value = tmp;
      	      	FExtension.store.set("SLG_langDst2", GEBI("SLG_langDst").value);

	  }
	}


	for (var i=0;i<BASELANGSCodes.length;i++){
		if(lng == BASELANGSCodes[i]){DetLangName = BASELANGSNames[i]; break;}
	}

//	if(DetLangName) GEBI("SLG_DETECTED").innerHTML = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetected')+" "+DetLangName;

}





function SLG_DICTparser(resp){

   var PARTS = new Array();
   var SLG_to = GEBI('SLG_langDst').value;
   if(SLG_DETECT==GEBI('SLG_langDst').value) SLG_to = GEBI('SLG_langSrc').value;

   var SLG_from = GEBI('SLG_langSrc').value;
   var SLG_from_ = SLG_from;
   var DETECTEDlng=SLG_DETECT;

   var parsedRES="";
   var parsedTRANS="";
   var DETECTEDlongName=DetLangName;
   for (var z=0; z<BASELANGSCodes.length; z++){
       if(DETECTEDlng==BASELANGSCodes[z]) {SLG_DETECT=BASELANGSCodes[z]; DETECTEDlongName=BASELANGSNames[z];SLG_from=SLG_DETECT;break; }
   }


   var SLG_LABLE="";

   if(localStorage["SLG_no_detect"]=="true" || GEBI('SLG_langSrc').value=="auto" || GEBI('SLlocpl').checked==false) SLG_LABLE = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetected') + " " + DETECTEDlongName;
   GEBI('SLG_DETECTED').innerText = SLG_LABLE;

//   SLG_Flip_Langs(DETECTEDlng);

//   localStorage["SLG_langSrc2"]=GEBI('SLG_langSrc').value;
//   localStorage["SLG_langDst2"]=GEBI('SLG_langDst').value;

   if(resp.indexOf('spell_res":"')==-1){
	var Tr1=resp.split('dict":[');
	var Tr2=Tr1[0].split('trans":"');
	var Tr3=Tr2[1].split('"');
	var TRANSLATION = Tr3[0];
   } else {
	var Tr1=resp.split('dict":[');
	var Tr2=Tr1[0].split('orig":"');
        var Tr3=Tr2[1].split('"');
   }


/*
	   var Tr1=resp.split('spell_res":"');
	   var Tr2=Tr1[1].split('"');
	   var TRANSLATION = Tr2[0];
*/

   var WAY = SLG_TTSicn(DETECTEDlng,0);
   var WAY2 = SLG_TTSicn(GEBI('SLG_langDst').value,1);
   var FAKE="";
   if(SLG_TTS.indexOf(SLG_DETECT)!=-1 || (G_TTS.indexOf(SLG_DETECT)!=-1 && localStorage["SLG_GVoices"]!="0")){
           GEBI('SLG_dict_tts').style.display='block';
	   if(resp.indexOf("reverse_translation")!=-1){
	      var TOPword = GEBI("SLG_DICTtext").value.replace(/"/ig,"'");
	      TOPword = TOPword.replace(/''/ig,"'");
	      TOPword = TOPword.replace(/'/ig,"`");
	      if(WAY == 1) 	FAKE = "<div id=_X><div id=_XL><div class=TTS"+WAY+" id=SLG_000 lang=\""+DETECTEDlng+"\" title='"+TOPword+"'></div></div><div id=_XR style='font-weight:bold;font-size:14px;'>" + GEBI("SLG_DICTtext").value + "</div></div>";
	      else    	FAKE = "<div id=_X><div id=_FL><div class=TTS"+WAY+" id=SLG_000 lang=\""+DETECTEDlng+"\" title='"+TOPword+"'></div></div><div id=_FR>" + GEBI("SLG_DICTtext").value + "</div></div>";

	   } else {
	      if(WAY == "1"){
	 	parsedTRANS = "<div dir=rtl>"+TRANSLATION+"</div>";
	      } else {
	 	parsedTRANS = "<div dir=ltr>"+TRANSLATION+"</div>";
	      }
	   }
   } else {
           GEBI('SLG_dict_tts').style.display='none';
	   if(resp.indexOf("reverse_translation")!=-1){
	      if(WAY == 1) 	FAKE = "<div id=_X><div id=_XR style='font-weight:bold;font-size:14px;'>" + GEBI("SLG_DICTtext").value + "</div></div>";
	      else    	FAKE = "<div id=_X><div id=_FR>" + GEBI("SLG_DICTtext").value + "</div></div>";
	   } else {
	      if(WAY == "1"){
	 	parsedTRANS = "<div dir=rtl>"+TRANSLATION+"</div>";
	      } else {
	 	parsedTRANS = "<div dir=ltr>"+TRANSLATION+"</div>";
	      }
	   }
   }

   parsedRES = parsedTRANS+"<br>";

   if(resp.indexOf('pos":"')!=-1){
     try {
        var Rline,article;
	const obj = JSON.parse(resp);
	for(var i = 0; i < obj.dict.length; i++){
		parsedRES = parsedRES + "<div id=_Y>" +obj.dict[i].pos + "</div>";
		for (var j=0; j < obj.dict[i].entry.length; j++){
			        article="<x id=_ART>" + obj.dict[i].entry[j].word + "</x> ";
                                Rline = "";
				for(var k = 0; k < obj.dict[i].entry[j].reverse_translation.length; k++){
					var tmpLNK = obj.dict[i].entry[j].reverse_translation[k].replace(/\\'/g,'~');
					tmpLNK = tmpLNK.replace(/\\u0027/g,'~');
					var F = SLG_from;
					if(F != FBOX && FBOX != "") F = FBOX;
					var T = SLG_to;
					if(T != TBOX && TBOX != "") T = TBOX;
					if(k < obj.dict[i].entry[j].reverse_translation.length-1){
						Rline = Rline + "<a class=_ALNK href='dictionary.html?dir="+ F + "|" + T +"&text=" + encodeURIComponent(tmpLNK) + "'>" + tmpLNK + "</a>, ";
					} else {
						Rline = Rline + "<a class=_ALNK href='dictionary.html?dir="+ F + "|" + T +"&text=" + encodeURIComponent(tmpLNK) + "'>" + tmpLNK + "</a>";
					}
				}
				var REV=obj.dict[i].entry[j].reverse_translation;
				var WORD=obj.dict[i].entry[j].word;
				var SLG_myTTS = article;// + REV;
			        if(SLG_TTS.indexOf(SLG_to)!=-1 || (G_TTS.indexOf(SLG_to)!=-1 && localStorage["SLG_GVoices"]!="0")){
				   if(WAY2==1) SLG_myTTS = "<div id=_X><div id=_XL><div class=_V id=\"SLG_"+i+j+"\" lang=\""+SLG_to+"\" title=\"" + WORD + "\"></div></div><div id=_XR>" + article +"</div></div>";
				   else SLG_myTTS = "<div id=_X><div id=_FL><div class=TTS"+WAY2+" id=\"SLG_"+i+j+"\" lang=\""+SLG_to+"\" title=\"" + WORD + "\"></div></div><div id=_XR>" + article + "</div></div>";
				}			
				parsedRES = parsedRES + "<div id=_A><div id=_AL>" + SLG_myTTS + "</div><div id=_AR>" + Rline + "</div></div>";
		}
		parsedRES = parsedRES + "<br>";
	}
      } catch(ex){
	FAKE="";
       	parsedRES=TRANSLATION;
      }	

    } else parsedRES = parsedTRANS;
      if(parsedRES.indexOf("_A")!=-1){
	    setTimeout(function(){
	     SLG_ALIGNER1(GEBI('SLG_langDst').value);
	     SLG_ALIGNER2(DETECTEDlng)
	    },5);
      } else setTimeout(function(){ SLG_ALIGNER3(DETECTEDlng,GEBI('SLG_langDst').value);},5);
 return [parsedRES, FAKE];
}




function SLG_ALIGNER1(SLG_to){
 var nums=document.getElementsByTagName("div").length;
 if(SLG_to!="ar" && SLG_to!="iw" && SLG_to!="fa" && SLG_to!="ur" && SLG_to!="yi" && SLG_to!="ps" && SLG_to!="sd" && SLG_to!="ckb"){
      for(var I = 0; I < nums; I++){
       if(document.getElementsByTagName("div")[I].id == "_AL")	 document.getElementsByTagName("div")[I].style.textAlign="left";
      }
 } else {
      for(var I = 0; I < nums; I++){
       if(document.getElementsByTagName("div")[I].id == "_AL")	 document.getElementsByTagName("div")[I].style.textAlign="right";
       if(document.getElementsByTagName("div")[I].id == "_XR")	 document.getElementsByTagName("div")[I].style.float="right";		
      }
 }
}

function SLG_ALIGNER2(SLG_from){
 var nums=document.getElementsByTagName("div").length;
 if(SLG_from!="ar" && SLG_from!="iw" && SLG_from!="fa" && SLG_from!="yi" && SLG_from!="ur" && SLG_from!="ps" && SLG_from!="sd" && SLG_from!="ckb" && SLG_from!="ug" && SLG_from!="dv" && SLG_from!="prs"){
      for(var I = 0; I < nums; I++){
       if(document.getElementsByTagName("div")[I].id == "_AR")	 document.getElementsByTagName("div")[I].style.textAlign="left";
      }
 } else {
      for(var I = 0; I < nums; I++){
       if(document.getElementsByTagName("div")[I].id == "_AR")	 document.getElementsByTagName("div")[I].style.textAlign="right";
      }
 }
}

function SLG_ALIGNER3(SLG_from,SLG_to){
 if(SLG_to=="ar" || SLG_to=="iw" || SLG_to=="fa" || SLG_to=="yi" || SLG_to=="ur" || SLG_to=="ps" || SLG_to=="sd" || SLG_to=="ckb" || SLG_to=="ug" || SLG_to=="dv" || SLG_to=="prs") GEBI("SLG_DICTsource").style.textAlign='right';
 else	GEBI("SLG_DICTsource").style.textAlign='left';
 if(SLG_from=="ar" || SLG_from=="iw" || SLG_from=="fa" || SLG_from=="yi" || SLG_from=="ur" || SLG_from=="ps" || SLG_from=="sd" || SLG_from=="ckb" || SLG_from=="ug" || SLG_from=="dv" || SLG_from=="prs")	GEBI("SLG_DICTtext").style.textAlign='right';
 else	GEBI("SLG_DICTtext").style.textAlign='left';
}


function DODetection(myTransText) {
  if(myTransText=="") myTransText = GEBI("SLG_DICTtext").value;
  if(myTransText!=""){


    var cntr = myTransText.split(" ");
    var newTEXT = myTransText;
    newTEXT = truncStrByWord(newTEXT,100)

    var num = Math.floor((Math.random() * SLG_GEO.length)); 
    var theRegion = SLG_GEO[num];
    if(FExtension.store.get("SLG_DOM")!="auto") theRegion=FExtension.store.get("SLG_DOM");

    var baseUrl = 'https://translate.google.'+theRegion+'/translate_a/single';
    var SLG_Params="client=gtx&dt=t&dt=bd&dj=1&source=input&q="+encodeURIComponent(newTEXT) + "&sl=auto&tl=en&hl=en";    
                   


	var ajaxRequest;  
	try{
		ajaxRequest = new XMLHttpRequest();
	} catch (e){
		try{
			ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			try{
				ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (e){
				SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extError1'));
				return false;
			}
		}
	}

	ajaxRequest.onreadystatechange = function(){
		if(ajaxRequest.readyState == 4){
                        var resp = ajaxRequest.responseText;                        
                        var captcha=0;
			if(resp.indexOf('CaptchaRedirect')!=-1) captcha = 1;
		        if(resp.indexOf('ld_result":{"srclangs":["')!=-1) {

                                var GDImTranslator_lang=resp.split('ld_result":{"srclangs":["');
				var GDImTranslator_lang1=GDImTranslator_lang[1].split('"');
 				resp=GDImTranslator_lang1[0];

				var resp2=resp.replace("zh-CN","zh");
				resp2=resp2.replace("zh-TW","zt");

        	                var thetemp=GEBI("SLG_langSrc").value.replace("zh-TW","zt");
                	        thetemp=thetemp.replace("zh-CN","zh");

				SLG_DETECT = resp;


				// NOT TRUSTED LANGUAGES
				myTransText = myTransText.trim();
				globaltheQ = myTransText.split(" ").length;

	                        if(DO_NOT_TRUST_WORD.indexOf(SLG_DETECT)!=-1 && globaltheQ==1){
					SLDetector(myTransText);
					return false;
				}	

	                        if(resp2==DO_NOT_TRUST_TEXT){
					SLDetector(myTransText);
					return false;
				}
				//----------------------

/*
				   resp = resp.replace("or-IN","or");
				   resp = resp.replace("ku-Latn","ku");
				   resp = resp.replace("ku-Arab","ckb");
				   resp = resp.replace("sr-Latn-RS","sr-Latn");  

				   if(GEBI("SLG_langDst").value == "tlsl") resp = resp.replace("tl","tlsl");
				   if(GEBI("SLG_langDst").value == "srsl") resp = resp.replace("sr","srsl");
*/
				   SLG_DETECT=resp;

				CNTR('2311',resp2+"/"+resp2, newTEXT.length);
					var cnt=0;
        		                for (var i=0;i<BASELANGSCodes.length;i++){
						if(resp == BASELANGSCodes[i]){
							cnt=1; 
							SLG_DETECT = BASELANGSCodes[i];

//							if(SLG_WRONGLANGUAGEDETECTED==0){
				                	        GEBI("SLG_DETECTED").innerText = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetected')+" "+BASELANGSNames[i];
								GEBI("SLG_DETECTED").style.display='block';
//							}	
						}
					}
	                	        SLG_WRONGLANGUAGEDETECTED=0;
	                	        
					if(cnt==0){
						//SLG_DETECT="zu";
						//SLG_setTEMP("PROV","Google"); 
						
						GEBI("SLG_DETECTED").innerText ="";
				    		setTimeout(function(){
							for(var i=0; i<LISTofPR.length; i++){
				 				if(GEBI("SLG_P"+i).title.toLowerCase() == "google"){GEBI("SLG_P"+i).className="SLG_TAB_DICT";}
								else GEBI("SLG_P"+i).className="SLG_TAB_DEACT_DICT";
							}
							GEBI("SLG_DETECTED").style.visibility="hidden";
					        },500); 

			                        SLG_WRONGLANGUAGEDETECTED=1;
					}
					
                                        SLG_Flip_Langs(SLG_DETECT);
					SET_PROV();
                                        SET_FIRST_AVAILABLE_PROV();



			} else 	SLDetectPATCH(myTransText);
		}

	}
	baseUrl = baseUrl +"?"+ SLG_Params;
	ajaxRequest.open("GET", baseUrl, true);
        ajaxRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	ajaxRequest.send(SLG_Params);    
  }                                

}                                 
        
function SLDetectPATCH(theText){
        SLDetector(theText);
}


function SLDetector (text){
	if(text=="") text = GEBI("SLG_source").value;
  	var theLIMIT = 100;     

        var fr = GEBI("SLG_langSrc").value;
        if(fr=="auto") fr="*a";
        CNTRP('2311',fr+"/"+GEBI("SLG_langDst").value, truncStrByWord(text,theLIMIT).length);
                       
	var SLDImTranslator_url = ImTranslator_theurl+"ld.asp?tr=pl_d&text="+encodeURIComponent(truncStrByWord(text,theLIMIT));
	if(text=="") text = GEBI("SLG_source").value;
		var ajaxRequest;  
		try{
			ajaxRequest = new XMLHttpRequest();
		} catch (e){
			try{
				ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
				try{
					ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (e){
					SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extError1'));
					return false;
				}
			}
		}
		ajaxRequest.onreadystatechange = function(){
			if(ajaxRequest.readyState == 4){
                        	var tmp = ajaxRequest.responseText;
				if(tmp.indexOf("#|#")!=-1){
				    var tmp2 = tmp.split("#|#");
		                    SLG_DETECT="en";
        		            if(tmp2[0].length>0 && tmp2[0].length<7) SLG_DETECT=tmp2[0];
        		            if(SLG_DETECT == "zh") SLG_DETECT="zh-CN";
        		            if(SLG_DETECT == "zt") SLG_DETECT="zh-TW";

        		            var cnt=0;
				    var ALLlangs=SLG_BaseLanguages.split(",");
				    for (var z=0; z<ALLlangs.length; z++){
					var ALLcodes = ALLlangs[z].split(":");
				       	if(SLG_DETECT==ALLcodes[0]) {cnt=1;DetLangName=ALLcodes[1];break; }
				    }

		                    SLG_WRONGLANGUAGEDETECTED=0;
				    if(cnt==0){
				    	setTimeout(function(){
						GEBI("SLG_DETECTED").style.visibility="hidden";
				        },500); 
					//SLG_DETECT = document.getElementById('SLG_langSrc').value;
		                        SLG_WRONGLANGUAGEDETECTED=1;
//					SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extnotsupported'));
				    }


// removed by VK 10/25/22
//                		    if(document.getElementById('SLG_langSrc').value!=SLG_DETECT){
	                		    if(tmp2[0]!="un"){
						GEBI("SLG_DETECTED").innerText = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetected')+" "+DetLangName;
					    }
//			            }
			    	} else SLG_DETECT="en";
				SLG_Flip_Langs(SLG_DETECT);
				SET_PROV();
				SET_FIRST_AVAILABLE_PROV();
			}
		}
		ajaxRequest.open("POST", SLDImTranslator_url, true);
		ajaxRequest.send(null);                          
}





function truncStrByWord(str, length){
 if(str!="undefined"){
  if(str.length>25){
   length=length-25;
   var thestr=str;
   if (str.length > length) {
      	str = str.substring (0, length);
	str = str.replace(new RegExp("/(.{1,"+length+"})\b.*/"), "$1")    // VK - cuts str to max length without splitting words.
      var str2 = thestr.substring(length, (length+25));
      var tempstr=str2.split(" ");
      var tmp="";
      
      for (i=0; i<tempstr.length-1; i++){
          tmp = tmp+tempstr[i]+" ";
      } 
      str=str+tmp;
   }
  } else str = str+" ";
 }
 return str;
}

function startURL(url){ FExtension.browserPopup.openNewTab(url); }

function SLG_alert(txt){
 GEBI('SLG_alert').style.display="block";
 GEBI("SLalertcont").innerText=txt;
	if(GEBI('SLG_alert').style.display=="block"){
		var obw = GEBI('SLG_alert').clientWidth;
		GEBI('SLG_alert').style.marginLeft=(GLOBAL_WIDTH/2-obw/2)+"px";
		var obh = GEBI('SLG_alert').clientHeight;
		GEBI('SLG_alert').style.marginTop=(GLOBAL_HEIGHT/2-obh/2-50)+"px";
	}
}

function SLShowHideAlert(){
 GEBI('SLG_alert').style.display='none'; 
}

function SLG_HK_TRANSLATE(){
                SLG_TEMPKEYSTRING=SLG_TEMPKEYSTRING.replace("18:|","Alt:|");
                SLG_TEMPKEYSTRING=SLG_TEMPKEYSTRING.replace("17:|","Ctrl:|");
                SLG_TEMPKEYSTRING=SLG_TEMPKEYSTRING.replace("16:|","Shift:|");
		var TMP1= SLG_TEMPKEYSTRING.split(":|");
		var NUM = TMP1.length-1;
		var HOTKEY = Array();
		var HOTKEYSline="";
		var cnt=0;
		for(var x=0; x<NUM; x++){
		    if(TMP1[x]!="Alt" && TMP1[x]!="Ctrl" && TMP1[x]!="Shift") HOTKEY[x]=String.fromCharCode(TMP1[x]);
		    else HOTKEY[x]=TMP1[x];
                    HOTKEYSline=HOTKEYSline+HOTKEY[x]+":|";
                    if(TMP1[x]=="Alt")cnt++;
                    if(TMP1[x]=="Ctrl")cnt++;
		}
		if(cnt==2){
                  HOTKEYSline=HOTKEYSline.replace("Alt:|","");
                  HOTKEYSline=HOTKEYSline.replace("Ctrl:|","");
                  HOTKEYSline="Ctrl:|Alt:|"+HOTKEYSline;
		}
		SLG_KEYCOUNT = { length: 0 }; SLG_KEYSTRING="";SLG_TEMPKEYSTRING="";
		return HOTKEYSline.toLowerCase();
}

function SLG_setTEMP(cname, cvalue) {
    localStorage["PLD_"+cname] = cvalue;
}



function SLG_getTEMP(cname) {
    var cvalue = localStorage["PLD_"+cname];
    if(cvalue != "") return cvalue;
    else return "";
}

function LOCcontrol(){    
    GEBI("SLlocboxd").src="../../img/util/box.png";
    if(GEBI('SLlocpl').checked == true){
	GEBI("SLlocboxd").src="../../img/util/box-on.png";
    }
    SLG_setTEMP("LOC",String(GEBI('SLlocpl').checked));
}



function GoToTranslator(){
	   var s=GEBI("SLG_DICTtext").value.replace(/(^[\s]+|[\s]+$)/g, '');
	   var TEXT = SetTextLimit(s,2000);
           FExtension.bg.ImTranslatorBG.DIC_TRIGGER=1;
	   FExtension.store.set("SLG_Dtext", encodeURIComponent(TEXT));
	   if(FExtension.store.get("SLG_BACK_VIEW")==2) window.location.href="../../html/popup/translation-back.html?text="+encodeURIComponent(TEXT)+"&t=1";
	   else window.location.href="../../html/popup/translator.html?text="+encodeURIComponent(TEXT)+"&t=1";
}


function SetTextLimit(text,limit){
 text=text.replace(/(\r\n|\n|\r)/gm,"");
 if(text.indexOf(" ")>-1 && text.length>limit){
   var texttmp=text.split(" ");
   var OutPut="";
   var OutPut_="";
   for(var i=0; i<texttmp.length; i++){
     OutPut=OutPut+texttmp[i]+" ";
     if(OutPut.length>limit) break;
     else OutPut_=OutPut_+texttmp[i]+" ";
   }
 }else OutPut_ = text.substring(0,limit);
 return(OutPut_);
}




function SLG_VIEW_manu(st){
        if(st==0) GEBI('SLG_view_menu').style.display='none';
	else GEBI('SLG_view_menu').style.display='block';
}


function SLG_DONATE_manu(st){
        if(st==0) GEBI('SLG_donate_menu').style.display='none';
	else GEBI('SLG_donate_menu').style.display='block';
}

function SLG_DONATE_links(st){
	var link = 'https://imtranslator.net'+_CGI+'&a=5';
 	switch(st){
		case 1: link = 'https://imtranslator.net'+_CGI+'&a=5'; break;
		case 2: link = 'https://imtranslator.net'+_CGI+'&a=10'; break;
		case 3: link = 'https://imtranslator.net'+_CGI+'&a=20'; break;
		case 4: link = 'https://imtranslator.net'+_CGI+'&a=0'; break;
	}
	SLG_OPEN_WINDOW(link);
}


function SLG_VIEW_link(st){
  	SLG_OPEN_WINDOW("https://chrome.google.com/webstore/detail/translation-comparison/kicpmhgmcajloefloefojbfdmenhmhjf?utm_source=chrome-ntp-icon");
}

function SLG_OPEN_WINDOW(url){
        window.open(url, '_blank', 'toolbar=yes, location=yes, status=yes, menubar=yes, scrollbars=yes');
}


function SET_DICT_PROVIDER(){
  for(var I=0; I<LISTofPR.length; I++){
    if(SLG_getTEMP("DPROV") == LISTofPR[I]) GEBI("SLG_P"+I).className="SLG_TAB_DICT";
    else GEBI("SLG_P"+I).className="SLG_TAB_OFF_DICT";   
  }
}

function SLG_SET_DICT_PRIVIDER(pr){
	SLG_setTEMP("DPROV",pr);
	SET_PROV();
	SET_FIRST_AVAILABLE_PROV();
	SLG_INIT_DICT();
}

function SET_PROV(){
  ListProviders="";
  for(var I=0; I<LISTofPR.length; I++){
    var from=GEBI("SLG_langSrc").value;
    var to = GEBI("SLG_langDst").value;

    if(from=="auto" || SLG_DETECT!="") from=SLG_DETECT;
    if(SLG_getTEMP("DPROV") == LISTofPR[I]) GEBI("SLG_P"+I).className="SLG_TAB_DICT";
    else {
	if(localStorage["SLG_other_gt"]=="1"){
	  GEBI("SLG_P"+I).className="SLG_TAB_OFF_DICT";   
	}
    }

    if(from!="") {
    	if(LISTofPR[I]!="Translator"){
	     if(FIND_PROVIDER(LISTofPRpairs[I],from) ==-1 || FIND_PROVIDER(LISTofPRpairs[I],to)==-1){
		 GEBI("SLG_P"+I).className="SLG_LABLE_DEACT";
		 ListProviders=ListProviders.replace(LISTofPR[I]+",","");
	     } else ListProviders=ListProviders+LISTofPR[I]+",";
    	} else {
	      if(LISTofPRpairs[I].indexOf(from + "/" + to)==-1){
		 GEBI("SLG_P"+I).className="SLG_LABLE_DEACT";
		 ListProviders=ListProviders.replace(LISTofPR[I]+",","");
	      } else ListProviders=ListProviders+LISTofPR[I]+",";
    	}
    }

  }

  ListProviders=ListProviders.replace("Translator,Translator","Translator");
  if(ListProviders !="" && SLG_getTEMP("DPROV") == "") {
        var arr = ListProviders.split(",");
	SLG_setTEMP("DPROV",arr[0]);  
        FExtension.store.set("PLD_DPROV",arr[0]);
  }	
}


function FIND_PROVIDER(list,ln){
  var arr = list.split(",");
  var cnt=-1
  for(var i=0; i<arr.length; i++){
	if(arr[i]==ln) cnt++;
  }
  return cnt;
}




function MS(f,t,text){
 if(GEBI("SLG_DICTtext").value=="" && window.location.href.indexOf("&text=")==-1 && FExtension.store.get("SLG_SaveText_box_gt")==1) GEBI("SLG_DICTtext").value=FExtension.store.get("SLG_SavedText_gt").substring(0,100).replace(/\^/ig,"%");
 SLG_OTHER_PROVIDERS(text,f,t);
}

function SLG_OTHER_PROVIDERS(text,f,t){
 if(GEBI("SLG_DICTtext").value=="" && window.location.href.indexOf("&text=")==-1 && FExtension.store.get("SLG_SaveText_box_gt")==1) GEBI("SLG_DICTtext").value=FExtension.store.get("SLG_SavedText_gt").substring(0,100).replace(/\^/ig,"%");
 
  var ctrl = "SLG_DICTsource";

  var mySourceLang = GEBI("SLG_langSrc").value;
  var myTargetLang = GEBI("SLG_langDst").value;


  if(text=="")text=GEBI("SLG_DICTtext").value;

    if(text!=""){
	PROV = SLG_getTEMP("DPROV");
	GEBI('SLG_loading').style.display='block';
	if(GEBI('SLlocpl').checked==false || GEBI('SLG_langSrc').value=="auto"){
	    if(localStorage["SLG_no_detect"]=="true" || GEBI('SLG_langSrc').value=="auto" || GEBI('SLlocpl').checked==false){
		//SLG_DETECT=GEBI('SLG_langSrc').value;  
		//SLG_Tabs_Settler()
	    } else {
		SLG_DETECT=GEBI('SLG_langSrc').value;
	    }	
	 } else SLG_DETECT=GEBI('SLG_langSrc').value;




	 if(GEBI('SLG_langSrc').value!="auto" && GEBI('SLlocpl').checked==true) GEBI('SLG_DETECTED').innerText="";


	 if(PROV.toLowerCase()=="" || PROV.toLowerCase() == "undefined" || PROV.toLowerCase() =="null") PROV = "microsoft";

	 if(f=="auto" || SLG_DETECT!="") f=SLG_DETECT;
	 if(f=="") f=mySourceLang;



 	 if(PROV.toLowerCase()=="microsoft"){
		text=text.replace(/</g,"< ");

				if(f == "zh") f = "zh-CHS";
				if(f == "zt") f = "zh-CHT";
				if(f == "iw") f = "he";
				if(f == "sr") f = "sr-Cyrl";
			        if(f == "srsl") f = "sr-Cyrl";
				if(f == "bs") f = "bs-Latn";
				if(f == "tl") f = "fil";
				if(f == "tlsl") f = "fil";
				if(f == "hmn") f = "mww";
				if(f == "ku") f = "kmr";
				if(f == "ckb") f = "ku";

				if(t == "zh") t = "zh-CHS";
				if(t == "zt") t = "zh-CHT";
				if(t == "iw") t = "he";
				if(t == "sr") t = "sr-Cyrl";
			        if(t == "srsl") t = "sr-Cyrl"
				if(t == "bs") t = "bs-Latn";
				if(t == "tl") t = "fil";
				if(t == "tlsl") t = "fil";
				if(t == "hmn") t = "mww";
				if(t == "ku") t = "kmr";
				if(t == "ckb") t = "ku";
 	 }


	 if(text!=""){

		var baseUrl = ImTranslator_theurl+"dotrans.asp";
		var cgi = "dir="+f+"/"+t+"&provider="+PROV.toLowerCase()+"&text="+encodeURIComponent(text);

		var ajaxRequest;  
		try{
			ajaxRequest = new XMLHttpRequest();
		} catch (e){
			try{
				ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
				try{
					ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (e){
					SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extError1'));
					return false;
				}
			}
		}
		ajaxRequest.onreadystatechange = function(){

			if(ajaxRequest.readyState == 4){
		             var resp = ajaxRequest.responseText;

			     if(ajaxRequest.status!=200) resp=PROV + ": "+ FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),"extnotrsrv");
			     if(ajaxRequest.status==414) resp=PROV + ": "+ FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extADVstu').replace("XXX","4000");;
		             if(resp.indexOf('<#<')!=-1 || resp.indexOf('&lt;#')!=-1) resp=PROV + ": "+ FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),"extnotrsrv");
			     if(resp.indexOf("ID=V2_Json_Translate")!=-1) resp=FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),"extnotrsrv");

                             resp=resp.replace(/\\/g,"");
			     if(PROV.toLowerCase()=="microsoft") {
				resp=resp.replace(/< /g,"<");
				resp=resp.replace(/ >/g,">");
				resp=resp.replace(/\\"/g,"'");
			     }
			     if(PROV.toLowerCase()=="translator") {
				resp=resp.replace(/&lt;/g,"<");
				resp=resp.replace(/&gt;/g,">");
			     }
	  		     //CNTR('2331',f+"/"+t, text.length);

			     resp = PseudoDICT(resp);

                             GEBI(ctrl).innerHTML=resp;
			     GEBI('SLG_indicator1').style.display='none';
			     GEBI('SLG_loading').style.display='none';

			     GEBI('SLG_DICTtext').style.direction="ltr";
			     GEBI('SLG_DICTtext').style.textAlign="left";
			     var SLG_lng = GEBI('SLG_langSrc').value;

			     if(localStorage["SLG_no_detect"]=="true" || SLG_lng=="auto") SLG_lng=SLG_DETECT;
			     if(SLG_lng=="ar" || SLG_lng=="iw" || SLG_lng=="fa" || SLG_lng=="yi" || SLG_lng=="ur" || SLG_lng=="ps" || SLG_lng=="sd" || SLG_lng=="ckb" || SLG_lng=="ug" || SLG_lng=="dv" || SLG_lng=="prs"){
			  	 GEBI('SLG_DICTtext').style.direction="rtl";
				 GEBI('SLG_DICTtext').style.textAlign="right";
			     }
			     GEBI('SLG_DICTsource').style.direction="ltr";
			     GEBI('SLG_DICTsource').style.textAlign="left";
			     var SLG_lng2 = GEBI('SLG_langDst').value;
			     if(SLG_lng2=="ar" || SLG_lng2=="iw" || SLG_lng2=="fa" || SLG_lng2=="yi" || SLG_lng2=="ur" || SLG_lng2=="ps" || SLG_lng2=="sd" || SLG_lng2=="ckb" || SLG_lng2=="ug" || SLG_lng2=="dv" || SLG_lng2=="prs"){
			  	 GEBI('SLG_DICTsource').style.direction="rtl";
				 GEBI('SLG_DICTsource').style.textAlign="right";
			     }




			        if (FExtension.store.get("SLG_TH_1")==1){
			        	var SLnow = new Date();
			        	SLnow=SLnow.toString();
			        	var TMPtime=SLnow.split(" ");
		        		var CurDT=TMPtime[1]+" "+TMPtime[2]+" "+TMPtime[3]+", "+TMPtime[4];
		        		if(mySourceLang=="auto") mySourceLang=SLG_DETECT;

					
					setTimeout(function(){
                                                text=text.replace(/~/ig," ");
                                                resp=resp.replace(/~/ig," ");
				        	FExtension.store.set("SLG_History", text + "~~" + resp + "~~" + mySourceLang + "|" + myTargetLang + "~~"+ FExtension.store.get("THE_URL") +"~~"+CurDT+"~~6~~"+PROV[0]+"^^" + FExtension.store.get("SLG_History"));
					},1500);


			        }

			}
		}

		ajaxRequest.open("POST", baseUrl, true);
		ajaxRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		ajaxRequest.send(cgi); 
	      }
	      GEBI('SLG_loading').style.display='none';

   } else {
	GEBI("SLG_DETECTED").style.display='none';
        GEBI('SLG_loading').style.display="none";
   }		
}

function SET_FIRST_AVAILABLE_PROV(){
 if(SLG_getTEMP("DIC_FIRSTRUN")!="dicdone"){
  	var theList = ListProviders.split(",");
  	if(localStorage["SLG_dict"]=="true"){
	  	var arr1 = localStorage["SLG_DICT_PRESENT"].split(",");
	  	for(var I=0; I<(theList.length-1); I++){
		    	for(var J=0; J<arr1.length; J++){
	        		var arr2=arr1[J].split(":");
				if(arr2[1]==1 && theList[I]==arr2[0]){
					SLG_setTEMP("DPROV",arr2[0]);
			      		PROV=arr2[0];
			      		GEBI("SLG_P"+J).className="SLG_TAB_DICT";
					SET_DICT_PROVIDER();
					SLG_setTEMP("DIC_FIRSTRUN","dicdone");
					I=1000;J=1000;
				}
		    	}
		}
  	} else {
		if(ListProviders.indexOf(SLG_getTEMP("DPROV"))==-1){
		      var theList = ListProviders.split(",");
		      for(var I=0; I<(theList.length-1); I++){
				PROV=theList[I];
			        SLG_setTEMP("DPROV",PROV);
			        GEBI("SLG_P"+I).className="SLG_TAB_DICT";
			        break;
		      }
		}else{
			if(SLG_getTEMP("DPROV")!=""){
	   			var theList = ListProviders.split(",");
   				for(var I=0; I<(theList.length-1); I++){
					if(theList[I] == SLG_getTEMP("DPROV")){
	      					GEBI("SLG_P"+I).className="SLG_TAB_DICT";
      						break;
					}
		   		}
			} else {
	   			var theList = ListProviders.split(",");
				var arr = localStorage["SLG_ALL_PROVIDERS_GT"].split(",");
			        SLG_setTEMP("DPROV",theList[0]);
			        for(var J=0; J<arr.length; J++){
	   				for(var I=0; I<(theList.length-1); I++){
						if(theList[I] == arr[J] && theList[I] == SLG_getTEMP("DPROV")){
	      						GEBI("SLG_P"+J).className="SLG_TAB_DICT";
      							I=1000;J=1000;
							SLG_setTEMP("DIC_FIRSTRUN","dicdone");
						}
			   		}
				}
			}
		}
	}
 }else{
	if(ListProviders.indexOf(SLG_getTEMP("DPROV"))==-1){
   		var theList = ListProviders.split(",");
   		for(var I=0; I<(theList.length-1); I++){
      			PROV=theList[I];
      			SLG_setTEMP("DPROV",PROV);
      			GEBI("SLG_P"+I).className="SLG_TAB_DICT";
      			break;
   		}
  	}
 }
}


function REMOTE_Voice_Close (){
try{
 if(GEBI("SLG_player3")) GEBI("SLG_player3").style.display='none';
 synth.cancel();

 var frame = document.getElementById('PL_lbframe');
 if(frame) {
	frame.parentNode.removeChild(frame);
	 SetProperHeight(293);
 }

}catch(ext){}
}

function Start_GOOGLE_TTS_backup(){
 try{
    if(GEBI("SLG_controls").className=="SLG_play"){
	GEBI("SLG_controls").className="SLG_pause";
	GOOGLE_TTS_backup();
    } else {
	GEBI("SLG_controls").className="SLG_play";
	synth.pause();	
    }
 }catch(ext){}
}

function GOOGLE_TTS_backup(TTSlang){
 try{
	FirstLoop=1;
	synth.cancel();


	var speechText = TheNewText; 



			var voices = synth.getVoices();
			const utterance = new SpeechSynthesisUtterance();
			var LNG="";
			if(TheNewLang=="") TheNewLang=TTSlang;
			switch(TheNewLang){
			 	case "zt":LNG = "zh-HK"; break;
			 	case "zh":LNG = "zh-TW"; break;
//			 	case "en":LNG = "en-GB|Male"; break;
			 	case "en":LNG = "en-US"; break;
			 	case "de":LNG = "de-DE"; break;
			 	case "hi":LNG = "hi-IN"; break;
			 	case "id":LNG = "id-ID"; break;
			 	case "it":LNG = "it-IT"; break;
			 	case "nl":LNG = "nl-NL"; break;
			 	case "pl":LNG = "pl-PL"; break;
			 	case "es":LNG = "es-US"; break;

			 	case "ru":LNG = "ru-RU"; break;
			 	case "ja":LNG = "ja-JP"; break;
			 	case "ko":LNG = "ko-KR"; break;
			 	case "fr":LNG = "fr-FR"; break;
			 	case "pt":LNG = "pt-BR"; break;

			}


			for (var a=0; a<voices.length; a++){
			    if(LNG.indexOf("|")!=-1){
				var ARR=LNG.split("|");
				if(ARR[0]==voices[a].lang && voices[a].name.indexOf(ARR[1])!=-1){
					utterance.voice = voices[a];
				}
			    }else{
				if(LNG==voices[a].lang){
					utterance.voice = voices[a];
				}
			    }
			}
			var SP = 1.0;


			if(SLG_getTEMP("TTSvolume")!=null && SLG_getTEMP("TTSvolume")!="undefined" && SLG_getTEMP("TTSvolume")!="") TheVolume = SLG_getTEMP("TTSvolume");


			var PLANSHET = GEBI("SLG_player3");
		 	PLANSHET.style.display='block';
		 	var PLAYER = "<div id='PL_lbplayer'><table width='350' colspan='3' style='padding:6px;' bgcolor='#fff'><tr><td width=20><div id='SLG_controls' class='SLG_pause'></div></td><td width=5></td><td align='left' width=20><div id='SLG_volume' class='SLG_volume'></div></td><td><input type='range' min='0' max='10' value='"+TheVolume+"' class='SLG_slider' id='SLG_myRange'></td></tr></table></div>";
			PLANSHET.innerHTML=PLAYER;




                        if(TheNewText=="") TheNewText = speechText;

			utterance.text = TheNewText;
			utterance.rate = SP;
			utterance.volume = SLG_getTEMP("TTSvolume")*1/10;


			utterance.addEventListener('end', handleSpeechEvent);
			utterance.addEventListener('pause', handleSpeechPause);
			utterance.addEventListener('resume', handleSpeechResume);

			synth.speak(utterance);
			if(GEBI("PL_lbplayer").style.display!="block"){



			}

	if(SLG_getTEMP("TTSvolume")==null || SLG_getTEMP("TTSvolume")=="undefined" || SLG_getTEMP("TTSvolume")=="") SLG_setTEMP("TTSvolume","5");
	else SLG_setTEMP("TTSvolume",GEBI("SLG_myRange").value);
	if(SLG_getTEMP("TTSvolume")>0)	GEBI("SLG_volume").className="SLG_volume";
	else 	GEBI("SLG_volume").className="SLG_novolume";

	GEBI("SLG_myRange").value = SLG_getTEMP("TTSvolume");
 }catch(ext){}
}

function handleSpeechPause(){
	GEBI("SLG_controls").className="SLG_pause";
}

function handleSpeechResume(){
	GEBI("SLG_controls").className="SLG_play";
}

function handleSpeechEvent(){
	GEBI("SLG_controls").className="SLG_play";
	FirstLoop=0;	
}

function PlayPause(ob, event){   
 try{
    if(GEBI(ob).className=="SLG_play"){
	GEBI(ob).className="SLG_pause";
	if(FirstLoop==0){
		Reload(ob);
		FirstLoop=1;
	} else {
		synth.resume();	
		event.preventDefault();
	}
    } else {
	FirstLoop=1;
	event.preventDefault();
	GEBI(ob).className="SLG_play";
	synth.pause();	
    }
 }catch(ext){}
}

function Reload(ob){
 try{
    synth.cancel();    
    FirstLoop=0;	
    GOOGLE_TTS_backup();
    GEBI(ob).className="SLG_pause";
 }catch(ext){}
}

function PseudoDICT(text){
   var TO_ = GEBI('SLG_langDst').value;
   var WAY = SLG_TTSicn(SLG_DETECT,0);
   var WAY2 = SLG_TTSicn(TO_,1);
   var OUT="";
   if(SLG_TTS.indexOf(TO_)!=-1 || (G_TTS.indexOf(TO_)!=-1 && localStorage["SLG_GVoices"]!="0")){
	   if(WAY2==1) var SLG_myTTS = "<div id=_X><div id=_XL><div class=_V id=\"SLG_00\" lang=\""+TO_+"\" title=\"" + text + "\"></div></div><div id=_XR>" + text + "</div></div>";
	   else var SLG_myTTS = "<div id=_X><div id=_FL><div class=TTS"+WAY2+" id=\"SLG_00\" lang=\""+TO_+"\" title=\"" + text + "\"></div></div><div style='width:92%;text-align:right;' id=_AR>" + text + "</div></div>";
   OUT = OUT + "<div id=_A style='border:0px;'>" + SLG_myTTS + "</div>";
   }else   OUT = OUT + "<div id=_A style='border:0px;'>" + text + "</div>";			
   SLG_ALIGNER(TO_);
   return(OUT);
}

function SLG_ALIGNER(SLG_to){
 var nums=document.getElementsByTagName("div").length;

 if(SLG_to!="ar" && SLG_to!="iw" && SLG_to!="fa" && SLG_to!="yi" && SLG_to!="ur" && SLG_to!="ps" && SLG_to!="sd" && SLG_to!="ckb" && SLG_to!="ug" && SLG_to!="dv" && SLG_to!="prs"){
      for(var I = 0; I < nums; I++){
       if(document.getElementsByTagName("div")[I].id == "_A")	 document.getElementsByTagName("div")[I].style.textAlign="left";
      }
 } else {
      for(var I = 0; I < nums; I++){
       if(document.getElementsByTagName("div")[I].id == "_A")	document.getElementsByTagName("div")[I].style.textAlign="right";
      }
 }
}

function SAVEtheSTATE(){
// var txt = GEBI('SLG_DICTtext').value.replace(/'/ig,'"');
 var txt = GEBI('SLG_DICTtext').value;
 var userText = txt.replace(/^\s+/, '').replace(/\s+$/, '');
 if (userText === '') txt = "";
 if(txt != ""){
	 txt = txt.trim();
	 FExtension.store.set("SLG_SavedText_gt",txt);
 } else DICTClear();
}

function GET_Y_DICT(){
	GEBI('SLG_DICTtext').value=GEBI('SLG_DICTtext').value.replace(/</ig,"");
	GEBI('SLG_DICTtext').value=GEBI('SLG_DICTtext').value.replace(/>/ig,"");

	var text = GEBI('SLG_DICTtext').value;
	getYSID(0);
	setTimeout(function(){
	    var YSLIDL = setInterval(function(){
		if(YSIDstatus === true) {
			clearInterval(YSLIDL);
			YSLIDL="";
			var dir = GEBI('SLG_langSrc').value+"/"+GEBI('SLG_langDst').value;


			getY_TRANSLATION(dir,text);
		} 
	    },5);  
       	},5);  		
}

function getYSID(st){
 	var YK = FExtension.store.get("SLG_YKEY");
	YSIDold = YK;
	if(st==1) YK=0;
	if(YK==0) {
	       	var baseUrl="https://translate.yandex.net/website-widget/v1/widget.js?widgetId=ytWidget&pageLang=en&widgetTheme=light&autoMode=false";
		var ajaxRequest;	
		try{
			ajaxRequest = new XMLHttpRequest();
		} catch (e){
			try{
				ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
				try{
					ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (e){
					return false;
				}
			}
		}
		ajaxRequest.onreadystatechange = function(){
		        var resp = "";
			if(ajaxRequest.readyState == 4 && ajaxRequest.status == 200){
		            var resp = ajaxRequest.responseText.match(/sid\:\s\'[0-9a-f\.]+/);
	                    if (resp && resp[0] && resp[0].length > 7) {
               		        YSID = resp[0].substring(6);

				var H = FExtension.store.get("SLG_YHIST");
				if(H == "") H="First key";
				else H = H +"; Rekey";
				var K = "***"+YSID.substring(45);
				FExtension.store.set("SLG_YHIST",H+" -> "+K);
				FExtension.store.set("SLG_YKEY", YSID);
	                        YSIDstatus = true;
               		    } else {
				var H = FExtension.store.get("SLG_YHIST");
				FExtension.store.set("SLG_YHIST",H+"; KEY not found");
	                        YSIDstatus = false;
				FExtension.store.set("SLG_YKEY", "0");
               		    }
			}else { 
				if(ajaxRequest.readyState == 4){
				    var msg = "Yandex: "+FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extnotrsrv');
				    msg = PseudoDICT(msg);
				    GEBI("SLG_DICTsource").innerHTML=msg;
				    GEBI('SLG_loading').style.display='none';
				}
			}
		}
		ajaxRequest.open("GET", baseUrl, true);
		ajaxRequest.setRequestHeader("Access-Control-Allow-Headers", "*");
		ajaxRequest.setRequestHeader("Access-Control-Allow-Origin", "null");
		ajaxRequest.send();
	  } else {
		YSID = FExtension.store.get("SLG_YKEY");
                YSIDstatus = true;
	  }
}


function getY_TRANSLATION(dir, text){
        var tmp=dir.split("/");
	var mySourceLang=tmp[0];
	if(SLG_DETECT!="") {
		mySourceLang=SLG_DETECT;
		dir = dir.replace("auto",SLG_DETECT);
		var tmpdir = dir.split("/");
		dir = SLG_DETECT+"/"+tmpdir[1];
	}

       	dir = dir.replace("zh-CN","zh");
	dir = dir.replace("jw","jv");
        dir = dir.replace("iw","he");
	dir = dir.replace(/srsl/g,"sr");
        dir = dir.replace(/tlsl/g,"tl");
        dir = dir.replace("/","-");

	var myTargetLang=tmp[1];
  	var baseUrl="https://translate.yandex.net/api/v1/tr.json/translate?srv=tr-url-widget&id=" + YSID + "-0-0&format=html&lang=" + dir + "&text="+ encodeURIComponent(text);

	var ajaxRequest;	
	try{
		ajaxRequest = new XMLHttpRequest();
	} catch (e){
		try{
			ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			try{
				ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (e){
				return false;
			}
		}
	}
	ajaxRequest.onreadystatechange = function(){
	        var resp = "";
		if(ajaxRequest.readyState == 4 && ajaxRequest.status == 200){
	            var resp = ajaxRequest.responseText;

        	    resp=resp.replace(/\\"/ig,"'");
        	    if(resp.indexOf('text":["')!=-1){
	    		var R1 = resp.split('text":["');
		    	var R2 = R1[1].split('"');
	    		var R3 = R2[0];
       		        R3 = R3.replace(/\\n/ig,"\n");
		     	R3 = PseudoDICT(R3);
                        GEBI('SLG_DICTsource').innerHTML=R3;

			var theQ = text.split(" ").length;
			if (theQ==1) CNTR('2332',dir.replace("-","/"), text.length);
			else CNTR('2322',dir.replace("-","/"), text.length);


			GEBI('SLG_loading').style.display='none';
			     	GEBI('SLG_DICTtext').style.direction="ltr";
			     	GEBI('SLG_DICTtext').style.textAlign="left";
			     	var SLG_lng = GEBI('SLG_langSrc').value;

			     	if(localStorage["SLG_no_detect"]=="true" || SLG_lng=="auto") SLG_lng=SLG_DETECT;
				if(SLG_lng=="ar" || SLG_lng=="iw" || SLG_lng=="fa" || SLG_lng=="yi" || SLG_lng=="ur" || SLG_lng=="ps" || SLG_lng=="sd" || SLG_lng=="ckb" || SLG_lng=="ug" || SLG_lng=="dv" || SLG_lng=="prs"){
			  		 GEBI('SLG_DICTtext').style.direction="rtl";
					 GEBI('SLG_DICTtext').style.textAlign="right";
			     	}
			     	GEBI('SLG_DICTsource').style.direction="ltr";
			     	GEBI('SLG_DICTsource').style.textAlign="left";
			     	var SLG_lng2 = GEBI('SLG_langDst').value;
				if(SLG_lng2=="ar" || SLG_lng2=="iw" || SLG_lng2=="fa" || SLG_lng2=="yi" || SLG_lng2=="ur" || SLG_lng2=="ps" || SLG_lng2=="sd" || SLG_lng2=="ckb" || SLG_lng2=="ug" || SLG_lng2=="dv" || SLG_lng2=="prs"){
			  		 GEBI('SLG_DICTsource').style.direction="rtl";
				 	 GEBI('SLG_DICTsource').style.textAlign="right";
			     	}


			        if (FExtension.store.get("SLG_TH_1")==1){
			        	var SLnow = new Date();
			        	SLnow=SLnow.toString();
			        	var TMPtime=SLnow.split(" ");
		        		var CurDT=TMPtime[1]+" "+TMPtime[2]+" "+TMPtime[3]+", "+TMPtime[4];
		        		if(mySourceLang=="auto") mySourceLang=SLG_DETECT;

					
					setTimeout(function(){
                                                text=text.replace(/~/ig," ");
                                                resp=resp.replace(/~/ig," ");
                                                PROV = SLG_getTEMP("DPROV");
				        	FExtension.store.set("SLG_History", text + "~~" + R3 + "~~" + mySourceLang + "|" + myTargetLang + "~~"+ FExtension.store.get("THE_URL") +"~~"+CurDT+"~~6~~"+PROV[0]+"^^" + FExtension.store.get("SLG_History"));
					},1500);


			        }


		   } else {
                        YSIDstatus = false;
			FExtension.store.set("SLG_YKEY", YSID);
			var H = FExtension.store.get("SLG_YHIST");
			FExtension.store.set("SLG_YHIST",H+"; Keys are equal -> yandex response: " +resp);
		    	var msg = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extTOO_MANY_REQUESTS');
			msg = msg.replace("XXX","Yandex");
			SLG_alert(msg);
			GEBI("SLG_alert").style.height="185px";
			GEBI('SLG_indicator'+ind).style.display='none';
		   }
		} else {
		    if(ajaxRequest.status == 403){
			FExtension.store.set("SLG_YKEY", 0);
			YSID=0;
			if(YSID!=YSIDold){
				GET_Y_DICT();
				var H = FExtension.store.get("SLG_YHIST");
				FExtension.store.set("SLG_YHIST",H+"; Yandex answers: #405 -> requesting a new key");
			}else{
	                        YSIDstatus = false;
				FExtension.store.set("SLG_YKEY", 0);
				YSIDold = 0;
			}
		    }else { 
			if(ajaxRequest.readyState == 4){
			    var msg = "Yandex: "+FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extnotrsrv');
			    msg = PseudoDICT(msg);
			    GEBI("SLG_DICTsource").innerHTML=msg;
			    GEBI('SLG_loading').style.display='none';
			}
		    }
		}
	}
	ajaxRequest.open("GET", baseUrl, true);
	ajaxRequest.setRequestHeader("Access-Control-Allow-Headers", "*");
	ajaxRequest.setRequestHeader("Access-Control-Allow-Origin", "null");
	ajaxRequest.send();
} 



function TTSDODetection(myTransText) {
  if(myTransText=="") myTransText = GEBI("SLG_DICTtext").value;
  if(myTransText!=""){


    var cntr = myTransText.split(" ");
    var newTEXT = myTransText;


    var num = Math.floor((Math.random() * SLG_GEO.length)); 
    var theRegion = SLG_GEO[num];
    if(FExtension.store.get("SLG_DOM")!="auto") theRegion=FExtension.store.get("SLG_DOM");

    var baseUrl = 'https://translate.google.'+theRegion+'/translate_a/single';
    var SLG_Params="client=gtx&dt=t&dt=bd&dj=1&source=input&q="+encodeURIComponent(truncStrByWord(newTEXT,100)) + "&sl=auto&tl=en&hl=en";

	var ajaxRequest;  
	try{
		ajaxRequest = new XMLHttpRequest();
	} catch (e){
		try{
			ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			try{
				ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (e){
				SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extError1'));
				return false;
			}
		}
	}
	ajaxRequest.onreadystatechange = function(){
		if(ajaxRequest.readyState == 4){
                        var resp = ajaxRequest.responseText;
                        var captcha=0;
			if(resp.indexOf('CaptchaRedirect')!=-1) captcha = 1;
		        if(resp.indexOf('ld_result":{"srclangs":["')!=-1) {

                                var GDImTranslator_lang=resp.split('ld_result":{"srclangs":["');
				var GDImTranslator_lang1=GDImTranslator_lang[1].split('"');
 				resp=GDImTranslator_lang1[0];

        	                var thetemp=GEBI("SLG_langSrc").value.replace("zh-TW","zt");
                	        thetemp=thetemp.replace("zh-CN","zh");
				SLG_DETECT = resp;
				
				// NOT TRUSTED LANGUAGES
				myTransText = myTransText.trim();
				globaltheQ = myTransText.split(" ").length;

	                        if(DO_NOT_TRUST_WORD.indexOf(SLG_DETECT)!=-1 && globaltheQ==1){
					SLDetector(myTransText);
					return false;
				}	

	                        if(SLG_DETECT==DO_NOT_TRUST_TEXT){
					SLDetector(myTransText);
					return false;
				//----------------------
				} else { 

					var cnt=0;
        		                for (var i=0;i<BASELANGSCodes.length;i++){
						if(resp == BASELANGSCodes[i]){
							cnt=1; 
							SLG_DETECT = BASELANGSCodes[i];
			                	        GEBI("SLG_DETECTED").innerText = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetected')+" "+BASELANGSNames[i];
							GEBI("SLG_DETECTED").style.display='block';
	
						}
					}
	                	        SLG_WRONGLANGUAGEDETECTED=0;

					if(cnt==0){
						//SLG_DETECT="zu";
						SLG_setTEMP("PROV","Google"); 
                                                GEBI("SLG_DETECTED").innerText="";
				    		setTimeout(function(){
							for(var i=0; i<LISTofPR.length; i++){
					 			if(GEBI("SLG_P"+i).title.toLowerCase() == "google"){GEBI("SLG_P"+i).className="SLG_TAB_DICT";}
								else GEBI("SLG_P"+i).className="SLG_TAB_DEACT_DICT";
							}
							GEBI("SLG_DETECTED").style.visibility="hidden";
					        },500); 

			                        SLG_WRONGLANGUAGEDETECTED=1;
					}

					SET_PROV();
                                        SET_FIRST_AVAILABLE_PROV();
				}

			} else 	SLDetectPATCH(myTransText);
		}

	}
	baseUrl = baseUrl +"?"+ SLG_Params;
	ajaxRequest.open("GET", baseUrl, true);
        ajaxRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
//        ajaxRequest.setRequestHeader("Referer", "https://translate.google.com/");
	ajaxRequest.send(SLG_Params);         
// } else {
//	SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Text'));
 }
                                
}                                 

function TTSSLDetectPATCH(theText){
        TTSSLDetector(theText);
        setTimeout(function() { 
	        var lng = SLG_DETECT;
		if(lng!='un'){
			SLG_DETECT = lng;
			var templang="";

                        for (var i=0;i<SLDetLngCodes.length;i++){
				if(lng == SLDetLngCodes[i]){ SLG_DETECT = lng; DetLangName = SLDetLngNames[i];}
                       	}
			if(DetLangName!="undefined") {
				GEBI("SLG_DETECTED").style.display="block";
				GEBI("SLG_DETECTED").style.visibility="visible";
			}
			GEBI("SLG_DETECTED").innerText = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetected') + " "+DetLangName;
		} else {
			SLG_DETECT = "en";
			GEBI("SLG_DETECTED").innerText = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'DetectedEn');
		}
	}, 300);
}


function TTSSLDetector (text){

	if(text=="") text = GEBI("SLG_DICTtext").value;
        if(text!=""){
  	var theLIMIT = 100;                            
	var SLDImTranslator_url = ImTranslator_theurl+"ld.asp?tr=pl_d&text="+encodeURIComponent(truncStrByWord(text,theLIMIT));
		var ajaxRequest;  
		try{
			ajaxRequest = new XMLHttpRequest();
		} catch (e){
			try{
				ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
				try{
					ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (e){
					SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extError1'));
					return false;
				}
			}
		}
		ajaxRequest.onreadystatechange = function(){
			if(ajaxRequest.readyState == 4){
                        	var tmp = ajaxRequest.responseText;
				if(tmp.indexOf("#|#")!=-1){
				    var tmp2 = tmp.split("#|#");
		                    SLG_DETECT="en";
        		            if(tmp2[0].length>0 && tmp2[0].length<7) SLG_DETECT=tmp2[0];
        		            if(SLG_DETECT == "zh") SLG_DETECT="zh-CN";
        		            if(SLG_DETECT == "zt") SLG_DETECT="zh-TW";
        		            var cnt=0;
				    for (var z=0; z<SLDetLngCodes.length; z++){
				       if(SLG_DETECT==SLDetLngCodes[z]) {cnt=1;DetLangName=SLDetLngNames[z];break; }
				    }
		                    SLG_WRONGLANGUAGEDETECTED=0;
				    if(cnt==0){
				    	setTimeout(function(){
						GEBI("SLG_DETECTED").style.visibility="hidden";
				        },500); 
					//SLG_DETECT = document.getElementById('SLG_langSrc').value;
		                        SLG_WRONGLANGUAGEDETECTED=1;
//					SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extnotsupported'));
				    }

                		    if(document.getElementById('SLG_langSrc').value!=SLG_DETECT){
	                		    if(tmp2[0]!="un"){
						GEBI("SLG_DETECTED").innerText = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetected')+" "+DetLangName;
					    }
			            }
			    	} else SLG_DETECT="en";

				SET_PROV();
				SET_FIRST_AVAILABLE_PROV();
			}
		}
		ajaxRequest.open("POST", SLDImTranslator_url, true);
		ajaxRequest.send(null);                          
//		} else {
//			SLG_alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extNo_Text'));
		}

}

function ACTIVATE_THEME(st){
 	if(st==1){
		var bg="#191919";
		var clr="#BF7D44";
		var clr_deact="#BDBDBD";
		GEBI("SLG_body").style.filter=SLG_DARK;
		GEBI("SLG_body").style.background=bg;
		GEBI("SLG_trans_button").style.filter=SLG_DARK;
                GEBI("SLG_DETECTED").style.color=clr;
		GEBI("SLG_h1").style.color=clr;
		GEBI("SLG_h3").style.color=clr;
		GEBI("SLG_tab1").style.color=clr;
		GEBI("SLG_tab2").style.color=clr;
                if(GEBI("SLG_P0")){
			ACTIVATE_THEME_TABS(1);
		}

	    	setTimeout(function(){
			ACTIVATE_THEME_TABS(1);
			var OPT = document.getElementsByTagName("option");
			for(var i=0; i<OPT.length; i++){
				OPT[i].setAttribute("style", "background:"+bg+";color:#fff;");
			}  
	        },1000);
                if(GEBI("SLG_CloseAlertBTN")) GEBI("SLG_CloseAlertBTN").style.filter=SLG_DARK;
	}
}

function ACTIVATE_THEME_TABS(st){
 	if(st==1){
		var clr="#BF7D44";
		var clr_deact="#BDBDBD";

		if(GEBI("SLG_P0").className!="SLG_TAB_DEACT_DICT") GEBI("SLG_P0").style.color=clr;
		else GEBI("SLG_P0").style.color=clr_deact;
		if(localStorage["SLG_other_gt"]=="1"){   
			if(GEBI("SLG_P1").className!="SLG_TAB_DEACT_DICT") GEBI("SLG_P1").style.color=clr;		
			else GEBI("SLG_P1").style.color=clr_deact;
			if(GEBI("SLG_P2").className!="SLG_TAB_DEACT_DICT") GEBI("SLG_P2").style.color=clr;
			else GEBI("SLG_P2").style.color=clr_deact;
			if(GEBI("SLG_P3").className!="SLG_TAB_DEACT_DICT") GEBI("SLG_P3").style.color=clr;
			else GEBI("SLG_P3").style.color=clr_deact;
		}
	}
}

function ACTIVATE_THEME_PARSER(st){
 	if(st==1){
		var hrefs = document.getElementsByClassName("_ALNK");
		for(var i=0; i<hrefs.length; i++) hrefs[i].setAttribute("style", "filter:invert(100%)");
	}
}

function i18n_LanguageDetect(text){
    	return("");
}

function CNTR(id,dir,nmb){
	    chrome.runtime.sendMessage({greeting: "CNTR:>"+id+","+dir+","+nmb}, function(response) {}); 
}


function CNTRP(id,dir,nmb){
	    chrome.runtime.sendMessage({greeting: "CNTRP:>"+id+","+dir+","+nmb}, function(response) {}); 
}

function SLG_ADD_LONG_NAMES(codes){
	var OUT = "";
	var MENU = SLG_Languages.split(",");
	if(MENU.length>=SLG_FAV_START){
		var FAV = codes.split(",");
		for (var i=0; i<FAV.length; i++){
			var MARKER = 0;
			for (var j=0; j<MENU.length; j++){
				var M = MENU[j].split(":");
				if(FAV[i] == M[0]){
					OUT = OUT + M[0] + ":" + M[1];
					MARKER=1;
				}
			}
			if(MARKER==1){
				if(i <= FAV.length) OUT = OUT + ","
			}
		}
	}
	if(OUT.slice(-1)==",") 	OUT = OUT.slice(0, OUT.length - 1);
	return OUT;	
}

function SLG_SAVE_FAVORITE_LANGUAGES(ln){
	var OUT = "";
	var OUT2 = "";
	SLG_FAV_LANGS_IMT = FExtension.store.get("SLG_FAV_LANGS_IMT");
	if(SLG_FAV_LANGS_IMT.indexOf(ln)!=-1){
		SLG_FAV_LANGS_IMT = SLG_FAV_LANGS_IMT.replace(ln+",",""); 
		if(SLG_FAV_LANGS_IMT.indexOf(",")==-1) SLG_FAV_LANGS_IMT = SLG_FAV_LANGS_IMT.replace(ln,""); 
	}
	OUT = ln + ",";	
	var ARR = SLG_FAV_LANGS_IMT.split(",");
	for (var i = 0; i < ARR.length; i++){
	 	OUT = OUT + ARR[i]+",";
	}
	if(OUT.slice(-1)==",") 	OUT = OUT.slice(0, OUT.length - 1);
	var TMP = OUT.split(",");
	if(TMP.length > SLG_FAV_MAX) {
		for (var j = 0; j < TMP.length-1; j++){
		 	OUT2 = OUT2 + TMP[j]+",";
		}		
		OUT = OUT2 
	}
	if(OUT.slice(-1)==",") 	OUT = OUT.slice(0, OUT.length - 1);
       	FExtension.store.set("SLG_FAV_LANGS_IMT", OUT);
	var MENU = SLG_Languages.split(",");
	if(MENU.length>=SLG_FAV_START){
		SLG_REBUILD_TARGET_LANGUAGE_MENU(OUT,"SLG_langDst");
	}
}


function SLG_REBUILD_TARGET_LANGUAGE_MENU (FAV, ob){
		var doc = document;
		var MENU = SLG_Languages.split(",");
		if(MENU.length>=SLG_FAV_START){
        	        doc.getElementById(ob).innerText="";
			var SEL = 0;
			if(FAV!=""){
                        	FAV = SLG_ADD_LONG_NAMES(FAV);
				var favArr=FAV.split(","); 
				for(var J=0; J < favArr.length; J++){
				    var CURlang = favArr[J].split(":");
				    var OB_FAV = doc.createElement('option');

				    var v = doc.createAttribute("value");				    		
				    v.value = CURlang[0];
				    OB_FAV.setAttributeNode(v);

				    if(J == 0){
					    var sel = doc.createAttribute("selected");
					    sel.value = "selected";
					    OB_FAV.setAttributeNode(sel);
					    var SLG_langDst = CURlang[0];
					    SEL = 1;	
				    }

				    OB_FAV.appendChild(doc.createTextNode(CURlang[1]));
				    doc.getElementById(ob).appendChild(OB_FAV);
				}
				OB_FAV = doc.createElement('option');
				var d = doc.createAttribute("disabled");
				d.value = true;
				OB_FAV.setAttributeNode(d);
				var all = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extwptDAll');
			    	OB_FAV.appendChild(doc.createTextNode("-------- [ "+ all +" ] --------"));
			    	doc.getElementById(ob).appendChild(OB_FAV);
			}
			var tmp =favArr[0].split(":");
		        var thelang = tmp[0];
			for(J=0; J < MENU.length; J++){
			    CURlang = MENU[J].split(":");
			    var option = doc.createElement('option');
			    if(SEL == 0){
				    if(CURlang[0] == thelang){
					    var sel = doc.createAttribute("selected");
					    sel.value = "selected";
					    option.setAttributeNode(sel);
				    }
			    }
			    v = doc.createAttribute("value");
			    v.value = CURlang[0];
			    option.setAttributeNode(v);
			    option.appendChild(doc.createTextNode(CURlang[1]));
			    doc.getElementById(ob).appendChild(option);
			}
		} else {
			doc.getElementById(ob).innerText="";
		        var thelang = localStorage["SLG_langDst2"];
			for(J=0; J < MENU.length; J++){
			    CURlang = MENU[J].split(":");
			    var option = doc.createElement('option');
			    if(CURlang[0] == thelang){
				    var sel = doc.createAttribute("selected");
				    sel.value = "selected";
				    option.setAttributeNode(sel);
			    }
			    v = doc.createAttribute("value");
			    v.value = CURlang[0];
			    option.setAttributeNode(v);
			    option.appendChild(doc.createTextNode(CURlang[1]));
			    doc.getElementById(ob).appendChild(option);
			}

		}
}


function SLG_GLOBAL_RESIZER(){        

       	GLOBAL_HEIGHT = window.innerHeight;
	GLOBAL_WIDTH = window.innerWidth;

	var MIN_W = 465

	if(GLOBAL_WIDTH==484 || WINDOW_TYPE==1) REMOTE_Voice_Close(SLG_EVENT);
	if(GLOBAL_WIDTH >= MIN_W){
		if(GEBI('SLG_alert').style.display=="block"){
			var obw = GEBI('SLG_alert').clientWidth;
			GEBI('SLG_alert').style.marginLeft=(GLOBAL_WIDTH/2-obw/2)+"px";
			var obh = GEBI('SLG_alert').clientHeight;
			GEBI('SLG_alert').style.marginTop=(GLOBAL_HEIGHT/2-obh/2-50)+"px";
		}

		GEBI("SLG_LR").style.width='100%';
		var W = (GLOBAL_WIDTH-15)*1;
		GEBI("SLG_translate_container_app").style.width=W+'px';
		GEBI("button_area").style.width='85%';
		GEBI("button_area").align='right';
		GEBI("SLG_trans_button").style.marginRight='10px';
		GEBI("SLG_DICTsource").style.width=(W-22)+"px";
		GEBI("SLG_services").style.width=(W-4)+"px";
		GEBI("SLG_links").style.marginLeft=(W-340)+"px";
		GEBI("SLG_DICTtext").style.marginLeft="10px";
		if(!GEBI("_Y") && GEBI("_AR")){
			GEBI("_AR").style.float="right";
		}



		if((W)>520){
			GEBI("SLG_Search").style.width=(W-100)+'px';
		}

		localStorage["WINDOW_WIDTH"]=GLOBAL_WIDTH;
        }
	var MIN_H = 450
	if(GLOBAL_HEIGHT >= MIN_H){
		var H = (GLOBAL_HEIGHT-250)*1;
		GEBI("SLG_DICTsource").style.height=H+"px";
		localStorage["WINDOW_HEIGHT"]=GLOBAL_HEIGHT;
       }
}

function SetProperHeight(h){
	var h = window.innerHeight-h+40;
	GEBI("SLG_DICTsource").style.minHeight = "20px";
	GEBI("SLG_DICTsource").style.height = h+"px";
}

function NoProvidersAlert(){
	var msg = FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLPNotSupported');
	var selectDst = GEBI('SLG_langDst');
	var selectedDstIndex = selectDst.selectedIndex;
	var selectedDstText = selectDst.options[selectedDstIndex].text; 
	var selectSrc = GEBI('SLG_langSrc');
	var selectedSrcIndex = selectSrc.selectedIndex;
	var selectedSrcText = selectSrc.options[selectedSrcIndex].text; 
	if(selectSrc.value=="auto" || GEBI("SLlocpl").checked==false) selectedSrcText=DetLangName;
	if(GEBI("SLG_DETECTED").innerText!=""){
           var tmp = GEBI("SLG_DETECTED").innerText.split(":");
	   selectedSrcText = tmp[1];
	}
	msg = msg.replace("XXX",selectedSrcText);
	msg = msg.replace("YYY",selectedDstText);
	msg = msg + "\n\n" + "Please activate all providers in the Options";
	SLG_alert(msg); 
	GEBI("SLG_DICTsource").innerText="";
}

function DETERMIN_IF_LANGUAGE_IS_AVAILABLE(){
	try{
		GEBI("SLG_P0").className="SLG_TAB_DICT";
		var T = GEBI('SLG_langDst').value;
		var F = GEBI('SLG_langSrc').value;
		if(SLG_DETECT!="") F = SLG_DETECT;
		var lngarr = LISTofLANGsets[0].split(",");
		var cnt = 0;
		var cnt1 = 0;
		var cnt2 = 0;
		if(lngarr.length>1 && T!=""){
			for(var i=1; i<lngarr.length; i++){
				if(lngarr[i]==T) cnt1++;
				if(lngarr[i]==F) cnt2++;
			}
		}
		if(cnt1>0 && cnt2>0) cnt=1;
		if(cnt==0) {
			GEBI("SLG_DICTsource").innerText="";
			GEBI("SLG_P0").className="SLG_TAB_DEACT_DICT";
		} else GEBI("SLG_P0").className="SLG_TAB_DICT"; 
		return(cnt);
	} catch(ex){}
}

function DetectBig5(myTransText){
    var all = myTransText.length;
    var count = 0;
    for (var i = 0, len = myTransText.length; i < len; i++) {
	var rr = myTransText[i].match(/[\u3400-\u9FBF]/);
	if(rr) count ++;
    }
    var other = all-count;
    var OUT = 0	
    if(other<=count) OUT=1
    return(OUT);
}


function startCopyright(){ 
	FExtension.browserPopup.openNewTab("https://about.imtranslator.net/about/company/");
}
