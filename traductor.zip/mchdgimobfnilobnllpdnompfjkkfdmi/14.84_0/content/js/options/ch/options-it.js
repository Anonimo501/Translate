'use strict';
var SLG_DARK="invert(95%)";

var SLG_Languages = CUSTOM_LANGS(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLanguages'));

(function(){GEBI("SRV3").addEventListener("click",function(){SLG_ACTIVE = GEBI("SRV3"); SLG_TMP=SLG_ACTIVE.value; SLG_ACTIVE.focus();SLG_MSG_HANDLER(event);},!1); } )();
(function(){GEBI("SRV3").addEventListener("mouseout",function(){NoneColor(3);},!1); } )();
(function(){GEBI("SLG_del3").addEventListener("click",function(){SLG_DEL_AUTO(3);},!1);} )();
(function(){GEBI("SRV3").addEventListener("paste",function(){ PREVENT_PASTE(event); },!1);} )();

(function(){GEBI("SRV4").addEventListener("click",function(){SLG_ACTIVE = GEBI("SRV4"); SLG_TMP=SLG_ACTIVE.value; SLG_ACTIVE.focus();SLG_MSG_HANDLER(event);},!1); } )();
(function(){GEBI("SRV4").addEventListener("mouseout",function(){NoneColor(4);},!1); } )();
(function(){GEBI("SRV4").addEventListener("paste",function(){ PREVENT_PASTE(event); },!1);} )();

(function(){GEBI("SRV11").addEventListener("click",function(){SLG_ACTIVE = GEBI("SRV11"); SLG_TMP=SLG_ACTIVE.value; SLG_ACTIVE.focus();SLG_MSG_HANDLER(event);},!1); } )();
(function(){GEBI("SRV11").addEventListener("mouseout",function(){NoneColor(11);},!1); } )();
(function(){GEBI("SRV11").addEventListener("paste",function(){ PREVENT_PASTE(event); },!1);} )();

(function(){GEBI('SLG_inject_before').addEventListener("click",function(){ OneOfTwo(1); },!1);} )();
(function(){GEBI('SLG_hide_translation').addEventListener("click",function(){ OneOfTwo(2); },!1);} )();
(function(){window.addEventListener("mousemove",function(){NoneColor(3);},!1);} )();
(function(){GEBI("SLG_info").addEventListener("click",function(){FExtension.browserPopup.openNewTab(this.href);},!1);} )();

(function(){GEBI("SLG_FK_box1").addEventListener("click",function(){ SLG_HIDE_HK("SLG_FK_box1","SLG_HIDE3");},!1); } )();
(function(){GEBI("SLG_FK_box2").addEventListener("click",function(){ SLG_HIDE_HK("SLG_FK_box2","SLG_HIDE4");},!1); } )();
(function(){GEBI("SLG_FK_box11").addEventListener("click",function(){ SLG_HIDE_HK("SLG_FK_box11","SLG_HIDE11");},!1); } )();

(function(){GEBI("SLG_LOC").addEventListener("change",function(){SLG_SAVE_LOC();},!1);} )();
(function(){GEBI("SLG_LNG_STATUS").addEventListener("click",function(){ SLG_LANGS(); },!1); } )();

(function(){GEBI("SLG_THEME").addEventListener("change",function(){SLG_SAVE_THEME();},!1);} )();


(function(){GEBI("reset_all3").addEventListener("click",function(){ RESET_ALL_HK(3);},!1);} )();
(function(){GEBI("reset_all4").addEventListener("click",function(){ RESET_ALL_HK(4);},!1);} )();
(function(){GEBI("reset_all11").addEventListener("click",function(){ RESET_ALL_HK(11);},!1);} )();

(function(){window.addEventListener("mousemove",function(){
	BUILD_RESET_ICN(3);
	BUILD_RESET_ICN(4);
	BUILD_RESET_ICN(11);
},!1);} )();

(function(){window.addEventListener("click",function(event){
	SLG_MSG_HANDLER(event);
},!1);} )();



//AUTOSAVE BLOCK
window.addEventListener('change',function(e){
	save_options(0);
},!1);
//AUTOSAVE BLOCK

(function(){
    window.addEventListener('load',function(){
        GEBI('SLG_translate_container').style.opacity="1";
	CONSTRUCTOR();
	var OB = GEBI('SLG_langSrc_it');
	if(FExtension.store.get("SLG_LNG_LIST").indexOf("auto")!=-1 || FExtension.store.get("SLG_LNG_LIST")=="all"){
		var OB1 = document.createElement('option');
		var v = document.createAttribute("value");
		v.value = "auto";
		OB1.setAttributeNode(v);
		OB1.appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetect_language_from_box')));
		OB.appendChild(OB1); 
	}
	var SLG_TMP = SLG_Languages.split(",");
	for(var J=0; J < SLG_TMP.length; J++){
	    var SLG_TMP2=SLG_TMP[J].split(":");
	    var OB2 = document.createElement('option');
	    var v = document.createAttribute("value");
	    v.value = SLG_TMP2[0];
	    OB2.setAttributeNode(v);
	    //OB2.appendChild(document.createTextNode(SLG_TMP2[1].replace("&#160;"," ")));
	    OB2.appendChild(document.createTextNode(SLG_TMP2[1]));
	    OB.appendChild(OB2);
	}

	var OB3 = GEBI('SLG_langDst_it');
	for(var J=0; J < SLG_TMP.length; J++){
	    var SLG_TMP2=SLG_TMP[J].split(":");
	    var OB2 = document.createElement('option');
	    v = document.createAttribute("value");
	    v.value = SLG_TMP2[0];
	    OB2.setAttributeNode(v);
	    //OB2.appendChild(document.createTextNode(SLG_TMP2[1].replace("&#160;"," ")));
	    OB2.appendChild(document.createTextNode(SLG_TMP2[1]));
	    OB3.appendChild(OB2);
	}
	INIT();
    },!1);
})();

function CONSTRUCTOR(){
	GEBI('SLG_BG_op').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSLBG_op')));
	GEBI('SLG_setLS4allTr').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSLsetLS4allTr')));
	GEBI('SLSeSo').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSeSo')));
	GEBI('SLSeTa').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSeTa')));
	GEBI('SLG_DetSoLaAu').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetSoLaAu')));
	GEBI('SLG_TR_op').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extTR_op')));
	GEBI('SLG_enable_dict').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extEnable_Dict')));
	GEBI('SLG_HotKeys').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extHotKeys')));
	GEBI('SLG_TOMS').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extTOMS')));
	GEBI('SLG_ClearTr').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extClearTr')));
	GEBI('SLG_Appearance').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extAppearance')));
	GEBI('SLG_Color').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extColor')));
	GEBI('SLG_EIB').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extEIB')));
	GEBI('SLG_IBO').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extIBO')));
	GEBI('SLG_LB').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLB')));
	GEBI('SLG_ABW').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extABW')));
	GEBI('SLG_HO').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extHO')));
	GEBI('SLG_TrHi').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extTrHist')));
	GEBI('SLG_InTH').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extInTH')));
	GEBI('SLG_il').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLOC')));
	GEBI('SLG_L_BOX').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLangs')+":"));
	GEBI('SLG_LNG_STATUS').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extCustomize')));
	GEBI('SLG_INLINEflip').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSwitch_languages_ttl')));

	GEBI('SLG_LIST_TR_PR').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLIST_TR_PR')));

	GEBI('SLG_theme_ttl').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extTHEME')));
	GEBI('SLG_theme_1').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLIGHT')));
	GEBI('SLG_theme_2').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDARK')));
	GEBI('SLG_tr_with_target').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSeTa')));

	switch(PLATFORM){
	 case "Opera" : GEBI('SLG_info').href="https://about.imtranslator.net/tutorials/presentations/google-translate-for-opera/opera-inline-options/"; break;
	 case "Chrome": GEBI('SLG_info').href="https://about.imtranslator.net/tutorials/presentations/imtranslator-for-chrome/inline-translator-options/"; break;
	 default      : GEBI('SLG_info').href="https://about.imtranslator.net/tutorials/presentations/";break;
	}
        SLG_SHOWHIDEINLINEPROVIDERS();

	INLINE_PR_BUILDER("SLG_ALL_PROVIDERS_IT");
	ACTIVATE_THEME(FExtension.store.get("THEMEmode"));
}


(function(e){
	document.addEventListener("click",function(e){
	      if(e.target.id!="SLG_style" && GEBI("SLG_CL")){
		 GEBI("SLG_CL").style.display='none';
		 GEBI("SLG_style").style.background='#'+GEBI("SLG_style").value;
	      }
	},!1);
} )();

(function(e){
	GEBI('SLG_style').addEventListener("keydown",function(e){
	      GEBI("SLG_style").style.background='#'+GEBI("SLG_style").value;
	},!1);
} )();

(function(e){
	GEBI('SLG_style').addEventListener("keyup",function(e){
	      GEBI("SLG_style").style.background='#'+GEBI("SLG_style").value;
	},!1);
} )();

(function(e){
	GEBI('SLG_style').addEventListener("click",function(e){
		setTimeout(function() {
		      GEBI("SLG_style").focus();
		      GEBI("SLG_style").select();
		}, 300);

	},!1);
} )();



function INIT(){
  ACTIVATE_MENU_ELEMENT(2);
  GEBI("SLG_LOC").value=FExtension.store.get("SLG_LOCALIZATION");
  //*************************** inliner ***********************************
  var SLG_style = GEBI("SLG_style");
  var SLG_style_tr = FExtension.store.get("SLG_style");
  SLG_style.value = SLG_style_tr;
  SLG_style.style.backgroundColor = "#"+SLG_style_tr;
  
  var SLG_inject_brackets_tr = FExtension.store.get("SLG_inject_brackets"); 
  if(SLG_inject_brackets_tr=="true")  GEBI("SLG_inject_brackets").checked = true;
  else GEBI("SLG_inject_brackets").checked = false;
  
  var SLG_inject_before_tr = FExtension.store.get("SLG_inject_before"); 
  if(SLG_inject_before_tr=="true"){
	GEBI("SLG_inject_before").checked = true;
	if(GEBI('SLG_hide_translation').checked==true) GEBI('SLG_hide_translation').checked = false;
  }else GEBI("SLG_inject_before").checked = false;

  var SLG_line_break_tr = FExtension.store.get("SLG_line_break"); 
  if(SLG_line_break_tr=="true")  GEBI("SLG_line_break").checked = true;
  else GEBI("SLG_line_break").checked = false;
  
  var SLG_whole_word_tr = FExtension.store.get("SLG_whole_word"); 
  if(SLG_whole_word_tr=="true")  GEBI("SLG_whole_word").checked = true;
  else GEBI("SLG_whole_word").checked = false;
  
  var SLG_hide_translation_tr = FExtension.store.get("SLG_hide_translation"); 
  if(SLG_hide_translation_tr=="true"){
	GEBI("SLG_hide_translation").checked = true;
	if(GEBI('SLG_inject_before').checked==true) GEBI('SLG_inject_before').checked = false;
  }else GEBI("SLG_hide_translation").checked = false;
  
  var SLG_dictionary_tr = FExtension.store.get("SLG_dictionary"); 
  if(SLG_dictionary_tr=="true")  GEBI("SLG_dictionary").checked = true;
  else GEBI("SLG_dictionary").checked = false;

  var SLG_no_detect_tr = FExtension.store.get("SLG_no_detect_it");
  if(SLG_no_detect_tr=="true")  GEBI("SLG_no_detect_it").checked = true;
  else GEBI("SLG_no_detect_it").checked = false;

  // Hotkeys block
  var SLG_FK_box1 = FExtension.store.get("SLG_FK_box1"); 
  if(SLG_FK_box1=="true")  GEBI("SLG_FK_box1").checked = true;
  else GEBI("SLG_FK_box1").checked = false;

  var SLG_FK_box2 = FExtension.store.get("SLG_FK_box2"); 
  if(SLG_FK_box2=="true")  GEBI("SLG_FK_box2").checked = true;
  else GEBI("SLG_FK_box2").checked = false;


  var SLG_change_lang_HKbox_it = FExtension.store.get("SLG_change_lang_HKbox_it"); 
  if(SLG_change_lang_HKbox_it=="true")  GEBI("SLG_FK_box11").checked = true;
  else GEBI("SLG_FK_box11").checked = false;

  GEBI("SRV11").value = FExtension.store.get("SLG_change_lang_HK_it");


  SLG_SHOWHIDEINLINEPROVIDERS();

  // Hotkeys block



  //************************* end inliner *********************************

	if(FExtension.store.get("SLG_HK_it1")!=""){
		GEBI('SRV3').value=FExtension.store.get("SLG_HK_it1");
	} else {
		GEBI('SRV3').placeholder="Not set";
	}

        GEBI('SRV4').value = FExtension.store.get("SLG_HK_it2");


	var mySLG_langSrc_it = FExtension.store.get("SLG_langSrc_it");
	var mySLG_langSrcSelect_it = GEBI("SLG_langSrc_it");
	for (var i = 0; i < mySLG_langSrcSelect_it.options.length; i++) {
		var mySLG_langSrcOption_it = mySLG_langSrcSelect_it.options[i];
		if (mySLG_langSrcOption_it.value == mySLG_langSrc_it) {
			mySLG_langSrcOption_it.selected = "true";
			break;
		}
	}

	var mySLG_langDst_it = FExtension.store.get("SLG_langDst_it");
	var mySLG_langDstSelect_it = GEBI("SLG_langDst_it");
	for (var i = 0; i < mySLG_langDstSelect_it.options.length; i++) {
		var mySLG_langDstOption_it = mySLG_langDstSelect_it.options[i];
		if (mySLG_langDstOption_it.value == mySLG_langDst_it) {
			mySLG_langDstOption_it.selected = "true";
			break;
		}
	}

        var SLG_TH_4 = FExtension.store.get("SLG_TH_4");
        if(SLG_TH_4=="1")  GEBI("SLG_TH_4").checked = true;
        else GEBI("SLG_TH_4").checked = false;

	var SLG_global_lng_it = FExtension.store.get("SLG_global_lng_it");
	if(SLG_global_lng_it=="true")  GEBI("SLG_global_lng_it").checked = true;
	else GEBI("SLG_global_lng_it").checked = false;

	SLG_HIDE_HK("SLG_FK_box1","SLG_HIDE3");
	SLG_HIDE_HK("SLG_FK_box2","SLG_HIDE4");
	SLG_HIDE_HK("SLG_FK_box11","SLG_HIDE11");


	var INLINEflip = FExtension.store.get("INLINEflip");
	if(INLINEflip=="1")  GEBI("INLINEflip").checked = true;
	else GEBI("INLINEflip").checked = false;

        var SLG_THEMEmode = FExtension.store.get("THEMEmode");
	if(SLG_THEMEmode==0)  GEBI("SLG_THEME").value = 0;
	else GEBI("SLG_THEME").value = 1;
	save_options(1);
}

function save_options(st) {
 setTimeout(function() {

	var SLG_select_S_it = GEBI("SLG_langSrc_it");
	var SLG_select_T_it = GEBI("SLG_langDst_it");

	if(SLG_select_S_it.value!=SLG_select_T_it.value){

	   if(GEBI("SLG_TH_4").checked==true) FExtension.store.set("SLG_TH_4", "1");
	   else FExtension.store.set("SLG_TH_4","0");

	   //*************************** inliner ***********************************
	   var SLG_style = GEBI("SLG_style");
	   FExtension.store.set("SLG_style", SLG_style.value);
	   
	   var SLG_inject_brackets = GEBI("SLG_inject_brackets");
	   FExtension.store.set("SLG_inject_brackets", SLG_inject_brackets.checked+'');
	   
	   var SLG_inject_before = GEBI("SLG_inject_before");
	   FExtension.store.set("SLG_inject_before", SLG_inject_before.checked+'');
	   
	   var SLG_line_break = GEBI("SLG_line_break");
	   FExtension.store.set("SLG_line_break", SLG_line_break.checked + '');
	   
	   var SLG_whole_word = GEBI("SLG_whole_word");
	   FExtension.store.set("SLG_whole_word", SLG_whole_word.checked + '');
	   
	   var SLG_hide_translation = GEBI("SLG_hide_translation");
	   FExtension.store.set("SLG_hide_translation", SLG_hide_translation.checked + '');
	   
	   var SLG_dictionary = GEBI("SLG_dictionary");
	   FExtension.store.set("SLG_dictionary", SLG_dictionary.checked + '');
	   
	   //************************* end inliner *********************************


		var SLG_langSrc_it = SLG_select_S_it.children[SLG_select_S_it.selectedIndex].value;
		FExtension.store.set("SLG_langSrc_it", SLG_langSrc_it);
		
		var SLG_langDst_it = SLG_select_T_it.children[SLG_select_T_it.selectedIndex].value;
		FExtension.store.set("SLG_langDst_it", SLG_langDst_it);
		FExtension.store.set("SLG_WPT_TEMP_LANG", SLG_langDst_it);		
		var SLG_langDst_name_it = SLG_select_T_it.children[SLG_select_T_it.selectedIndex].text;
		FExtension.store.set("SLG_langDst_name_it", SLG_langDst_name_it);

		FExtension.store.set("SLG_no_detect_it", GEBI("SLG_no_detect_it").checked);

		FExtension.store.set("SLG_FK_box1", GEBI("SLG_FK_box1").checked);
		FExtension.store.set("SLG_FK_box2", GEBI("SLG_FK_box2").checked);
		FExtension.store.set("SLG_change_lang_HKbox_it", GEBI("SLG_FK_box11").checked);


		if(GEBI('SRV3').value!="None")	FExtension.store.set("SLG_HK_it1", GEBI('SRV3').value);
		else FExtension.store.set("SLG_HK_it1", "");

		FExtension.store.set("SLG_HK_it2", GEBI('SRV4').value);

		FExtension.store.set("SLG_change_lang_HK_it", GEBI('SRV11').value);



		if(GEBI("INLINEflip").checked==true)  FExtension.store.set("INLINEflip",1);
		else FExtension.store.set("INLINEflip",0);

//------TIME STAMP--------------
	new Date().getTime();
	FExtension.store.set("SLG_TS", Date.now());
//==============================


		if(GEBI("SLG_global_lng_it").checked==true){
			FExtension.store.set("SLG_langDst_name", SLG_langDst_name_it);
			FExtension.store.set("SLG_langDst_name_bbl", SLG_langDst_name_it);
			FExtension.store.set("SLG_langDst_name_wpt", SLG_langDst_name_it);
		}


		if(GEBI("SLG_global_lng_it").checked==true){

			FExtension.store.set("SLG_global_lng", GEBI("SLG_global_lng_it").checked);
			FExtension.store.set("SLG_global_lng_bbl", GEBI("SLG_global_lng_it").checked);
			FExtension.store.set("SLG_global_lng_wpt", GEBI("SLG_global_lng_it").checked);
			FExtension.store.set("SLG_global_lng_it", GEBI("SLG_global_lng_it").checked);

			FExtension.store.set("SLG_langSrc", SLG_select_S_it.children[SLG_select_S_it.selectedIndex].value);
			FExtension.store.set("SLG_langSrc2", SLG_select_S_it.children[SLG_select_S_it.selectedIndex].value);
			FExtension.store.set("SLG_langSrc_bbl", SLG_select_S_it.children[SLG_select_S_it.selectedIndex].value);
			FExtension.store.set("SLG_langSrc_wpt", SLG_select_S_it.children[SLG_select_S_it.selectedIndex].value);
			FExtension.store.set("SLG_langSrc_it", SLG_select_S_it.children[SLG_select_S_it.selectedIndex].value);

			FExtension.store.set("SLG_langDst", SLG_select_T_it.children[SLG_select_T_it.selectedIndex].value);
			FExtension.store.set("SLG_langDst2", SLG_select_T_it.children[SLG_select_T_it.selectedIndex].value);
			FExtension.store.set("SLG_langDst_bbl", SLG_select_T_it.children[SLG_select_T_it.selectedIndex].value);
			FExtension.store.set("SLG_langDst_wpt", SLG_select_T_it.children[SLG_select_T_it.selectedIndex].value);
			FExtension.store.set("SLG_langDst_it", SLG_select_T_it.children[SLG_select_T_it.selectedIndex].value);


			FExtension.store.set("SLG_langDst_name", SLG_select_T_it.children[SLG_select_T_it.selectedIndex].text);
			FExtension.store.set("SLG_langDst_name_wpt", SLG_select_T_it.children[SLG_select_T_it.selectedIndex].text);
			FExtension.store.set("SLG_langDst_name_bbl", SLG_select_T_it.children[SLG_select_T_it.selectedIndex].text);
			FExtension.store.set("SLG_langDst_name_it", SLG_select_T_it.children[SLG_select_T_it.selectedIndex].text);


			FExtension.store.set("SLG_no_detect", GEBI("SLG_no_detect_it").checked);
			FExtension.store.set("SLG_no_detect_bbl", GEBI("SLG_no_detect_it").checked);
			FExtension.store.set("SLG_no_detect_it", GEBI("SLG_no_detect_it").checked);

			var IDS = document.getElementById("SLG_langDst_it").value;
	   		SLG_SAVE_FAVORITE_LANGUAGES(IDS, "SLG_FAV_LANGS_IMT");
	   		SLG_SAVE_FAVORITE_LANGUAGES(IDS, "SLG_FAV_LANGS_BBL");
	   		SLG_SAVE_FAVORITE_LANGUAGES(IDS, "SLG_FAV_LANGS_IT");
	   		SLG_SAVE_FAVORITE_LANGUAGES(IDS, "SLG_FAV_LANGS_WPT");


		} else {
			SLG_SAVE_FAVORITE_LANGUAGES(document.getElementById("SLG_langDst_it").value, "SLG_FAV_LANGS_IT");
			FExtension.store.set("SLG_langDst_name_it", SLG_select_T_it.children[SLG_select_T_it.selectedIndex].text);
			FExtension.store.set("SLG_global_lng", GEBI("SLG_global_lng_it").checked);
			FExtension.store.set("SLG_global_lng_bbl", GEBI("SLG_global_lng_it").checked);
			FExtension.store.set("SLG_global_lng_wpt", GEBI("SLG_global_lng_it").checked);
			FExtension.store.set("SLG_global_lng_it", GEBI("SLG_global_lng_it").checked);
		}	

		RESET_TEMPS_TO_DEFAULT();
	  	SAVE_INLINE_LIST_PROVIDERS("SLG_ALL_PROVIDERS_IT");

		FExtension.store.set("SLG_Flag", "FALSE");
                FExtension.bg.ImTranslatorBG.PREPARE_RCM_CONTENT();
	 	FExtension.bg.ImTranslatorBG.SLG_WorkingSet();
	        FExtension.bg.FExtension.browser.refreshSettings();
		ACTIVATE_THEME(FExtension.store.get("THEMEmode"));

		if(GEBI('autohotkeys')){
		  var frame = GEBI('autohotkeys');
		  if(frame)	frame.parentNode.removeChild(frame);
		}


	}else 	  alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extS_T_L_diff'));
 }, 100);
}

function GEBI(id){ return document.getElementById(id);}



function OneOfTwo(st){
 if(st==1){
  if(GEBI('SLG_inject_before').checked == true) GEBI('SLG_hide_translation').checked = false;
 } else {
  if(GEBI('SLG_hide_translation').checked == true) GEBI('SLG_inject_before').checked = false;
 }
}

function ACTIVATE_MENU_ELEMENT(st){
  var win = top.frames['menu'];
  var li = win.document.getElementsByTagName("li");
  for(var i=1; i<=li.length; i++){
        if(st==i) win.document.getElementById('SLG_options_menu'+i).className='SLG_options-menu-on';
        else win.document.getElementById('SLG_options_menu'+i).className='SLG_options-menu-off';
  }
}

function SLG_SAVE_LOC(){
  FExtension.store.set("SLG_LOCALIZATION", GEBI("SLG_LOC").value);
  CONSTRUCTOR();
  FExtension.bg.ImTranslatorBG.SLG_WorkingSet();
  parent.frames["menu"].location.reload();
  location.reload();
}

function SLG_SAVE_THEME(){
  FExtension.store.set("THEMEmode", GEBI("SLG_THEME").value);
  FExtension.bg.ImTranslatorBG.SLG_WorkingSet();
  location.reload();
}

function ACTIVATE_THEME(st){
 	if(st==1){
		var bg="#191919";
		var clr="#BF7D44";
		var clr_deact="#BDBDBD";
		GEBI("SLG_translate_container").style.filter=SLG_DARK;
		var LBLS = document.getElementsByClassName("SLG_BG_op");
		for(var i=0; i<LBLS.length; i++) LBLS[i].style.color=clr;
		var A = document.getElementsByTagName("a");
		for(var i=0; i<A.length; i++) A[i].style.color=clr;
		var E = document.getElementsByClassName("SLMSG");
		for(var j=0; j<E.length; j++) E[j].style.filter=SLG_DARK;


		setTimeout(function() {
			var SLG_lngSrc_opt = GEBI("SLG_langSrc_it").getElementsByTagName("option");
			for(var j=0; j<SLG_lngSrc_opt.length; j++) SLG_lngSrc_opt[j].setAttribute("style", "background:"+bg+" !important;color:#fff;");
			var SLG_lngSrc_opt = GEBI("SLG_langDst_it").getElementsByTagName("option");
			for(var j=0; j<SLG_lngSrc_opt.length; j++) SLG_lngSrc_opt[j].setAttribute("style", "background:"+bg+" !important;color:#fff;");
		}, 1000);

		if(GEBI("item-0")) GEBI("item-0").style.borderRight="10px solid "+clr;	
		if(GEBI("item-1")) GEBI("item-1").style.borderRight="10px solid "+clr;
		
		GEBI("SLG_style").style.filter=SLG_DARK;	
		GEBI("SLG_AUTOKEYS").style.filter=SLG_DARK;	
	}
}

function SLG_SAVE_FAVORITE_LANGUAGES(ln, TR){
	var OUT = "";
	var OUT2 = "";
	var SLG_FAV_LANGS = FExtension.store.get(TR);
	var SLG_FAV_MAX = FExtension.store.get("SLG_FAV_MAX");
	if(SLG_FAV_LANGS.indexOf(ln)!=-1){
		SLG_FAV_LANGS = SLG_FAV_LANGS.replace(ln+",",""); 
		SLG_FAV_LANGS = SLG_FAV_LANGS.replace(ln,"");
	}
	OUT = ln + ",";	
	var ARR = SLG_FAV_LANGS.split(",");
	for (var i = 0; i < ARR.length; i++){
	 	OUT = OUT + ARR[i]+",";
	}
	if(OUT.slice(-1)==",") 	OUT = OUT.slice(0, OUT.length - 1);
	var TMP = OUT.split(",");
	if(TMP.length > SLG_FAV_MAX) {
		for (var j = 0; j < TMP.length-1; j++){
		 	OUT2 = OUT2 + TMP[j]+",";
		}		
		OUT = OUT2 
	}
	if(OUT.slice(-1)==",") 	OUT = OUT.slice(0, OUT.length - 1);
	FExtension.store.set(TR, OUT);
}



function BUILD_RESET_ICN(ob){
	GEBI("reset_all"+ob).title="Reset to default";
}

function SLG_DEL_AUTO(ob){
	GEBI("SRV"+ob).value = "Auto Translate"; 
	GEBI("SRV"+ob).placeholder = "Auto Translate"; 
        GEBI("MSG"+ob).style.visibility="hidden";
	save_options(0);
}                          


function RESET_ALL_HK(id){
        var st = "";
        switch (id){
         case 3: st = 'SLG_HK_it1'; break;
         case 4: st = 'SLG_HK_it2'; break;
         case 11: st = 'SLG_change_lang_HK_it'; break;

	}
	for(var i=0; i<PACK_PARAMS.length; i++){
		var tmp = PACK_PARAMS[i].split(";");
		var curDBname = tmp[0];
		var curDBparam = tmp[1];
		var DBparam = FExtension.store.get(curDBname);
		if(curDBname == st){
			FExtension.store.set(curDBname, curDBparam);			
			GEBI("MSG"+id).style.visibility="hidden";
		}
	}
	GEBI("SRV"+id).value=FExtension.store.get(st);
}

