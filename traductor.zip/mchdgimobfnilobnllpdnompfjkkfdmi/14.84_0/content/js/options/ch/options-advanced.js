'use strict';
var SLG_DARK="invert(95%)";
var HEADER = 1;
var ERRORS = "";
var ERRORS_TTL = "";
var GLOBAL_INPUT = "";
var EXCEPTIONS = new Array("SLG_YHIST","SLG_YKEY","SLG_GAPI1","SLG_GAPI1_ts","SLG_GAPI2","SLG_GAPI2_ts","SLG_History","ADV","AVOIDAUTODETECT","AVOIDAUTODETECT_LNG","FRUN","PLD_OLD_TS","PLT_OLD_TS_TR","ran_before","SLG_anchor","SLG_BBL_TS","SLG_Dtext","SLG_Flag","SLG_session","SLG_TS","SLG_Version","SLG_sort","SLG_Fontsize2","SLG_langSrc2","SLG_langDst2","THE_URL","SLG_Import_Report");
var SLG_Languages = CUSTOM_LANGS(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLanguages'));

function GEBI(id){ return document.getElementById(id);}
(function(){GEBI("SLG_info").addEventListener("click",function(){FExtension.browserPopup.openNewTab(this.href);},!1);} )();
(function(){GEBI("SLG_LOC").addEventListener("change",function(){SLG_SAVE_LOC();},!1);} )();
(function(){GEBI("SLG_LNG_STATUS").addEventListener("click",function(){ SLG_LANGS(); },!1); } )();

(function(){GEBI("SLG_EXPO").addEventListener("click",function(){SLG_export();},!1);} )();
(function(){GEBI("SLG_IMPO").addEventListener("change",function(){SLG_FileManager(event);},!1);} )();
(function(){GEBI("SLG_files").addEventListener("change",function(){handleFileSelect(event);},!1);} )();
(function(){GEBI("SLG_reset").addEventListener("click",function(){SLG_ResetToDefault(event);},!1);} )();
(function(){GEBI("SLG_ttl").addEventListener("click",function(){SLG_REPORT(event);},!1);} )();


//AUTOSAVE BLOCK
window.addEventListener('change',function(e){
	save_options(0);
},!1);
//AUTOSAVE BLOCK


(function(){GEBI("SLG_THEME").addEventListener("change",function(){SLG_SAVE_THEME();},!1);} )();

(function(){INIT();})();



function INIT(){
  ACTIVATE_MENU_ELEMENT(10);
  GEBI("SLG_LOC").value=FExtension.store.get("SLG_LOCALIZATION");
  CONSTRUCTOR();
     GEBI("SLG_DOM").value = FExtension.store.get("SLG_DOM");

     var mySLG_SLVoices = FExtension.store.get("SLG_SLVoices");
     var mySLG_SLVoiceSelect = GEBI("SLG_SLVoiceState");
     for (var i = 0; i < mySLG_SLVoiceSelect.options.length; i++) {
    	var mySLG_SLVoiceOption = mySLG_SLVoiceSelect.options[i];
	    if (String(mySLG_SLVoiceOption.value) == String(mySLG_SLVoices)) {
	      mySLG_SLVoiceOption.selected = "true";
	      break;
	    }
     }
     var SLG_TransButton = FExtension.store.get("SLG_PrefTrans");
     GEBI("imtranslator"+SLG_TransButton).checked = "true";
     for (var j = 1; j <= 7; j++){
	     var SLG_CM = String(FExtension.store.get("SLG_CM"+j));

	     if(SLG_CM=="1") GEBI("Context"+j).checked = true;
	     else GEBI("Context"+j).checked = false;

     }


     var SLG_THEMEmode = FExtension.store.get("THEMEmode");
     if(SLG_THEMEmode==0)  GEBI("SLG_THEME").value = 0;
     else GEBI("SLG_THEME").value = 1;

     save_options(1)
}


function ACTIVATE_MENU_ELEMENT(st){
  var win = top.frames['menu'];
  var li = win.document.getElementsByTagName("li");
  for(var i=1; i<=li.length; i++){
        if(st==i) win.document.getElementById('SLG_options_menu'+i).className='SLG_options-menu-on';
        else win.document.getElementById('SLG_options_menu'+i).className='SLG_options-menu-off';
  }
}


function CONSTRUCTOR(){  
 GEBI('SLG_il').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLOC')));
 GEBI('SLG_ttl').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extADV')));
 GEBI('SLG_BG_op').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extADVTTS')));
 GEBI('SLG_ADVuse').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extADVuse')));
 GEBI('SLG_SLVoice0').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extADV4lt')));
 GEBI('SLG_SLVoice1').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extADVN')));
 GEBI('SLG_SLVoice2').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extADVA')));
 GEBI('SLG_L_BOX').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLangs')+":"));
 GEBI('SLG_LNG_STATUS').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extCustomize')));
 GEBI('SLG_tb').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'exttb')));
 GEBI('SLG_cm').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extcm')));
 GEBI('SLG_chl').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extOptions') + " ("+ FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extCMcl')+")"));
 GEBI('SLG_cltr').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extCMct'))); 
 GEBI('SLG_PDOM').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extPDOM'))); 
 GEBI('SLG_UDOM').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extUDOM'))); 
 GEBI('BARO').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extOptions') + ": " + FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extBARO'))); 
 GEBI('SLG_theme_ttl').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extTHEME')));
 GEBI('SLG_theme_1').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLIGHT')));
 GEBI('SLG_theme_2').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDARK')));
 GEBI('SLG_translate_container').style.opacity="1";
	switch(PLATFORM){
	 case "Opera" : GEBI('SLG_info').href="https://about.imtranslator.net/tutorials/presentations/google-translate-for-opera/advanced-settings/"; break;
	 case "Chrome": GEBI('SLG_info').href="https://about.imtranslator.net/tutorials/presentations/imtranslator-for-chrome/advanced-settings/"; break;
	 default      : GEBI('SLG_info').href="https://about.imtranslator.net/";break;
	}
 ACTIVATE_THEME(FExtension.store.get("THEMEmode"));
}


function save_options(st) {

//------TIME STAMP--------------
	new Date().getTime();
	FExtension.store.set("SLG_TS", Date.now());
//==============================

		FExtension.store.set("SLG_SLVoices", GEBI("SLG_SLVoiceState").value);
		FExtension.store.set("SLG_DOM", GEBI("SLG_DOM").value);

		var PT=1;

	        if(FExtension.store.get("SLG_ENABLE")=="false"){
			GEBI("imtranslator3").style.visibility = "hidden";	    
			GEBI("SLG_CM_bbl").style.opacity = "0.2";	      
		}
                if(GEBI("imtranslator3").checked==true){
			if(FExtension.store.get("SLG_ENABLE")=="false"){
				GEBI("imtranslator1").checked=true;
			}
			PT=3;
		}

                if(GEBI("imtranslator1").checked==true) PT=1;
                if(GEBI("imtranslator2").checked==true) PT=2;

                if(GEBI("imtranslator4").checked==true) PT=4;
                if(GEBI("imtranslator5").checked==true) PT=5;
		FExtension.store.set("SLG_PrefTrans", PT);

	        for (var j = 1; j <= 7; j++){
		     var SLG_CM = GEBI("Context"+j).checked;
		     var ID = "SLG_CM"+j;
		     if(SLG_CM==true){
			FExtension.store.set(ID, "1");
		     }else{
			FExtension.store.set(ID, "0");
		     }
	        }


		SLG_Reset_Booxes(FExtension.store.get("SLG_LNG_LIST"));
       	        FExtension.bg.ImTranslatorBG.PREPARE_RCM_CONTENT();

		FExtension.store.set("SLG_Flag", "FALSE");
		FExtension.bg.ImTranslatorBG.SLG_WorkingSet();
	        FExtension.bg.FExtension.browser.refreshSettings();


}



function SLG_SAVE_LOC(){
  FExtension.store.set("SLG_LOCALIZATION", GEBI("SLG_LOC").value);
  CONSTRUCTOR();
  FExtension.bg.ImTranslatorBG.SLG_WorkingSet();
  parent.frames["menu"].location.reload();
  location.reload();
}

function SLG_SAVE_THEME(){
  FExtension.store.set("THEMEmode", GEBI("SLG_THEME").value);
  FExtension.bg.ImTranslatorBG.SLG_WorkingSet();
  location.reload();
}

function ACTIVATE_THEME(st){
 	if(st==1){
		var bg="#191919";
		var clr="#BF7D44";
		GEBI("SLG_translate_container").style.filter=SLG_DARK;
		GEBI("upload").style.filter=SLG_DARK;
		GEBI("SLG_reset").style.filter=SLG_DARK;
		GEBI("SLG_restore_lable").style.filter=SLG_DARK;
		var LBLS = document.getElementsByClassName("SLG_BG_op");
		for(var i=0; i<LBLS.length; i++) LBLS[i].style.color=clr;
		var A = document.getElementsByTagName("a");
		for(var i=0; i<A.length; i++) A[i].style.color=clr;

		setTimeout(function() {
			var SLG_DOM_opt = GEBI("SLG_DOM").getElementsByTagName("option");
			for(var j=0; j<SLG_DOM_opt.length; j++) SLG_DOM_opt[j].setAttribute("style", "background:"+bg+" !important;color:#fff;");
			var SLG_SLVoiceState_opt = GEBI("SLG_SLVoiceState").getElementsByTagName("option");
			for(var j=0; j<SLG_SLVoiceState_opt.length; j++) SLG_SLVoiceState_opt[j].setAttribute("style", "background:"+bg+" !important;color:#fff;");
		}, 1000);

		GEBI("SLG_AUTOKEYS").style.filter=SLG_DARK;	
	}
}

const Encr = SL => {
    const textToChars = text => text.split('').map(c => c.charCodeAt(0));
    const byteHex = n => ("0" + Number(n).toString(16)).substr(-2);
    const applySLToChar = code => textToChars(SL).reduce((a,b) => a ^ b, code);

    return text => text.split('')
        .map(textToChars)
        .map(applySLToChar)
        .map(byteHex)
        .join('');
}

const Decr = SL => {
    const textToChars = text => text.split('').map(c => c.charCodeAt(0));
    const applySLToChar = code => textToChars(SL).reduce((a,b) => a ^ b, code);
    return encoded => encoded.match(/.{1,2}/g)
        .map(hex => parseInt(hex, 16))
        .map(applySLToChar)
        .map(charCode => String.fromCharCode(charCode))
        .join('');
}

function SortLocalStorage(){
   if(localStorage.length > 0){
      var localStorageArray = new Array();

      for (var i=0;i<localStorage.length;i++){
	var Item = localStorage.key(i);

        if(Item == "SLG_Import_Report") localStorage.setItem(Item,"");
        var cnt=0;
        for (var j=0;j<EXCEPTIONS.length;j++){
		if(Item == EXCEPTIONS[j]) cnt++;		
	}
	if( cnt== 0 ){
	        var thedata = localStorage.getItem(Item);
	        if(Item == "SLG_style") thedata = "#"+localStorage.getItem(String(Item));
		localStorageArray[i] = Item + "," + thedata + "\n";
	} 
      }     
   }
   var sortedArray = localStorageArray.sort();
   return sortedArray;
}


function SLG_export(){
 var LocSt = new Array();
 LocSt = SortLocalStorage();


 var d = new Date();
 var tmp = String(d).split(" (");
 d = tmp[0];

 var EXP_DATA = PLATFORM + EXPORT_EXT+" Version: " +FExtension.store.get("SLG_Version") + " - " + d + "\n";
 var tmp1 = "";
 var tmp2 = "";

 for ( var i = 0; i <= LocSt.length; i++ ) {
   var jump = 0;
    if(String(LocSt[i]) === 'undefined') jump = 1;

    //PLANSHET
    if(String(LocSt[i]).indexOf("SLG_langDst,")!=-1 && String(LocSt[i]).indexOf("2")==-1){
	tmp1 = LocSt[i].split(",");
	tmp2=tmp1[0]+"2,"+tmp1[1];
    }

    if(String(LocSt[i]).indexOf("SLG_langDst2")!=-1) LocSt[i] = tmp2;

    //BBL
    if(String(LocSt[i]).indexOf("SLG_langDst_bbl,")!=-1 && String(LocSt[i]).indexOf("2")==-1){
	tmp1 = LocSt[i].split(",");
	tmp2=tmp1[0]+"2,"+tmp1[1];
    }
    if(String(LocSt[i]).indexOf("SLG_langDst_bbl2")!=-1) LocSt[i] = tmp2;

    //INLINE
    if(String(LocSt[i]).indexOf("SLG_langDst_it,")!=-1 && String(LocSt[i]).indexOf("2")==-1){
	tmp1 = LocSt[i].split(",");
	tmp2=tmp1[0]+"2,"+tmp1[1];
    }

    if(String(LocSt[i]).indexOf("SLG_langDst_it2")!=-1) LocSt[i] = tmp2;

    //SAVED TEXT
    if(String(LocSt[i]).indexOf("SLG_SavedText_gt")!=-1){
	var txt = LocSt[i].split("_SavedText_gt,");
	var txt1 = txt[0];
	var txt2 = txt[1];
	EXP_DATA = EXP_DATA + txt1 + "_SavedText_gt,"+ encodeURIComponent(txt2)+"\n";
	jump = 1;
    }	


    if(jump == 0 && LocSt[i]!="") EXP_DATA = EXP_DATA + LocSt[i];

 }
 const SLG_ENCR = Encr('SLFORMAT');
 EXP_DATA = SLG_ENCR(EXP_DATA);
 const SLG_DECR = Decr('SLFORMAT');
 EXP_DATA = SLG_DECR(EXP_DATA);

 var filename = "imtranslator-options.im";
// console.log("doSave(): called.");
 window.URL=window.URL||window.webkitURL;
 var b=document.createElement("a"),c=new Blob([EXP_DATA],{type:"application/octet-stream"});
// var encodedUri = encodeURI(EXP_DATA);
 var encodedUri = encodeURIComponent(EXP_DATA);
 b.setAttribute("href", "data:text/plain;charset=utf-8,\uFEFF" + encodedUri);
 b.setAttribute("download",filename);
 b.click();
}


function SLG_FileManager(event){
  setTimeout(function() {
	  SLG_Upload(event);
  }, 100);


}

function handleFileSelect(event){
  const reader = new FileReader()
  reader.onload = handleFileLoad;
  reader.readAsText(event.target.files[0])
}

function handleFileLoad(event){
  GLOBAL_INPUT = event.target.result;
  GEBI("SLG_upload_error").innerHTML="";
}

function SLG_ResetToDefault(e){
   var ver = localStorage.getItem("SLG_Version");
   localStorage.clear();
   FExtension.bg.ImTranslatorBG.setDefault();
   localStorage.setItem("SLG_Version",ver);
   localStorage.setItem("ADV",1);
   localStorage.setItem("FRUN",1);
   localStorage.setItem("ran_before",1); 
   var l = GEBI("SLG_LOC").value;
   localStorage.setItem("SLG_FAV_LANGS_IMT",l); 
   localStorage.setItem("SLG_FAV_LANGS_BBL",l); 
   localStorage.setItem("SLG_FAV_LANGS_IT",l); 
   localStorage.setItem("SLG_FAV_LANGS_WPT",l); 
   FExtension.store.set("SLG_langDst",l)
   FExtension.store.set("SLG_langDst2",l)
   FExtension.store.set("SLG_langDst_bbl",l)
   FExtension.store.set("SLG_langDst_bbl2",l)
   FExtension.store.set("SLG_langDst_it",l)
   FExtension.store.set("SLG_langDst_it2",l)
   FExtension.store.set("SLG_langDst_wpt",l)
   FExtension.store.set("SLG_langDst_wpt2",l)

   FExtension.store.set("SLG_GotIt",0);


//	  SLG_Reset_Booxes(SLG_Languages); 
  // 	  FExtension.bg.ImTranslatorBG.SLG_WorkingSet();
 //	  FExtension.bg.ImTranslatorBG.PREPARE_RCM_CONTENT();


   parent.frames["menu"].location.reload();
   location.reload();
}

function SLG_Upload(event){
    if(GLOB_PREF == "SL"){
	GLOBAL_INPUT = GLOBAL_INPUT.replace(/SLO/g,GLOB_PREF);
	GLOBAL_INPUT = GLOBAL_INPUT.replace(/SLG/g,GLOB_PREF);
    }
    if(GLOB_PREF == "SLO"){
	GLOBAL_INPUT = GLOBAL_INPUT.replace(/SL/g,GLOB_PREF);
	GLOBAL_INPUT = GLOBAL_INPUT.replace(/SLG/g,GLOB_PREF);
    }	

    if(GLOB_PREF == "SLG"){
	GLOBAL_INPUT = GLOBAL_INPUT.replace(/SL/g,GLOB_PREF);
	GLOBAL_INPUT = GLOBAL_INPUT.replace(/SLO/g,GLOB_PREF);
    }	

    if(GLOB_PREF == "SLO"){
	    GLOBAL_INPUT = GLOBAL_INPUT.replace(/SLOO/g,"SLO");
	    GLOBAL_INPUT = GLOBAL_INPUT.replace(/SLOG/g,"SLO");
	    GLOBAL_INPUT = GLOBAL_INPUT.replace(/SLGG/g,"SLG");
    }

    if(GLOB_PREF == "SLG"){
	    GLOBAL_INPUT = GLOBAL_INPUT.replace(/SLOO/g,"SLO");
	    GLOBAL_INPUT = GLOBAL_INPUT.replace(/SLGO/g,"SLG");
	    GLOBAL_INPUT = GLOBAL_INPUT.replace(/SLGG/g,"SLG");
    }

    GLOBAL_INPUT = GLOBAL_INPUT.replace(/SLOVoices/g,"SLVoices");
    GLOBAL_INPUT = GLOBAL_INPUT.replace(/SLGVoices/g,"SLVoices");

    var theKEY = SLG_UPLOAD_VALIDATOR(event);
    FExtension.bg.ImTranslatorBG.setDefault();
    if(theKEY == 1){
	  var NONES = DefineNONES();
	  var TMP = GLOBAL_INPUT.split("\n");
 	  ERRORS_TTL = TMP[0];
	  if(ERRORS_TTL.indexOf(",,")!=-1) ERRORS_TTL = ERRORS_TTL.replace(/[,+][, ]+/g, "").trim();
	  ERRORS_TTL = ERRORS_TTL + "<br>";

	  for(var i=HEADER; i < TMP.length; i++){
      		var LINE = TMP[i].split(",");
		var PARAMS = "";

		if(localStorage.getItem(LINE[0])!=null){
	      		for(var j=1; j<LINE.length; j++){
				if(LINE[j]!=""){
					if(LINE[j].toLowerCase()=="true" || LINE[j].toLowerCase()=="false") LINE[j] = LINE[j].toLowerCase();
					PARAMS = PARAMS + LINE[j].trim();
					PARAMS = PARAMS.replace(/^ +/gm, '');
					PARAMS = PARAMS.replace(/\r/g, '');
					PARAMS = PARAMS + ",";
				}
			}

			// DATA VALIDATION

			var SKIP = 0;
			 	if(LINE[0].indexOf("_LNG_LIST") != -1){
					SLG_Languages = CUSTOM_LANGS_RESET_TO_DEFAULT(PARAMS);

					if(PARAMS.indexOf(",")==-1){
						if(PARAMS.toLowerCase()!="all") {
							SKIP = 1;
							ERRORS = ERRORS + "<br>"+LINE[0]+" includes a wrong attribute";
						}
					} else {

						if(PARAMS.toLowerCase().indexOf("all")==-1) {
						 	var LNGS = PARAMS.split(",");
							var CNTR = 0;
							var NEWSTRING="";
							for(var l=0; l<LNGS.length; l++){
								var SLG_TMP = SLG_Languages.split(",");
								if(LNGS[l].toLowerCase()=="auto") {CNTR++; }
								var tmp1 = LNGS[l];
								for(var J=0; J < SLG_TMP.length; J++){
								    	var SLG_TMP2=SLG_TMP[J].split(":");

								    	if(SLG_TMP2[0].toLowerCase() == LNGS[l].toLowerCase()){
										var tmp2 = SLG_TMP2[0];
										CNTR++;
										NEWSTRING = NEWSTRING + SLG_TMP2[0] + ",";	
									}
								}

								if(tmp1 != tmp2 && PARAMS.indexOf(tmp1)!=-1){
									NEWSTRING = NEWSTRING + tmp1 + ",";	
								}
							}


							if(CNTR<2) {
								SKIP = 1;
//								ERRORS = ERRORS + "<br>"+LINE[0]+" does not include any valid languages - skipped";
							} else PARAMS = NEWSTRING;
							var PARAMS = GET_LANG_AVAILABILITY(PARAMS);
							if(CNTR == 0 && LNGS.length>=2) SKIP=0;
						}
					}
				}
				if(LINE[0].indexOf("_ALL_PROVIDERS_BBL") != -1 ){
						var OUT = ""
						var available=SYNC_PROV_LIST(PARAMS,"SLG_ALL_PROVIDERS_BBL");
						var av = available.split(",");
					 	var PROV = PARAMS.split(",");

						if(av.length<=PROV.length){
							for(var l=0; l<av.length-1; l++){
								if(av.indexOf(PROV[l])!=-1){
									var tmp=PROV[l];
									if(tmp!="") {
										OUT =  OUT + tmp + ",";
									}
								}
							}
							if(OUT=="") {
								SKIP=1;
								PARAMS = available;
						        }PARAMS=OUT;
						} else SKIP = 0;
				}

				if(LINE[0].indexOf("_ALL_PROVIDERS_GT") != -1 ){
						var OUT = ""
						var available=SYNC_PROV_LIST(PARAMS,"SLG_ALL_PROVIDERS_GT");
						var av = available.split(",");
					 	var PROV = PARAMS.split(",");

						if(av.length<=PROV.length){
							for(var l=0; l<av.length-1; l++){
								if(av.indexOf(PROV[l])!=-1){
									var tmp=PROV[l];
									if(tmp!="") {
										OUT =  OUT + tmp + ",";
									}
								}
							}
							if(OUT=="") {
								SKIP=1;
								PARAMS = available;
						        } PARAMS=OUT;

						} else SKIP = 0;
				}

				if(LINE[0].indexOf("_ALL_PROVIDERS_IT") != -1){
						var OUT = ""
						var available=SYNC_PROV_LIST(PARAMS,"SLG_ALL_PROVIDERS_IT");
						var av = available.split(",");
					 	var PROV = PARAMS.split(",");
						if(av.length<=PROV.length){
							for(var l=0; l<av.length-1; l++){
								if(av.indexOf(PROV[l])!=-1){
									var tmp=PROV[l];
									if(tmp!="") {
										OUT =  OUT + tmp + ",";
									}
								} 
							}
							if(OUT=="") {
								SKIP=1;
								PARAMS = available;
						        } else PARAMS=OUT;

						} else SKIP = 0;
				}                                                                                                                                                                                                                                                                                                           

				if(LINE[0].indexOf("_change_lang_HK_it") != -1 || LINE[0].indexOf("_HK_btn") != -1 || LINE[0].indexOf("_HK_gt2") != -1 || LINE[0].indexOf("_HK_it2") != -1 || LINE[0].indexOf("_HK_opt") != -1 || LINE[0].indexOf("_HK_bb2") != -1 || LINE[0].indexOf("_HK_wpt1") != -1 || LINE[0].indexOf("_HK_wpt2") != -1 || LINE[0].indexOf("_HK_SO_wpt") != -1  || LINE[0].indexOf("_HK_CT_wpt") != -1){
					var SLG_KSET = new Array("+","Escape","Shift","Ctrl","Alt","0","1","2","3","4","5","6","7","8","9","Q","W","E","R","T","Y","U","I","O","P","A","S","D","F","G","H","J","K","L","Z","X","C","V","B","N","M");
					PARAMS = SLG_Text_capitalize(PARAMS.toLowerCase());
					var HKset = PARAMS.split(" ");
					var CNT = 0;

					for(var h=0; h<HKset.length; h++){
						for(var k=0; k<SLG_KSET.length; k++){
							var sample = HKset[h].replace(/,/g,"");
							if(sample==SLG_KSET[k]) CNT++;
						}
					}
					if(CNT==0 || CNT < (HKset.length)) {
						FExtension.store.set(LINE[0], GetFromDefault(LINE[0]));
						SKIP = 1;
					}
					if(CNT>5) SKIP = 1;
					if(SKIP == 1){
//						ERRORS = ERRORS + "<br>"+LINE[0]+" includes wrong hotkey(s) - skipped";
					}
				}
				if(LINE[0].indexOf("_HK_gt1") != -1 || LINE[0].indexOf("_HK_it1") != -1 || LINE[0].indexOf("_HK_bb1") != -1){
					if(NONES > 1){
						FExtension.store.set(LINE[0], GetFromDefault(LINE[0]));						
						SKIP=1;
					}
				}
				if(LINE[0].indexOf("_LOCALIZATION") != -1){
					var SLG_LOCS = new Array("en","bg","zh","zt","cs","nl","tl","fr","de","el","hi","it","ja","ko","pl","pt","ro","ru","sr","sk","es","sv","tr","uk","vi");
					var CNT = 0;
					for(var k=0; k<SLG_LOCS.length; k++){
						PARAMS = PARAMS.toLowerCase();
						var sample = PARAMS.replace(/,/g,"");
						if(sample==SLG_LOCS[k]) CNT++;
					}
					if(CNT==0){
						SKIP = 1;
//						ERRORS = ERRORS + "<br>"+LINE[0]+" includes a wrong localization code - skipped";
					}
				}
				if(LINE[0].indexOf("_Version") != -1){
					var curVersion = PARAMS.replace(/,/g,"");
					if(FExtension.store.get(GLOB_PREF + "_Version") != curVersion) 	ERRORS = ERRORS + "<br>Installed Vesion : " + FExtension.store.get(GLOB_PREF + "_Version")+"<br>Restored Backup Vesion : " + curVersion;
					SKIP=1;
				}
				if(LINE[0].indexOf("_Timing") != -1){
					var PAR = PARAMS.replace(/,/g,"");
					var reg = new RegExp('^[0-9]+$');
                                        if(reg.test(PAR)==false || PAR<0 || PAR>99){
                                         	SKIP = 1;
//						ERRORS = ERRORS + "<br>" + LINE[0] + " must be a number between 0 and 99 - skipped";
					}
				}
				if(LINE[0].indexOf("_Delay") != -1){
					var PAR = PARAMS.replace(/,/g,"");
					var reg = new RegExp('^[0-9]+$');
                                        if(reg.test(PAR)==false || PAR<0 || PAR>9){
                                         	SKIP = 1;
//						ERRORS = ERRORS + "<br>" + LINE[0] + " must be a number between 0 and 9 - skipped";
					}
				}
				if(LINE[0].indexOf("_BBL_X") != -1 || LINE[0].indexOf("_BBL_Y") != -1){
					var PAR = PARAMS.replace(/,/g,"");
					var reg = new RegExp('^[0-9]+$');
                                        if(reg.test(PAR)==false || PAR<0 || PAR>99){
                                         	SKIP = 1;
//						ERRORS = ERRORS + "<br>" + LINE[0] + " must be a number between 0 and 99 - skipped";
					}
				}
				if(LINE[0].indexOf("_langDst_name") != -1 || LINE[0].indexOf("_langDst_name_bbl") != -1 || LINE[0].indexOf("_langDst_name_it") != -1 || LINE[0].indexOf("_langDst_name_wpt") != -1){
					PARAMS = SLG_capitalize(PARAMS.toLowerCase());
				}
				if(LINE[0].indexOf("_style") != -1){
					PARAMS = PARAMS.replace(/#/g,"");
				}
				if(LINE[0].indexOf("_Fontsize") != -1 || LINE[0].indexOf("_Fontsize_bbl") != -1){
					var res = PARAMS.replace(/\D/g, "");
					if(res=="" || res<12 || res>22){
                                         	SKIP = 1;
//						ERRORS = ERRORS + "<br>" + LINE[0] + " font size is not correct - skipped";
					}
				}
				if(LINE[0].indexOf("ADV") != -1 || LINE[0].indexOf("FRUN") != -1 || LINE[0].indexOf("ran_before") != -1){
					PARAMS="1";
				}
				if(LINE[0].indexOf("_Fontsize2") != -1){
					SKIP = 1;
				}
				if(LINE[0].indexOf("_History") != -1){
					SKIP = 1;
				}
				if(LINE[0].indexOf("SLG_langDst_it2") != -1) SKIP = 1;
				if(LINE[0].indexOf("_GAPI") != -1) SKIP = 1;
				if(LINE[0].indexOf("_YKEY") != -1) SKIP = 1;
				if(LINE[0].indexOf("SLG_YHIST") != -1) SKIP = 1;

				if(LINE[0].indexOf("_SavedText_gt") != -1){
					PARAMS = decodeURIComponent(PARAMS);
				}



				if(LINE[0] == GLOB_PREF + "_langDst"){
					var lng = GET_SINGLE_DST_AVAILABILITY(LINE[1]);
					PARAMS = lng + ",";
					FExtension.store.set(GLOB_PREF + "_langDst",lng);

				}
				if(LINE[0] == GLOB_PREF + "_langSrc"){
					var lng = GET_SINGLE_SRC_AVAILABILITY(LINE[1]);
					PARAMS = lng + ",";
					FExtension.store.set(GLOB_PREF + "_langSrc",lng);

				}
				if(FExtension.store.get(GLOB_PREF + "_langDst") == FExtension.store.get(GLOB_PREF + "_langSrc")){
					FIX_FROM_TO("");
				}



				if(LINE[0] == GLOB_PREF + "_langDst_bbl"){
					var lng = GET_SINGLE_DST_AVAILABILITY(LINE[1]);
					PARAMS = lng + ",";
					FExtension.store.set(GLOB_PREF + "_langDst_bbl",lng);

				}
				if(LINE[0] == GLOB_PREF + "_langSrc_bbl"){
					var lng = GET_SINGLE_SRC_AVAILABILITY(LINE[1]);
					PARAMS = lng + ",";
					FExtension.store.set(GLOB_PREF + "_langSrc_bbl",lng)
				}
				if(FExtension.store.get(GLOB_PREF + "_langDst_bbl") == FExtension.store.get(GLOB_PREF + "_langSrc_bbl")){
					FIX_FROM_TO("_bbl");
				}



				if(LINE[0] == GLOB_PREF + "_langDst_it"){
					var lng = GET_SINGLE_DST_AVAILABILITY(LINE[1]);
					PARAMS = lng + ",";
					FExtension.store.set(GLOB_PREF + "_langDst_it",lng)
				}
				if(LINE[0] == GLOB_PREF + "_langSrc_it"){
					var lng = GET_SINGLE_SRC_AVAILABILITY(LINE[1]);
					PARAMS = lng + ",";
					FExtension.store.set(GLOB_PREF + "_langSrc_it",lng)
				}
				if(FExtension.store.get(GLOB_PREF + "_langDst_it") == FExtension.store.get(GLOB_PREF + "_langSrc_it")){
					FIX_FROM_TO("_it");
				}



				if(LINE[0] == GLOB_PREF + "_langDst_wpt"){
					var lng = GET_SINGLE_DST_AVAILABILITY(LINE[1]);
					PARAMS = lng + ",";
					FExtension.store.set(GLOB_PREF + "_langDst_wpt",lng)
				}
				if(LINE[0] == GLOB_PREF + "_langSrc_wpt"){
					var lng = GET_SINGLE_SRC_AVAILABILITY(LINE[1]);
					PARAMS = lng + ",";
					FExtension.store.set(GLOB_PREF + "_langSrc_wpt",lng)
				}
				if(FExtension.store.get(GLOB_PREF + "_langDst_wpt") == FExtension.store.get(GLOB_PREF + "_langSrc_wpt")){
					FIX_FROM_TO("_wpt");
				}



/*  FAVS 
				if(LINE[0] == GLOB_PREF + "_FAV_LANGS_BBL"){
					if(LINE.length>1){	
						var theline = "";
						for(var LL=1; LL<LINE.length; LL++){
						 	theline= theline+LINE[LL] +",";
						}
						var lngs = GET_VAF_LIST(theline);
						PARAMS = lngs;
						FExtension.store.set(GLOB_PREF + "_FAV_LANGS_BBL",lngs)
					}
				}

				if(LINE[0] == GLOB_PREF + "_FAV_LANGS_IMT"){
					if(LINE.length>1){	
						var theline = "";
						for(var LL=1; LL<LINE.length; LL++){
						 	theline= theline+LINE[LL] +",";
						}
						var lngs = GET_VAF_LIST(theline);
						PARAMS = lngs;
						FExtension.store.set(GLOB_PREF + "_FAV_LANGS_IMT",lngs)
					}
				}       

				if(LINE[0] == GLOB_PREF + "_FAV_LANGS_IT"){
					if(LINE.length>1){	
						var theline = "";
						for(var LL=1; LL<LINE.length; LL++){
						 	theline= theline+LINE[LL] +",";
						}
						var lngs = GET_VAF_LIST(theline);
						PARAMS = lngs;
						FExtension.store.set(GLOB_PREF + "_FAV_LANGS_IT",lngs)
					}
				}

				if(LINE[0] == GLOB_PREF + "_FAV_LANGS_WPT"){
					if(LINE.length>1){	
						var theline = "";
						for(var LL=1; LL<LINE.length; LL++){
						 	theline= theline+LINE[LL] +",";
						}
						var lngs = GET_VAF_LIST(theline);
						PARAMS = lngs;
						FExtension.store.set(GLOB_PREF + "_FAV_LANGS_WPT",lngs)
					}
				}
*/

			// DATA VALIDATION
			
			if(SKIP == 0){
				if(PARAMS.indexOf(",,")!=-1) PARAMS = PARAMS.slice(0,-2);
				else PARAMS = PARAMS.slice(0,-1);
				FExtension.store.set(LINE[0], PARAMS);
				FExtension.store.set("ADV", 1);
				FExtension.store.set("FRUN", 1);
				FExtension.store.set("ran_before", 1);
			}
		} //else  ERRORS = ERRORS + "<br>"+LINE[0]+" is not present in "+ localStorage.getItem(GLOB_PREF + "_Version") +" version";
	  }

	 // Error Handler for HKs
	  if(FExtension.store.get(GLOB_PREF + "_change_lang_HK_it") == ""){   
	        FExtension.store.set(GLOB_PREF + "_change_lang_HKbox_it","true");
		var pr = GetFromDefault(GLOB_PREF + "_change_lang_HK_it");	
	        FExtension.store.set(GLOB_PREF + "_change_lang_HK_it",pr);
	  }
	  if(FExtension.store.get(GLOB_PREF + "_HK_btn") == ""){   
	        FExtension.store.set(GLOB_PREF + "_HK_btnbox","true");
		var pr = GetFromDefault(GLOB_PREF + "_HK_btn");	
	        FExtension.store.set(GLOB_PREF + "_HK_btn",pr);
	  }
	  if(FExtension.store.get(GLOB_PREF + "_HK_gt2") == ""){   
	        FExtension.store.set(GLOB_PREF + "_HKset_inv","3|90|true");
		var pr = GetFromDefault(GLOB_PREF + "_HK_gt2");	
	        FExtension.store.set(GLOB_PREF + "_HK_gt2",pr);
	  }
	  if(FExtension.store.get(GLOB_PREF + "_HK_it2") == ""){   
	        FExtension.store.set(GLOB_PREF + "_FK_box2","true");
		var pr = GetFromDefault(GLOB_PREF + "_HK_it2");	
	        FExtension.store.set(GLOB_PREF + "_HK_it2",pr);
	  }
	  if(FExtension.store.get(GLOB_PREF + "_HK_opt") == ""){   
	        FExtension.store.set(GLOB_PREF + "_HK_optbox","true");
		var pr = GetFromDefault(GLOB_PREF + "_HK_opt");	
	        FExtension.store.set(GLOB_PREF + "_HK_opt",pr);
	  }
	  if(FExtension.store.get(GLOB_PREF + "_HK_bb2") == ""){   
	        FExtension.store.set(GLOB_PREF + "_HK_bb2box","true");
		var pr = GetFromDefault(GLOB_PREF + "_HK_bb2");	
	        FExtension.store.set(GLOB_PREF + "_HK_bb2",pr);
	  }
	  if(FExtension.store.get(GLOB_PREF + "_HK_wpt1") == ""){   
	        FExtension.store.set(GLOB_PREF + "_HK_wptbox1","true");
		var pr = GetFromDefault(GLOB_PREF + "_HK_wpt1");	
	        FExtension.store.set(GLOB_PREF + "_HK_wpt1",pr);
	  }
	  if(FExtension.store.get(GLOB_PREF + "_HK_wpt2") == ""){   
	        FExtension.store.set(GLOB_PREF + "_HK_wptbox2","true");
		var pr = GetFromDefault(GLOB_PREF + "_HK_wpt2");	
	        FExtension.store.set(GLOB_PREF + "_HK_wpt2",pr);
	  }
                                                
	  if(FExtension.store.get(GLOB_PREF + "_HK_SO_wpt") == ""){   
	        FExtension.store.set(GLOB_PREF + "_HK_SObox_wpt","true");
		var pr = GetFromDefault(GLOB_PREF + "_HK_SObox_wpt");	
	        FExtension.store.set(GLOB_PREF + "_HK_SO_wpt",pr);
	  }


	  if(FExtension.store.get(GLOB_PREF + "_HK_CT_wpt") == ""){   
	        FExtension.store.set(GLOB_PREF + "_HK_CTbox_wpt","true");
		var pr = GetFromDefault(GLOB_PREF + "_HK_CTbox_wpt");	
	        FExtension.store.set(GLOB_PREF + "_HK_CT_wpt",pr);
	  }

	  SLG_Reset_Booxes(SLG_Languages); 
	  FExtension.bg.ImTranslatorBG.SLG_WorkingSet();
 	  FExtension.bg.ImTranslatorBG.PREPARE_RCM_CONTENT();
	  
	  //GLOBAL_HK_VALIDATOR(GLOB_PREF);

	  // for GT only
	  if(GLOB_PREF=="SLG"){
		  FExtension.store.set("SLG_other_gt", "0");
		  FExtension.store.set("SLG_other_bbl", "0");
		  FExtension.store.set("SLG_other_wpt", "0");
	  }



	  GEBI("SLG_restore_lable").innerHTML="Restoring...";
	  
	  if(ERRORS=="") ERRORS = "<br>Data has been successfully imported!"
	  ERRORS = ERRORS_TTL + ERRORS;
	  FExtension.store.set(GLOB_PREF + "_Import_Report", ERRORS);
	  setTimeout(function() {
		   parent.frames["menu"].location.reload();
		   location.reload();
	  }, 2000);
    } else GEBI("SLG_upload_error").innerHTML="Wrong file format";
}


function SLG_Text_capitalize(str) {
   var splitStr = str.toLowerCase().split(' ');
   for (var i = 0; i < splitStr.length; i++) {
       splitStr[i] = splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);     
   }
   return splitStr.join(' '); 
}

function SLG_capitalize(s) {
  if (typeof s !== 'string') return '';
  return s.charAt(0).toUpperCase() + s.slice(1);
}

function SLG_UPLOAD_VALIDATOR(e){
   var out = 0;
   var st1 = 0;
   var st2 = 0;
   var st3 = 0;
   var st4 = 0;
   var st5 = 0;
   var st6 = 0;
   SLG_HEADER_VALIDATION(); 
   out = SLG_VALIDATION_STAGE_0(e);
   if(out == 1){
	   SLG_VALIDATION_STAGE_1(e);
   }
   return out;
}

function SLG_HEADER_VALIDATION(){
	  SLG_VALIDATION_STAGE_1();
	  if(GLOBAL_INPUT.indexOf("Version:") == -1 && GLOBAL_INPUT.indexOf(":") == -1 && GLOBAL_INPUT.indexOf("-") == -1) {
		HEADER = 0
		ERRORS = ERRORS + "- Header is not present<br>";
	  } else {
        	var t1 = GLOBAL_INPUT.split("Version: ")
		var t2 = t1[1].split(" -")
		var curVersion = t2[0];
		if(FExtension.store.get(GLOB_PREF + "_Version") != curVersion) 	ERRORS = ERRORS + "<br>Installed Vesion : " + FExtension.store.get(GLOB_PREF + "_Version")+"<br>Restored Backup Vesion : " + curVersion;
	  }
}

function SLG_VALIDATION_STAGE_0(e){
  var out = 0;
  if(GLOBAL_INPUT.indexOf(",") != -1 && GLOBAL_INPUT.indexOf("_LNG_LIST") != -1 && GLOBAL_INPUT.indexOf("_DICT_PRESENT") != -1){
	out = 1;
  }
  return out;
}

function SLG_VALIDATION_STAGE_1(){
  if(GLOBAL_INPUT.indexOf(",,") != -1){
      	GLOBAL_INPUT = GLOBAL_INPUT.trim();
  //      GLOBAL_INPUT = GLOBAL_INPUT.replace(/[,+][, ]+/g, "").trim();
  //      GLOBAL_INPUT = GLOBAL_INPUT.replace(/"/g, '');
  }
}

function SLG_REPORT(e){
        var rep = FExtension.store.get(GLOB_PREF + "_Import_Report");
	if (rep!=""){
		  //GEBI(GLOB_PREF + "_upload_error").innerHTML=rep;
			rep=rep.replace(/<br>/g,"\n");
			alert(rep);
	}
}

function DefineNONES(){
        var out = 0;
	var TMP = GLOBAL_INPUT.split("\n");
	for(var i=HEADER; i < TMP.length; i++){
      		var LINE = TMP[i].split(",");
		if(LINE[0]=="SLG_HK_gt1" && LINE[1]=="") out++;
		if(LINE[0]=="SLG_HK_it1" && LINE[1]=="") out++;
		if(LINE[0]=="SLG_HK_bb1" && LINE[1]=="") out++;
	}
	return(out);
}

function GetFromDefault(name){
	for(var i=0; i<PACK_PARAMS.length; i++){
		var tmp = PACK_PARAMS[i].split(";");
		var curDBname = tmp[0];
		var curDBparam = tmp[1];
		var DBparam = FExtension.store.get(curDBname);
	        if(curDBname == name) return curDBparam;
  	}
}

function GLOBAL_HK_VALIDATOR(PREF){
	var TMP = GLOBAL_INPUT.split("\n");
	var NEWarrayNames= new Array();
	var NEWarrayParams= new Array();
	var cntr=0;
	for(var i=HEADER; i < TMP.length; i++){
	   if(TMP[i].indexOf(",")!=-1){
      		var LINE = TMP[i].split(",");
		LINE[0] = LINE[0].replace(PREF,"")
		if(reservedHK.indexOf(LINE[0])!=-1){
			NEWarrayNames[cntr] = LINE[0];
			NEWarrayParams[cntr++] = FINISHING(LINE[1]);
		}
	   }	
	}

	//Find any Matches
	NEWarrayParams.sort();
	NEWarrayParams.forEach(function (value, index, arr){
        	let first_index = arr.indexOf(value);
	        let last_index = arr.lastIndexOf(value);
        	if(first_index !== last_index){
        	    if(value!="") {
			var defPar = GetFromDefault(PREF+NEWarrayNames[index]);
//			ERRORS = ERRORS + "<br>"+ PREF + NEWarrayNames[index] +' - duplicate item ' + value + " resetted to: " +defPar;
			FExtension.store.set(PREF+NEWarrayNames[index], defPar);
		    }
        	}
	});
	DETECT_CONFLICTS_LAST_STAGE(PREF);
}

function DETECT_CONFLICTS_LAST_STAGE(PREF){
	var HKnames = reservedHK.split(",");
	var NEWarrayHK = new Array();
	for(var i=0; i < HKnames.length; i++){
		NEWarrayHK[i] = FExtension.store.get(PREF+HKnames[i]);
	}
	NEWarrayHK.forEach(function (value, index, arr){
        	let first_index = arr.indexOf(value);
	        let last_index = arr.lastIndexOf(value);
        	if(first_index !== last_index){
        	    if(value!="") {
			var defPar = GetFromDefault(PREF+HKnames[index]);
//			ERRORS = ERRORS + "<br>"+ PREF + HKnames[index] +' - duplicate item ' + value + " resetted to: " +defPar;
			FExtension.store.set(PREF+HKnames[index], defPar);
		    }
        	}
	});
}

function FINISHING(ob){
  var NewLine="";
  var ctrl="";
  var alt="";
  var shift="";
  var tmp = ob.split(" + ");
  for (var i=0; i<tmp.length; i++){
    if(tmp[i] == "Ctrl") ctrl=tmp[i];
    if(tmp[i] == "Alt") alt=tmp[i];
    if(tmp[i] == "Shift") shift=tmp[i];
  }
  if(ctrl!="") NewLine = NewLine + ctrl + " + ";
  if(alt!="") NewLine = NewLine + alt + " + ";
  if(shift!="") NewLine = NewLine + shift + " + ";
  for (i=0; i<tmp.length; i++){
    if(tmp[i] != "Ctrl" && tmp[i] != "Alt" && tmp[i] != "Shift") NewLine = NewLine + tmp[i] + " + ";
  }
  tmp = NewLine.split(" + ");
  NewLine="";
  for (var i=0; i<tmp.length-1; i++){
    if(i<tmp.length-2) NewLine = NewLine + tmp[i] + " + ";
    else NewLine = NewLine + tmp[i];
  }
 ob=NewLine;
 return ob;

}

function SYNC_PROV_LIST(pr,st){
	var OUT="";
	var OP = localStorage[st]+",";
	var JOINline = pr+OP;
	var JOINarr = JOINline.split(",");
	var unique = JOINarr.filter(onlyUnique);
	for (var i = 0; i<unique.length-1; i++){
		OUT = OUT + unique[i] + ",";
	}
	var NEWpr = OUT.split(",");
	var OLDpr = OP.split(",");
	if(NEWpr.length == OLDpr.length) OUT = OP;
	else OUT = ADD2END(OUT,OP);
	return (OUT);
}

function ADD2END(OUT,OP){
	var NEWpr = OUT.split(",");
	var OLDpr = OP.split(",");
	if(NEWpr.length == OLDpr.length){
	 	var tmp = OP;
		var SHORTarr=OP.split(",");
		for (var i=0; i<SHORTarr.length-1; i++){
		    if(OUT.indexOf(SHORTarr[i])!=-1){
			 OUT = OUT.replace(SHORTarr[i]+",","");
		    }
		}
		return (OP+OUT);
	}else return (OP);
}

function onlyUnique(value, index, self) {
  return self.indexOf(value) === index;
}


function SLG_CUSTOM(tp,l,flag){
  var Ltemp=l.split(",");
  var Dname="SLG_langDst"+tp;
  var Sname="SLG_langSrc"+tp;
  var D = FExtension.store.get(Dname);
  var S = FExtension.store.get(Sname);

  if(l.indexOf('auto')==-1){
    if(Ltemp.length==2){
	S =  "auto";
	for(var i = 0; i < Ltemp.length; i++){
		if(Ltemp[i] != 'auto' && Ltemp[i] != FExtension.store.get(Dname) != "auto") {
			D = Ltemp[i];
			break;
		}
	}
    }
  } else {
        var Scntr=0;
	var Dcntr=0;
	for(var i = 0; i < Ltemp.length; i++){
		if(FExtension.store.get(Sname) == Ltemp[i]) Scntr++;
		if(FExtension.store.get(Dname) == Ltemp[i]) Dcntr++;
	}
	if(Scntr==0 && Dcntr==0){
		S = Ltemp[0];
		D = Ltemp[1];
	}
	if(Scntr==0 && Dcntr>0){
		for(var i = 0; i < Ltemp.length; i++){
			if(FExtension.store.get(Dname) != Ltemp[i]) {
				S = Ltemp[i];
				break;
			}
		}
	}
	if(Scntr>0 && Dcntr==0){
		for(var i = 0; i < Ltemp.length; i++){
			if(FExtension.store.get(Sname) != Ltemp[i]) {
				D = Ltemp[i];
				break;
			}
		}
	}
  }

  FExtension.store.set(Sname, S);
  FExtension.store.set(Dname, D);

  if(Dname == "SLG_langDst")	SLG_SAVE_FAVORITE_LANGUAGES(D, "SLG_FAV_LANGS_IMT");
  if(Dname == "SLG_langDst_bbl")	SLG_SAVE_FAVORITE_LANGUAGES(D, "SLG_FAV_LANGS_BBL");
  if(Dname == "SLG_langDst_it")	SLG_SAVE_FAVORITE_LANGUAGES(D, "SLG_FAV_LANGS_IT");
  if(Dname == "SLG_langDst_wpt")	SLG_SAVE_FAVORITE_LANGUAGES(D, "SLG_FAV_LANGS_WPT");

  var SRC = FExtension.store.get("SLG_langSrc");
  var DST = FExtension.store.get("SLG_langDst");
  if(tp=="") FExtension.store.set("SLG_langSrc2", SRC);
  if(flag==0){
	  FExtension.store.set("SLG_langSrc_it", SRC);
	  FExtension.store.set("SLG_langSrc_bbl", SRC);
	  FExtension.store.set("SLG_langSrc_wpt", SRC);
	  FExtension.store.set("SLG_langDst", DST);
	  FExtension.store.set("SLG_langDst_it", DST);
	  FExtension.store.set("SLG_langDst_bbl", DST);
	  FExtension.store.set("SLG_langDst_wpt", DST);
  }

}

function SLG_Reset_Booxes(list){
	var listTMP = list.split(",");
	var OUT = "";
	for(var k=0; k<listTMP.length; k++){
	    var listTMP2 = listTMP[k].split(":");
	    if(k<listTMP.length-1) OUT = OUT + listTMP2[0]+",";
	    else  OUT = OUT + listTMP2[0];
	}
	if(OUT != "") list = OUT;
	if(FExtension.store.get("SLG_global_lng")=="true"){
		if(list != "all"){
			SLG_CUSTOM("",list,0);
		}
	}else{
		if(list != "all"){
			if(FExtension.store.get("SLG_global_lng")=="true"){
				SLG_CUSTOM("",list,1);
				SLG_CUSTOM("_it",list,1);
				SLG_CUSTOM("_bbl",list,1);
				SLG_CUSTOM("_wpt",list,1);
			} else {
					var tr1 = FExtension.store.get("SLG_langDst")
					if(list.indexOf(tr1) == -1) SLG_CUSTOM("",list,0);
					else SLG_CUSTOM("",list,1);

					var tr2 = FExtension.store.get("SLG_langDst_bbl")
					if(list.indexOf(tr2) == -1) SLG_CUSTOM("_bbl",list,0);
					else SLG_CUSTOM("_bbl",list,1);

					var tr3 = FExtension.store.get("SLG_langDst_it")
					if(list.indexOf(tr3) == -1) SLG_CUSTOM("_it",list,0);
					else SLG_CUSTOM("_it",list,1);

					var tr4 = FExtension.store.get("SLG_langDst_wpt")
					if(list.indexOf(tr4) == -1) SLG_CUSTOM("_wpt",list,0);
					else SLG_CUSTOM("_wpt",list,1);
			}		
		}
	}
}

function SLG_SAVE_FAVORITE_LANGUAGES(ln, TR){
	var OUT = "";
	var OUT2 = "";
	var SLG_FAV_LANGS = FExtension.store.get(TR);
	var SLG_FAV_MAX = FExtension.store.get("SLG_FAV_MAX");
	if(SLG_FAV_LANGS.indexOf(ln)!=-1){
		SLG_FAV_LANGS = SLG_FAV_LANGS.replace(ln+",",""); 
		SLG_FAV_LANGS = SLG_FAV_LANGS.replace(ln,"");
	}
	OUT = ln + ",";	
	var ARR = SLG_FAV_LANGS.split(",");
	for (var i = 0; i < ARR.length; i++){
	 	OUT = OUT + ARR[i]+",";
	}
	if(OUT.slice(-1)==",") 	OUT = OUT.slice(0, OUT.length - 1);
	var TMP = OUT.split(",");
	if(TMP.length > SLG_FAV_MAX) {
		for (var j = 0; j < TMP.length-1; j++){
		 	OUT2 = OUT2 + TMP[j]+",";
		}		
		OUT = OUT2 
	}
	if(OUT.slice(-1)==",") 	OUT = OUT.slice(0, OUT.length - 1);
	FExtension.store.set(TR, OUT);
}


function SLG_CUSTOM(tp,l,flag){
  var Ltemp=l.split(",");
  var Dname="SLG_langDst"+tp;
  var Sname="SLG_langSrc"+tp;
  var D = FExtension.store.get(Dname);
  var S = FExtension.store.get(Sname);

  if(l.indexOf('auto')!=-1){
        var Scntr=0;
	var Dcntr=0;
	for(var i = 0; i < Ltemp.length; i++){
		if(FExtension.store.get(Sname) == Ltemp[i]) Scntr++;
		if(FExtension.store.get(Dname) == Ltemp[i]) Dcntr++;
	}
	if(Scntr==0 && Dcntr==0){
		S = Ltemp[0];
		D = Ltemp[1];
	}
	if(Scntr==0 && Dcntr>0){
		for(var i = 0; i < Ltemp.length; i++){
			if(FExtension.store.get(Dname) != Ltemp[i]) {
				S = Ltemp[i];
				break;
			}
		}
	}
	if(Scntr>0 && Dcntr==0){
		for(var i = 0; i < Ltemp.length; i++){
			if(FExtension.store.get(Sname) != Ltemp[i]) {
				D = Ltemp[i];
				break;
			}
		}
	}
  }

  FExtension.store.set(Sname, S);
  FExtension.store.set(Dname, D);

  if(Dname == "SLG_langDst")	SLG_SAVE_FAVORITE_LANGUAGES(D, "SLG_FAV_LANGS_IMT");
  if(Dname == "SLG_langDst_bbl")	SLG_SAVE_FAVORITE_LANGUAGES(D, "SLG_FAV_LANGS_BBL");
  if(Dname == "SLG_langDst_it")	SLG_SAVE_FAVORITE_LANGUAGES(D, "SLG_FAV_LANGS_IT");
  if(Dname == "SLG_langDst_wpt")	SLG_SAVE_FAVORITE_LANGUAGES(D, "SLG_FAV_LANGS_WPT");

  var SRC = FExtension.store.get("SLG_langSrc");
  var DST = FExtension.store.get("SLG_langDst");
  if(tp=="") FExtension.store.set("SLG_langSrc2", SRC);
  if(flag==0){
	  FExtension.store.set("SLG_langSrc", SRC);
	  FExtension.store.set("SLG_langSrc_it", SRC);
	  FExtension.store.set("SLG_langSrc_bbl", SRC);
	  FExtension.store.set("SLG_langSrc_wpt", SRC);
	  FExtension.store.set("SLG_langDst", DST);
	  FExtension.store.set("SLG_langDst2", DST);
	  FExtension.store.set("SLG_langDst_it", DST);
	  FExtension.store.set("SLG_langDst_bbl", DST);
	  FExtension.store.set("SLG_langDst_wpt", DST);
  }

}

function GET_SINGLE_SRC_AVAILABILITY(active){
	try{
		var OUT="";
		var LIST = FExtension.store.get(GLOB_PREF + "_LNG_LIST")
		if(LIST!="all"){
			var tmp2 = LIST.split(",");	
			for(var i=0; i<tmp2.length; i++){
				if(active == tmp2[i]) OUT = active;
			}
			if(OUT==""){
				if(active=="auto") OUT = tmp2[0];
				else OUT = tmp2[1];
			}
		} else {
			OUT = active;				
		}
		if(OUT=="") OUT="auto";
		return(OUT);
	} catch(ex){}
}

function GET_SINGLE_DST_AVAILABILITY(active){
	try{
		var lngarr = SLG_Languages.split(",");
		var OUT = "";
		for(var i=0; i<lngarr.length; i++){
			var tmp = lngarr[i].split(":");	
			if(tmp[0].toLowerCase()==active.toLowerCase()){
					OUT = active;
			}
		}
		if(OUT=="") {
			var LIST = FExtension.store.get(GLOB_PREF + "_LNG_LIST")
			if(LIST!="all"){
				var tmp2 = LIST.split(",");	
				OUT = tmp2[0];
			} else {
				var LIST = LISTofPRpairsDefault.split(",");
				OUT = LIST[0];				
			}
		}
		return(OUT);
	} catch(ex){}
}


function FIX_FROM_TO(app){
        if(FExtension.store.get(GLOB_PREF + "_langSrc" + app)!="auto"){
		var LIST = FExtension.store.get(GLOB_PREF + "_LNG_LIST");
		var tmp = LIST.split(",");	
		FExtension.store.set(GLOB_PREF + "_langDst" + app,tmp[0]);
		FExtension.store.set(GLOB_PREF + "_langSrc" + app,tmp[1]);
	}
}

function GET_LANG_AVAILABILITY(active_list){
	try{
		var lngarr = SLG_Languages.split(",");
		var active_lngarr = active_list.split(",");
		var OUT = "";
		if(active_list.indexOf("auto")!=-1) OUT="auto,";
		for(var i=0; i<lngarr.length; i++){
			var tmp = lngarr[i].split(":");	
			for(var j=0; j<active_lngarr.length; j++){
				if(tmp[0].toLowerCase()==active_lngarr[j].toLowerCase()){
					OUT = OUT + active_lngarr[j]+",";
				}
			}
		}
		return(OUT);
	} catch(ex){}
}

function GET_VAF_LIST(active_list){
	try{
		var lngarr = SLG_Languages.split(",");
		var active_lngarr = active_list.split(",");
		var OUT = "";
		for(var i=0; i<lngarr.length; i++){
			var tmp = lngarr[i].split(":");	
			for(var j=0; j<active_lngarr.length; j++){
				if(tmp[0].toLowerCase()==active_lngarr[j].toLowerCase()){
					OUT = OUT + active_lngarr[j]+",";
				}
			}
		}
		OUT = OUT.substring(0,OUT.length-1);		    
		return(OUT);
	} catch(ex){}
}

