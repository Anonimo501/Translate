'use strict';
var SLG_DARK="invert(95%)";

var SLG_Languages = CUSTOM_LANGS(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLanguages'));

(function(){GEBI("SRV0").addEventListener("click",function(){SLG_ACTIVE = GEBI("SRV0"); SLG_TMP=SLG_ACTIVE.value; SLG_ACTIVE.focus();SLG_MSG_HANDLER(event);},!1); } )();
(function(){GEBI("SRV0").addEventListener("mouseout",function(){NoneColor(0);},!1); } )();
(function(){GEBI("SRV0").addEventListener("paste",function(){ PREVENT_PASTE(event); },!1);} )();


(function(){GEBI("SRV1").addEventListener("click",function(){SLG_ACTIVE = GEBI("SRV1"); SLG_TMP=SLG_ACTIVE.value; SLG_ACTIVE.focus();SLG_MSG_HANDLER(event);},!1); } )();
(function(){GEBI("SRV1").addEventListener("mouseout",function(){NoneColor(1);},!1); } )();
(function(){GEBI("SLG_del1").addEventListener("click",function(){SLG_DEL_AUTO(1);},!1);} )();
(function(){GEBI("SRV1").addEventListener("paste",function(){ PREVENT_PASTE(event); },!1);} )();

(function(){GEBI("SRV2").addEventListener("click",function(){SLG_ACTIVE = GEBI("SRV2"); SLG_TMP=SLG_ACTIVE.value; SLG_ACTIVE.focus();SLG_MSG_HANDLER(event);},!1); } )();
(function(){GEBI("SRV2").addEventListener("mouseout",function(){NoneColor(2);},!1); } )();
(function(){GEBI("SRV2").addEventListener("paste",function(){ PREVENT_PASTE(event); },!1);} )();

(function(){GEBI("SLG_info").addEventListener("click",function(){FExtension.browserPopup.openNewTab(this.href);},!1);} )();
(function(){GEBI("SLG_LOC").addEventListener("change",function(){SLG_SAVE_LOC();},!1);} )();

(function(){GEBI("SLG_HK0").addEventListener("click",function(){ SLG_HIDE_HK("SLG_HK0","SLG_HIDE0");},!1); } )();
(function(){GEBI("SLG_HK1").addEventListener("click",function(){ SLG_HIDE_HK("SLG_HK1","SLG_HIDE1");},!1); } )();
(function(){GEBI("SLG_HK2").addEventListener("click",function(){ SLG_HIDE_HK("SLG_HK2","SLG_HIDE2");},!1); } )();

(function(){GEBI("SLG_LNG_STATUS").addEventListener("click",function(){ SLG_LANGS(); },!1); } )();
//(function(){GEBI("SLG_down_box").addEventListener("click",function(){ SLG_LANGS(); },!1); } )();
//(function(){GEBI("SLG_down").addEventListener("click",function(){ SLG_LANGS(); },!1); } )();

(function(){GEBI("SLG_OtherTr").addEventListener("click",function(){ SLG_SHOWHIDEPROVIDERS(); },!1); } )();
(function(){window.addEventListener("mousemove",function(){NoneColor(1);},!1);} )();

(function(){GEBI("SLG_THEME").addEventListener("change",function(){SLG_SAVE_THEME();},!1);} )();

(function(){GEBI("reset_all0").addEventListener("click",function(){ RESET_ALL_HK(0);},!1);} )();
(function(){GEBI("reset_all1").addEventListener("click",function(){ RESET_ALL_HK(1);},!1);} )();
(function(){GEBI("reset_all2").addEventListener("click",function(){ RESET_ALL_HK(2);},!1);} )();

(function(){window.addEventListener("mousemove",function(){
	BUILD_RESET_ICN(0);
	BUILD_RESET_ICN(1);
	BUILD_RESET_ICN(2);
},!1);} )();

(function(){window.addEventListener("click",function(event){
	SLG_MSG_HANDLER(event);
},!1);} )();

//AUTOSAVE BLOCK
window.addEventListener('change',function(e){
	save_options(0);
},!1);
//AUTOSAVE BLOCK

(function(){
    window.addEventListener('load',function(){
        GEBI('SLG_translate_container').style.opacity="1";
	CONSTRUCTOR();
	var OB = GEBI('SLG_langSrc_tr');
	if(FExtension.store.get("SLG_LNG_LIST").indexOf("auto")!=-1 || FExtension.store.get("SLG_LNG_LIST")=="all"){
		var OB1 = document.createElement('option');
		var v = document.createAttribute("value");
		v.value = "auto";
		OB1.setAttributeNode(v);
		OB1.appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetect_language_from_box')));
		OB.appendChild(OB1); 
	}
	var SLG_TMP = SLG_Languages.split(",");
	for(var J=0; J < SLG_TMP.length; J++){
	    var SLG_TMP2=SLG_TMP[J].split(":");
	    var OB2 = document.createElement('option');
	    var v = document.createAttribute("value");
	    v.value = SLG_TMP2[0];
	    OB2.setAttributeNode(v);
	    OB2.appendChild(document.createTextNode(SLG_TMP2[1]));
	    OB.appendChild(OB2);
	}

	var OB3 = GEBI('SLG_langDst_tr');
	for(var J=0; J < SLG_TMP.length; J++){
	    var SLG_TMP2=SLG_TMP[J].split(":");
	    var OB2 = document.createElement('option');
	    v = document.createAttribute("value");
	    v.value = SLG_TMP2[0];
	    OB2.setAttributeNode(v);
	    OB2.appendChild(document.createTextNode(SLG_TMP2[1]));
	    OB3.appendChild(OB2);
	}
	INIT();

    },!1);
})();


function CONSTRUCTOR(){
	GEBI('SLG_BG_op').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSLBG_op')));
	GEBI('SLG_setLS4allTr').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSLsetLS4allTr')));
	GEBI('SLSeSo').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSeSo')));
	GEBI('SLSeTa').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSeTa')));
	GEBI('SLG_TR_op').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extTR_op')));
	GEBI('SLG_DetSoLaAu').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetSoLaAu')));
	GEBI('SLG_enable_dict').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extEnable_Dict')));
	GEBI('SLG_showBW').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extShowBW')));
	GEBI('SLG_ChFS').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extChFS')));
	GEBI('SLG_FS_small').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extFS_small')));
	GEBI('SLG_FS_large').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extFS_large')));
	GEBI('SLG_HotKeys').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extHotKeys')));
	GEBI('SLG_TOMS').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extTOMS')));
	GEBI('SLG_InvTr').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extInvTr')));
	GEBI('SLG_EnTH').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extEnTH')));
	GEBI('SLG_TrHi').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extTrHist')));
	GEBI('SLG_OptTrBut').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extOptTrBut')));
	GEBI('SLG_il').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLOC')));
	GEBI('SLG_SaveText_gt').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSaveText')));
	GEBI('SLG_L_BOX').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLangs')+":"));
	GEBI('SLG_LNG_STATUS').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extCustomize')));
	GEBI('SLG_LIST_TR_PR').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLIST_TR_PR')));
	GEBI('SLG_SET_TR_PR').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSET_TR_PR')));
	GEBI('SLG_SHOWHIDE_TR_PR').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSHOWHIDE_TR_PR')));

	GEBI('SLG_theme_ttl').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extTHEME')));
	GEBI('SLG_theme_1').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLIGHT')));
	GEBI('SLG_theme_2').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDARK')));

	switch(PLATFORM){
	 case "Opera" : GEBI('SLG_info').href="https://about.imtranslator.net/tutorials/presentations/google-translate-for-opera/opera-translator-options/"; break;
	 case "Chrome": GEBI('SLG_info').href="https://about.imtranslator.net/tutorials/presentations/imtranslator-for-chrome/chrome-imtranslator-options/"; break;
	 default      : GEBI('SLG_info').href="https://about.imtranslator.net/tutorials/presentations/";break;
	}
	PR_BUILDER("SLG_ALL_PROVIDERS_GT");
	ACTIVATE_THEME(FExtension.store.get("THEMEmode"));
}

function INIT(){
  ACTIVATE_MENU_ELEMENT(1);
  GEBI("SLG_LOC").value=FExtension.store.get("SLG_LOCALIZATION");

  var mySLG_langSrc_tr = FExtension.store.get("SLG_langSrc");
  var mySLG_langSrc_trSelect = GEBI("SLG_langSrc_tr");                                                         
  for (var i = 0; i < mySLG_langSrc_trSelect.options.length; i++) {
    var mySLG_langSrc_trOption = mySLG_langSrc_trSelect.options[i];
    if (mySLG_langSrc_trOption.value == mySLG_langSrc_tr) {
      mySLG_langSrc_trOption.selected = "true";
      break;
    }
  }

  var mySLG_langDst_tr = FExtension.store.get("SLG_langDst");
  var mySLG_langDst_trSelect = GEBI("SLG_langDst_tr");
  for (var i = 0; i < mySLG_langDst_trSelect.options.length; i++) {
    var mySLG_langDst_trOption = mySLG_langDst_trSelect.options[i];
    if (mySLG_langDst_trOption.value == mySLG_langDst_tr) {
      mySLG_langDst_trOption.selected = "true";
      break;
    }
  }


  var SLG_TH_1 = FExtension.store.get("SLG_TH_1");
  if(SLG_TH_1=="1")  GEBI("SLG_TH_1").checked = true;
  else GEBI("SLG_TH_1").checked = false;

  var SLG_global_lng = FExtension.store.get("SLG_global_lng");
  if(SLG_global_lng=="true")  GEBI("SLG_global_lng").checked = true;
  else GEBI("SLG_global_lng").checked = false;

  var SLG_no_detect = FExtension.store.get("SLG_no_detect");
  if(SLG_no_detect=="true")  GEBI("SLG_no_detect").checked = true;
  else GEBI("SLG_no_detect").checked = false;

  var SLG_dict = FExtension.store.get("SLG_dict");
  if(SLG_dict=="true")  GEBI("SLG_dictionary").checked = true;
  else GEBI("SLG_dictionary").checked = false;

  var SLG_OtherTr = FExtension.store.get("SLG_other_gt");
  if(SLG_OtherTr=="1"){
	GEBI("SLG_OtherTr").checked = true;
  }else{
	GEBI("SLG_OtherTr").checked = false;
  }	

  var SLG_pr_gt = FExtension.store.get("SLG_pr_gt");
  if(SLG_pr_gt=="1") GEBI("SLG_pr_gt").checked = true;
  else	GEBI("SLG_pr_gt").checked = false;
  SLG_SHOWHIDEPROVIDERS();


  var mySLG_show_back = FExtension.store.get("SLG_BACK_VIEW");
  if(mySLG_show_back==1)  GEBI("SLG_show_back").checked = true;
  else GEBI("SLG_show_back").checked = false;

  var mySLG_Fontsize = FExtension.store.get("SLG_Fontsize");
  var mySLG_FontsizeSelect = GEBI("SLG_Fontsize");
  for (var i = 0; i < mySLG_FontsizeSelect.options.length; i++) {
    var mySLG_FontsizeOption = mySLG_FontsizeSelect.options[i];
    if (mySLG_FontsizeOption.value == mySLG_Fontsize) {
      mySLG_FontsizeOption.selected = "true";
      break;
    }
  }

  // Hotkeys block

  var mySLG_HKset = FExtension.store.get("SLG_HKset").split("|");
  var mySLG_HK = mySLG_HKset[2];
  if(mySLG_HK=="true")  GEBI("SLG_HK1").checked = true;
  else GEBI("SLG_HK1").checked = false;

  var mySLG_HKset_inv = FExtension.store.get("SLG_HKset_inv").split("|");
  var mySLG_HK_inv = mySLG_HKset_inv[2];
  if(mySLG_HK_inv=="true")  GEBI("SLG_HK2").checked = true;
  else GEBI("SLG_HK2").checked = false;

  if(FExtension.store.get("SLG_HK_gt1")!=""){
	GEBI('SRV1').value=FExtension.store.get("SLG_HK_gt1");
  } else {
	GEBI('SRV1').placeholder="Not set";
  }
  GEBI('SRV2').value=FExtension.store.get("SLG_HK_gt2");

  if(FExtension.store.get("SLG_HK_btnbox")=="true") GEBI('SLG_HK0').checked=true;
  else GEBI('SLG_HK0').checked=false;
  GEBI('SRV0').value=FExtension.store.get("SLG_HK_btn");

  SLG_HIDE_HK("SLG_HK0","SLG_HIDE0");
  SLG_HIDE_HK("SLG_HK1","SLG_HIDE1");
  SLG_HIDE_HK("SLG_HK2","SLG_HIDE2");

  if(FExtension.store.get("SLG_SaveText_box_gt")==1) GEBI('SLG_SaveText_box_gt').checked=true;
  else GEBI('SLG_SaveText_box_gt').checked=false;

  var SLG_THEMEmode = FExtension.store.get("THEMEmode");
  if(SLG_THEMEmode==0)  GEBI("SLG_THEME").value = 0;
  else GEBI("SLG_THEME").value = 1;
  save_options(1);
}

function save_options(st) {
 setTimeout(function() {

  var SLG_select_S = GEBI("SLG_langSrc_tr");
  var SLG_select_T = GEBI("SLG_langDst_tr");
  var SLG_select_FS = GEBI("SLG_Fontsize");
 
   if(SLG_select_S.value!=SLG_select_T.value){
	   if(GEBI("SLG_TH_1").checked==true) FExtension.store.set("SLG_TH_1", "1");
	   else FExtension.store.set("SLG_TH_1", "0");

   

	        if(GEBI("SLG_pr_gt").checked==true){
		   SAVE_LIST_PROVIDERS_SYN("SLG_ALL_PROVIDERS_GT","SLG_ALL_PROVIDERS_BBL");
		   FExtension.store.set("SLG_pr_gt", "1");
		   FExtension.store.set("SLG_pr_bbl", "1");
		        if(GEBI("SLG_OtherTr").checked == true) {
				FExtension.store.set("SLG_other_bbl", "1");
				FExtension.store.set("SLG_other_gt", "1");
		        }else{
				FExtension.store.set("SLG_other_bbl", "0");
				FExtension.store.set("SLG_other_gt", "0");
			}
	   	} else {
	   	   SAVE_LIST_PROVIDERS("SLG_ALL_PROVIDERS_GT");
		   FExtension.store.set("SLG_pr_gt", "0");
		   FExtension.store.set("SLG_pr_bbl", "0");
		        if(GEBI("SLG_OtherTr").checked == true) {
				FExtension.store.set("SLG_other_gt", "1");
		        }else{
				FExtension.store.set("SLG_other_gt", "0");
			}
	   	}

//------TIME STAMP--------------
	new Date().getTime();
	FExtension.store.set("SLG_TS", Date.now());
//==============================

		var SLG_langSrc_tr = SLG_select_S.children[SLG_select_S.selectedIndex].value;
		FExtension.store.set("SLG_langSrc", SLG_langSrc_tr);

		FExtension.store.set("SLG_langSrc2",SLG_langSrc_tr);

		var SLG_langDst_tr = SLG_select_T.children[SLG_select_T.selectedIndex].value;
		FExtension.store.set("SLG_langDst", SLG_langDst_tr);
		FExtension.store.set("SLG_langDst2", SLG_langDst_tr);
		FExtension.store.set("SLG_WPT_TEMP_LANG", SLG_langDst_tr);			

		FExtension.store.set("SLG_no_detect", GEBI("SLG_no_detect").checked);
	
		var SLG_langDst_name = SLG_select_T.children[SLG_select_T.selectedIndex].text;
		FExtension.store.set("SLG_langDst_name", SLG_langDst_name);

 	        var SLG_Fontsize = SLG_select_FS.children[SLG_select_FS.selectedIndex].value;
	        FExtension.store.set("SLG_Fontsize", SLG_Fontsize);
	        FExtension.store.set("SLG_Fontsize2", SLG_Fontsize);

		FExtension.store.set("SLG_dict", GEBI("SLG_dictionary").checked);
		FExtension.store.set("SLG_show_back", GEBI("SLG_show_back").checked);
		FExtension.store.set("SLG_show_back2", GEBI("SLG_show_back").checked);

		if(GEBI("SLG_show_back").checked==true)	FExtension.store.set("SLG_BACK_VIEW",1);
		else	FExtension.store.set("SLG_BACK_VIEW",2);


		var SLG_HKset = 3;
	        SLG_HKset = SLG_HKset + "|" + GET_CODE(SLG_HK_SPLIT("SRV2",2));
	   	SLG_HKset = SLG_HKset + "|" + GEBI("SLG_HK1").checked;	
		FExtension.store.set("SLG_HKset", SLG_HKset);

		FExtension.store.set("SLG_HKset_inv", "3|90|"+GEBI("SLG_HK2").checked);

		if(GEBI('SRV1').value!="")	FExtension.store.set("SLG_HK_gt1", GEBI('SRV1').value);
		else FExtension.store.set("SLG_HK_gt1", "");
		FExtension.store.set("SLG_HK_gt2", GEBI('SRV2').value);

		FExtension.store.set("SLG_HK_btn", GEBI('SRV0').value);
		if(GEBI('SLG_HK0').checked==true) FExtension.store.set("SLG_HK_btnbox", "true");
		else FExtension.store.set("SLG_HK_btnbox", "false");

		FExtension.store.set("SLG_Flag", "FALSE");

		if(GEBI('SLG_SaveText_box_gt').checked==true) FExtension.store.set("SLG_SaveText_box_gt",1);
		else FExtension.store.set("SLG_SaveText_box_gt",0);


	   if(GEBI("SLG_global_lng").checked==true){
		   FExtension.store.set("SLG_global_lng", GEBI("SLG_global_lng").checked);
		   FExtension.store.set("SLG_global_lng_bbl", GEBI("SLG_global_lng").checked);
		   FExtension.store.set("SLG_global_lng_wpt", GEBI("SLG_global_lng").checked);
		   FExtension.store.set("SLG_global_lng_it", GEBI("SLG_global_lng").checked);
	
		   FExtension.store.set("SLG_langSrc", SLG_select_S.children[SLG_select_S.selectedIndex].value);
		   FExtension.store.set("SLG_langSrc2", SLG_select_S.children[SLG_select_S.selectedIndex].value);
		   FExtension.store.set("SLG_langSrc_bbl", SLG_select_S.children[SLG_select_S.selectedIndex].value);
		   FExtension.store.set("SLG_langSrc_wpt", SLG_select_S.children[SLG_select_S.selectedIndex].value);
		   FExtension.store.set("SLG_langSrc_it", SLG_select_S.children[SLG_select_S.selectedIndex].value);
	
		   FExtension.store.set("SLG_langDst", SLG_select_T.children[SLG_select_T.selectedIndex].value);
		   FExtension.store.set("SLG_langDst2", SLG_select_T.children[SLG_select_T.selectedIndex].value);
		   FExtension.store.set("SLG_langDst_bbl", SLG_select_T.children[SLG_select_T.selectedIndex].value);
		   FExtension.store.set("SLG_langDst_wpt", SLG_select_T.children[SLG_select_T.selectedIndex].value);
		   FExtension.store.set("SLG_langDst_it", SLG_select_T.children[SLG_select_T.selectedIndex].value);

		   FExtension.store.set("SLG_no_detect", GEBI("SLG_no_detect").checked);
		   FExtension.store.set("SLG_no_detect_bbl", GEBI("SLG_no_detect").checked);
		   FExtension.store.set("SLG_no_detect_it", GEBI("SLG_no_detect").checked);

		   FExtension.store.set("SLG_langDst_name", SLG_select_T.children[SLG_select_T.selectedIndex].text);
		   FExtension.store.set("SLG_langDst_name_wpt", SLG_select_T.children[SLG_select_T.selectedIndex].text);
		   FExtension.store.set("SLG_langDst_name_bbl", SLG_select_T.children[SLG_select_T.selectedIndex].text);
		   FExtension.store.set("SLG_langDst_name_it", SLG_select_T.children[SLG_select_T.selectedIndex].text);

		   var IDS = document.getElementById("SLG_langDst_tr").value;
		   SLG_SAVE_FAVORITE_LANGUAGES(IDS, "SLG_FAV_LANGS_IMT");
		   SLG_SAVE_FAVORITE_LANGUAGES(IDS, "SLG_FAV_LANGS_BBL");
		   SLG_SAVE_FAVORITE_LANGUAGES(IDS, "SLG_FAV_LANGS_IT");
   		   SLG_SAVE_FAVORITE_LANGUAGES(IDS, "SLG_FAV_LANGS_WPT");
	   	} else {		   
	   	   FExtension.store.set("SLG_global_lng", GEBI("SLG_global_lng").checked);
	   	   FExtension.store.set("SLG_global_lng_bbl", GEBI("SLG_global_lng").checked);
	   	   FExtension.store.set("SLG_global_lng_wpt", GEBI("SLG_global_lng").checked);
	   	   FExtension.store.set("SLG_global_lng_it", GEBI("SLG_global_lng").checked);
		   SLG_SAVE_FAVORITE_LANGUAGES(document.getElementById("SLG_langDst_tr").value, "SLG_FAV_LANGS_IMT");
	           FExtension.store.set("SLG_langDst_name", SLG_select_T.children[SLG_select_T.selectedIndex].text);
	   	}

                RESET_TEMPS_TO_DEFAULT();
                FExtension.bg.ImTranslatorBG.PREPARE_RCM_CONTENT();
	 	FExtension.bg.ImTranslatorBG.SLG_WorkingSet();
	        FExtension.bg.FExtension.browser.refreshSettings();

		FExtension.bg.ImTranslatorBG.DIC_TRIGGER = 0;
		ACTIVATE_THEME(FExtension.store.get("THEMEmode"));

		if(GEBI('autohotkeys')){
		  var frame = GEBI('autohotkeys');
		  if(frame)	frame.parentNode.removeChild(frame);
		}

		localStorage["WINDOW_WIDTH"] = 555;
		localStorage["WINDOW_HEIGHT"] = 670; //540;
	    	localStorage["WINDOW_TOP"] = ((screen.height - localStorage["WINDOW_HEIGHT"] ) / 2);
	    	localStorage["WINDOW_LEFT"]= (( screen.width - localStorage["WINDOW_WIDTH"] ) / 2 );



   }else{ 
	  alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extS_T_L_diff'));
   }
 }, 100);
}

function GEBI(id){ return document.getElementById(id);}




function ACTIVATE_MENU_ELEMENT(st){
  var win = top.frames['menu'];
  var li = win.document.getElementsByTagName("li");
  for(var i=1; i<=li.length; i++){
        if(st==i) win.document.getElementById('SLG_options_menu'+i).className='SLG_options-menu-on';
        else win.document.getElementById('SLG_options_menu'+i).className='SLG_options-menu-off';
  }
}

function SLG_SAVE_LOC(){
  FExtension.store.set("SLG_LOCALIZATION", GEBI("SLG_LOC").value);
  CONSTRUCTOR();
  FExtension.bg.ImTranslatorBG.SLG_WorkingSet();
  parent.frames["menu"].location.reload();
  location.reload();
}

function SLG_SAVE_THEME(){
  FExtension.store.set("THEMEmode", GEBI("SLG_THEME").value);
  FExtension.bg.ImTranslatorBG.SLG_WorkingSet();
  location.reload();
}


function ACTIVATE_THEME(st){
 	if(st==1){
		var bg="#191919";
		var clr="#BF7D44";
		var clr_deact="#BDBDBD";
		GEBI("SLG_translate_container").style.filter=SLG_DARK;
		var LBLS = document.getElementsByClassName("SLG_BG_op");
		for(var i=0; i<LBLS.length; i++) LBLS[i].style.color=clr;
		var A = document.getElementsByTagName("a");
		for(var i=0; i<A.length; i++) A[i].style.color=clr;

		var E = document.getElementsByClassName("SLMSG");
		for(var j=0; j<E.length; j++) E[j].style.filter=SLG_DARK;


		setTimeout(function() {
			var SLG_lngSrc_opt = GEBI("SLG_langSrc_tr").getElementsByTagName("option");
			for(var j=0; j<SLG_lngSrc_opt.length; j++) SLG_lngSrc_opt[j].setAttribute("style", "background:"+bg+" !important;color:#fff;");
			var SLG_lngSrc_opt = GEBI("SLG_langDst_tr").getElementsByTagName("option");
			for(var j=0; j<SLG_lngSrc_opt.length; j++) SLG_lngSrc_opt[j].setAttribute("style", "background:"+bg+" !important;color:#fff;");
			var SLG_fnt_opt = GEBI("SLG_Fontsize").getElementsByTagName("option");
			for(var j=0; j<SLG_fnt_opt.length; j++) SLG_fnt_opt[j].setAttribute("style", "background:"+bg+" !important;color:#fff;");
		}, 1000);
		
		if(GEBI("item-0")) GEBI("item-0").style.borderRight="10px solid "+clr;	
		if(GEBI("item-1")) GEBI("item-1").style.borderRight="10px solid "+clr;
		if(GEBI("item-2")) GEBI("item-2").style.borderRight="10px solid "+clr;
		if(GEBI("item-3")) GEBI("item-3").style.borderRight="10px solid "+clr;
		GEBI("SLG_AUTOKEYS").style.filter=SLG_DARK;	
	}
}



function SLG_SAVE_FAVORITE_LANGUAGES(ln, TR){
	var OUT = "";
	var OUT2 = "";
	var SLG_FAV_LANGS = FExtension.store.get(TR);
	var SLG_FAV_MAX = FExtension.store.get("SLG_FAV_MAX");
	if(SLG_FAV_LANGS.indexOf(ln)!=-1){
		SLG_FAV_LANGS = SLG_FAV_LANGS.replace(ln+",",""); 
		SLG_FAV_LANGS = SLG_FAV_LANGS.replace(ln,"");
	}
	OUT = ln + ",";	
	var ARR = SLG_FAV_LANGS.split(",");
	for (var i = 0; i < ARR.length; i++){
	 	OUT = OUT + ARR[i]+",";
	}
	if(OUT.slice(-1)==",") 	OUT = OUT.slice(0, OUT.length - 1);
	var TMP = OUT.split(",");
	if(TMP.length > SLG_FAV_MAX) {
		for (var j = 0; j < TMP.length-1; j++){
		 	OUT2 = OUT2 + TMP[j]+",";
		}		
		OUT = OUT2 
	}
	if(OUT.slice(-1)==",") 	OUT = OUT.slice(0, OUT.length - 1);
	FExtension.store.set(TR, OUT);
}



function BUILD_RESET_ICN(ob){
	GEBI("reset_all"+ob).title="Reset to default";
}

function SLG_DEL_AUTO(ob){
	GEBI("SRV"+ob).value = "Auto Translate"; 
	GEBI("SRV"+ob).placeholder = "Auto Translate"; 
        GEBI("MSG"+ob).style.visibility="hidden";
	save_options(0);
}                          


function RESET_ALL_HK(id){
        var st = "";
        switch (id){
         case 0: st = 'SLG_HK_btn'; break;
         case 1: st = 'SLG_HK_gt1'; break;
         case 2: st = 'SLG_HK_gt2'; break;
	}
	for(var i=0; i<PACK_PARAMS.length; i++){
		var tmp = PACK_PARAMS[i].split(";");
		var curDBname = tmp[0];
		var curDBparam = tmp[1];
		var DBparam = FExtension.store.get(curDBname);
		if(curDBname == st){
			FExtension.store.set(curDBname, curDBparam);			
			GEBI("MSG"+id).style.visibility="hidden";
		}
	}
	GEBI("SRV"+id).value=FExtension.store.get(st);
}

