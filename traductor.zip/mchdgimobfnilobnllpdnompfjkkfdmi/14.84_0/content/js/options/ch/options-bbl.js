'use strict';
var SLG_DARK="invert(95%)";

var SLG_Languages = CUSTOM_LANGS(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLanguages'));

(function(){GEBI("SRV5").addEventListener("click",function(){SLG_ACTIVE = GEBI("SRV5"); SLG_TMP=SLG_ACTIVE.value; SLG_ACTIVE.focus();SLG_MSG_HANDLER(event);},!1); } )();
(function(){GEBI("SRV5").addEventListener("mouseout",function(){NoneColor(5);},!1); } )();
(function(){GEBI("SLG_del5").addEventListener("click",function(){SLG_DEL_AUTO(5);},!1);} )();
(function(){GEBI("SRV5").addEventListener("paste",function(){ PREVENT_PASTE(event); },!1);} )();

(function(){GEBI("SRV6").addEventListener("click",function(){SLG_ACTIVE = GEBI("SRV6"); SLG_TMP=SLG_ACTIVE.value; SLG_ACTIVE.focus();SLG_MSG_HANDLER(event);},!1); } )();
(function(){GEBI("SRV6").addEventListener("mouseout",function(){NoneColor(6);},!1); } )();
(function(){GEBI("SRV6").addEventListener("paste",function(){ PREVENT_PASTE(event); },!1);} )();

(function(){GEBI("SLG_ENABLE").addEventListener("click",function(){SLG_Enable_ImTranslator_Bubble_SYNCHRO();},!1);} )();

(function(){GEBI("SLX").addEventListener("keyup",function(){Coord(this);},!1);} )();
(function(){GEBI("SLY").addEventListener("keyup",function(){Coord(this);},!1);} )();

(function(){GEBI("SLX").addEventListener("click",function(){if(this.value==0)this.value="";},!1);} )();
(function(){GEBI("SLY").addEventListener("click",function(){if(this.value==0)this.value="";},!1);} )();
(function(){GEBI("SLX").addEventListener("mouseout",function(){ReSettler(this);},!1);} )();
(function(){GEBI("SLY").addEventListener("mouseout",function(){ReSettler(this);},!1);} )();

(function(){GEBI("DELAY").addEventListener("keyup",function(){Delay(this);},!1);} )();
(function(){GEBI("DELAY").addEventListener("click",function(){if(this.value==0)this.value="";},!1);} )();
(function(){GEBI("DELAY").addEventListener("mouseout",function(){ReSettler(this);},!1);} )();

(function(){GEBI("timing").addEventListener("keyup",function(){Timing(this);},!1);} )();
(function(){GEBI("timing").addEventListener("click",function(){if(this.value==0)this.value="";},!1);} )();
(function(){GEBI("timing").addEventListener("mouseout",function(){ReSettler(this);},!1);} )();


(function(){GEBI("SLG_info").addEventListener("click",function(){FExtension.browserPopup.openNewTab(this.href);},!1);} )();
(function(){GEBI("SLG_translation_mos_bbl").addEventListener("click",function(){ SLG_HIDE_HK("SLG_translation_mos_bbl","SLG_HIDE5");},!1); } )();
(function(){GEBI("SLG_LOC").addEventListener("change",function(){SLG_SAVE_LOC();},!1);} )();
(function(){GEBI("SLG_LNG_STATUS").addEventListener("click",function(){ SLG_LANGS(); },!1); } )();
(function(){GEBI("SLG_translation_mos_bbl2").addEventListener("click",function(){ CLOSER(); },!1); } )();
(function(){GEBI("SLG_OtherTr").addEventListener("click",function(){ SLG_SHOWHIDEPROVIDERS(); },!1); } )();
(function(){window.addEventListener("mousemove",function(){NoneColor(5);},!1);} )();
(function(){window.addEventListener("mousemove",function(){NoneColor(6);},!1);} )();
(function(){GEBI("SLG_THEME").addEventListener("change",function(){SLG_SAVE_THEME();},!1);} )();

(function(){window.addEventListener("mouseover",function(){ToolTip(event,1);},!1);} )();

(function(){GEBI("reset_all5").addEventListener("click",function(){ RESET_ALL_HK(5);},!1);} )();
(function(){GEBI("reset_all6").addEventListener("click",function(){ RESET_ALL_HK(6);},!1);} )();

(function(){window.addEventListener("mousemove",function(){
	BUILD_RESET_ICN(5);
	BUILD_RESET_ICN(6);
},!1);} )();

(function(){window.addEventListener("click",function(event){
	SLG_MSG_HANDLER(event);
},!1);} )();


//AUTOSAVE BLOCK
window.addEventListener('change',function(e){
	save_options(0);
},!1);
//AUTOSAVE BLOCK

(function(){
    window.addEventListener('load',function(){
        GEBI('SLG_translate_container').style.opacity="1";
	CONSTRUCTOR();
	var OB = GEBI('SLG_langSrc_bbl');
	if(FExtension.store.get("SLG_LNG_LIST").indexOf("auto")!=-1 || FExtension.store.get("SLG_LNG_LIST")=="all"){
		var OB1 = document.createElement('option');
		var v = document.createAttribute("value");
		v.value = "auto";
		OB1.setAttributeNode(v);
		OB1.appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetect_language_from_box')));
		OB.appendChild(OB1); 
	}
	var SLG_TMP = SLG_Languages.split(",");
	for(var J=0; J < SLG_TMP.length; J++){
	    var SLG_TMP2=SLG_TMP[J].split(":");
	    var OB2 = document.createElement('option');
	    var v = document.createAttribute("value");
	    v.value = SLG_TMP2[0];
	    OB2.setAttributeNode(v);
	    OB2.appendChild(document.createTextNode(SLG_TMP2[1]));
	    OB.appendChild(OB2);
	}

	var OB3 = GEBI('SLG_langDst_bbl');
	for(var J=0; J < SLG_TMP.length; J++){
	    var SLG_TMP2=SLG_TMP[J].split(":");
	    var OB2 = document.createElement('option');
	    v = document.createAttribute("value");
	    v.value = SLG_TMP2[0];
	    OB2.setAttributeNode(v);
	    OB2.appendChild(document.createTextNode(SLG_TMP2[1]));
	    OB3.appendChild(OB2);
	}
	INIT();
    },!1);
})();

function CONSTRUCTOR(){
	GEBI('SLG_BG_op').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSLBG_op')));
	GEBI('SLG_setLS4allTr').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSLsetLS4allTr')));
	GEBI('SLSeSo').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSeSo')));
	GEBI('SLSeTa').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSeTa')));
	GEBI('SLG_DetSoLaAu').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetSoLaAu')));
	GEBI('SLG_TR_op').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extTR_op')));
	GEBI('SLG_enable_dict').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extEnable_Dict')));
	GEBI('SLG_enable').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extEnable')));
	GEBI('SLG_Pin').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extPin_ttl')));
	GEBI('SLG_STB').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSTB')));
	GEBI('SLG_TOMS').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extTOMS')));
	GEBI('SLG_ChFS').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extChFS')));
	GEBI('SLG_FS_small').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extFS_small')));
	GEBI('SLG_FS_large').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extFS_large')));
	GEBI('SLG_TrHi').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extTrHist')));
	GEBI('SLG_BblTH').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extBblTH')));
	GEBI('SLG_DBL').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDBLclick')));
	GEBI('SLG_HotKeys').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extHotKeys')));
	GEBI('SLG_CLOSE').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extClose')));
	GEBI('SLDuring').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDuring')));
	GEBI('SLSeconds').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSeconds')));
	GEBI('SLG_il').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLOC')));
	GEBI('SLG_SaveText_bbl').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSaveText')));
	GEBI('SLG_L_BOX').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLangs')+":"));
	GEBI('SLG_LNG_STATUS').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extCustomize')));
	GEBI('SLG_LIST_TR_PR').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLIST_TR_PR')));
	GEBI('SLG_SET_TR_PR').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSET_TR_PR')));
	GEBI('SLG_SHOWHIDE_TR_PR').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSHOWHIDE_TR_PR')));
	GEBI('SLG_FORSE').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extFORSE')));

	GEBI('SLG_theme_ttl').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extTHEME')));
	GEBI('SLG_theme_1').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLIGHT')));
	GEBI('SLG_theme_2').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDARK')));

	switch(PLATFORM){
	 case "Opera" : GEBI('SLG_info').href="https://about.imtranslator.net/tutorials/presentations/google-translate-for-opera/opera-bubble-options/"; break;
	 case "Chrome": GEBI('SLG_info').href="https://about.imtranslator.net/tutorials/presentations/imtranslator-for-chrome/bubble-translator-options/"; break;
	 default      : GEBI('SLG_info').href="https://about.imtranslator.net/tutorials/presentations/";break;
	}
	PR_BUILDER("SLG_ALL_PROVIDERS_BBL");
	ACTIVATE_THEME(FExtension.store.get("THEMEmode"));
}




function INIT(){
  ACTIVATE_MENU_ELEMENT(3);
  GEBI("SLG_LOC").value=FExtension.store.get("SLG_LOCALIZATION");
  var mySLG_langSrc_bbl = FExtension.store.get("SLG_langSrc_bbl");
  var mySLG_langSrcSelect_bbl = GEBI("SLG_langSrc_bbl");
  for (var i = 0; i < mySLG_langSrcSelect_bbl.options.length; i++) {
    var mySLG_langSrcOption_bbl = mySLG_langSrcSelect_bbl.options[i];
    if (mySLG_langSrcOption_bbl.value == mySLG_langSrc_bbl) {
      mySLG_langSrcOption_bbl.selected = "true";
      break;
    }
  }

  var mySLG_langDst_bbl = FExtension.store.get("SLG_langDst_bbl");
  var mySLG_langDstSelect_bbl = GEBI("SLG_langDst_bbl");
  for (var i = 0; i < mySLG_langDstSelect_bbl.options.length; i++) {
    var mySLG_langDstOption_bbl = mySLG_langDstSelect_bbl.options[i];
    if (mySLG_langDstOption_bbl.value == mySLG_langDst_bbl) {
      mySLG_langDstOption_bbl.selected = "true";
      break;
    }
  }


  var SLG_FORSE = FExtension.store.get("FORSEbubble");
  if(SLG_FORSE=="1")  GEBI("SLG_FORSE_bbl").checked = true;
  else GEBI("SLG_FORSE_bbl").checked = false;


  var SLG_TH_2 = FExtension.store.get("SLG_TH_2");
  if(SLG_TH_2=="1")  GEBI("SLG_TH_2").checked = true;
  else GEBI("SLG_TH_2").checked = false;


  var SLG_ENABLE = FExtension.store.get("SLG_ENABLE");
  if(SLG_ENABLE=="true")  GEBI("SLG_ENABLE").checked = true;
  else GEBI("SLG_ENABLE").checked = false;

  var SLG_global_lng_bbl = FExtension.store.get("SLG_global_lng_bbl");
  if(SLG_global_lng_bbl=="true")  GEBI("SLG_global_lng_bbl").checked = true;
  else GEBI("SLG_global_lng_bbl").checked = false;

  var SLG_no_detect_bbl = FExtension.store.get("SLG_no_detect_bbl");
  if(SLG_no_detect_bbl=="true")  GEBI("SLG_no_detect_bbl").checked = true;
  else GEBI("SLG_no_detect_bbl").checked = false;

  var mySLG_Fontsize_bbl = FExtension.store.get("SLG_Fontsize_bbl");
  var mySLG_FontsizeSelect_bbl = GEBI("SLG_Fontsize_bbl");
  for (var i = 0; i < mySLG_FontsizeSelect_bbl.options.length; i++) {
    var mySLG_FontsizeOption_bbl = mySLG_FontsizeSelect_bbl.options[i];
    if (mySLG_FontsizeOption_bbl.value == mySLG_Fontsize_bbl) {
      mySLG_FontsizeOption_bbl.selected = "true";
      break;
    }
  }


  var SLG_OtherTr = FExtension.store.get("SLG_other_bbl");
  if(SLG_OtherTr=="1"){
	GEBI("SLG_OtherTr").checked = true;
  }else{
	GEBI("SLG_OtherTr").checked = false;
  }	

  var SLG_pr_bbl = FExtension.store.get("SLG_pr_bbl");
  if(SLG_pr_bbl=="1") GEBI("SLG_pr_bbl").checked = true;
  else	GEBI("SLG_pr_bbl").checked = false;
  SLG_SHOWHIDEPROVIDERS();


  var SLG_dict = FExtension.store.get("SLG_dict_bbl");
  if(SLG_dict=="true")  GEBI("SLG_dictionary").checked = true;
  else GEBI("SLG_dictionary").checked = false;

  var SLG_translation_mos_bbl = FExtension.store.get("SLG_translation_mos_bbl");
  if(SLG_translation_mos_bbl=="true")  GEBI("SLG_translation_mos_bbl").checked = true;
  else GEBI("SLG_translation_mos_bbl").checked = false;

  var SLG_translation_mos_bbl2 = FExtension.store.get("SLG_HK_bb2box");
  if(SLG_translation_mos_bbl2=="true"){
	GEBI("SLG_translation_mos_bbl2").checked = true;
	GEBI("SLG_HIDE6").style.display="none";
  }else{
	GEBI("SLG_translation_mos_bbl2").checked = false;
	GEBI("SLG_HIDE6").style.display="block";
  }	

  var SLG_pin_bbl = FExtension.store.get("SLG_pin_bbl");
  if(SLG_pin_bbl=="true")  GEBI("SLG_pin_bbl").checked = true;
  else GEBI("SLG_pin_bbl").checked = false;

  var SLG_DBL_bbl = FExtension.store.get("SLG_DBL_bbl");
  if(SLG_DBL_bbl=="true")  GEBI("SLG_DBL_bbl").checked = true;
  else GEBI("SLG_DBL_bbl").checked = false;

  var SLG_show_button_bbl = FExtension.store.get("SLG_show_button_bbl");
  if(SLG_show_button_bbl=="true")  GEBI("SLG_show_button_bbl").checked = true;
  else GEBI("SLG_show_button_bbl").checked = false;

  if(FExtension.store.get("SLG_HK_bb1")!=""){
	GEBI('SRV5').value=FExtension.store.get("SLG_HK_bb1");
  } else {
	GEBI('SRV5').placeholder="Not set";
  }


  GEBI('SRV6').value=FExtension.store.get("SLG_HK_bb2").replace("Escape","Esc");



  if(FExtension.store.get("SLG_SaveText_box_bbl")==1) GEBI('SLG_SaveText_box_bbl').checked=true;
  else GEBI('SLG_SaveText_box_bbl').checked=false;


  var SLG_TIMING = FExtension.store.get("SLG_Timing");
  GEBI("timing").value=SLG_TIMING;

  var SLG_DELAY = FExtension.store.get("SLG_Delay");
  GEBI("DELAY").value=SLG_DELAY;

  var SLG_X = FExtension.store.get("SLG_BTN_X");
  GEBI("SLX").value=SLG_X;

  var SLG_Y = FExtension.store.get("SLG_BTN_Y");
  GEBI("SLY").value=SLG_Y;

  SLG_HIDE_HK("SLG_translation_mos_bbl","SLG_HIDE5");

  var SLG_THEMEmode = FExtension.store.get("THEMEmode");
  if(SLG_THEMEmode==0)  GEBI("SLG_THEME").value = 0;
  else GEBI("SLG_THEME").value = 1;



  SLG_Enable_ImTranslator_Bubble_SYNCHRO();
  save_options(1);
}

function save_options(st) {
 setTimeout(function() {
  var SLG_select_S_bbl = GEBI("SLG_langSrc_bbl");
  var SLG_select_T_bbl = GEBI("SLG_langDst_bbl");
  var SLG_select_FS_bbl = GEBI("SLG_Fontsize_bbl");

  if(SLG_select_S_bbl.value!=SLG_select_T_bbl.value){

   if(GEBI("SLG_TH_2").checked==true) FExtension.store.set("SLG_TH_2", "1");
   else FExtension.store.set("SLG_TH_2","0");


        if(GEBI("SLG_pr_bbl").checked==true){
	   SAVE_LIST_PROVIDERS_SYN("SLG_ALL_PROVIDERS_BBL","SLG_ALL_PROVIDERS_GT");
	   FExtension.store.set("SLG_pr_bbl", "1");
	   FExtension.store.set("SLG_pr_gt", "1");
	        if(GEBI("SLG_OtherTr").checked == true) {
			FExtension.store.set("SLG_other_bbl", "1");
			FExtension.store.set("SLG_other_gt", "1");
	        }else{
			FExtension.store.set("SLG_other_bbl", "0");
			FExtension.store.set("SLG_other_gt", "0");
		}
   	} else {
   	   SAVE_LIST_PROVIDERS("SLG_ALL_PROVIDERS_BBL");
	   FExtension.store.set("SLG_pr_bbl", "0");
	   FExtension.store.set("SLG_pr_gt", "0");
	        if(GEBI("SLG_OtherTr").checked == true) {
			FExtension.store.set("SLG_other_bbl", "1");
	        }else{
			FExtension.store.set("SLG_other_bbl", "0");
		}
   	}

	var SLG_langSrc_bbl = SLG_select_S_bbl.children[SLG_select_S_bbl.selectedIndex].value;
	FExtension.store.set("SLG_langSrc_bbl", SLG_langSrc_bbl);

	var SLG_langDst_bbl = SLG_select_T_bbl.children[SLG_select_T_bbl.selectedIndex].value;
	FExtension.store.set("SLG_langDst_bbl", SLG_langDst_bbl);
	FExtension.store.set("SLG_WPT_TEMP_LANG", SLG_langDst_bbl);		

	FExtension.store.set("SLG_no_detect_bbl", GEBI("SLG_no_detect_bbl").checked);

	FExtension.store.set("SLG_ENABLE", GEBI("SLG_ENABLE").checked);
	if(FExtension.store.get("SLG_ENABLE")=="false" && FExtension.store.get("SLG_PrefTrans")==3){
		FExtension.store.set("SLG_PrefTrans", 1);
	}

	var SLG_langDst_name_bbl = SLG_select_T_bbl.children[SLG_select_T_bbl.selectedIndex].text;
	FExtension.store.set("SLG_langDst_name_bbl", SLG_langDst_name_bbl);

        FExtension.store.set("SLG_dict_bbl", GEBI("SLG_dictionary").checked);
        FExtension.store.set("SLG_DBL_bbl", GEBI("SLG_DBL_bbl").checked);
	
	if(String(GEBI('SRV5').value)!="None")	FExtension.store.set("SLG_HK_bb1", GEBI('SRV5').value);
	else FExtension.store.set("SLG_HK_bb1", "");

	FExtension.store.set("SLG_HK_bb2", GEBI('SRV6').value.replace("Esc","Escape"));


	if(GEBI('SLG_SaveText_box_bbl').checked==true) FExtension.store.set("SLG_SaveText_box_bbl",1);
	else FExtension.store.set("SLG_SaveText_box_bbl",0);

	if(GEBI('SLG_FORSE_bbl').checked==true) FExtension.store.set("FORSEbubble",1);
	else FExtension.store.set("FORSEbubble",0);

//------TIME STAMP--------------
	new Date().getTime();
	FExtension.store.set("SLG_TS", Date.now());
//==============================
	

        if(GEBI("SLG_global_lng_bbl").checked==true){

	   FExtension.store.set("SLG_global_lng", GEBI("SLG_global_lng_bbl").checked);
	   FExtension.store.set("SLG_global_lng_bbl", GEBI("SLG_global_lng_bbl").checked);
	   FExtension.store.set("SLG_global_lng_wpt", GEBI("SLG_global_lng_bbl").checked);
	   FExtension.store.set("SLG_global_lng_it", GEBI("SLG_global_lng_bbl").checked);

	   FExtension.store.set("SLG_langSrc", SLG_select_S_bbl.children[SLG_select_S_bbl.selectedIndex].value);
	   FExtension.store.set("SLG_langSrc_bbl", SLG_select_S_bbl.children[SLG_select_S_bbl.selectedIndex].value);
	   FExtension.store.set("SLG_langSrc_wpt", SLG_select_S_bbl.children[SLG_select_S_bbl.selectedIndex].value);
	   FExtension.store.set("SLG_langSrc_it", SLG_select_S_bbl.children[SLG_select_S_bbl.selectedIndex].value);

	   FExtension.store.set("SLG_langDst", SLG_select_T_bbl.children[SLG_select_T_bbl.selectedIndex].value);
	   FExtension.store.set("SLG_langDst_bbl", SLG_select_T_bbl.children[SLG_select_T_bbl.selectedIndex].value);
	   FExtension.store.set("SLG_langDst_wpt", SLG_select_T_bbl.children[SLG_select_T_bbl.selectedIndex].value);
	   FExtension.store.set("SLG_langDst_it", SLG_select_T_bbl.children[SLG_select_T_bbl.selectedIndex].value);


	   FExtension.store.set("SLG_no_detect", GEBI("SLG_no_detect_bbl").checked);
	   FExtension.store.set("SLG_no_detect_bbl", GEBI("SLG_no_detect_bbl").checked);
	   FExtension.store.set("SLG_no_detect_it", GEBI("SLG_no_detect_bbl").checked);

	   FExtension.store.set("SLG_langDst_name", SLG_langDst_name_bbl);
	   FExtension.store.set("SLG_langDst_name_wpt", SLG_langDst_name_bbl);
	   FExtension.store.set("SLG_langDst_name_bbl", SLG_langDst_name_bbl);
	   FExtension.store.set("SLG_langDst_name_it", SLG_langDst_name_bbl);



	   var IDS = document.getElementById("SLG_langDst_bbl").value;
	   SLG_SAVE_FAVORITE_LANGUAGES(IDS, "SLG_FAV_LANGS_IMT");
	   SLG_SAVE_FAVORITE_LANGUAGES(IDS, "SLG_FAV_LANGS_BBL");
	   SLG_SAVE_FAVORITE_LANGUAGES(IDS, "SLG_FAV_LANGS_IT");
  	   SLG_SAVE_FAVORITE_LANGUAGES(IDS, "SLG_FAV_LANGS_WPT");

        } else {
	   SLG_SAVE_FAVORITE_LANGUAGES(document.getElementById("SLG_langDst_bbl").value, "SLG_FAV_LANGS_BBL");
	   FExtension.store.set("SLG_langDst_name_bbl", SLG_select_T_bbl.children[SLG_select_T_bbl.selectedIndex].text);
	   
	   FExtension.store.set("SLG_global_lng", GEBI("SLG_global_lng_bbl").checked);
	   FExtension.store.set("SLG_global_lng_bbl", GEBI("SLG_global_lng_bbl").checked);
	   FExtension.store.set("SLG_global_lng_wpt", GEBI("SLG_global_lng_bbl").checked);
	   FExtension.store.set("SLG_global_lng_it", GEBI("SLG_global_lng_bbl").checked);

        }	

        RESET_TEMPS_TO_DEFAULT();


	FExtension.store.set("SLG_Flag", "FALSE");
        FExtension.bg.ImTranslatorBG.PREPARE_RCM_CONTENT();
 	FExtension.bg.ImTranslatorBG.SLG_WorkingSet();
        FExtension.bg.FExtension.browser.refreshSettings();
	if(GEBI("SLG_ENABLE").checked==false) FExtension.bg.ImTranslatorBG.SLG_callbackRequestToChangeRightClickMenu(0);
	else FExtension.bg.ImTranslatorBG.SLG_callbackRequestToChangeRightClickMenu(1);




   var SLG_Fontsize_bbl = SLG_select_FS_bbl.children[SLG_select_FS_bbl.selectedIndex].value;
   FExtension.store.set("SLG_Fontsize_bbl", SLG_Fontsize_bbl);
   FExtension.store.set("SLG_Fontsize_bbl2", "");


   var SLG_translation_mos_bbl = GEBI("SLG_translation_mos_bbl").checked;
   FExtension.store.set("SLG_translation_mos_bbl", SLG_translation_mos_bbl);

   var SLG_translation_mos_bbl2 = GEBI("SLG_translation_mos_bbl2").checked;
   FExtension.store.set("SLG_HK_bb2box", SLG_translation_mos_bbl2);



   var SLG_pin_bbl = GEBI("SLG_pin_bbl").checked;
   FExtension.store.set("SLG_pin_bbl", SLG_pin_bbl);
   FExtension.store.set("SLG_pin_bbl2",FExtension.store.get("SLG_pin_bbl"));

   var SLG_show_button_bbl = GEBI("SLG_show_button_bbl").checked;
   FExtension.store.set("SLG_show_button_bbl", SLG_show_button_bbl);

   if(GEBI("DELAY").value!="-" && GEBI("DELAY").value!="") FExtension.store.set("SLG_Delay",GEBI("DELAY").value);
   else {
	FExtension.store.set("SLG_Delay",0);
	GEBI("DELAY").value=0;
   }	

   if(GEBI("timing").value!="-" && GEBI("timing").value!="") FExtension.store.set("SLG_Timing",GEBI("timing").value);
   else {
	FExtension.store.set("SLG_Timing",0);
	GEBI("timing").value=0;
   }	

   if(GEBI("SLX").value!="-" && GEBI("SLX").value!="") FExtension.store.set("SLG_BTN_X",GEBI("SLX").value);
   else {
	FExtension.store.set("SLG_BTN_X",0);
	GEBI("SLX").value=0;
   }	
   if(GEBI("SLY").value!="-" && GEBI("SLY").value!="") FExtension.store.set("SLG_BTN_Y",GEBI("SLY").value);
   else {
	FExtension.store.set("SLG_BTN_Y",0);
	GEBI("SLY").value=0;
   }	

   ACTIVATE_THEME(FExtension.store.get("THEMEmode"));
   if(GEBI('autohotkeys')){
	  var frame = GEBI('autohotkeys');
	  if(frame)	frame.parentNode.removeChild(frame);
   }

  }else alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extS_T_L_diff'));
 }, 100);
}

function GEBI(id){ return document.getElementById(id);}






function SLG_Enable_ImTranslator_Bubble_SYNCHRO(){
    if(GEBI("SLG_ENABLE").checked == false) GEBI('SLG_ENJECT').style.color='red';
    else GEBI('SLG_ENJECT').style.color='black';
}

function Timing(ob){
  if(ob.value!=""){
	 ob.value = ob.value.replace(/[^0-9]+/g, '');
	 if(ob.value[2]=="-") ob.value = ob.value[0]+ob.value[1];
	 for (var i=0;i<ob.value.length;i++){
	   var temp=ob.value.substring(i,i+1);
	   if(ob.value>99) ob.value=ob.value[0]+ob.value[1];
	 }
	 ob.value = ob.value*1;
  }
}

function Delay(ob){
  if(ob.value!=""){
 	ob.value = ob.value.replace(/[^0-9]+/g, '');
	for (var i=0;i<ob.value.length;i++){
	   var temp=ob.value.substring(i,i+1);
	   if(ob.value>9) ob.value=ob.value[0];
	}
	ob.value = ob.value*1;
  }	
}

function Coord(ob){
  if(ob.value!=""){
	 ob.value = ob.value.replace(/[^0-9-]+/g, '');
	 if(ob.value[2]=="-") ob.value = ob.value[0]+ob.value[1];
	 for (var i=0;i<ob.value.length;i++){
	      var temp=ob.value.substring(i,i+1);
	      if(ob.value>99){
        	ob.value=ob.value[0]+ob.value[1];
	      }
	 }
	 if(ob.value.indexOf("-")==-1) ob.value=ob.value*1;
	 else {
	    if(ob.value[0]!="-") ob.value = ob.value.replace("-","");
	 }
	 if(ob.value.length==1 && ob.value[0]=="-") ob.value = "-";	
 	 ob.value = ob.value.replace(/--/gi, '-');

	ob.value = ob.value.replace("00","0")
	ob.value = ob.value.replace("-0","0")
  }
}

function ReSettler(ob){
  if(ob.value=="" || ob.value=="-") ob.value=0;
}



function ACTIVATE_MENU_ELEMENT(st){
  var win = top.frames['menu'];
  var li = win.document.getElementsByTagName("li");
  for(var i=1; i<=li.length; i++){
        if(st==i) win.document.getElementById('SLG_options_menu'+i).className='SLG_options-menu-on';
        else win.document.getElementById('SLG_options_menu'+i).className='SLG_options-menu-off';
  }
}

function SLG_getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i=0; i<ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1);
        if (c.indexOf(name) == 0) return c.substring(name.length,c.length);
    }
    return "";
}

function CLOSER(){
   if(GEBI("SLG_translation_mos_bbl2").checked == false){
	GEBI("SLG_HIDE6").style.display="block";
   }else{
	GEBI("SLG_HIDE6").style.display="none";
   }
}



function SLG_SAVE_LOC(){
  FExtension.store.set("SLG_LOCALIZATION", GEBI("SLG_LOC").value);
  CONSTRUCTOR();
  FExtension.bg.ImTranslatorBG.SLG_WorkingSet();
  parent.frames["menu"].location.reload();
  location.reload();
}

function SLG_SAVE_THEME(){
  FExtension.store.set("THEMEmode", GEBI("SLG_THEME").value);
  FExtension.bg.ImTranslatorBG.SLG_WorkingSet();
  location.reload();
}

function ACTIVATE_THEME(st){
 	if(st==1){
		var bg="#191919";
		var clr="#BF7D44";
		var clr_deact="#BDBDBD";
		GEBI("SLG_translate_container").style.filter=SLG_DARK;
		var LBLS = document.getElementsByClassName("SLG_BG_op");
		for(var i=0; i<LBLS.length; i++) LBLS[i].style.color=clr;
		var A = document.getElementsByTagName("a");
		for(var i=0; i<A.length; i++) A[i].style.color=clr;
		var E = document.getElementsByClassName("SLMSG");
		for(var j=0; j<E.length; j++) E[j].style.filter=SLG_DARK;


		setTimeout(function() {
			var SLG_lngSrc_opt = GEBI("SLG_langSrc_bbl").getElementsByTagName("option");
			for(var j=0; j<SLG_lngSrc_opt.length; j++) SLG_lngSrc_opt[j].setAttribute("style", "background:"+bg+" !important;color:#fff;");
			var SLG_lngSrc_opt = GEBI("SLG_langDst_bbl").getElementsByTagName("option");
			for(var j=0; j<SLG_lngSrc_opt.length; j++) SLG_lngSrc_opt[j].setAttribute("style", "background:"+bg+" !important;color:#fff;");
			var SLG_fnt_opt = GEBI("SLG_Fontsize_bbl").getElementsByTagName("option");
			for(var j=0; j<SLG_fnt_opt.length; j++) SLG_fnt_opt[j].setAttribute("style", "background:"+bg+" !important;color:#fff;");

		}, 1000);

		if(GEBI("item-0")) GEBI("item-0").style.borderRight="10px solid "+clr;	
		if(GEBI("item-1")) GEBI("item-1").style.borderRight="10px solid "+clr;
		if(GEBI("item-2")) GEBI("item-2").style.borderRight="10px solid "+clr;
		if(GEBI("item-3")) GEBI("item-3").style.borderRight="10px solid "+clr;
		
		GEBI("SLG_AUTOKEYS").style.filter=SLG_DARK;	
	}
}

function ToolTip(e,st){
 if(e.target.className=="info"){
	var div = GEBI(e.target.id);
	var divOffset = offset(div);
	console.log(divOffset.left, divOffset.top);
	
 }	
}	

function offset(el) {
    var rect = el.getBoundingClientRect(),
    scrollLeft = window.pageXOffset || document.documentElement.scrollLeft,
    scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    return { top: rect.top + scrollTop, left: rect.left + scrollLeft }
}

function SLG_SAVE_FAVORITE_LANGUAGES(ln, TR){
	var OUT = "";
	var OUT2 = "";
	var SLG_FAV_LANGS = FExtension.store.get(TR);
	var SLG_FAV_MAX = FExtension.store.get("SLG_FAV_MAX");
	if(SLG_FAV_LANGS.indexOf(ln)!=-1){
		SLG_FAV_LANGS = SLG_FAV_LANGS.replace(ln+",",""); 
		SLG_FAV_LANGS = SLG_FAV_LANGS.replace(ln,"");
	}
	OUT = ln + ",";	
	var ARR = SLG_FAV_LANGS.split(",");
	for (var i = 0; i < ARR.length; i++){
	 	OUT = OUT + ARR[i]+",";
	}
	if(OUT.slice(-1)==",") 	OUT = OUT.slice(0, OUT.length - 1);
	var TMP = OUT.split(",");
	if(TMP.length > SLG_FAV_MAX) {
		for (var j = 0; j < TMP.length-1; j++){
		 	OUT2 = OUT2 + TMP[j]+",";
		}		
		OUT = OUT2 
	}
	if(OUT.slice(-1)==",") 	OUT = OUT.slice(0, OUT.length - 1);
	FExtension.store.set(TR, OUT);
}

function BUILD_RESET_ICN(ob){
	GEBI("reset_all"+ob).title="Reset to default";
}

function SLG_DEL_AUTO(ob){
	GEBI("SRV"+ob).value = "Auto Translate"; 
	GEBI("SRV"+ob).placeholder = "Auto Translate"; 
        GEBI("MSG"+ob).style.visibility="hidden";
	save_options(0);
}                          


function RESET_ALL_HK(id){
        var st = "";
        switch (id){
         case 5: st = 'SLG_HK_bb1'; break;
         case 6: st = 'SLG_HK_bb2'; break;
	}
	for(var i=0; i<PACK_PARAMS.length; i++){
		var tmp = PACK_PARAMS[i].split(";");
		var curDBname = tmp[0];
		var curDBparam = tmp[1];
		var DBparam = FExtension.store.get(curDBname);
		if(curDBname == st){
			FExtension.store.set(curDBname, curDBparam);			
			GEBI("MSG"+id).style.visibility="hidden";
		}
	}
	var newParam = FExtension.store.get(st);
	newParam = newParam.replace("Escape","Esc");
	GEBI("SRV"+id).value=newParam;
}

