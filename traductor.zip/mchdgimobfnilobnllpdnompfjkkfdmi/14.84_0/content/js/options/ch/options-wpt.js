'use strict';
var SLG_DARK="invert(95%)";

var SLG_Languages = CUSTOM_LANGS(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLanguages'));

(function(){GEBI("SLG_info").addEventListener("click",function(){FExtension.browserPopup.openNewTab(this.href);},!1);} )();

(function(){GEBI("SRV6").addEventListener("click",function(){SLG_ACTIVE = GEBI("SRV6"); SLG_TMP=SLG_ACTIVE.value; SLG_ACTIVE.focus();SLG_MSG_HANDLER(event);},!1); } )();
(function(){GEBI("SRV6").addEventListener("mouseout",function(){NoneColor(6);},!1); } )();
(function(){GEBI("SRV6").addEventListener("paste",function(){ PREVENT_PASTE(event); },!1);} )();

(function(){GEBI("SRV7").addEventListener("click",function(){SLG_ACTIVE = GEBI("SRV7"); SLG_TMP=SLG_ACTIVE.value; SLG_ACTIVE.focus();SLG_MSG_HANDLER(event);},!1); } )();
(function(){GEBI("SRV7").addEventListener("mouseout",function(){NoneColor(7);},!1); } )();
(function(){GEBI("SRV7").addEventListener("paste",function(){ PREVENT_PASTE(event); },!1);} )();

(function(){GEBI("SRV12").addEventListener("click",function(){SLG_ACTIVE = GEBI("SRV12"); SLG_TMP=SLG_ACTIVE.value; SLG_ACTIVE.focus();SLG_MSG_HANDLER(event);},!1); } )();
(function(){GEBI("SRV12").addEventListener("mouseout",function(){NoneColor(12);},!1); } )();
(function(){GEBI("SRV12").addEventListener("paste",function(){ PREVENT_PASTE(event); },!1);} )();

(function(){GEBI("SRV13").addEventListener("click",function(){SLG_ACTIVE = GEBI("SRV13"); SLG_TMP=SLG_ACTIVE.value; SLG_ACTIVE.focus();SLG_MSG_HANDLER(event);},!1); } )();
(function(){GEBI("SRV13").addEventListener("mouseout",function(){NoneColor(13);},!1); } )();
(function(){GEBI("SRV13").addEventListener("paste",function(){ PREVENT_PASTE(event); },!1);} )();

(function(){GEBI("SLG_HK6").addEventListener("click",function(){ SLG_HIDE_HK("SLG_HK6","SLG_HIDE6");},!1); } )();
(function(){GEBI("SLG_HK7").addEventListener("click",function(){ SLG_HIDE_HK("SLG_HK7","SLG_HIDE7");},!1); } )();
(function(){GEBI("SLG_HK12").addEventListener("click",function(){ SLG_HIDE_HK("SLG_HK12","SLG_HIDE12");},!1); } )();
(function(){GEBI("SLG_HK13").addEventListener("click",function(){ SLG_HIDE_HK("SLG_HK13","SLG_HIDE13");},!1); } )();

(function(){GEBI("SLG_LOC").addEventListener("change",function(){SLG_SAVE_LOC();},!1);} )();
(function(){GEBI("SLG_LNG_STATUS").addEventListener("click",function(){ SLG_LANGS(); },!1); } )();

(function(){GEBI("SLG_wptReset1").addEventListener("click",function(){ SLG_RESET(1); },!1); } )();
(function(){GEBI("SLG_wptReset2").addEventListener("click",function(){ SLG_RESET(2); },!1); } )();

(function(){GEBI("SLG_THEME").addEventListener("change",function(){SLG_SAVE_THEME();},!1);} )();

(function(){GEBI("reset_all6").addEventListener("click",function(){ RESET_ALL_HK(6);},!1);} )();
(function(){GEBI("reset_all7").addEventListener("click",function(){ RESET_ALL_HK(7);},!1);} )();
(function(){GEBI("reset_all12").addEventListener("click",function(){ RESET_ALL_HK(12);},!1);} )();
(function(){GEBI("reset_all13").addEventListener("click",function(){ RESET_ALL_HK(13);},!1);} )();

(function(){window.addEventListener("mousemove",function(){
	BUILD_RESET_ICN(6);
	BUILD_RESET_ICN(7);
	BUILD_RESET_ICN(12);
	BUILD_RESET_ICN(13);
},!1);} )();

(function(){window.addEventListener("click",function(event){
	SLG_MSG_HANDLER(event);
},!1);} )();


//AUTOSAVE BLOCK
window.addEventListener('change',function(e){
	save_options(0);
},!1);
//AUTOSAVE BLOCK


(function(){
    window.addEventListener('load',function(){
	GEBI('SLG_translate_container').style.opacity="1";
	CONSTRUCTOR();
	var OB = GEBI('SLG_langSrc_wpt');
	if(FExtension.store.get("SLG_LNG_LIST").indexOf("auto")!=-1 || FExtension.store.get("SLG_LNG_LIST")=="all"){
		var OB1 = document.createElement('option');
		var v = document.createAttribute("value");
		v.value = "auto";
		OB1.setAttributeNode(v);
		OB1.appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDetect_language_from_box')));
		OB.appendChild(OB1); 
	}
	var SLG_TMP = SLG_Languages.split(",");
	for(var J=0; J < SLG_TMP.length; J++){
	    var SLG_TMP2=SLG_TMP[J].split(":");
	    var OB2 = document.createElement('option');
	    var v = document.createAttribute("value");
	    v.value = SLG_TMP2[0];
	    OB2.setAttributeNode(v);
	    //OB2.appendChild(document.createTextNode(SLG_TMP2[1].replace("&#160;"," ")));
	    OB2.appendChild(document.createTextNode(SLG_TMP2[1]));
	    OB.appendChild(OB2);
	}

	var OB3 = GEBI('SLG_langDst_wpt');
	for(var J=0; J < SLG_TMP.length; J++){
	    var SLG_TMP2=SLG_TMP[J].split(":");
	    var OB2 = document.createElement('option');
	    v = document.createAttribute("value");
	    v.value = SLG_TMP2[0];
	    OB2.setAttributeNode(v);
	    //OB2.appendChild(document.createTextNode(SLG_TMP2[1].replace("&#160;"," ")));
	    OB2.appendChild(document.createTextNode(SLG_TMP2[1]));
	    OB3.appendChild(OB2);
	}
	INIT();
    },!1);
})();
function CONSTRUCTOR(){
	GEBI('SLG_BG_op').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSLBG_op')));
	GEBI('SLG_setLS4allTr').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSLsetLS4allTr')));
	GEBI('SLSeSo').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSeSo')));
	GEBI('SLSeTa').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSeTa')));
	GEBI('SLG_TrHi').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extTrHist')));
	GEBI('SLG_WpTH').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extWpTH')));
	GEBI('SLG_sc').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extHotKeys')));
	GEBI('SLG_il').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLOC')));
	GEBI('SLG_L_BOX').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLangs')+":"));
	GEBI('SLG_LNG_STATUS').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extCustomize')));
	GEBI('SLG_wptttl').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extADV')));
	GEBI('SLG_wptDAlways').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extwptDAlways')));
	GEBI('SLG_wptDTb').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extwptDTb')));
	GEBI('SLG_wptDOrTip').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extwptDOrTip')));
	GEBI('SLG_wptDReset').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extwptDReset')));
	GEBI('SLG_wptLReset').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extwptLReset')));
	GEBI('SLG_wptReset1').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extwptReset')));
	GEBI('SLG_wptReset2').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extwptReset')));
	GEBI('SLG_SH_OR').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extCMsot')));
	GEBI('SLG_CL_TR').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extCMct')));
	GEBI('SLG_theme_ttl').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extTHEME')));
	GEBI('SLG_theme_1').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLIGHT')));
	GEBI('SLG_theme_2').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDARK')));
	GEBI('SLG_WPTflip').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extSwitch_languages_ttl')));
	GEBI('SLG_TR_op').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extTR_op')));
	switch(PLATFORM){
	 case "Opera" : GEBI('SLG_info').href="https://about.imtranslator.net/tutorials/presentations/google-translate-for-opera/opera-webtranslation-options/"; break;
	 case "Chrome": GEBI('SLG_info').href="https://about.imtranslator.net/tutorials/presentations/imtranslator-for-chrome/webpage-translation-options/"; break;
	 default      : GEBI('SLG_info').href="https://about.imtranslator.net/tutorials/presentations/";break;
	}
	ACTIVATE_THEME(FExtension.store.get("THEMEmode"));
}



function INIT(){
  ACTIVATE_MENU_ELEMENT(4);
  GEBI("SLG_LOC").value=FExtension.store.get("SLG_LOCALIZATION");
	var mySLG_langSrc_wpt = FExtension.store.get("SLG_langSrc_wpt");
	var mySLG_langSrcSelect_wpt = GEBI("SLG_langSrc_wpt");
	for (var i = 0; i < mySLG_langSrcSelect_wpt.options.length; i++) {
		var mySLG_langSrcOption_wpt = mySLG_langSrcSelect_wpt.options[i];
		if (mySLG_langSrcOption_wpt.value == mySLG_langSrc_wpt) {
			mySLG_langSrcOption_wpt.selected = "true";
			break;
		}
	}

	var mySLG_langDst_wpt = FExtension.store.get("SLG_langDst_wpt");
	var mySLG_langDstSelect_wpt = GEBI("SLG_langDst_wpt");
	for (var i = 0; i < mySLG_langDstSelect_wpt.options.length; i++) {
		var mySLG_langDstOption_wpt = mySLG_langDstSelect_wpt.options[i];
		if (mySLG_langDstOption_wpt.value == mySLG_langDst_wpt) {
			mySLG_langDstOption_wpt.selected = "true";
			break;
		}
	}

	var SLG_TH_3 = FExtension.store.get("SLG_TH_3");
	if(SLG_TH_3=="1")  GEBI("SLG_TH_3").checked = true;
	else GEBI("SLG_TH_3").checked = false;

	var SLG_global_lng_wpt = FExtension.store.get("SLG_global_lng_wpt");
	if(SLG_global_lng_wpt=="true")  GEBI("SLG_global_lng_wpt").checked = true;
	else GEBI("SLG_global_lng_wpt").checked = false;


        var SLG_THEMEmode = FExtension.store.get("THEMEmode");
	if(SLG_THEMEmode==0)  GEBI("SLG_THEME").value = 0;
	else GEBI("SLG_THEME").value = 1;



  var tempTIP = FExtension.store.get("SLG_wptGlobTip");
  if(tempTIP=="1") GEBI("SLG_SOOOM").checked=true;
  else GEBI("SLG_SOOOM").checked=false;

  var tempTB = FExtension.store.get("SLG_wptGlobTb");
  if(tempTB=="1") GEBI("SLG_Toolbar").checked=true;
  else GEBI("SLG_Toolbar").checked=false;




  var tempHK6 = FExtension.store.get("SLG_HK_wptbox1");
  if(tempHK6=="true") GEBI("SLG_HK6").checked=true;
  else GEBI("SLG_HK6").checked=false;
  
  GEBI("SRV6").value=FExtension.store.get("SLG_HK_wpt1");

  var tempHK7 = FExtension.store.get("SLG_HK_wptbox2");
  if(tempHK7=="true") GEBI("SLG_HK7").checked=true;
  else 	 GEBI("SLG_HK7").checked=false;

  GEBI("SRV7").value=FExtension.store.get("SLG_HK_wpt2");

  var tempHK12 = FExtension.store.get("SLG_HK_SObox_wpt");
  if(tempHK12=="true") GEBI("SLG_HK12").checked=true;
  else 	 GEBI("SLG_HK12").checked=false;

  GEBI("SRV12").value=FExtension.store.get("SLG_HK_SO_wpt");

  var tempHK13 = FExtension.store.get("SLG_HK_CTbox_wpt");
  if(tempHK13=="true") GEBI("SLG_HK13").checked=true;
  else 	 GEBI("SLG_HK13").checked=false;

  GEBI("SRV13").value=FExtension.store.get("SLG_HK_CT_wpt").replace("Escape", "Esc");

  var WPTflip = FExtension.store.get("WPTflip");
  if(WPTflip=="1")  GEBI("WPTflip").checked = true;
  else GEBI("WPTflip").checked = false;


  SLG_HIDE_HK("SLG_HK6","SLG_HIDE6");
  SLG_HIDE_HK("SLG_HK7","SLG_HIDE7");
  SLG_HIDE_HK("SLG_HK12","SLG_HIDE12");
  SLG_HIDE_HK("SLG_HK13","SLG_HIDE13");

  save_options(1);
}

function save_options(st) {
 setTimeout(function() {
	var SLG_select_S_wpt = GEBI("SLG_langSrc_wpt");
	var SLG_select_T_wpt = GEBI("SLG_langDst_wpt");

	if(SLG_select_S_wpt.value!=SLG_select_T_wpt.value){

		if(GEBI("SLG_TH_3").checked==true) FExtension.store.set("SLG_TH_3","1");
		else FExtension.store.set("SLG_TH_3", "0");

		if(GEBI("SLG_global_lng_wpt").checked==true){
			FExtension.store.set("SLG_global_lng", GEBI("SLG_global_lng_wpt").checked);
			FExtension.store.set("SLG_global_lng_bbl", GEBI("SLG_global_lng_wpt").checked);
			FExtension.store.set("SLG_global_lng_wpt", GEBI("SLG_global_lng_wpt").checked);
			FExtension.store.set("SLG_global_lng_it", GEBI("SLG_global_lng_wpt").checked);

			FExtension.store.set("SLG_langSrc", SLG_select_S_wpt.children[SLG_select_S_wpt.selectedIndex].value);
			FExtension.store.set("SLG_langSrc2", SLG_select_S_wpt.children[SLG_select_S_wpt.selectedIndex].value);
			FExtension.store.set("SLG_langSrc_bbl", SLG_select_S_wpt.children[SLG_select_S_wpt.selectedIndex].value);
			FExtension.store.set("SLG_langSrc_wpt", SLG_select_S_wpt.children[SLG_select_S_wpt.selectedIndex].value);
			FExtension.store.set("SLG_langSrc_it", SLG_select_S_wpt.children[SLG_select_S_wpt.selectedIndex].value);

			FExtension.store.set("SLG_langDst", SLG_select_T_wpt.children[SLG_select_T_wpt.selectedIndex].value);
			FExtension.store.set("SLG_langDst2", SLG_select_T_wpt.children[SLG_select_T_wpt.selectedIndex].value);
			FExtension.store.set("SLG_langDst_bbl", SLG_select_T_wpt.children[SLG_select_T_wpt.selectedIndex].value);
			FExtension.store.set("SLG_langDst_wpt", SLG_select_T_wpt.children[SLG_select_T_wpt.selectedIndex].value);
			FExtension.store.set("SLG_langDst_it", SLG_select_T_wpt.children[SLG_select_T_wpt.selectedIndex].value);

			var IDS = document.getElementById("SLG_langDst_wpt").value;
	   		SLG_SAVE_FAVORITE_LANGUAGES(IDS, "SLG_FAV_LANGS_IMT");
	   		SLG_SAVE_FAVORITE_LANGUAGES(IDS, "SLG_FAV_LANGS_BBL");
	   		SLG_SAVE_FAVORITE_LANGUAGES(IDS, "SLG_FAV_LANGS_IT");
	   		SLG_SAVE_FAVORITE_LANGUAGES(IDS, "SLG_FAV_LANGS_WPT");

		} else {
			SLG_SAVE_FAVORITE_LANGUAGES(document.getElementById("SLG_langDst_wpt").value, "SLG_FAV_LANGS_WPT");
			FExtension.store.set("SLG_langDst_name_wpt", SLG_select_T_wpt.children[SLG_select_T_wpt.selectedIndex].text);
			FExtension.store.set("SLG_global_lng", GEBI("SLG_global_lng_wpt").checked);
			FExtension.store.set("SLG_global_lng_bbl", GEBI("SLG_global_lng_wpt").checked);
			FExtension.store.set("SLG_global_lng_wpt", GEBI("SLG_global_lng_wpt").checked);
			FExtension.store.set("SLG_global_lng_it", GEBI("SLG_global_lng_wpt").checked);
		}	

		RESET_TEMPS_TO_DEFAULT();

		var SLG_langSrc_wpt = SLG_select_S_wpt.children[SLG_select_S_wpt.selectedIndex].value;
		FExtension.store.set("SLG_langSrc_wpt", SLG_langSrc_wpt);
		
		var SLG_langDst_wpt = SLG_select_T_wpt.children[SLG_select_T_wpt.selectedIndex].value;
		FExtension.store.set("SLG_langDst_wpt", SLG_langDst_wpt);
		FExtension.store.set("SLG_WPT_TEMP_LANG", SLG_langDst_wpt);


		
		var SLG_langDst_name_wpt = SLG_select_T_wpt.children[SLG_select_T_wpt.selectedIndex].text;
		FExtension.store.set("SLG_langDst_name_wpt", SLG_langDst_name_wpt);

                FExtension.store.set("SLG_HK_wptbox1", GEBI("SLG_HK6").checked);
                FExtension.store.set("SLG_HK_wptbox2", GEBI("SLG_HK7").checked);
                FExtension.store.set("SLG_HK_SObox_wpt", GEBI("SLG_HK12").checked);
                FExtension.store.set("SLG_HK_CTbox_wpt", GEBI("SLG_HK13").checked);

                FExtension.store.set("SLG_HK_wpt1", GEBI("SRV6").value);
                FExtension.store.set("SLG_HK_wpt2", GEBI("SRV7").value);
                FExtension.store.set("SLG_HK_SO_wpt", GEBI("SRV12").value);
                FExtension.store.set("SLG_HK_CT_wpt", GEBI("SRV13").value);

                if(GEBI("SLG_SOOOM").checked==true) FExtension.store.set("SLG_wptGlobTip", "1");
                else FExtension.store.set("SLG_wptGlobTip", "0");

                if(GEBI("SLG_Toolbar").checked==true) {
			FExtension.store.set("SLG_wptGlobTb", "1");
                }else{
			FExtension.store.set("SLG_wptGlobTb", "0");
		}

		if(GEBI("WPTflip").checked==true)  FExtension.store.set("WPTflip",1);
		else FExtension.store.set("WPTflip",0);

//------TIME STAMP--------------
	new Date().getTime();
	FExtension.store.set("SLG_TS", Date.now());
//==============================

		if(GEBI("SLG_global_lng_wpt").checked==true){
			FExtension.store.set("SLG_langDst_name", SLG_langDst_name_wpt);
			FExtension.store.set("SLG_langDst_name_bbl", SLG_langDst_name_wpt);
			FExtension.store.set("SLG_langDst_name_wpt", SLG_langDst_name_wpt);
			FExtension.store.set("SLG_langDst_name_it", SLG_langDst_name_wpt);
		}

//		FExtension.store.set("SLG_Flag", "FALSE");
                FExtension.bg.ImTranslatorBG.PREPARE_RCM_CONTENT();
	 	FExtension.bg.ImTranslatorBG.SLG_WorkingSet();
	        FExtension.bg.FExtension.browser.refreshSettings();

		if(GEBI('autohotkeys')){
		  var frame = GEBI('autohotkeys');
		}

	}else alert(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extS_T_L_diff'));
 }, 100);
}

function GEBI(id){ return document.getElementById(id);}





function ACTIVATE_MENU_ELEMENT(st){
  var win = top.frames['menu'];
  var li = win.document.getElementsByTagName("li");
  for(var i=1; i<=li.length; i++){
        if(st==i) win.document.getElementById('SLG_options_menu'+i).className='SLG_options-menu-on';
        else win.document.getElementById('SLG_options_menu'+i).className='SLG_options-menu-off';
  }
}

function SLG_SAVE_LOC(){
  FExtension.store.set("SLG_LOCALIZATION", GEBI("SLG_LOC").value);
  CONSTRUCTOR();
  FExtension.bg.ImTranslatorBG.SLG_WorkingSet();
  parent.frames["menu"].location.reload();
  location.reload();
}

function SLG_RESET(st){
  GEBI("SLG_reset"+st).style.display="block";
  if(st==1) FExtension.store.set("SLG_wptDHist","");
  else FExtension.store.set("SLG_wptLHist","");
  setTimeout(function() {
	GEBI("SLG_reset"+st).style.display="none";
  }, 1000);
}

function SLG_SAVE_THEME(){
  FExtension.store.set("THEMEmode", GEBI("SLG_THEME").value);
  FExtension.bg.ImTranslatorBG.SLG_WorkingSet();
  location.reload();
}

function ACTIVATE_THEME(st){
 	if(st==1){
		var bg="#191919";
		var clr="#BF7D44";
		var clr_deact="#BDBDBD";
		GEBI("SLG_translate_container").style.filter=SLG_DARK;
		GEBI("SLG_wptReset1").style.filter=SLG_DARK;
		GEBI("SLG_wptReset2").style.filter=SLG_DARK;
		var LBLS = document.getElementsByClassName("SLG_BG_op");
		for(var i=0; i<LBLS.length; i++) LBLS[i].style.color=clr;
		var A = document.getElementsByTagName("a");
		for(var i=0; i<A.length; i++) A[i].style.color=clr;

		setTimeout(function() {
			var SLG_lngSrc_opt = GEBI("SLG_langSrc_wpt").getElementsByTagName("option");
			for(var j=0; j<SLG_lngSrc_opt.length; j++) SLG_lngSrc_opt[j].setAttribute("style", "background:"+bg+" !important;color:#fff;");
			var SLG_lngSrc_opt = GEBI("SLG_langDst_wpt").getElementsByTagName("option");
			for(var j=0; j<SLG_lngSrc_opt.length; j++) SLG_lngSrc_opt[j].setAttribute("style", "background:"+bg+" !important;color:#fff;");
		}, 1000);

		GEBI("SLG_AUTOKEYS").style.filter=SLG_DARK;	
	}
}

function SLG_SAVE_FAVORITE_LANGUAGES(ln, TR){
	var OUT = "";
	var OUT2 = "";
	var SLG_FAV_LANGS = FExtension.store.get(TR);
	var SLG_FAV_MAX = FExtension.store.get("SLG_FAV_MAX");
	if(SLG_FAV_LANGS.indexOf(ln)!=-1){
		SLG_FAV_LANGS = SLG_FAV_LANGS.replace(ln+",",""); 
		SLG_FAV_LANGS = SLG_FAV_LANGS.replace(ln,"");
	}
	OUT = ln + ",";	
	var ARR = SLG_FAV_LANGS.split(",");
	for (var i = 0; i < ARR.length; i++){
	 	OUT = OUT + ARR[i]+",";
	}
	if(OUT.slice(-1)==",") 	OUT = OUT.slice(0, OUT.length - 1);
	var TMP = OUT.split(",");
	if(TMP.length > SLG_FAV_MAX) {
		for (var j = 0; j < TMP.length-1; j++){
		 	OUT2 = OUT2 + TMP[j]+",";
		}		
		OUT = OUT2 
	}
	if(OUT.slice(-1)==",") 	OUT = OUT.slice(0, OUT.length - 1);
	FExtension.store.set(TR, OUT);
}


function BUILD_RESET_ICN(ob){
	GEBI("reset_all"+ob).title="Reset to default";
}

function SLG_DEL_AUTO(ob){
	GEBI("SRV"+ob).value = "Auto Translate"; 
	GEBI("SRV"+ob).placeholder = "Auto Translate"; 
        GEBI("MSG"+ob).style.visibility="hidden";
	save_options(0);
}                          


function RESET_ALL_HK(id){
        var st = "";
        switch (id){
         case 6: st = 'SLG_HK_wpt1'; break;
         case 7: st = 'SLG_HK_wpt2'; break;
         case 12: st = 'SLG_HK_SO_wpt'; break;
         case 13: st = 'SLG_HK_CT_wpt'; break;
	}
	for(var i=0; i<PACK_PARAMS.length; i++){
		var tmp = PACK_PARAMS[i].split(";");
		var curDBname = tmp[0];
		var curDBparam = tmp[1];
		var DBparam = FExtension.store.get(curDBname);
		if(curDBname == st){
			FExtension.store.set(curDBname, curDBparam);			
			GEBI("MSG"+id).style.visibility="hidden";
		}
	}
	var newParam = FExtension.store.get(st);
	newParam = newParam.replace("Escape","Esc");
	GEBI("SRV"+id).value=newParam;

}

