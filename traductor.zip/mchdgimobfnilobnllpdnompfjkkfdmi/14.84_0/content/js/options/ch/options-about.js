﻿'use strict';
var SLG_DARK="invert(95%)";

function GEBI(id){ return document.getElementById(id);}
(function(){GEBI("SLG_info").addEventListener("click",function(){FExtension.browserPopup.openNewTab(this.href);},!1);} )();
(function(){GEBI("SLG_LOC").addEventListener("change",function(){SLG_SAVE_LOC();},!1);} )();
(function(){GEBI("SLG_THEME").addEventListener("change",function(){SLG_SAVE_THEME();},!1);} )();

(function(){INIT();})();


function INIT(){
  ACTIVATE_MENU_ELEMENT(8);
  GEBI("SLG_LOC").value=FExtension.store.get("SLG_LOCALIZATION");
  CONSTRUCTOR();
  var SLG_THEMEmode = FExtension.store.get("THEMEmode");
  if(SLG_THEMEmode==0)  GEBI("SLG_THEME").value = 0;
  else GEBI("SLG_THEME").value = 1;
  CONTRIBUTIN();
}

function CONTRIBUTIN(){
  GEBI("d0").href="https://imtranslator.net"+_CGI+"&a=0";
  GEBI("d1").href="https://imtranslator.net"+_CGI+"&a=5";
  GEBI("d2").href="https://imtranslator.net"+_CGI+"&a=10";
  GEBI("d3").href="https://imtranslator.net"+_CGI+"&a=20";
  GEBI("d4").href="https://imtranslator.net"+_CGI+"&a=0";
}

function ACTIVATE_MENU_ELEMENT(st){
  var win = top.frames['menu'];
  var li = win.document.getElementsByTagName("li");
  for(var i=1; i<=li.length; i++){
        if(st==i) win.document.getElementById('SLG_options_menu'+i).className='SLG_options-menu-on';
        else win.document.getElementById('SLG_options_menu'+i).className='SLG_options-menu-off';
  }
}


function CONSTRUCTOR(){  
 GEBI('SLG_menu_h3').innerText="v."+FExtension.bg.ImTranslatorBG.Version();  
 GEBI('SLG_descr').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extAboutDescr')));  
 GEBI('SLG_contrib').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extContrib')));  
 GEBI('SLG_il').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLOC')));
 var Ab = "© ImTranslator";
 if(FExtension.store.get("SLG_LOCALIZATION")=="en") Ab = "About";
 GEBI('SLG_ttl').appendChild(document.createTextNode(Ab));
 GEBI('SLG_theme_ttl').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extTHEME')));
 GEBI('SLG_theme_1').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLIGHT')));
 GEBI('SLG_theme_2').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDARK')));
 GEBI('SLG_translate_container').style.opacity="1";
	switch(PLATFORM){
	 case "Opera" : GEBI('SLG_info').href="https://about.imtranslator.net/tutorials/presentations/google-translate-for-opera/"; break;
	 case "Chrome": GEBI('SLG_info').href="https://about.imtranslator.net/tutorials/presentations/imtranslator-for-chrome/"; break;
	 default      : GEBI('SLG_info').href="https://about.imtranslator.net/";break;
	}
 ACTIVATE_THEME(FExtension.store.get("THEMEmode"));
}

function SLG_SAVE_LOC(){
  FExtension.store.set("SLG_LOCALIZATION", GEBI("SLG_LOC").value);
  CONSTRUCTOR();
  FExtension.bg.ImTranslatorBG.SLG_WorkingSet();
  parent.frames["menu"].location.reload();
  location.reload();
}



function SLG_SAVE_THEME(){
  FExtension.store.set("THEMEmode", GEBI("SLG_THEME").value);
  FExtension.bg.ImTranslatorBG.SLG_WorkingSet();
  location.reload();
}

function ACTIVATE_THEME(st){
 	if(st==1){
		var clr="#BF7D44";
		GEBI("SLG_translate_container").style.filter=SLG_DARK;
		GEBI("SLG_ttl2").style.filter=SLG_DARK;
		var LBLS = document.getElementsByClassName("SLG_BG_op");
		for(var i=0; i<LBLS.length; i++) LBLS[i].style.color=clr;
		var A = document.getElementsByTagName("a");
		for(var i=0; i<A.length; i++) A[i].style.color=clr;
		var IMG = document.getElementsByTagName("img");
		for(var i=0; i<IMG.length; i++) IMG[i].style.filter=SLG_DARK;
	}
}