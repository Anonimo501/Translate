var SLG_DARK="invert(95%)";

(function(){GEBI("SLG_LOC").addEventListener("change",function(){SLG_SAVE_LOC();},!1);} )();
window.addEventListener("load",function(){ 
 ACTIVATE_MENU_ELEMENT(7);
 GEBI("SLG_LOC").value=FExtension.store.get("SLG_LOCALIZATION");
 CONSTRUCTOR();
},!1);
(function(){GEBI("SLG_info").addEventListener("click",function(){FExtension.browserPopup.openNewTab('https://about.imtranslator.net/tutorials/presentations/google-translate-for-opera/');},!1);} )();
(function(){GEBI("SLG_THEME").addEventListener("change",function(){SLG_SAVE_THEME();},!1);} )();

function GEBI(id){ return document.getElementById(id);}

function CONSTRUCTOR(){
 GEBI('SLG_translate_container').style.opacity="1";
 var v = FExtension.bg.ImTranslatorBG.Version();
 var ln = FExtension.store.get("SLG_LOCALIZATION");
 if(ln == "bg" || ln == "sk" || ln == "tl" || ln=="vi" || ln=="sr") ln="en";
 GEBI('SLG_mailer').src = GEBI('SLG_mailer').src + ln;
 GEBI('SLG_mailer').src = GEBI('SLG_mailer').src.replace("v=","v="+ v);
 GEBI('SLG_ttl').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extFeedback')));
 GEBI('SLG_FBK1').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extFBK1')));
 GEBI('SLG_FBK2').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extFBK2')));
 GEBI('SLG_il').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLOC')));
 GEBI('SLG_theme_ttl').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extTHEME')));
 GEBI('SLG_theme_1').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extLIGHT')));
 GEBI('SLG_theme_2').appendChild(document.createTextNode(FExtension.element(FExtension.store.get("SLG_LOCALIZATION"),'extDARK')));

 var SLG_THEMEmode = FExtension.store.get("THEMEmode");
 if(SLG_THEMEmode==0)  GEBI("SLG_THEME").value = 0;
 else GEBI("SLG_THEME").value = 1;
 ACTIVATE_THEME(FExtension.store.get("THEMEmode"));
}

function ACTIVATE_MENU_ELEMENT(st){
  var win = top.frames['menu'];
  var li = win.document.getElementsByTagName("li");
  for(var i=1; i<=li.length; i++){
        if(st==i) win.document.getElementById('SLG_options_menu'+i).className='SLG_options-menu-on';
        else win.document.getElementById('SLG_options_menu'+i).className='SLG_options-menu-off';
  }
}

function SLG_SAVE_LOC(){
  FExtension.store.set("SLG_LOCALIZATION", GEBI("SLG_LOC").value);
  CONSTRUCTOR();
  parent.frames["menu"].location.reload();
  FExtension.bg.ImTranslatorBG.SLG_WorkingSet();
  location.reload();
}

function SLG_SAVE_THEME(){
  FExtension.store.set("THEMEmode", GEBI("SLG_THEME").value);
  FExtension.bg.ImTranslatorBG.SLG_WorkingSet();
  location.reload();
}

function ACTIVATE_THEME(st){
 	if(st==1){
		var clr="#BF7D44";
		GEBI("SLG_translate_container").style.filter=SLG_DARK;
		GEBI("SLG_mailer").style.filter=SLG_DARK;
		GEBI("SLG_mailer").style.background="#fff";
		var A = document.getElementsByTagName("a");
		for(var i=0; i<A.length; i++) A[i].style.color=clr;  
	}
}
