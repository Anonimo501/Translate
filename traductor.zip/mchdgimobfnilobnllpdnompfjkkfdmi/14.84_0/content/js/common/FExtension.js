//var PLATFORM = "Chrome";
//var EXPORT_EXT = " SL";
//var GLOB_PREF = "SL";
//var GLOB_CNTR = 2;


//var PLATFORM = "Opera";
//var EXPORT_EXT = " SLO";
//var GLOB_PREF = "SLO";
//var GLOB_CNTR = 3;



//for GT only
var PLATFORM = "Opera";
var EXPORT_EXT = " GT";
var GLOB_PREF = "SLG";
var GLOB_CNTR = 4;


var SLG_GEO = new Array ("com","es","de","it","fr","rs","pn","ps","sn","so");
var DET = 0;
// 0 - G
// 1 - SL
var _TP = "op-GT"

var _FOLDER = "extensions";
var _CGI = "/"+_FOLDER+"/?tp="+_TP;

var reservedHK = "_HK_bb1,_HK_bb2,_HK_btn,_HK_gt1,_HK_gt2,_HK_it1,_HK_it2,_HK_opt,_HK_wpt1,_HK_wpt2,_change_lang_HK_it,_HK_SO_wpt,_HK_CT_wpt";
var SLG_TTS = "en,es,ru,de,pt,fr,it,ko,ja,zh-CN,zh-TW,en-gb,fr-CA,lzh,yue,pt-PT";             
var G_TTS = "ar,cs,da,nl,fi,el,hi,hu,no,pl,sk,sv,th,tr,la,bn,id,km,uk,vi";
    G_TTS = G_TTS+","+SLG_TTS;

var LISTofPRpairsDefault=",af,ak,am,ar,as,ay,az,ba,be,bg,bho,bm,bn,bo,bs,ca,ceb,ckb,co,cs,cv,cy,da,de,doi,dsb,dv,ee,el,emj,en,en-gb,eo,es,et,eu,fa,fi,fj,fo,fr,fr-CA,fy,ga,gd,gl,gn,gom,gu,ha,haw,hi,hmn,hr,hsb,ht,hu,hy,id,ig,ikt,ilo,is,it,iu,iu-Latn,iw,ja,jw,ka,kazlat,kk,km,kn,ko,kri,ku,ky,la,lb,lg,ln,lo,lt,lug,lus,lv,lzh,mai,mg,mhr,mi,mk,ml,mn,mni-Mtei,mn-Mong,mr,mrj,ms,mt,my,ne,nl,no,nso,ny,nya,om,or,otq,pa,pap,pl,prs,ps,pt,pt-PT,qu,ro,ru,run,rw,sa,sah,sd,si,sk,sl,sm,sn,so,sq,sr,sr-Latn,srsl,st,su,sv,sw,ta,te,tg,th,ti,tk,tl,tlh-Latn,tlsl,tn,to,tr,ts,tt,ty,udm,ug,uk,ur,uz,uzbcyr,vi,xh,yi,yo,yua,yue,zh-CN,zh-TW,zu";
var LISTofPR = new Array ("Google","Microsoft","Translator","Yandex");
var LISTofLANGsets = new Array (",af,ak,am,ar,as,ay,az,be,bg,bho,bm,bn,bs,ca,ceb,ckb,co,cs,cy,da,de,doi,dv,ee,el,en,eo,es,et,eu,fa,fi,fr,fy,ga,gd,gl,gn,gom,gu,ha,haw,hi,hmn,hr,ht,hu,hy,id,ig,ilo,is,it,iw,ja,jw,ka,kk,km,kn,ko,kri,ku,ky,la,lb,lg,ln,lo,lt,lus,lv,mai,mg,mi,mk,ml,mn,mni-Mtei,mr,ms,mt,my,ne,nl,no,nso,ny,om,or,pa,pl,ps,pt,qu,ro,ru,rw,sa,sd,si,sk,sl,sm,sn,so,sq,sr,srsl,st,su,sv,sw,ta,te,tg,th,ti,tk,tl,tlsl,tr,ts,tt,ug,uk,ur,uz,vi,xh,yi,yo,zh-CN,zh-TW,zu",",af,am,ar,as,az,ba,bg,bn,bo,bs,ca,ckb,cs,cy,da,de,dsb,dv,el,en,en-gb,es,et,eu,fa,fi,fj,fo,fr,fr-CA,ga,gl,gom,gu,ha,hi,hmn,hr,hsb,ht,hu,hy,id,ig,ikt,is,it,iu,iu-Latn,iw,ja,ka,kk,km,kn,ko,ku,ky,ln,lo,lt,lug,lv,lzh,mai,mg,mi,mk,ml,mn,mn-Mong,mr,ms,mt,my,ne,nl,no,nso,nya,or,otq,pa,pl,prs,ps,pt,pt-PT,ro,ru,run,rw,sd,si,sk,sl,sm,sn,so,sq,sr,sr-Latn,srsl,st,sv,sw,ta,te,th,ti,tk,tl,tlh-Latn,tlsl,tn,to,tr,tt,ty,ug,uk,ur,uz,vi,xh,yo,yua,yue,zh-CN,zh-TW,zu","en/fr,en/de,en/pt,en/ru,en/es,fr/en,fr/ru,fr/es,de/en,de/ru,pt/en,ru/en,ru/fr,ru/de,ru/es,es/en,es/fr,es/ru",",af,am,ar,az,ba,be,bg,bn,bs,ca,ceb,cs,cv,cy,da,de,el,emj,en,eo,es,et,eu,fa,fi,fr,ga,gd,gl,gu,hi,hr,ht,hu,hy,id,is,it,iw,ja,jv,ka,kazlat,kk,km,kn,ko,ky,la,lb,lo,lt,lv,mg,mhr,mi,mk,ml,mn,mr,mrj,ms,mt,my,ne,nl,no,pa,pap,pl,pt,ro,ru,sah,si,sk,sl,sq,sr,sr-Latn,srsl,su,sv,sw,ta,te,tg,th,tl,tlsl,tr,tt,udm,uk,ur,uz,uzbcyr,vi,xh,yi,zh-CN,zu");

                                  
var LISTofPRpairs = new Array ();

var PACK_PARAMS = new Array();

for (var SLG_I = 0 ; SLG_I < LISTofPR.length; SLG_I++){
    switch(LISTofPR[SLG_I]){
	case "Google": LISTofPRpairs[SLG_I]=LISTofLANGsets[0];break;
	case "Microsoft": LISTofPRpairs[SLG_I]=LISTofLANGsets[1];break;
	case "Translator": LISTofPRpairs[SLG_I]=LISTofLANGsets[2];break;
	case "Yandex": LISTofPRpairs[SLG_I]=LISTofLANGsets[3];break;
    }	
}

var DO_NOT_TRUST_WORD = "be,bg,mk,sr,kk,mn,tg";
var DO_NOT_TRUST_TEXT = "zh";

var ImTranslator_theurl = "https://imtranslator.net/";

var FExtension = {
	config: {
		debugIsEnabled: true
	},

	extend: function(parentPrototype, child) {
		function CloneInternal(){};
		CloneInternal.prototype = parentPrototype;
		child.prototype.constructor = child;
		return new CloneInternal();
	},

	AddHtmlToObj: function(obj,tag,htm){
	      var container = GEBI(obj);
		while (container.firstChild) {
		  container.removeChild(container.firstChild);
		}
	      var eUL = document.createElement(tag);
	      var st = document.createAttribute("src");
	      st.value = htm;
	      eUL.setAttributeNode(st);
      	container.appendChild(eUL); 
	},

	element: function(loc,msg){
                return SLG_SETCHROMELOC(msg,loc);
	}

       		
};

FExtension.alert_debug = function(msg) {
//	if (FExtension.config.debugIsEnabled)
//		window.alert(msg);
};


function SLG_SETCHROMELOC(name,CLloc){

    if(chrome.i18n.getUILanguage()){
	 var BRloc=chrome.i18n.getUILanguage();
	 name=name.replace("ext","_");
	 if(BRloc==CLloc){
	  var BRloc=BRloc.substr(0,2);
	  return chrome.i18n.getMessage(BRloc+name);
	 } else { 
		return chrome.i18n.getMessage(CLloc+name);
	 }	
    }
}


function SLG_isLinux() {
        var OSName = false;
	if (navigator.appVersion.indexOf("X11")!=-1) OSName=true;
	if (navigator.appVersion.indexOf("Linux")!=-1) OSName=true;
	return OSName;
}

EXTENSION_DEFAULTS();

function EXTENSION_DEFAULTS(){
	try{
	    var SLG_PR_ALL = "Google,Microsoft,Translator,Yandex";
	    var SLG_PR_KEYS = "Google:1,Microsoft:0,Translator:0,Yandex:0";
	    var SLG_PR_IT = "Google,Microsoft,Yandex";



	        var BRlanguage = "en";
		var BRloc=chrome.i18n.getUILanguage().substr(0,2);
		if(BRloc!=""){
		   var Arr = LISTofPRpairsDefault.split(",")
		   for(var I=0; I<Arr.length; I++){
	        	var lng = Arr[I].replace("zh-TW","zh");
		        lng = lng.replace("zh-CN","zh");
		   	if(BRloc==lng){
			  BRlanguage=lng;
			  break;
			}
		   }
		}



            var SLG_BR_LN=BRlanguage;
            var manifestData = chrome.app.getDetails();
	    PACK_PARAMS[0] = "SLG_session;0";
            if(manifestData.version) PACK_PARAMS[1] = "SLG_Version;"+ manifestData.version;
	    //ADV
	    PACK_PARAMS[2] = "ADV;0";
	    PACK_PARAMS[3] = "FRUN;0";
            PACK_PARAMS[4] = "ran_before;0";
 	    //------------------------------- History ------------------------------------
	    PACK_PARAMS[5] = "SLG_History;";
	    PACK_PARAMS[6] = "SLG_TH_1;0";
	    PACK_PARAMS[7] = "SLG_TH_2;0";
	    PACK_PARAMS[8] = "SLG_TH_3;0";
	    PACK_PARAMS[9] = "SLG_TH_4;0";
            //------------------------------- option gt ----------------------------------
	    PACK_PARAMS[10] = "SLG_global_lng;true";
	    PACK_PARAMS[11] = "SLG_Fontsize;17px";
	    PACK_PARAMS[12] = "SLG_langSrc;auto";
	    PACK_PARAMS[13] = "SLG_langDst;"+ SLG_BR_LN;
	    PACK_PARAMS[14] = "SLG_no_detect;true";
	    PACK_PARAMS[15] = "SLG_other_gt;0";
	    PACK_PARAMS[16] = "SLG_dict;true";
	    PACK_PARAMS[17] = "SLG_show_back;false";
	    PACK_PARAMS[18] = "SLG_show_back2;false";
	    PACK_PARAMS[19] = "SLG_HKset;3|90|true";
	    PACK_PARAMS[20] = "SLG_HKset_inv;3|90|true";
	    PACK_PARAMS[21] = "SLG_langDst_name;Spanish";
	    //??
	    PACK_PARAMS[22] = "SLG_Flag;FALSE";
            //------------------------------- option bbl ---------------------------------
	    PACK_PARAMS[23] = "SLG_ENABLE;true";
	    PACK_PARAMS[24] = "SLG_show_button_bbl;true";
	    PACK_PARAMS[25] = "SLG_global_lng_bbl;true";
	    PACK_PARAMS[26] = "SLG_Fontsize_bbl;14px";
	    PACK_PARAMS[27] = "SLG_langSrc_bbl;auto";
	    PACK_PARAMS[28] = "SLG_langDst_bbl;"+ SLG_BR_LN;
	    PACK_PARAMS[29] = "SLG_no_detect_bbl;true";
	    PACK_PARAMS[30] = "SLG_other_bbl;0";
	    PACK_PARAMS[31] = "SLG_dict_bbl;true";
	    PACK_PARAMS[32] = "SLG_translation_mos_bbl;true";
	    PACK_PARAMS[33] = "SLG_pin_bbl;false";

	    PACK_PARAMS[34] = "SLG_langDst_name_bbl;Spanish";
	    PACK_PARAMS[35] = "SLG_DBL_bbl;false";
	    PACK_PARAMS[36] = "SLG_Timing;3";
	    PACK_PARAMS[37] = "SLG_Delay;0";

            //------------------------------- option it ----------------------------------
	    PACK_PARAMS[38] = "SLG_langSrc_it;auto";
	    PACK_PARAMS[39] = "SLG_langDst_it;"+ SLG_BR_LN;
	    PACK_PARAMS[40] = "SLG_global_lng_it;true";
	    PACK_PARAMS[41] = "SLG_style;239e23";
	    PACK_PARAMS[42] = "SLG_inject_brackets;true";
	    PACK_PARAMS[43] = "SLG_inject_before;false";
	    PACK_PARAMS[44] = "SLG_line_break;false";
	    PACK_PARAMS[45] = "SLG_whole_word;true";
	    PACK_PARAMS[46] = "SLG_hide_translation;false";
	    PACK_PARAMS[47] = "SLG_dictionary;true";
	    PACK_PARAMS[48] = "SLG_no_detect_it;true";
	    PACK_PARAMS[49] = "SLG_other_it;1";
	    PACK_PARAMS[50] = "SLG_langDst_name_it;Spanish";
	    PACK_PARAMS[51] = "SLG_FK_box1;true";
	    PACK_PARAMS[52] = "SLG_FK_box2;true";

            //------------------------------- option wpt ---------------------------------
	    PACK_PARAMS[53] = "SLG_global_lng_wpt;true";
	    PACK_PARAMS[54] = "SLG_langSrc_wpt;auto";
	    PACK_PARAMS[55] = "SLG_langDst_wpt;" + SLG_BR_LN;
	    PACK_PARAMS[56] = "SLG_other_wpt;1";
	    PACK_PARAMS[57] = "SLG_langDst_name_wpt;Spanish";

	    //-----------------------HK for All Translators-------------------------------
	    PACK_PARAMS[58] = "SLG_HK_gt1;Ctrl + Alt + V";
	    PACK_PARAMS[59] = "SLG_HK_gt2;Ctrl + Alt + Z";


	    if(SLG_isLinux()==true) PACK_PARAMS[60] = "SLG_HK_it1;Ctrl + Alt + C";
	    else PACK_PARAMS[60] = "SLG_HK_it1;Ctrl + Alt + C";

	    if(SLG_isLinux()==true) PACK_PARAMS[61] = "SLG_HK_it2;Ctrl + Alt + X";
	    else PACK_PARAMS[61] = "SLG_HK_it2;Ctrl + Alt + X";

	    if(SLG_isLinux()==true) PACK_PARAMS[62] = "SLG_HK_bb1;Ctrl + Alt";
	    else PACK_PARAMS[62] = "SLG_HK_bb1;Ctrl + Alt";

	    PACK_PARAMS[63] = "SLG_HK_bb2;Escape";
	    PACK_PARAMS[64] = "SLG_HK_bb2box;true";
	    PACK_PARAMS[65] = "SLG_HK_wptbox1;true";

	    if(SLG_isLinux()==true) PACK_PARAMS[66] = "SLG_HK_wpt1;Ctrl + Alt + P";
	    else PACK_PARAMS[66] = "SLG_HK_wpt1;Ctrl + Alt + P";

	    PACK_PARAMS[67] = "SLG_HK_wptbox2;true";

	    if(SLG_isLinux()==true) PACK_PARAMS[68] = "SLG_HK_wpt2;Ctrl + Alt + M";
	    else PACK_PARAMS[68] = "SLG_HK_wpt2;Ctrl + Alt + M";

	    PACK_PARAMS[69] = "SLG_HK_optbox;true";
	    PACK_PARAMS[70] = "SLG_HK_opt;Ctrl + Alt + O";
	    PACK_PARAMS[71] = "SLG_HK_btnbox;true";

	    if(SLG_isLinux()==true) PACK_PARAMS[72] = "SLG_HK_btn;Ctrl + Alt + A";
	    else PACK_PARAMS[72] = "SLG_HK_btn;Ctrl + Alt + A";

            //--------------------NEW PARAMS PROVIDERs---------------------------------------
	    PACK_PARAMS[73] = "SLG_pr_gt;1";
	    PACK_PARAMS[74] = "SLG_pr_bbl;1";

	    //??
	    PACK_PARAMS[75] = "SLG_Dtext;";

            //********************SET OF THE ADVANCES****************************
	    PACK_PARAMS[76] = "SLG_GVoices;1";
	    PACK_PARAMS[77] = "SLG_SLVoices;0";
            //********************SET OF THE ADVANCES****************************

	    PACK_PARAMS[78] = "SLG_SaveText_box_gt;1";
	    PACK_PARAMS[79] = "SLG_SavedText_gt;";
	    PACK_PARAMS[80] = "SLG_SaveText_box_bbl;0";
	    PACK_PARAMS[81] = "SLG_LNG_LIST;all";
	    PACK_PARAMS[82] = "SLG_BACK_VIEW;2";
	    PACK_PARAMS[83] = "SLG_BACK_VIEW;1";
	    PACK_PARAMS[84] = "SLG_PrefTrans;1";
	    PACK_PARAMS[85] = "SLG_CM1;1";
	    PACK_PARAMS[86] = "SLG_CM2;1";
	    PACK_PARAMS[87] = "SLG_CM3;1";
	    PACK_PARAMS[88] = "SLG_CM4;1";
	    PACK_PARAMS[89] = "SLG_CM5;1";
	    PACK_PARAMS[90] = "SLG_CM6;1";
	    PACK_PARAMS[91] = "SLG_CM7;1";
	    PACK_PARAMS[92] = "SLG_DOM;auto";
	    PACK_PARAMS[93] = "SLG_wptDHist;";
	    PACK_PARAMS[94] = "SLG_wptLHist;";
	    PACK_PARAMS[95] = "SLG_wptGlobAuto;0";
	    PACK_PARAMS[96] = "SLG_wptGlobTb;1";	
	    PACK_PARAMS[97] = "SLG_wptGlobTip;1";	
	    PACK_PARAMS[98] = "SLG_wptGlobLang;"+ SLG_BR_LN;

	    PACK_PARAMS[99] = "SLG_ALL_PROVIDERS_GT;"+ SLG_PR_ALL;
	    PACK_PARAMS[100] = "SLG_ALL_PROVIDERS_BBL;"+ SLG_PR_ALL;
	    PACK_PARAMS[101] = "SLG_DICT_PRESENT;"+ SLG_PR_KEYS;

	    PACK_PARAMS[102] = "SLG_ALL_PROVIDERS_IT;"+ SLG_PR_IT;
	    PACK_PARAMS[103] = "SLG_BTN_X;0";
	    PACK_PARAMS[104] = "SLG_BTN_Y;0";
	    PACK_PARAMS[105] = "SLG_BBL_X;0";
	    PACK_PARAMS[106] = "SLG_BBL_Y;0";

	    //FORSE BUBBLE
	    PACK_PARAMS[107] = "FORSEbubble;0";

	    //FORMER BBL CS
	    PACK_PARAMS[108] = "TTSvolume;10";
	    PACK_PARAMS[109] = "BL_D_PROV;Google";
	    PACK_PARAMS[110] = "BL_T_PROV;Google";

	    //INLINE FLIP
	    PACK_PARAMS[111] = "INLINEflip;0";

	    //THEME MODE
	    PACK_PARAMS[112] = "THEMEmode;0";

	    //FORMER PLANSHET DIC CS
	    PACK_PARAMS[113] = "PLD_TTSvolume;10";
	    PACK_PARAMS[114] = "PLD_DPROV;Google";
	    PACK_PARAMS[115] = "PLD_OLD_TS;0";
	    PACK_PARAMS[116] = "PLD_DIC_FIRSTRUN;dicdone";

	    //FORMER PLANSHET TRANSLATOR CS
	    PACK_PARAMS[117] = "PLT_TTSvolume;10";
	    PACK_PARAMS[118] = "PLT_PROV;Google";
	    PACK_PARAMS[119] = "PLT_OLD_TS_TR;0";
	    PACK_PARAMS[120] = "PLT_TR_FIRSTRUN;done";

	    //FORMER OPTIONS CS
	    PACK_PARAMS[121] = "SLG_anchor;0";
	    PACK_PARAMS[122] = "SLG_sort;0";

	    PACK_PARAMS[123] = "AVOIDAUTODETECT;0";
	    PACK_PARAMS[124] = "AVOIDAUTODETECT_LNG;en";

	    PACK_PARAMS[125] = "THE_URL;";
	    PACK_PARAMS[126] = "SLG_Import_Report;";
	    PACK_PARAMS[127] = "SLG_GWPTHist;";
	    PACK_PARAMS[128] = "SLG_BBL_TS;0";
	    PACK_PARAMS[129] = "SLG_langSrc2;0";
	    PACK_PARAMS[130] = "SLG_langDst2;0";

	    //BBL SESSION RESET 
	    PACK_PARAMS[131] = "SLG_langSrc_bbl2;auto";
	    PACK_PARAMS[132] = "SLG_langDst_bbl2;"+ SLG_BR_LN;
	    PACK_PARAMS[133] = "SLG_show_button_bbl2;true";
	    PACK_PARAMS[134] = "SLG_Fontsize_bbl2;14px";
	    PACK_PARAMS[135] = "SLG_bbl_loc_langs;false";

	    //IT CHANGE LANG  
	    PACK_PARAMS[136] = "SLG_change_lang_HKbox_it;true";
	    PACK_PARAMS[137] = "SLG_change_lang_HK_it;Ctrl + Alt + S";
	    PACK_PARAMS[138] = "SLG_langDst_it2;"+ SLG_BR_LN;
	    PACK_PARAMS[139] = "SLG_TS;"+ Date.now();

	    //-----------------------LOCALIZATION-------------------------------
	    PACK_PARAMS[140] = "SLG_LOCALIZATION;"+ SLG_BR_LN;

	    PACK_PARAMS[141] = "SLG_YKEY;0";
	    PACK_PARAMS[142] = "SLG_YHIST;";

	    PACK_PARAMS[143] = "MoveBBLX;0";
	    PACK_PARAMS[144] = "MoveBBLY;0";

	    PACK_PARAMS[145] = "SLG_HK_SObox_wpt;true";
	    PACK_PARAMS[146] = "SLG_HK_SO_wpt;Ctrl + Alt + W";

	    PACK_PARAMS[147] = "SLG_HK_CTbox_wpt;true";
	    PACK_PARAMS[148] = "SLG_HK_CT_wpt;Escape";
	    PACK_PARAMS[149] = "SLG_WPT_TEMP_LANG;"+ SLG_BR_LN;
	    PACK_PARAMS[150] = "SLG_FAV_START;10";
	    PACK_PARAMS[151] = "SLG_FAV_MAX;3";
	    PACK_PARAMS[152] = "SLG_FAV_LANGS_BBL;"+SLG_BR_LN;
	    PACK_PARAMS[153] = "SLG_FAV_LANGS_IT;"+SLG_BR_LN;
	    PACK_PARAMS[154] = "SLG_FAV_LANGS_WPT;"+SLG_BR_LN;
	    PACK_PARAMS[155] = "SLG_FAV_LANGS_IMT;"+SLG_BR_LN;
	    PACK_PARAMS[156] = "SLG_FAV_TRIGGER;0";
	    PACK_PARAMS[157] = "WPTflip;0";
	    PACK_PARAMS[158] = "SLG_GotIt;0";
	    PACK_PARAMS[159] = "SLG_UNTRUST;"+DO_NOT_TRUST_WORD+":"+DO_NOT_TRUST_TEXT;
	    PACK_PARAMS[160] = "WINDOW_TOP;"+(( screen.height - winHeight ) / 2);
	    PACK_PARAMS[161] = "WINDOW_LEFT;"+(( screen.width - winWidth ) / 2 );
	    PACK_PARAMS[162] = "WINDOW_WIDTH;480";
	    PACK_PARAMS[163] = "WINDOW_HEIGHT;650";



	} catch(ex){}
}